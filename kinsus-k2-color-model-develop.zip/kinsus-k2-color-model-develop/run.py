import os, json, shutil, filecmp
from datetime import datetime
from sklearn.cluster import KMeans
import cv2
import numpy as np
# import copy

def check_image_type(filename):
    temp = [".JPG", ".jpg", ".jpeg", ".JPEG", ".BMP", ".bmp", ".png", ".PNG"]
    if os.path.splitext(filename)[-1] in temp:
        return filename, False
    else:
        return "", True

def data_and_config_exist(datasetPath, newDataPath, filterDataPath, logFile):

    if os.path.exists(datasetPath):
        print("The datasetPath exist!")
    else:
        text = f"The datasetPath do not exist! "
        text += " "*(50 - len(text))
        print(f"[ ERROR] {text}\n", file=logFile)
        os._exit(0)

    if os.path.exists(newDataPath):
        print("The newDataPath exist!")
    else:
        text = f"The newDataPath do not exist! "
        text += " "*(50 - len(text))
        print(f"[ ERROR] {text}\n", file=logFile)
        os._exit(0)

    className = os.listdir(newDataPath)
    for cls in className:
        if not os.path.exists(os.path.join(filterDataPath, cls)):
            os.mkdir(os.path.join(filterDataPath, cls))

def read_config():

    with open('Config.json') as file:
        config = json.load(file)
    return config

def new_data_rename(newDataPath, datatime):
    # CP00_xxxxxx_230711.jpg
    # 前面類別
    # 後面資料匯入時間
    print("Renaming the data with datetime...\n")

    dataDir = os.listdir(newDataPath)
    for className in dataDir:
        if os.path.isdir(os.path.join(newDataPath, className)):
            nameList = os.listdir(os.path.join(newDataPath, className))
            for name in nameList:
                checkName, skip = check_image_type(name)
                if skip:
                    continue
                rename = f'{className}_{os.path.splitext(checkName)[0]}_{datatime}{os.path.splitext(checkName)[1]}'
                os.rename(os.path.join(newDataPath, className, checkName), os.path.join(newDataPath, className, rename))

def file_size_check(folderImgPath, filterDataPath, targetFileSize, logFile):
    print("Checking the file size...\n")
    dataDir = os.listdir(folderImgPath)
    for className in dataDir:
        if os.path.isdir(os.path.join(folderImgPath, className)):
            nameList = os.listdir(os.path.join(folderImgPath, className))
            for name in nameList:
                checkName, skip = check_image_type(name)
                if skip:
                    continue
                fileSize = os.path.getsize(os.path.join(folderImgPath, className, checkName)) / 1024
                for tsize in targetFileSize:
                    if fileSize < tsize[0] or fileSize > tsize[1]:
                        # print(checkName, f"file size {round(fileSize, 2)}kB is not acceptable", file=logFile)
                        text = f"file size {round(fileSize, 2)}kB is not acceptable "
                        text += " "*(50 - len(text))
                        # print(f'[FAILED] file size {round(fileSize, 2)}kB is not acceptable ', checkName, file=logFile)
                        print(f'[FAILED] {text:.50}', checkName, file=logFile)
                        shutil.move(os.path.join(folderImgPath, className, checkName), os.path.join(filterDataPath, className, checkName))

def image_size_check(folderImgPath, filterDataPath, targetImageSize, logFile):
    print("Checking the image size...\n")
    dataDir = os.listdir(folderImgPath)
    for className in dataDir:
        if os.path.isdir(os.path.join(folderImgPath, className)):
            nameList = os.listdir(os.path.join(folderImgPath, className))
            for name in nameList:
                checkName, skip = check_image_type(name)
                if skip:
                    continue
                size = cv2.imread(os.path.join(folderImgPath, className, checkName), 0).shape
                for tsize in targetImageSize:
                    if size[0] != tsize[0] and size[1] != tsize[1]:
                        # print(checkName, f"image size {size[0], size[1]} is not acceptable", file=logFile)
                        text = f"image size {size[0], size[1]}kB is not acceptable "
                        text += " "*(50 - len(text))
                        print(f'[FAILED] {text}', checkName, file=logFile)
                        shutil.move(os.path.join(folderImgPath, className, checkName), os.path.join(filterDataPath, className, checkName))
                        

def visualize_colors(cluster, centroids):
    # Get the number of different clusters, create histogram, and normalize
    labels = np.arange(0, len(np.unique(cluster.labels_)) + 1)
    (hist, _) = np.histogram(cluster.labels_, bins = labels)
    hist = hist.astype("float")
    hist /= hist.sum()

    # Create frequency rect and iterate through each cluster's color and percentage
    rect = np.zeros((50, 300, 3), dtype=np.uint8)
    colors = sorted([(percent, color) for (percent, color) in zip(hist, centroids)])
    start = 0
    color_list = []
    for (percent, color) in colors:
        # print(color, "{:0.2f}%".format(percent * 100))
        color_list.append(color)
        end = start + (percent * 300)
        cv2.rectangle(rect, (int(start), 0), (int(end), 50), \
                      color.astype("uint8").tolist(), -1)
        start = end
    return rect, color_list


def color_check(folderImgPath, filterDataPath, config, logFile):
    print("Checking the color...\n")
    dataDir = os.listdir(folderImgPath)
    for className in dataDir:
        if os.path.isdir(os.path.join(folderImgPath, className)):
            nameList = os.listdir(os.path.join(folderImgPath, className))
            for name in nameList:
                checkName, skip = check_image_type(name)
                if skip:
                    continue
                # print(checkName)
                image = cv2.imread(os.path.join(folderImgPath, className, checkName))
                # imageOG = image.copy()
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                reshape = image.reshape((image.shape[0] * image.shape[1], 3))
                cluster = KMeans(n_clusters=2).fit(reshape)
                visualize, colorList = visualize_colors(cluster, cluster.cluster_centers_)
                # print(colorList[1])
                visualize = cv2.cvtColor(visualize, cv2.COLOR_RGB2BGR)

                filter = False
                front = colorList[1]
                R, G, B = front[0], front[1], front[2]
                brightness = (R + G + B) / 3
                # print("brightnessValue :", brightness)
                RGAvgToB = ((R + G) / 2) - B
                # print("diffOfRGAvgToBValue :", RGAvgToB)
                RGDiff = R - G
                # print("diffOfRToGValue :", RGDiff)
                RBDiff = R - B
                # print("diffOfRToBValue :", RBDiff)
                GBDiff = G - B
                # print("diffOfGToBValue :", GBDiff)

                for tbright in config["brightnessValue"]:
                    if brightness < tbright[0] or brightness > tbright[1]:
                        shutil.move(os.path.join(folderImgPath, className, checkName), os.path.join(filterDataPath, className, checkName))
                        filter = True
                        # print(checkName, f"brightnessValue {round(brightness, 1)} not in [{tbright[0]}, {tbright[1]}] failed", file=logFile)
                        text = f"brightnessValue {round(brightness, 1)} not in [{tbright[0]}, {tbright[1]}] "
                        text += " "*(50 - len(text))
                        print(f'[FAILED] {text}', checkName, file=logFile)


                if filter:
                    continue

                for tRGAvgToB in config["diffOfRGAvgToBValue"]:
                    if RGAvgToB < tRGAvgToB[0] or RGAvgToB > tRGAvgToB[1]:
                        shutil.move(os.path.join(folderImgPath, className, checkName), os.path.join(filterDataPath, className, checkName))
                        filter = True
                        # print(checkName, f"diffOfRGAvgToBValue {round(RGAvgToB, 1)} not in [{tRGAvgToB[0]}, {tRGAvgToB[1]}] failed", file=logFile)
                        text = f"diffOfRGAvgToBValue {round(RGAvgToB, 1)} not in [{tRGAvgToB[0]}, {tRGAvgToB[1]}] "
                        text += " "*(50 - len(text))
                        print(f'[FAILED] {text}', checkName, file=logFile)

                if filter:
                    continue

                for tRGDiff in config["diffOfRToGValue"]:
                    if RGDiff < tRGDiff[0] or RGDiff > tRGDiff[1]:
                        shutil.move(os.path.join(folderImgPath, className, checkName), os.path.join(filterDataPath, className, checkName))
                        filter = True
                        # print(checkName, f"diffOfRToGValue {round(RGDiff, 1)} not in [{tRGDiff[0]}, {tRGDiff[1]}] failed", file=logFile)
                        text = f"diffOfRToGValue {round(RGDiff, 1)} not in [{tRGDiff[0]}, {tRGDiff[1]}] "
                        text += " "*(50 - len(text))
                        print(f'[FAILED] {text}', checkName, file=logFile)

                if filter:
                    continue

                for tRBDiff in config["diffOfRToBValue"]:
                    if RBDiff < tRBDiff[0] or RBDiff > tRBDiff[1]:
                        shutil.move(os.path.join(folderImgPath, className, checkName), os.path.join(filterDataPath, className, checkName))
                        filter = True
                        # print(checkName, f"diffOfRToBValue {round(RBDiff, 1)} not in [{tRBDiff[0]}, {tRBDiff[1]}] failed", file=logFile)
                        text = f"diffOfRToBValue {round(RBDiff, 1)} not in [{tRBDiff[0]}, {tRBDiff[1]}] "
                        text += " "*(50 - len(text))
                        print(f'[FAILED] {text}', checkName, file=logFile)

                if filter:
                    continue

                for tGBDiff in config["diffOfGToBValue"]:
                    if GBDiff < tGBDiff[0] or GBDiff > tGBDiff[1]:
                        shutil.move(os.path.join(folderImgPath, className, checkName), os.path.join(filterDataPath, className, checkName))
                        # print(checkName, f"diffOfGToBValue {round(GBDiff, 1)} not in [{tGBDiff[0]}, {tGBDiff[1]}] failed", file=logFile)
                        text = f"diffOfGToBValue {round(GBDiff, 1)} not in [{tGBDiff[0]}, {tGBDiff[1]}] "
                        text += " "*(50 - len(text))
                        print(f'[FAILED] {text}', checkName, file=logFile)

                # cv2.imshow('visualize', visualize)
                # cv2.imshow('og', imageOG)
                # cv2.waitKey()


def file_check(newDataPath, datasetPath, filterDataPath, logFile):
    print("Checking the repeat file...\n")
    # 新類內
    dataDir = os.listdir(newDataPath)
    for className in dataDir:
        if os.path.isdir(os.path.join(newDataPath, className)):
            nameList = os.listdir(os.path.join(newDataPath, className))
            total = len(nameList)
            num = 1
            while nameList:
                print(num, "/", total)
                j = len(nameList) - 2
                counter = 0

                while j >= 0:
                    checkName, skip1 = check_image_type(nameList[-1])
                    if skip1:
                        break
                    checkCompare, skip2 = check_image_type(nameList[j])
                    if skip2:
                        break
                    if filecmp.cmp(os.path.join(newDataPath, className, checkName), os.path.join(newDataPath, className, checkCompare), False):
                        # print(checkName, f'is the same as {checkCompare} in the same classes', file=logFile)
                        text = f"The same is in newDataPath of classes "
                        text += " "*(50 - len(text))
                        print(f'[FAILED] {text}', checkName, file=logFile)
                        shutil.move(os.path.join(newDataPath, className, checkName), os.path.join(filterDataPath, className, checkName))
                        break
                    j -= 1
                    counter += 1
                nameList.pop()
                num += 1
    
    # 新跨類
    dataDir = os.listdir(newDataPath)
    for className in dataDir:
        for otherClass in dataDir:
            if className != otherClass:
                if not os.path.isdir(os.path.join(newDataPath, className)):
                    continue
                if not os.path.isdir(os.path.join(newDataPath, otherClass)):
                    continue

                nameList = os.listdir(os.path.join(newDataPath, className))
                otherClassNameList = os.listdir(os.path.join(newDataPath, otherClass))
                moveList = []

                for i in nameList:
                    for j in otherClassNameList:
                        checkName, skip1 = check_image_type(i)
                        if skip1:
                            continue
                        checkCompare, skip2 = check_image_type(j)
                        if skip2:
                            continue
                        if filecmp.cmp(os.path.join(newDataPath, className, checkName), os.path.join(newDataPath, otherClass, checkCompare), False):
                            if not [os.path.join(newDataPath, className, checkName), os.path.join(filterDataPath, className, checkName)] in moveList:
                                moveList.append([os.path.join(newDataPath, className, checkName), os.path.join(filterDataPath, className, checkName)])
                            if not [os.path.join(newDataPath, otherClass, checkCompare), os.path.join(filterDataPath, otherClass, checkCompare)] in moveList:
                                moveList.append([os.path.join(newDataPath, otherClass, checkCompare), os.path.join(filterDataPath, otherClass, checkCompare)])
                            # print(checkName, f'is the same as {checkCompare} in the different classes', file=logFile)
                            text = f"The same is in newDataPath of different classes "
                            text += " "*(50 - len(text))
                            print(f'[FAILED] {text}', checkName, file=logFile)

                for move in moveList:
                    shutil.move(move[0], move[1])


    # 新比舊類內
    dataDir = os.listdir(newDataPath)
    for className in dataDir:
        for sameClass in dataDir:
            if className == sameClass:
                if not os.path.isdir(os.path.join(newDataPath, className)):
                    continue
                if not os.path.isdir(os.path.join(datasetPath, sameClass)):
                    continue

                nameList = os.listdir(os.path.join(newDataPath, className))
                sameClassNameList = os.listdir(os.path.join(datasetPath, sameClass))
                moveList = []

                for i in nameList:
                    for j in sameClassNameList:
                        checkName, skip1 = check_image_type(i)
                        if skip1:
                            continue
                        checkCompare, skip2 = check_image_type(j)
                        if skip2:
                            continue
                        if filecmp.cmp(os.path.join(newDataPath, className, checkName), os.path.join(datasetPath, sameClass, checkCompare), False):
                            if not [os.path.join(newDataPath, className, checkName), os.path.join(filterDataPath, className, checkName)] in moveList:
                                moveList.append([os.path.join(newDataPath, className, checkName), os.path.join(filterDataPath, className, checkName)])
                            # print(checkName, f'is the same as {checkCompare} in the same classes and different dataset', file=logFile)
                            text = f"The same classes is different dataset "
                            text += " "*(50 - len(text))
                            print(f'[FAILED] {text}', checkName, file=logFile)

                for move in moveList:
                    shutil.move(move[0], move[1])

    # 新比舊類跨
    dataDir = os.listdir(newDataPath)
    for className in dataDir:
        for otherClass in dataDir:
            if className != otherClass:
                if not os.path.isdir(os.path.join(newDataPath, className)):
                    continue
                if not os.path.isdir(os.path.join(datasetPath, otherClass)):
                    continue

                nameList = os.listdir(os.path.join(newDataPath, className))
                otherClassNameList = os.listdir(os.path.join(datasetPath, otherClass))
                moveList = []

                for i in nameList:
                    for j in otherClassNameList:
                        checkName, skip1 = check_image_type(i)
                        if skip1:
                            continue
                        checkCompare, skip2 = check_image_type(j)
                        if skip2:
                            continue
                        if filecmp.cmp(os.path.join(newDataPath, className, checkName), os.path.join(datasetPath, otherClass, checkCompare), False):
                            if not [os.path.join(newDataPath, className, checkName), os.path.join(filterDataPath, className, checkName)] in moveList:
                                moveList.append([os.path.join(newDataPath, className, checkName), os.path.join(filterDataPath, className, checkName)])
                            if not [os.path.join(datasetPath, otherClass, checkCompare), os.path.join(filterDataPath, otherClass, checkCompare)] in moveList:
                                moveList.append([os.path.join(datasetPath, otherClass, checkCompare), os.path.join(filterDataPath, otherClass, checkCompare)])
                            # print(checkName, f'is the same as {checkCompare} in the different classes and different dataset', file=logFile)
                            text = f"The same is different classes and dataset "
                            text += " "*(50 - len(text))
                            print(f'[FAILED] {text}', checkName, file=logFile)

                for move in moveList:
                    shutil.move(move[0], move[1])



if __name__ == '__main__':

    logFile = open(f'log_{datetime.now().strftime("%Y%m%d%H%M%S")}.txt', 'a')
    
    try:
        config = read_config()
        data_and_config_exist(config["datasetPath"], config["newDataPath"], config["filterDataPath"], logFile)
        new_data_rename(config["newDataPath"], config["dataImportTime"])
        file_size_check(config["newDataPath"], config["filterDataPath"], config["fileSize"], logFile)
        image_size_check(config["newDataPath"], config["filterDataPath"], config["imageSize"], logFile)
        color_check(config["newDataPath"], config["filterDataPath"], config, logFile)
        file_check(config["newDataPath"], config["datasetPath"], config["filterDataPath"], logFile)
    except Exception as e:
        print(str(e), file=logFile)
    
    logFile.close()