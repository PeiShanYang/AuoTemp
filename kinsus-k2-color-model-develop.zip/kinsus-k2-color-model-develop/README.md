# Kinsus K2 Data Clean Module

## 功能
1. 檔案大小檢查
2. 影像尺寸檢查
3. 重複影像檢查
4. 影像色調檢查
