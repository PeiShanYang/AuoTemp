import json

def load_json_config():
    try:
        with open('.//main//ConfigDet.json') as configFile:
        # with open('.//main//ConfigCls.json') as configFile:
            configDict = json.load(configFile)
    except:
        raise BaseException('json file not found. Please check if the file name is "Config.json".')

    return configDict

if __name__ == '__main__':
    load_json_config()