# -*- coding: utf-8 -*-

# 
# from main.MainCls import main
from main.MainDet import main


if __name__ == "__main__":
    main()
