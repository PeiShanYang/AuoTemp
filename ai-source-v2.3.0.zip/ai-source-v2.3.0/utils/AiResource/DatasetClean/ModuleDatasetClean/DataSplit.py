# -*- coding: utf-8 -*-

import math
import os
import pathlib
from shutil import copyfile
from sklearn.model_selection import train_test_split
from utils.AiResource.DatasetClean.ModuleDatasetClean.BasicFileProcess import *
from .AnnotationTransfer import AnnotationTransfer

class DataSplitMethods():
    def __init__(self, taskType:int, inputPath:str, outputPath:str, percentage:list):
        """
        Split th dataset into train, test and valid.

        Args:
            taskType: (int) 0 is classification and 1 is detection
            inputPath: (str) input path
            outputPath: (str) output path
            percentage: (list) [trainPer(float), validPer(float), testPer(float)] data percentage of train, valid and test
        """
        
        self.taskType = taskType
        self.imagePath = os.path.join(inputPath, "Image") if taskType == 1 else inputPath
        self.labelPath = os.path.join(inputPath, "Annotation") 
        self.outputPath = outputPath
        self.percentage = percentage
        self.tempPath = None
        self.classNameList = [i for i in os.listdir(inputPath) if os.path.isdir(os.path.join(inputPath, i))] if taskType == 0 else None
        self.targetNum = 10
        self.cloneFileList = []

    @staticmethod
    def image_file_to_label_file(imageName:str) -> str:
        """
        image(path) name convert to label(path) name
        
        Args:
            imageName: (str) image(path) name

        Return:
            labelName: (str) label(path) name
        """
        imageFileName = pathlib.Path(imageName)
        labelName = imageName.replace(imageFileName.suffix, '.txt')
        return labelName

    @staticmethod
    def get_split_list(percentage:list, imagesList:list) -> list:
        """
        Split image list names into lists of train、vaild、test names
        
        Args:
            percentage: (list) [trainPer(float), validPer(float), testPer(float)] data percentage of train, valid and test
            imagesList: (list) [imageName(str), ....] List of image names

        Return:
            imageSplitList: (2d list) [[imageNames(str), ...], [], []]: Split image list names into lists of train、vaild、test
        """
        trainImages, validNTestImages = train_test_split(imagesList, test_size=sum(percentage[1:3]), random_state=233)
        validImages, testImages = train_test_split(validNTestImages, test_size=percentage[2]/sum(percentage[1:3]), random_state=233)
        imageSplitList = [trainImages, validImages, testImages]      
        return imageSplitList

    def get_images_with_Label_List(self, imagesList:list) -> list:
        """
        Base on imagesList, check if both labels and images files are exist, and return image file name list 

        Args:
            imagesList: (list) [imageName(str), ...] List of image names

        Return:
            imagesList: (list) [imageName(str), ...]: List of image names (Both labels and images are exist)
        """

        imgType =  ('JPG', 'BMP', 'EPS', 'GIF', 'JPEG', 'PNG', 'TIFF')
        labelList = get_specific_files_list(self.labelPath, '.txt')
        imageListTemp = []
        for imageName in imagesList:
            labelName = self.image_file_to_label_file(imageName)
            if imageName.upper().endswith(imgType) and labelName in labelList:
                imageListTemp.append(imageName)
        imagesList = imageListTemp
        return imagesList


    def label_classification(self, imagesPath:str, labelPath:str, classNameDict:dict, tempPath:str) -> None:
        """
        Using annotation to get images into label folders

        Args:
            imagesPath: (str) image folder path
            labelPath: (str) annotation folder path 
            classNameDict: (dict) {classNum(int): className(str), ...}
                           classNum is class corresponding number and className is class name
            tempPath: (str) created temporary folder path
        """

        imagesList = get_specific_files_list(imagesPath, "image")
        for className in classNameDict.values():
            create_empty_folder(os.path.join(tempPath, className))

        imagesClassDict = dict(zip(classNameDict.values(), [list() for _ in range(len(classNameDict.items()))]))  #create dict = {classname:[]}
        imagesList = self.get_images_with_Label_List(imagesList)
        
        for imageName in imagesList:
            f = open(os.path.join(labelPath, self.image_file_to_label_file(imageName)), 'r')
            txt = f.readline()
            f.close()
            if txt =="":
                print(f' - {self.image_file_to_label_file(imageName)} is empty')
            elif int(txt[0]) in classNameDict.keys():
                imagesClassDict[classNameDict[int(txt[0])]].append(imageName)
            elif int(txt[0]) not in classNameDict.keys():
                print(f' - label {txt[0]} is not in className:{classNameDict}')                
    
        for className in classNameDict.values():
            copy_files_in_list(imagesClassDict[className], imagesPath, os.path.join(tempPath, className))

    def duplicate_file(self, imagePath:str, imagesList:list, className:str=None, targetNum:int=10) -> list:
        """
        If the amount of data in the folder is not enough to the targetNum, copy until the targetNum is met

        Args:
            imagePath: (str) image path 
            imagesList: (list) [imageName(str), ...] List of image names
            className: (str, None): class folder names (for classification). Defaults to None.
            targetNum: (int): At lest requrie amount of data. Defaults to 10 

        Return:
            [imagePath(str), ....]: (list) after duplicated, path of image list names
        """
        
        if len(imagesList) == 0:
            if className != None:
                raise BaseException(f"(State error) Please delete the empty folder {className}")
            else:
                raise BaseException(f"(State error) Please delete the empty folder or check DATA_STATE[state].")
        else:
            ### Copy image
            copyIter = int(targetNum - len(imagesList))
            i = 0
            while (i<copyIter):
                for imageName in imagesList:
                    imageFilePath = os.path.join(imagePath, imageName)
                    copyfile(imageFilePath, os.path.join(imagePath, f'clone{i}_{imageName}'))
                    self.cloneFileList.append(os.path.join(imagePath, f'clone{i}_{imageName}'))  # keep clone file path
                    
                    if self.taskType == 1:
                        labelName = self.image_file_to_label_file(imageName)
                        copyfile(os.path.join(self.labelPath, labelName), os.path.join(self.labelPath, f'clone{i}_{labelName}'))
                        self.cloneFileList.append(os.path.join(self.labelPath, f'clone{i}_{labelName}'))
                    i+=1
                    if i >= copyIter: break
                
            return get_specific_files_list(imagePath, 'image')

    def split_dataset(self, imagePath:str, className:str=None) -> list:
        """
        Split a list of train, valid, and test dataset names according to the given data path and ratio

        Args:
            imagePath: (str) image path 
            className: (str) class folder names (for classification)

        Return:
            imageSplitList: (2d list) [[imageNames(str), ...], [], []]: Split image list names into lists of train、vaild、test
        """
        if math.fsum(self.percentage) != 1.0:  
            raise BaseException(f"(Config error) The sum of percentage:{self.percentage} must be 1")
        
        imagesList = get_specific_files_list(imagePath, 'image')
        if self.taskType == 1: 
            imagesList = self.get_images_with_Label_List(imagesList)

        if len(imagesList) < self.targetNum:
            imagesList = self.duplicate_file(imagePath=imagePath, imagesList=imagesList, className=className, targetNum=self.targetNum)
            if className != None:
                print(f"  - The data amount in {className} are less than 10. Duplicate the images to avoid some dataset has no data.")
            else:
                print(f"  - The data amount are less than 10. Duplicate the images to avoid some dataset has no data.")
                imagesList = self.get_images_with_Label_List(imagesList)

        return self.get_split_list(self.percentage, imagesList) 


class SplitMethodsSelection(DataSplitMethods):
    def __init__(self,
        taskType: int, 
        inputPath: str, 
        outputPath: int, 
        percentage: list, 
        classNameDict: dict=None, 
        trainPath: str=None,
        validPath: str=None,
        testPath: str=None,
        **kwargs
        ) -> None:
        """
        Running for spliting the dataset into train, test and valid.
        
        Args:
            taskType      (int)       : classification or detection
            inputPath     (str)       : input path
            outputPath    (int)       : output path
            percentage    (list)      : [trainPer(float), validPer(float), testPer(float)] data percentage of train, valid and test
            classNameDict (dict, None): {classNumber(str): className(str), ....} the class name corresponding to the number. Defaults to None.
            trainPath     (str, None) : If trainPath is not none, move from outputPath/Trian to trainPath. Defaults to None.
            validPath     (str, None) : If validPath is not none, move from outputPath/Valid to validPath. Defaults to None.
            testPath      (str, None) : If testPath is not none, move from outputPath/Test to testPath. Defaults to None.
        
        """
        super().__init__(taskType, inputPath, outputPath, percentage)
        classNameDict = {int(key): value for key, value in classNameDict.items()}

        setList = ['Train', 'Valid', 'Test']
        folderNames = [None, None, None]
        for i, folderName in enumerate(setList):
            folderNames[i] = os.path.join(outputPath, folderName)

        for i in os.listdir(self.outputPath):
            if i in setList:
                raise BaseException(f'The output path has {i} folder, please confirm the output path do not have {setList} folders before splitting dataset')

        if len([i for i in os.listdir(inputPath) if i in setList]) == 3:
            # if input has been split into trian, vaild and test, copy folder to outpath
            if inputPath == outputPath:
                raise BaseException(f'The input and output path are the same, please confirm the config.')
            else:
                for i in os.listdir(inputPath): 
                    if i in setList:
                        copy_all_files(os.path.join(inputPath, i), self.outputPath)
                print(f'Data is already splited, from {inputPath} copy to {self.outputPath}')

        if taskType == 0:
            self.data_split_classification(inputPath, classNameDict, folderNames)

        elif taskType == 1:
            self.data_split_detection(classNameDict, folderNames)

        self.remove_clone()

        self.errorRecord = []
        if trainPath != None:
            self.outputPath_move_usingPath(os.path.join(outputPath, 'Train'), trainPath)
            print(f' - Train dataset path is {trainPath}')
        if validPath != None:
            self.outputPath_move_usingPath(os.path.join(outputPath, 'Valid'), validPath)
            print(f' - Valid dataset path is {validPath}')
        if testPath != None:
            self.outputPath_move_usingPath(os.path.join(outputPath, 'Test'), testPath)
            print(f' - Test dataset path is {testPath}')

        for error in self.errorRecord:
            print(error)
                
    def outputPath_move_usingPath(self, outputPath: str, usingPath: str)-> list:
        """
        Move the data under the outputPath to usingPath and record the error message

        Args:
            outputPath (str): output path
            usingPath  (str): where you want ot move the file to 
        """
        create_folder(usingPath)
        folderLsit = os.listdir(outputPath)
        errorList = []
        for folder in folderLsit:
            if os.path.exists(os.path.join(usingPath, folder)):
                errorList.append(f"{os.path.join(usingPath, folder)} is exists, please make sure you don't have an \'{folder}\' folder under your {usingPath} Path")
                self.errorRecord.append(f"{os.path.join(usingPath, folder)} is exists, please make sure you don't have an \'{folder}\' folder under your {usingPath} Path")
            else:
                shutil.move(os.path.join(outputPath, folder), os.path.join(usingPath, folder))
        
        if errorList == []:
            shutil.rmtree(outputPath)

    def data_split_classification(self, inputPath:str, classNameDict:dict, folderNames:list) -> None:
        """
        data split for classification

        Args:
            inputPath     (str)       :  input path
            classNameDict (dict, None):  {classNumber(str): className(str), ....} the class name corresponding to the number. Defaults to None.
            folderNames   (list)      :  [trainPath(str), validPath(str), testPath(str)] train, valid and test output folder path 
        """
        # Classification
        if os.path.exists(self.labelPath):
            self.imagePath = os.path.join(inputPath, "Image")
            self.tempPath = os.path.join(inputPath, "ImageTemp")
            self.label_classification(self.imagePath, self.labelPath, classNameDict, self.tempPath)
            self.imagePath = self.tempPath
            self.classNameList = os.listdir(self.imagePath)
            print(f" - have annotation and class name is {self.classNameList}")
        
        for className in self.classNameList:
            if not os.path.isdir(os.path.join(self.imagePath, className)):
                raise ValueError(f"The {self.imagePath} not only has class folder, but also has {self.classNameList} file")
            
            imagesList = self.split_dataset(imagePath=os.path.join(self.imagePath, className), className=className)
            for i, folderName in enumerate(folderNames):
                copy_files_in_list(imagesList[i], os.path.join(self.imagePath, className), os.path.join(folderName, className))
    
    def data_split_detection(self, classNameDict:dict, folderNames:list) -> None:
        """
        data split for detection

        Args:
            classNameDict (dict, None):  {classNumber(str): className(str), ....} the class name corresponding to the number. Defaults to None.
            imageShape    (list, None):  [width(int), height(int), channel(int)] image relative size. Defaults to None.
            folderNames   (list)      :  [trainPath(str), validPath(str), testPath(str)] train, valid and test output folder path 
        """

        if not os.path.exists(self.labelPath):
            raise BaseException(f'The annotation path: {self.labelPath} is not exists !!!!')
        if not os.path.exists(self.imagePath):
            raise BaseException(f'The image path: {self.imagePath} is not exists !!!!')
        
        LabelTransfer = AnnotationTransfer(self.labelPath, 
                                            os.path.join(self.labelPath, "../AnnotationTemp"), 
                                            classNameDict, 
                                            self.imagePath, 
                                            transToType="bbox_txt")
        
        if LabelTransfer.outputPath != self.labelPath:       
            self.tempPath = LabelTransfer.outputPath
            self.labelPath = self.tempPath
        
        imagesList = self.split_dataset(imagePath=self.imagePath)
        for i, folderName in enumerate(folderNames):
            copy_files_in_list(imagesList[i], self.imagePath, os.path.join(folderName, "Image"))
            labelsList = [self.image_file_to_label_file(imageName) for imageName in imagesList[i]]
            copy_files_in_list(labelsList, self.labelPath, os.path.join(folderName, "Annotation"))

    def remove_clone(self) -> None:
        """
        Delete cloned folders or files
        """

        if self.cloneFileList:  # remove clone file
            for cloneFile in self.cloneFileList:
                os.remove(cloneFile)

        if self.tempPath != None: # remove temporary folder
            shutil.rmtree(self.tempPath)
