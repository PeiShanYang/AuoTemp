# -*- coding: utf-8 -*-

"""
Created on Mon Jun 15 17:00:00 2022
"""
class PostProcessPara:
    def __init__(self) -> None:
        pass
    
class ClsPostProcessPara(PostProcessPara):
    def __init__(self, confidenceFilter: dict, unknownFilter: dict) -> None:
        """
        # confidenceFilter: if the confidence of 'clsName' is lower than 'thresholdValue', reduce the confidence to 0.
        confidenceFilter: {
            "order"     : (int) 0: disable, 1: enable
            "parameters": (dict) {
                "threshold": (dict) {clsName(str): thresholdValue(str), ...} give the class name and the corresponding threshold value
            }
        }
        # Filter out images with scores below the threshold
        unknownFilter: {
            "order"     : (int) 0: disable, 1: enable
            "parameters": (dict) {
                "threshold": (dict) {tagName(str): thresholdValue(str), ...} give the tag name and the corresponding threshold value
                "reverse"  : (int) 0: disable, 1: enable
            }
        }
        """
        self.confidenceFilter = confidenceFilter
        self.unknownFilter = unknownFilter

    @classmethod
    def create_from_dict(cls, postProcessPara: dict):
        """
        postProcessPara: {
            # confidenceFilter: if the confidence of 'clsName' is lower than 'thresholdValue', reduce the confidence to 0.
            "confidenceFilter": (dict) {
                "order"     : (int) 0: disable, 1: enable
                "parameters": (dict) {
                    "threshold": (dict) {clsName(str): thresholdValue(str), ...} give the class name and the corresponding threshold value
                }
            }

            # Filter out images with scores below the threshold
            "unknownFilter": (dict) {
                "order"     : (int) 0: disable, 1: enable
                "parameters": (dict) {
                    "threshold": (dict) {tagName(str): thresholdValue(str), ...} give the tag name and the corresponding threshold value
                    "reverse"  : (int) 0: disable, 1: enable
                }
            }
        }
        """
        return cls(**postProcessPara)