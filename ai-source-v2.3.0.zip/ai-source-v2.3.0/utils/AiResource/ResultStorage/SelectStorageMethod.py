import os

import torch
import torch.functional
import torch.nn as nn

from .ModuleResultStorage.Cls.SaveResult import ResultCsv, write_ini_file
from .ModuleResultStorage.Cls.SaveWeight import pack_onnx, save_model_optimizer, save_script_model, save_weight
from .ModuleResultStorage.Det.drawBox import draw_box
from .ModuleResultStorage.Det.SaveDetResult import DetResultSaver

from ..ModelService.PytorchDetectionModel.ConfigPytorchModel import ServicePara
from .ConfigResultStorage import ClsResultStoragePara, DetResultStoragePara


def cls_save_result(
    resultStoragePara: ClsResultStoragePara,
    resultList:list,
    classNameList:list,
    outputPath:str,
    task:str
) -> None:
    """
    output prediction for 3 types as csv file which include unknownFilter, normal prediction, and wrong file.

    Args:
        resultStoragePara: include all result storaged methods parameters
        resultList: output result of model or result after postprocess (if selected)
        [{
            'filename': 'BUMP_184_TOP_ok_70_31.bmp',
            'label': 'OK',
            'predict': 'OK',
            'confidence': 0.9999998807907104
            'output': {
                'NG': 8.45041796537771e-08,
                'OK': 0.9999998807907104
                }
        }, {...}
        ]
        classNameList: including all classes name
        outputPath: the output path of csv files
        task: 'Test' and 'Inference'
    """
    classNameList.sort()
    classNameList.sort(key=lambda x:x)
    for count, result in enumerate(resultList):
        if resultStoragePara.saveUnknownFile["switch"]:
            ResultCsv(result, count, task, outputPath, classNameList).write_unknown()
        if resultStoragePara.savePredictResult["switch"]:
            ResultCsv(result, count, task, outputPath, classNameList).write_result()

        if resultStoragePara.saveWrongFile["switch"] and task == 'Test':
            ResultCsv(result, count, task, outputPath, classNameList).write_wrong()

def cls_save_ini_file(resultStoragePara: ClsResultStoragePara, outputPath: str, className: list, unknownFilter: dict) -> None:
    """
    Save class name and postprocessing class name into ini file.

    Args:
        resultStoragePara: include all result storaged methods parameters
        outputPath: result output path
        className: list record all class name
        unknownFilter: {
            "switch": (int) 0: disable, 1: enable,
            "threshold": (dict) {"name" (str): threshold (float)},
            "reverse": (int) 0: disable, 1: enable
        }
    """
    if resultStoragePara.saveClassIniFile["switch"]:
        outputPath = os.path.join(outputPath, resultStoragePara.saveClassIniFile["fileName"])
        classNameDict, postList = {}, {}
        className.sort()
        className.sort(key=lambda x: x)
        for i, name in enumerate(className):
            classNameDict[str(i)] = name
        write_ini_file(outputPath, "CLASSES", classNameDict, 'w')

        if unknownFilter["order"] > 0 and isinstance(unknownFilter["order"], int):
            for j, name in enumerate(unknownFilter["parameters"]["threshold"]):
                postList[str(i+j+1)] = name
            write_ini_file(outputPath, "POSTPROCESSING", postList, 'a')

def cls_save_model(
    task: str,
    resultStoragePara:ClsResultStoragePara,
    modelType:str,
    model:nn.Module,
    optimizer:torch.functional,
    cudaDevice:torch.device,
    bestAcc:float,
    currentAcc:float,
    epoch:int,
    finalEpoch: int,
    storagedPath:str,
    imageSize:list
) -> float:
    """
    According to configs in ConfigResultStorage, save different model weight.

    Args:
        task: 
        resultStoragePara: include all result storaged methods parameters
        modelType: the selected model structure name
        model: whole model
        optimizer: optimizer use for training
        cudaDevice: cuda deveice that used for training
        bestAcc: best accuracy till now
        currentAcc: accuracy of the current epoch
        epoch: current epoch number
        finalEpoch: final epoch number
        storagedPath: the path to save weight file
        imageSize: image size that input to model
    Return:
        bestAcc: update best accuracy till now and return
    """
    if bestAcc <= currentAcc:
        bestAcc = currentAcc
        if resultStoragePara.saveBestDictPth["switch"]:
            if modelType is not 'CustomModel':
                save_weight(model, 'BestDictPth', storagedPath)
            else:
                print('Warning: CustomModel(ScriptPth) is not supported DictPth model saving')
        # For retrain situation with script model as initial model
        if resultStoragePara.saveBestScriptPth["switch"] and task == 'Retrain':
            save_script_model(model, 'BestScriptPth', storagedPath)

    if resultStoragePara.saveCheckpoint["switch"] and (epoch + 1) % resultStoragePara.saveCheckpoint["saveIter"] == 0:
        save_model_optimizer(epoch, model, optimizer, 'CheckPoint', storagedPath)

    if epoch + 1 == finalEpoch:
        if resultStoragePara.saveFinalDictPth["switch"]:
            if modelType is not 'CustomModel':
                save_weight(model, 'FinalDictPth', storagedPath)
            else:
                print('Warning: CustomModel(ScriptPth) is not supported DictPth model saving')
        if resultStoragePara.saveFinalScriptPth["switch"]:
            save_script_model(model, 'FinalScriptPth', storagedPath)
        if resultStoragePara.saveFinalOnnx["switch"]:
            try:
                pack_onnx(model, cudaDevice, 'FinalOnnx', storagedPath, imageSize)
            except:
                if modelType == 'CustomModel':
                    print('Warning: CustomModel(ScriptPth) can not save as onnx model')
                else:
                    print('Warning: The official onnx module have not supported mobilenet(Hardswish) packing')
        
    return bestAcc

def cls_transform_model(resultStoragePara: ClsResultStoragePara, modelType: str, model: nn.Module,
                    cudaDevice: torch.device, storagedPath: str, imageSize: list):
    """
    transform model into scriptPth or onnx

    Args:
        resultStoragePara: include all result storaged methods parameters
        modelType: the selected model structure name
        model: whole model
        cudaDevice: cuda deveice that used for training
        storagedPath: the path to save weight file
        imageSize: image size that input to model
    """
    if resultStoragePara.saveBestScriptPth["switch"]:
        save_script_model(model, 'BestScriptPth', storagedPath)
    if resultStoragePara.saveBestOnnx["switch"]:
        try:
            pack_onnx(model, cudaDevice, 'BestOnnx', storagedPath, imageSize)
        except:
            if modelType is 'CustomModel':
                print('Warning: CustomModel(ScriptPth) can not save as onnx model')
            else:
                print('Warning: The official onnx module have not supported mobilenet(Hardswish) packing')


def det_save_model(
    resultStorage: DetResultStoragePara,
    servicePara: ServicePara,
    outputPath:str,
    task: str,
    model:nn.Module,
    optimizer:torch.functional,
    bestmAP:float,
    currentmAP:float,
    epoch:int,
    modelType:str = None,
) -> float:

    if bestmAP <= currentmAP:
        bestmAP = currentmAP
        if resultStorage.saveBestDictPth["switch"]:
            if modelType is not 'CustomModel':
                save_weight(model, 'BestDictPth', outputPath)
            else:
                print('Warning: CustomModel(ScriptPth) is not supported DictPth model saving')
        # For retrain situation with script model as initial model
        if resultStorage.saveBestScriptPth["switch"] and task == 'Retrain':
            save_script_model(model, 'BestScriptPth', outputPath)

    if resultStorage.saveCheckpoint["switch"] and (epoch + 1) % resultStorage.saveCheckpoint["saveIter"] == 0:
        save_model_optimizer(epoch, model, optimizer, 'CheckPoint', outputPath)

    if epoch + 1 == servicePara.epochs:
        if resultStorage.saveFinalDictPth["switch"]:
            if modelType is not 'CustomModel':
                save_weight(model, 'FinalDictPth', outputPath)
            else:
                print('Warning: CustomModel(ScriptPth) is not supported DictPth model saving')
        if resultStorage.saveFinalScriptPth["switch"]:
            save_script_model(model, 'FinalScriptPth', outputPath)
        
    return bestmAP

def det_save_result(
    resultStorage: DetResultStoragePara,
    task:str, 
    classLabel:dict,
    outputPath:str, 
    resultList:list, 
    ):
    """
    save detection result 

    Args:
        resultStorage (DetResultStoragePara): Parameters include all result Storaged methods
        task (str): "Test" / "Inference" 
        classLabel (dict): number corresponds to category include background
        outputPath (str): output path
        result (list): result every item 
            [
            "image"       (PIL) : image
            "boxes"   (ndarray) : predict the coordinates of box
            "labels"  (ndarray) : predict box of category
            "scores"  (ndarray) : predict box confidence score
            "imageName"   (str) : image name
            "iou"         (str) : iou for every predict box
            ]
    """

    if task in ['Test', 'Inference'] and resultStorage.saveResultCsv["switch"]:
        resultSaver = DetResultSaver(outputPath, 'result', task, classLabel)
        resultSaver.write_result_csv(resultList, resultStorage.scoreThreshold, resultStorage.iouTreshold)
    
    if task in ['Test', 'Inference'] and resultStorage.drawResultImage["switch"]:
        draw_box(resultList, 
            os.path.join(outputPath, f"{task}ImageResult"), 
            classLabel, 
            resultStorage.scoreThreshold, 
            resultStorage.drawResultImage["lineThickness"])

