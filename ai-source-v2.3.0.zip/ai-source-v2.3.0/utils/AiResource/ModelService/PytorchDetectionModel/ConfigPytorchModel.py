# -*- coding: utf-8 -*-

"""
Created on Thur July 28 10:00:00 2022
"""

class ServicePara:
    def __init__(self, 
        cudaDevice: int, 
        batchSize: int, 
        epochs: int,
        printEpochFreq: int,
        sampleBatch: dict
        ) -> None:
        """
        Args:
            cudaDevice      (int) : GPU device used for running program
            batchSize       (int) : Number of data use for training at the same time
            epochs          (int) : The iteration number of training
            printEpochFreq  (int) : for "training" to show how often you want to display the loss in the console
            sampleBatch     (dict): {
                "switch"           (int): 0: disable, 1: enable
                "trainAspectGroup" (int): The number of groups according to the image size, used for the "training" sample batch
            }
        """

        self.cudaDevice         = cudaDevice   # GPU device used for running program
        self.batchSize          = batchSize    # Number of data use for training at the same time
        self.epochs             = epochs       # The iteration number of training
        self.printEpochFreq     = printEpochFreq
        self.sampleBatch        = sampleBatch

    @classmethod
    def create_from_dict(cls, servicePara: dict):
        """
        Args:
            servicePara["cudaDevice"]     (int) : GPU device used for running program
            servicePara["batchSize"]      (int) : Number of data use for training at the same time
            servicePara["epochs"]         (int) : The iteration number of training
            servicePara["printEpochFreq"] (int) : for "training" to show how often you want to display the loss in the console
            servicePara["sampleBatch"]    (dict): {
                "switch"           (int): 0: disable, 1: enable
                "trainAspectGroup" (int): The number of groups according to the image size, used for the "training" sample batch
            }
        """
        return cls(**servicePara)

class PathPara:
    def __init__(self,
        trainPath: str,
        validPath: str,
        testPath: str,
        inferencePath: str,
        weightPath: dict) -> None:
        """
        Args:
            Data path:
                trainPath     (str): (str) Train data path
                validPath     (str): (str) Validation data path
                testPath      (str): (str) Test data path
                inferencePath (str): Inference data path

            Model weight path:
                weightPath (dict): {
                    "pretrainedWeight" (str): Model weight for training
                    "evaluatedWeight"  (str): Model weight for test and inference
                    "customModel"      (str): Model weight for retrain and fine-tune
                }
        """
        self.trainPath          = trainPath     # Train data path
        self.validPath          = validPath     # Validation data path
        self.testPath           = testPath     # Test data path
        self.inferencePath      = inferencePath     # Inference data path
        self.weightPath         = weightPath     # Model weight for test and inference

    @classmethod
    def create_from_dict(cls, pathPara:dict):
        """
        Args:
            Data path:
                pathPara["trainPath"]     (str): Train data path
                pathPara["validPath"]     (str): Validation data path
                pathPara["testPath"]      (str): Test data path
                pathPara["inferencePath"] (str): Inference data path

            Model weight path:
                pathPara["weightPath"] (dict): {
                    "pretrainedWeight" (str): Model weight for training
                    "evaluatedWeight"  (str): Model weight for test and inference
                    "customModel"      (str): Model weight for retrain and fine-tune
                }
        """
        return cls(**pathPara)

class ModelPara:
    def __init__(self,
        oneStage:dict,
        twoStage:dict,
        pytorchModel:dict) -> None:
        """
        Args:
            oneStage (dict): {
                "switch"             : (int) 0: disable, 1: enable
                "backboneStructure"  : (str) backbone structure name
                "backbonePretrained" : (int) 0: disable, 1: enable
                "modelStructure"     : (str) model structure name
                "modelPretrained"    : (int) 0: disable, 1: enable
            }

            twoStage (dict): {
                "switch"             : (int) 0: disable, 1: enable
                "backboneStructure"  : (str) backbone structure name
                "backbonePretrained" : (int) 0: disable, 1: enable
                "modelStructure"     : (str) model structure name
                "modelPretrained"    : (int) 0: disable, 1: enable
            }

            pytorchModel (dict): {
                "switch"             : (int) 0: disable, 1: enable
                "modelStructure"     : (str) model structure name, ex: retinanet_resnet50_fpn
                "modelPretrained"    : (int) 0: disable, 1: enable
            }

        """
        self.oneStage = oneStage
        self.twoStage = twoStage
        self.pytorchModel = pytorchModel


    @classmethod
    def create_from_dict(cls, modelPara:dict):
        """
        Args:
            modelPara["oneStage"] : (dict) {
                "switch"             : (int) 0: disable, 1: enable
                "backboneStructure"  : (str) backbone structure name
                "backbonePretrained" : (int) 0: disable, 1: enable
                "modelStructure"     : (str) model structure name
                "modelPretrained"    : (int) 0: disable, 1: enable
            }

            modelPara["twoStage"] : (dict) {
                "switch"             : (int) 0: disable, 1: enable
                "backboneStructure"  : (str) backbone structure name
                "backbonePretrained" : (int) 0: disable, 1: enable
                "modelStructure"     : (str) model structure name
                "modelPretrained"    : (int) 0: disable, 1: enable
            }

            detModelPara["pytorchModel"] : (dict) {
                "switch"             : (int) 0: disable, 1: enable
                "modelStructure"     : (str) model structure name
                "modelPretrained"    : (int) 0: disable, 1: enable
            }
        """
        return cls(**modelPara)
