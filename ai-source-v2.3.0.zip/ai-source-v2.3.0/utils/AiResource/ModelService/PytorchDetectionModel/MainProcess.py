import os
import time

import torch
import torchvision
from main.Config import DetBasicSettingPara, PrivateSettingPara
from torch.utils.data import DataLoader
from ...Evaluation.ConfigEvaluation import DetEvaluationPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigModelService import (
    LearningRatePara, OptimizerPara, ScalerPara, SchedulerPara)
from .ConfigPreprocess import PreprocessPara
from .ConfigAugmentation import AugmentationPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPostprocess import \
    PostprcessPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPytorchModel import (
    ServicePara, ModelPara, PathPara)
from utils.AiResource.ModelService.PytorchDetectionModel.SelectScaler import \
    select_scaler
from utils.AiResource.ResultStorage.ConfigResultStorage import \
    DetResultStoragePara
from ...Evaluation.ModuleEvaluation.Det.SaveConfusionMatrix import ConfusionMatrix
from ...Evaluation.ModuleEvaluation.Det.coco_eval import CocoEvaluator
from ...Evaluation.ModuleEvaluation.Det.coco_utils import get_coco_api_from_dataset
from ...Evaluation.SelectEvaluationMethod import det_select_evaluation
from .CustomDataset import DetectionDataset, create_sample_batch
from .package.utils import MetricLogger
from .package.engine import apply_nms, evaluate, train_one_epoch

from .SelectTransform import get_train_transform, get_eval_transform
from .SelectDetectionModel import select_model
from .SelectOptimizer import select_optimizer
from .SelectScheduler import select_scheduler
from ...ResultStorage.SelectStorageMethod import det_save_model
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
### REPRODUCIBILITY
torch.manual_seed(3407)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

def train(        
    basicSettingPara: DetBasicSettingPara,
    privateSettingPara: PrivateSettingPara,
    evaluationPara: DetEvaluationPara,
    learningRatePara: LearningRatePara,
    optimizerPara: OptimizerPara,
    schedulerPara: SchedulerPara,
    scalerPara: ScalerPara,
    servicePara: ServicePara,
    pathPara: PathPara,
    prePara: PreprocessPara,
    augPara: AugmentationPara,
    modelPara: ModelPara,
    resultStorage: DetResultStoragePara) -> None:
    """
    Training procedure: Use training data for model training, and record epoch mAP, best weight.
    Args:
        basicSettingPara    : record task attribute
        privateSettingPara  : record output path
        evaluationPara      : Parameters include all evaluation methods
        learningRatePara    : attribute learningRate: float
        optimizerPara       : Parameters include all optimizers
        schedulerPara       : Parameters include all schedulers
        scalerPara          : Parameters include all scaler
        servicePara         : Parameters include cudaDevice, batch size, total epochs, printEporchFreq and sample batch
        pathPara            : Include valid, train, test, inference data Path
        prePara             : Parameters include all preprocess methods
        augPara             : Parameters include all augmentation methods
        modelPara           : Parameters include one stage, two stage, torchvision model
        resultStorage       : Parameters include all result Storaged methods
    Return:
        weight.pth          : for saving weight
        Train_mAP.txt, Valid_mAP.txt
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')
    # Data loading code
    print("Loading data")
    hasNotBackground = basicSettingPara.classNameDict.__contains__(0)
    classLabelHasBg = {k+1 : v for k, v in basicSettingPara.classNameDict.items()} if hasNotBackground else basicSettingPara.classNameDict
    numClasses = classLabelHasBg.__len__() + 1 if hasNotBackground else classLabelHasBg.__len__()

    print(f'class has background number is {numClasses}')
    trainSet = DetectionDataset(pathPara.trainPath, transform=get_train_transform(prePara.preprocessPara, augPara.augmentationPara), hasNotBackground=hasNotBackground)
    validSet = DetectionDataset(pathPara.validPath, transform=get_eval_transform(prePara.preprocessPara), hasNotBackground=hasNotBackground)

    print("Creating data loaders")
    if servicePara.sampleBatch["switch"]:
        trainBatch = {'batch_sampler': create_sample_batch(trainSet, servicePara.batchSize, isTrainData=True, aspectRatioGroupFactor=servicePara.sampleBatch["trainAspectGroup"])}
        validBatch = {'batch_size': servicePara.batchSize, 'sampler': create_sample_batch(validSet, servicePara.batchSize)}
    else:
        trainBatch = {'batch_size': servicePara.batchSize, 'shuffle': True}
        validBatch = {'batch_size': servicePara.batchSize, 'shuffle': False}

    trainLoader = DataLoader(
        trainSet, num_workers=0, collate_fn=trainSet.collate_fn, **trainBatch)

    validLoader = DataLoader(
        validSet, num_workers=0, collate_fn=validSet.collate_fn, **validBatch)

    print("select model")
    model = select_model(modelPara, pathPara, basicSettingPara.task, numClasses, cudaDevice)
    model = model.to(cudaDevice)

    parameters = [p for p in model.parameters() if p.requires_grad]    # requires_grad 紀錄的值
    optimizer = select_optimizer(optimizerPara, learningRatePara.learningRate, parameters)
    scheduler = select_scheduler(schedulerPara, optimizer)
    scaler = select_scaler(scalerPara)

    print("Start training")
    bestmAP = 0
    for epoch in range(servicePara.epochs):
        localtime = time.asctime(time.localtime(time.time()))
        lineLength = len(f'Epoch: {epoch + 1}/{servicePara.epochs} --- < Starting Time : {localtime} >')
        singleLine = '-' * (int(lineLength/2) - 3)
        print('=' * lineLength)
        print(f'{singleLine} train {singleLine}')
        print(f'Epoch: {epoch + 1}/{servicePara.epochs} --- < Starting Time : {localtime} >')

        train_one_epoch(model, optimizer, trainLoader, cudaDevice, epoch, servicePara.printEpochFreq, scaler)
        scheduler.step()

        # evaluate after every epoch
        coco_evaluator_train = evaluate(model, trainLoader, device=cudaDevice)

        print(f'{singleLine} valid {singleLine}')
        coco_evaluator_val = evaluate(model, validLoader, device=cudaDevice)

        # gather the stats from all processes
        trainmAP = coco_evaluator_train.coco_eval["bbox"].stats[0]
        validmAP = coco_evaluator_val.coco_eval["bbox"].stats[0]
        print('train mAP is {}'.format(trainmAP))
        print('validation mAP is {}'.format(validmAP))
        print('best mAP is {}'.format(bestmAP))

        det_select_evaluation(evaluationPara, "Train", classLabelHasBg, privateSettingPara.outputPath, cocoEval=coco_evaluator_train.coco_eval["bbox"].stats, epochRecord=f"{epoch+1}/{servicePara.epochs}" )
        det_select_evaluation(evaluationPara, "Valid", classLabelHasBg, privateSettingPara.outputPath, cocoEval=coco_evaluator_val.coco_eval["bbox"].stats, epochRecord=f"{epoch+1}/{servicePara.epochs}" )
        ##### Save weight #####
        bestmAP = det_save_model(resultStorage, servicePara, privateSettingPara.outputPath, basicSettingPara.task, model, optimizer, bestmAP, validmAP, epoch)

def test(
    basicSettingPara: DetBasicSettingPara,
    servicePara: ServicePara,
    pathPara: PathPara,
    prePara: PreprocessPara,
    modelPara: ModelPara,
    postProcessPara: PostprcessPara,
    resultStoragePara: DetResultStoragePara,
):
    """
    Testing procedure: Use test data for model verification, and output the predicted result csv and confusion matrix.
    Args:
        basicSettingPara    : record task attribute
        servicePara         : Parameters include cudaDevice, batch size, total epochs, printEporchFreq and sample batch
        pathPara            : Include valid, train, test, inference data Path
        modelPara           : Parameters include one stage, two stage, torchvision model
        postProcessPara     : Parameters include all postprocee methods
        resultStoragePara       : Parameters include all result Storaged methods
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')
    print(cudaDevice)
    hasNotBackground = basicSettingPara.classNameDict.__contains__(0)
    classLabelHasBg = {k+1 : v for k, v in basicSettingPara.classNameDict.items()} if hasNotBackground else basicSettingPara.classNameDict
    numClasses = classLabelHasBg.__len__() + 1 if hasNotBackground else classLabelHasBg.__len__()

    print("Loading data")
    testSet = DetectionDataset(pathPara.testPath,
                            transform=get_eval_transform(prePara.preprocessPara),
                            hasNotBackground=hasNotBackground)
    print("Creating data loaders")
    if servicePara.sampleBatch["switch"]:
        testBatch = {'batch_size': servicePara.batchSize, 'sampler': create_sample_batch(testSet, servicePara.batchSize)}
    else:
        testBatch = {'batch_size': 1}

    testLoader = DataLoader(
        testSet, num_workers=1, collate_fn=testSet.collate_fn, **testBatch)

    print("select model")
    model = select_model(modelPara, pathPara, basicSettingPara.task, numClasses, cudaDevice)
    model = model.to(cudaDevice)
    model.eval()

    coco = get_coco_api_from_dataset(testLoader.dataset)
    cocoEvaluator = CocoEvaluator(coco, ["bbox"])

    metricLogger = MetricLogger(delimiter="  ")
    header = "Test:"
    
    confusionMatrix = ConfusionMatrix(classLabelHasBg, resultStoragePara.scoreThreshold, resultStoragePara.iouTreshold)
    with torch.no_grad():
        resultList = []

        for images, targets in metricLogger.log_every(testLoader, servicePara.printEpochFreq, header):

            images = list(img.to(cudaDevice) for img in images)
            prediction = model(images)[0]
            prediction = apply_nms(prediction, postProcessPara.nms['iouTreshold']) if postProcessPara.nms['order'] else prediction
            confusionMatrix.process(prediction, targets[0])

            predDict = {
                "image"          : torchvision.transforms.ToPILImage(mode='RGB')(images[0]),
                "boxes"          : prediction["boxes"].cpu().numpy(),
                "labels"         : prediction["labels"].cpu().numpy(),
                "scores"         : prediction["scores"].cpu().numpy(),
                "imageName"      : targets[0]['imageName'],
                "iou"            : ConfusionMatrix.box_iou(targets[0]['boxes'].cpu(), prediction['boxes'].cpu()),
                "matrix"         : confusionMatrix.matrix,
                "classLabelhasBg": classLabelHasBg,
            }

            resultList.append(predDict)
            
            if len(predDict["boxes"]) == 0:
                print("No target detected!")

            outputs = [{k: v.cpu() for k, v in prediction.items()}]
            res = {target["image_id"].item(): output for target, output in zip(targets, outputs)}
            cocoEvaluator.update(res)
        cocoEvaluator.synchronize_between_processes()
        # accumulate predictions from all images
        cocoEvaluator.accumulate()
        cocoEvaluator.summarize()
        cocoEval = cocoEvaluator.coco_eval["bbox"].stats
    
    testmAP = cocoEvaluator.coco_eval["bbox"].stats[0]
    print(f'test mAP is : {testmAP}')

    return resultList, cocoEval

def inference(
    basicSettingPara: DetBasicSettingPara,
    servicePara: ServicePara,
    pathPara: PathPara,
    prePara: PreprocessPara,
    modelPara: ModelPara,
    postProcessPara: PostprcessPara,
):
    """
    Inference procedure: Use trained model for detection inference data, and output the result csv.
    Args:
        basicSettingPara    : record task attribute
        servicePara         : Parameters include cudaDevice, batch size, total epochs, printEporchFreq and sample batch
        pathPara            : Include valid, train, test, inference data Path
        modelPara           : Parameters include one stage, two stage, torchvision model
        postProcessPara     : Parameters include all postprocee methods
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')

    hasNotBackground = basicSettingPara.classNameDict.__contains__(0)
    classLabelHasBg = {k+1 : v for k, v in basicSettingPara.classNameDict.items()} if hasNotBackground else basicSettingPara.classNameDict
    numClasses = classLabelHasBg.__len__()+1 if hasNotBackground else classLabelHasBg.__len__()

    print("Loading data")
    inferenceSet = DetectionDataset(pathPara.inferencePath,
                                transform=get_eval_transform(prePara.preprocessPara),
                                hasNotBackground=hasNotBackground,
                                isInference=True)

    print("Creating data loaders")
    if servicePara.sampleBatch["switch"]:
        inferenceBatch  = {'batch_size': servicePara.batchSize, 'sampler': create_sample_batch(inferenceSet, servicePara.batchSize)}
    else:
        inferenceBatch = {'batch_size': 1}

    inferenceLoader = DataLoader(
        inferenceSet, shuffle=False, num_workers=1, collate_fn=inferenceSet.collate_fn, **inferenceBatch)

    print("select model")
    model = select_model(modelPara, pathPara, basicSettingPara.task, numClasses, cudaDevice)
    model = model.to(cudaDevice)
    model.eval()
    resultList = []
    with torch.no_grad():
        for images, targets in inferenceLoader:
            images = list(img.to(cudaDevice) for img in images)
            prediction = model(images)[0]
            prediction = apply_nms(prediction, postProcessPara.nms['iouTreshold']) if postProcessPara.nms['order'] else prediction
            predDict = {
                "image"          : torchvision.transforms.ToPILImage(mode='RGB')(images[0]),
                "boxes"          : prediction["boxes"].cpu().numpy(),
                "labels"         : prediction["labels"].cpu().numpy(),
                "scores"         : prediction["scores"].cpu().numpy(),
                "imageName"      : targets[0]["imageName"],
                "classLabelhasBg": classLabelHasBg
            }
            if len(predDict["boxes"]) == 0:
                print("No target detected!")
            resultList.append(predDict)

    return resultList
