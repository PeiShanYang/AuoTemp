import torch.functional
import torch.nn as LossFunctionMethod

from .ConfigModelService import LossFunctionPara


def cls_select_loss_function(selectedLoss: LossFunctionPara) -> torch.functional:
    """
    Select loss functcion from torch.nn module.

    Args:
        selectedLoss: function name of loss
    Return:
        lossFunction
    """
    method = getattr(LossFunctionMethod, selectedLoss.lossFunction)
    lossFunction = method()

    return lossFunction
