from utils.AiResource.ModelService.PytorchClassificationModel.ConfigPreprocess import \
    PreprocessPara
from utils.AiResource.Postprocess.ConfigPostprocess import ClsPostProcessPara
import json, collections, os

class DepolyConfigJsonSetting:
    def __init__(self,     
        preprocessPara:PreprocessPara, 
        postProcessPara:ClsPostProcessPara,
        fileName:str,
        classNameList:list,
        ) -> None:
        """config file setting for deployment

        Args:
            preprocessPara (PreprocessPara): preprocess para from ConfigCls.json
            postProcessPara (ClsPostProcessPara): post-Process para from ConfigCls.json
            fileName (str): deployment file name
            classNameList (list): class name list 
        """
        
        self.preprocessPara = self.cls_sort_dict_by_value(preprocessPara.preprocessPara)
        self.postProcessPara = self.cls_sort_dict_by_value(postProcessPara.__dict__)
        self.inferencePara = {
                "cudaDevice": 0,
                "pathPara": "./image",
                "classNameList": classNameList,
                "csvSave":{
                    "switch": 1,
                    "name": fileName
                },
                "onnxModelName": fileName
            }
        pass

    def config_json_item(self):
        """Generate dictionary of config json files

        Returns:
            jsonfile (dict): Parameter for the classification infernece config file 
        """
        normalizePara = self.preprocessPara['Normalize']
        if normalizePara['order'] > 0:
            mode, mean, std = normalizePara["parameters"]["mode"], normalizePara["parameters"]["mean"], normalizePara["parameters"]["std"]
            jsonFilePath = './utils/AiResource/Preprocess/ModulePreprocess/Cls/normalizeRecord.json'
            infoDict = self.load_dict_from_json(jsonFilePath)
            try:
                normalization = infoDict[mode]
            except:
                if isinstance(mean, list) and isinstance(std, list):
                    if len(mean) == 3 and len(std) == 3:
                        normalization = {"mean": mean, "std": std}
                    else:
                        raise ValueError('["mean"] and ["std"] value must include three values [R, G, B].')
                else:
                    raise BaseException(f'Can not find "{mode}" normalization and got no input of maen and std.')
            self.preprocessPara['Normalize']['parameters'] = normalization
        jsonFile = {**{"inferencePara":self.inferencePara}, 
            **{"preprocessPara":self.preprocessPara}, 
            **{"postProcessPara":self.postProcessPara}}
        return jsonFile

    @staticmethod
    def cls_sort_dict_by_value(sortDict: dict) -> dict:
        """
        Sort Dict according to value["order"], the order should be non-negative integer
        1. value["order"] is 0, meaning not used.
        2. value["order"] must be greater than 0
        3. value["order"] must be integer

        Args:
            sortDict (dict): {key: {"order": num}, ...}
        
        return:
            resultDict (dict): sorted dict
        """
        resultDict = collections.OrderedDict()
        # _recordOrder = []
        for key, value in sortDict.items():
            # 1. unused
            if value["order"] == 0:
                continue
            
            # 2&3. check if value["order"] is non-negative integer
            if value["order"] < 0 or not isinstance(value["order"], int):
                raise ValueError(f'The order of "{key}" in main/ConfigCls.json should be a non-negative integer.')
            
            # # 4. check value["order"] is not repeated
            # if value["order"] not in _recordOrder:
            #     _recordOrder.append(value["order"])
            # else:
            #     raise ValueError(f'The order of "{[k for k, v in sortDict.items() if v["order"] == value["order"]]}" in main/ConfigCls.json is the same as other operation.')
            
            # keep used dict
            resultDict[key] = value
        resultDict = dict(sorted(resultDict.items(), key=lambda item: item[1]["order"]))
        return resultDict
    
    @staticmethod
    def load_dict_from_json(jsonFilePath: str) -> dict:
        """
        Load dict from json file

        Args:
            jsonFilePath: json file path
        
        Return:
            infoDict: dict in json file
        """
        with open(jsonFilePath, 'r') as f:
            try:
                infoDict = json.load(f)
            except:
                raise BaseException('Something went wrong while loading normalizeRecord.json')
        return infoDict


def write_mainPy(fileName:str, outputPath:str):
    """
    Generate main.py file
    
    Args:
        fileName (str): inference pyd file name
        outputPath (str): output path you want to save to
    """
    with open(os.path.join(outputPath, 'main.py'), "w") as outfile:
        outfile.write(f'from utils.{fileName} import inference \n\n')
        outfile.write("""if __name__ == '__main__':
    resultList = inference()
    for i, finalResult in enumerate(resultList):
        print("FileName: {:15s}  Prediction: {:15s}  Confidence: {}".format(finalResult['filename'], finalResult['predict'], finalResult['confidence']))
""")