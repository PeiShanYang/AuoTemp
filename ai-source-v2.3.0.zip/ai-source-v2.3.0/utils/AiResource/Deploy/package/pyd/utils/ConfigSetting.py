class InferencePara:
    def __init__(self, cudaDevice:int, pathPara:str, classNameList:list, csvSave:dict, onnxModelName:str) ->None:
        """inference parameters

        Args:
            cudaDevice (int): cuda device ID
            pathPara (str): image path for inferencing
            classNameList (list):  give class list in 'Inference' task
            csvSave (dict): {
                switch (int): save csv or not
                name: csv file name
            }
            onnxModelName (str): onnx model name
        """
        self.cudaDevice = cudaDevice
        self.pathPara = pathPara
        self.classNameList = classNameList
        self.csvSave = csvSave
        self.onnxModelName = onnxModelName

    @classmethod
    def create_from_dict(cls, inferencePara: dict):
        """inference parameters

        Args:
            inferencePara (dict): {
                cudaDevice (int): cuda device ID
                pathPara (str): image path for inferencing
                classNameList (list):  give class list in 'Inference' task
                csvSave (dict): {
                    switch (int): save csv or not
                    name: csv file name
                }
                onnxModelName (str): onnx model name
            }

        Returns:
            cls(**inferencePara)
        """
        return cls(**inferencePara)


class PostProcessPara:
    def __init__(self) -> None:
        pass

class ClsPostProcessPara(PostProcessPara):
    def __init__(self, confidenceFilter: dict, unknownFilter: dict) -> None:
        """
        # confidenceFilter: if the confidence of 'clsName' is lower than 'thresholdValue', reduce the confidence to 0.
        confidenceFilter: {
            "order"     : (int) 0: disable, 1: enable
            "parameters": (dict) {
                "threshold": (dict) {clsName(str): thresholdValue(str), ...} give the class name and the corresponding threshold value
            }
        }
        # Filter out images with scores below the threshold
        unknownFilter: {
            "order"     : (int) 0: disable, 1: enable
            "parameters": (dict) {
                "threshold": (dict) {tagName(str): thresholdValue(str), ...} give the tag name and the corresponding threshold value
                "reverse"  : (int) 0: disable, 1: enable
            }
        }
        """
        self.confidenceFilter = confidenceFilter
        self.unknownFilter = unknownFilter

    @classmethod
    def create_from_dict(cls, postProcessPara: dict):
        """
        postProcessPara: {
            # confidenceFilter: if the confidence of 'clsName' is lower than 'thresholdValue', reduce the confidence to 0.
            "confidenceFilter": (dict) {
                "order"     : (int) 0: disable, 1: enable
                "parameters": (dict) {
                    "threshold": (dict) {clsName(str): thresholdValue(str), ...} give the class name and the corresponding threshold value
                }
            }

            # Filter out images with scores below the threshold
            "unknownFilter": (dict) {
                "order"     : (int) 0: disable, 1: enable
                "parameters": (dict) {
                    "threshold": (dict) {tagName(str): thresholdValue(str), ...} give the tag name and the corresponding threshold value
                    "reverse"  : (int) 0: disable, 1: enable
                }
            }
        }
        """
        return cls(**postProcessPara)


class PreprocessPara:
    def __init__(self, preprocessPara: dict) -> None:
        """
        preprocessPara: {
            # In train task, mean and std can be calculated automatically if necessary
            Normalize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "mode": (str) select "ImageNet", "CIFAR10, "MNIST, "VRS" or input a new one. If you give null, a name in UID will be given
                    "mean": (list) [R(float), G(float), B(float)] give a mean value list if you input a new mode name, R, G, B in [0, 1]
                    "std" : (list) [R(float), G(float), B(float)] give a std value list if you input a new mode name, R, G, B in [0, 1]
                }
            }
            Resize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "imageSize"    : (list) [height(int), width(int)], 3090 GPU memory limit: [2**14, 2**14]
                    "interpolation": (str) "BILINEAR", "NEAREST", or "BICUBIC"
                }
            }
            CenterCrop: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "size": (list) [height(int), width(int)], (sequence or int) Don't exceed the MAX_IMAGE_PIXELS(178956970 ~= [13377, 13377])pixels
                }
            }
            Pad: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "padding"    : (list) [x1(int), y1(int), x2(int), y2(int)], The limit value is different according to different equipment
                    "fill"       : (list) [R(int), G(int), B(int)],  (int or RGB(tuple))
                    "paddingMode": (str) "constant", "edge", "reflect", or "symmetric"
                }
            }
            GaussianBlur: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "kernelSize": (list) [height(int), width(int)], (int or sequence) should be an odd and positive number and must be smaller than image size
                    "sigma"     : (float) in (0, 2**127]
                }
            }
            Brightness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "brightness": (float) in [0, 2**127]
                }    
            }
            Contrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "contrast": (float) in [0, 2**127]
                }
            }
            Saturation: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "saturation": (float) in [0, 2**127]
                } 
            }
            Hue: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "hue": (float) in [-0.5, 0.5]
                }
            }
        }
        """
        self.preprocessPara = preprocessPara

    @classmethod
    def create_from_dict(cls, preprocessPara: dict):
        """
        preprocessPara: {
            # In train task, mean and std can be calculated automatically if necessary
            Normalize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "mode": (str) select "ImageNet", "CIFAR10, "MNIST, "VRS" or input a new one. If you give null, a name in UID will be given
                    "mean": (list) [R(float), G(float), B(float)] give a mean value list if you input a new mode name, R, G, B in [0, 1]
                    "std" : (list) [R(float), G(float), B(float)] give a std value list if you input a new mode name, R, G, B in [0, 1]
                }
            }
            Resize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "imageSize"    : (list) [height(int), width(int)], 3090 GPU memory limit: [2**14, 2**14]
                    "interpolation": (str) "BILINEAR", "NEAREST", or "BICUBIC"
                }
            }
            CenterCrop: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "size": (list) [height(int), width(int)], (sequence or int) Don't exceed the MAX_IMAGE_PIXELS(178956970 ~= [13377, 13377])pixels
                }
            }
            Pad: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "padding"    : (list) [x1(int), y1(int), x2(int), y2(int)], The limit value is different according to different equipment
                    "fill"       : (list) [R(int), G(int), B(int)],  (int or RGB(tuple))
                    "paddingMode": (str) "constant", "edge", "reflect", or "symmetric"
                }
            }
            GaussianBlur: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "kernelSize": (list) [height(int), width(int)], (int or sequence) should be an odd and positive number and must be smaller than image size
                    "sigma"     : (float) in (0, 2**127]
                }
            }
            Brightness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "brightness": (float) in [0, 2**127]
                }    
            }
            Contrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "contrast": (float) in [0, 2**127]
                }
            }
            Saturation: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "saturation": (float) in [0, 2**127]
                } 
            }
            Hue: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "hue": (float) in [-0.5, 0.5]
                }
            }
        }
        """
        return cls(preprocessPara)

