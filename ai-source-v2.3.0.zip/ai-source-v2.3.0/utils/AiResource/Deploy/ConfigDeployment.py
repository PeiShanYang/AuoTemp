class DeploymentPara:
    def __init__(self, deployMode:int, deployPath:str, deployName:str, saveIniFile:int) -> None:
        """
        Args:
            deployMode (int): deploy mode: 0 -> onnx&config,  1 -> pyd, 2 -> exe
            deployPath (str): the path you want to deploy to 
            deployName (str): the name you want to deploy
            saveIniFile (int): Whether to save the ini file
        """
        self.deployMode = deployMode
        self.deployPath = deployPath
        self.deployName = deployName
        self.saveIniFile = saveIniFile
        pass

class ClsDeploymentPara(DeploymentPara):
    def __init__(self, deployMode:int, deployPath:str, deployName:str, saveIniFile:int) -> None:
        super().__init__(deployMode, deployPath, 
                        deployName, saveIniFile)
        pass

    @classmethod
    def create_from_dict(cls, deploymentPara:dict) -> None:
        """
        Args:
            deploymentPara (dict): {
                deployMode (int): deploy mode: 0 -> onnx&config,  1 -> pyd(so), 2 -> exe
                deployPath (str): the path you want to deploy to 
                deployName (str): the name you want to deploy
                saveIniFile (int): Whether to save the ini file
            }
        """
        return cls(**deploymentPara)