import numpy as np
from numpy import ndarray
from .ModuleEvaluation.Det import SaveConfusionMatrix, SaveMapTxt
from .ConfigEvaluation import ClsEvaluationPara, DetEvaluationPara
from .ModuleEvaluation.DrawPlot import draw_acc_curve, plot_confusion_matrix
from .ModuleEvaluation.Cls.EvaluationMethod import eval_class_acc, eval_other_cls_rate, eval_total_acc, save_acc_json, save_acc_txt, show_num_acc

def cls_select_valid_plot(evaluationPara: ClsEvaluationPara, accRecord:list, outputPath:str) -> None:
    """
    According to configs in ConfigEvaluation, draw ValicAcc.

    Args:
        evaluationPara: include all evaluation methods parameters
        accRecord: list of acc for each epoch
        outputPath: output path of result files
    """
    if evaluationPara.drawAccCurve["switch"]:
        draw_acc_curve(accRecord, outputPath)

def cls_select_test_plot(
    evaluationPara:ClsEvaluationPara,
    outputPath:str,
    cfMatrix:np.ndarray,
    className:list
) -> None:
    """
    According to configs in ConfigEvaluation, draw cfMatrix.

    Args:
        evaluationPara: include all evaluation methods parameters
        outputPath: output path of result files
        cfMatrix: cfMatrix
        className: className: list of class name
    """
    if evaluationPara.drawConfusionMatrix["switch"]:
        plot_confusion_matrix(cfMatrix=cfMatrix,
                              className=className,
                              showNumber=evaluationPara.drawConfusionMatrix["showNumber"],
                              title='PredictedResult',
                              outputPath=outputPath)

def cls_select_train_evaluation(
    evaluationPara:ClsEvaluationPara,
    outputPath:str,
    totalNumbers:int,
    totalCorrect:int,
    totalEpoch:int,
    epoch:int
) -> None:
    """
    According to configs in ConfigEvaluation, select evaluation methods for train.
    Note: Do not combine into other evaluaiton, cause too many if-else statement.
    
    Args:
        evaluationPara: include all evaluation methods parameters
        outputPath: output path of result files
        totalNumbers: total data amount
        totalCorrect: correctly predicted data amount
        totalEpoch: total epoch
        epoch: this epoch
    """
    if evaluationPara.accuracy["switch"] and 'Train' in evaluationPara.accuracy["mode"]:
        accuracy = eval_total_acc(totalNumbers, totalCorrect)
        if evaluationPara.accuracy["saveTxt"]:
            save_acc_txt('Train', outputPath, accuracy, epoch=epoch, totalEpoch=totalEpoch)
        if evaluationPara.accuracy["saveJson"]:
            save_acc_json('Train', outputPath, accuracy, epoch=epoch, totalEpoch=totalEpoch)   

def cls_select_evaluation(
    evaluationPara:ClsEvaluationPara,
    outputPath:str,
    task:str,
    totalNumbers:int,
    totalCorrect:int,
    perClassNumbers:list,
    perClassCorrect:list,
    className:list,
    resultList:list=None,
    totalEpoch:int=None,
    epoch:int=None
) -> None:
    """
    According to configs in ConfigEvaluation, select evaluation methods for valid.

    Args:
        evaluationPara: include all evaluation methods parameters
        outputPath: output path of result files
        task: valid or test
        totalNumbers: total data amount
        totalCorrect: correctly predicted data amount
        perClassNumbers: amount of per class
        perClassCorrect: predicted correctly image amount of per class
        className: list of class name
        resultList: result list after model
        totalEpoch: total epoch
        epoch: this epoch
    """
    totalAccTxt  = totalAccJson  = None
    classAccTxt  = classAccJson  = None
    classNumTxt  = classNumJson  = None
    otherRateTxt = otherRateJson = None
    if evaluationPara.accuracy["switch"] and task in evaluationPara.accuracy["mode"]:
        accuracy = eval_total_acc(totalNumbers, totalCorrect)
        if evaluationPara.accuracy["saveTxt"]:
            totalAccTxt = accuracy
        if evaluationPara.accuracy["saveJson"]:
            totalAccJson = accuracy
    
    if evaluationPara.accOfClasses["switch"] and task in evaluationPara.accOfClasses["mode"]:
        perClassAccuracy = eval_class_acc(perClassNumbers, perClassCorrect, className)
        if evaluationPara.accOfClasses["saveTxt"]:
            classAccTxt = perClassAccuracy
        if evaluationPara.accOfClasses["saveJson"]:
            classAccJson = perClassAccuracy
    
    if evaluationPara.numOfClasses["switch"] and task in evaluationPara.numOfClasses["mode"]:
        perClassNum = show_num_acc(perClassNumbers, perClassCorrect, className)
        if evaluationPara.accOfClasses["saveTxt"]:
            classNumTxt = perClassNum
        if evaluationPara.accOfClasses["saveJson"]:
            classNumJson = perClassNum
    
    if evaluationPara.otherClsRate["switch"] and task == 'Test':
        otherRate = eval_other_cls_rate(resultList, evaluationPara.otherClsRate["posClass"],
                                        evaluationPara.otherClsRate["negClass"])
        if evaluationPara.otherClsRate["saveTxt"]:
            otherRateTxt = otherRate
        if evaluationPara.otherClsRate["saveJson"]:
            otherRateJson = otherRate
    
    save_acc_txt(task, outputPath, totalAccTxt, classAccTxt, classNumTxt, otherRateTxt, epoch=epoch, totalEpoch=totalEpoch)
    save_acc_json(task, outputPath, totalAccJson, classAccJson, classNumJson, otherRateJson, epoch=epoch, totalEpoch=totalEpoch)

def cls_test_evaluation(
    evaluationPara:ClsEvaluationPara,
    outputPath:str,
    resultList:list,
    classNameList:list
) -> None:
    """
    Sum each record from resultList to evaluate

    Args:
        evaluationPara: include all evaluation methods parameters
        outputPath: output path of result files
        resultList: result list after model
        classNameList: className: list of class name
    """
    ##### sort class #####
    classNameList.sort()
    classNameList.sort(key=lambda x:x)
    ##### record #####
    totalCorrect = postProcessFilter = 0
    classCorrect = [0.] * len(classNameList)
    classTotal = [0.] * len(classNameList)
    cfMatrix = np.zeros([len(classNameList), len(classNameList)])
    for result in resultList:
        if not result["predict"] in classNameList:
            postProcessFilter += 1
        else:
            if result["predict"] == result["label"]:
                totalCorrect = totalCorrect + 1
                classCorrect[classNameList.index(result["label"])] += 1
            classTotal[classNameList.index(result["label"])] += 1
            cfMatrix[classNameList.index(result["label"])][classNameList.index(result["predict"])] += 1
    
    ##### evaluate #####
    cls_select_evaluation(evaluationPara, outputPath, task='Test', totalNumbers=len(resultList)-postProcessFilter, totalCorrect=totalCorrect,
                      perClassNumbers=classTotal, perClassCorrect=classCorrect, className=classNameList, resultList=resultList)
    
    ##### print unknown rate #####
    if len(resultList) == 0:
        postProcessRate = 0
    else:
        postProcessRate = postProcessFilter/len(resultList)
    print(f'- Post Processing filters out {postProcessFilter} images: {postProcessRate*100:.4f} %')
    
    ##### draw cfMatrix #####
    cls_select_test_plot(evaluationPara, outputPath, cfMatrix, className=classNameList)



def det_select_evaluation(
    evaluationPara: DetEvaluationPara,
    task:str, 
    classLabel:dict, 
    outputPath:str,
    result:list=None, 
    cocoEval:ndarray=None, 
    epochRecord:str=None, 
    ):
    """
    record for detection evalutaion 

    Args:
        evaluationPara (DetEvaluationPara): Parameters include all evaluation methods
        task (str): "Train" / "Valid" / "Test" / "Inference" 
        classLabel (dict): number corresponds to category include background
        outputPath (str): output path
        result (list, optional): result every item 
            [
            "matrix"  (ndarray) : confusionMatrix.matrix
            ] Defaults to None.
        cocoEval (ndarray, optional): evaluate result for coco data form. Defaults to None.
        epochRecord (str, optional): record epoch. Defaults to None.
    """
    if task in evaluationPara.saveMapTxt["mode"] and evaluationPara.saveMapTxt["switch"]:
        SaveMapTxt.write_mAP_txt(outputPath, task, cocoEval, epochRecord)  
    
    if task == 'Test' and evaluationPara.drawConfusionMatrix["switch"] and result != None:
        SaveConfusionMatrix.draw_confusion_matrix(result, classLabel, outputPath, showNumber=True)