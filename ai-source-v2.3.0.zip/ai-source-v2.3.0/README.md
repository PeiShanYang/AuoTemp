# 瑕疵檢測模組

## 檔案目錄

    │  .gitignore
    │  enter.bat
    │  enter.py
    │  README.md
    │
    ├─config
    │      Config.py
    │      ConfigDataClean.py
    │      ConfigDetection.py
    │      ConfigModelService.py
    │      ConfigPytorchModel.py
    │      ConfigResultStorage.py
    │
    ├─input
    │  ├─CustomModel
    │  │      Put_your_customModel_weight_here.txt
    │  │
    │  ├─Data
    │  │      Put_your_data_here.txt
    │  │
    │  └─PretrainedWeight
    │          Put_pretrained_weight_here.txt
    │
    ├─main
    │      Config.py
    │      ConfigCls.json
    │      ConfigLoader.py
    │      MainCls.py
    │      MainDet.py
    │
    ├─output
    │      result_output_here.txt
    │
    ├─sampleConfig
    │      ConfigCls.json
    │
    └─utils
        └─AiResource
            ├─AiModel
            │      alexnet.py
            │      cbam_resnet.py
            │      csp_resnet.py
            │      densenet.py
            │      efficientnet.py
            │      mnasnet.py
            │      mobilenetv3.py
            │      regnet.py
            │      resnet.py
            │      resnetModule.py
            │      se_cbam_resnet.py
            │      se_resnet.py
            │      shufflenetv2.py
            │      torchFuture.py
            │      vgg.py
            │      __init__.py
            │
            ├─DataAugmentation
            │      AugmentationMethod.py
            │      ResizeImage.py
            │      __init__.py
            │
            ├─DatasetClean
            │      AnnotationTransfer.py
            │      BasicFileProcess.py
            │      ConfigDataClean.py
            │      DataSplit.py
            │      __init__.py
            │
            ├─Evaluation
            │      ConfigEvaluation.py
            │      DrawPlot.py
            │      EvaluationMethod.py
            │      SelectEvaluationMethod.py
            │      __init__.py
            │
            ├─ModelService
            │  ├─PytorchClassificationModel
            │  │      ConfigAugmentation.py
            │  │      ConfigModelService.py
            │  │      ConfigPreprocess.py
            │  │      ConfigPytorchModel.py
            │  │      CustomDataset.py
            │  │      MainProcess.py
            │  │      SelectLossFunction.py
            │  │      SelectModel.py
            │  │      SelectOptimizer.py
            │  │      SelectScheduler.py
            │  │      SelectTransform.py
            │  │      __init__.py
            │  │
            │  └─PytorchDetectionModel
            │      │  ConfigAugmentation.py
            │      │  ConfigModelService.py
            │      │  ConfigPostprocess.py
            │      │  ConfigPreprocess.py
            │      │  ConfigPytorchModel.py
            │      │  CustomDataset.py
            │      │  MainProcess.py
            │      │  SelectBackbone.py
            │      │  SelectDetectionModel.py
            │      │  SelectPostprocess.py
            │      │  SelectOptimizer.py
            │      │  SelectScaler.py
            │      │  SelectScheduler.py
            │      │  SelectTransform.py
            │      │
            │      └─package
            │              engine.py
            │              group_by_aspect_ratio.py
            │              utils.py
            │
            ├─Others
            │      feature_visualize.py
            │      __init__.py
            │
            ├─Postprocess
            │      ConfidenceFilter.py
            │      ConfigPostprocess.py
            │      SelectPostprocess.py
            │      UnknownFilter.py
            │      __init__.py
            │
            ├─Preprocess
            │      normalizeRecord.json
            │      NormalizeValueCalculate.py
            │      PreprocessMethod.py
            │      SelectNormalization.py
            │      __init__.py
            │
            └─ResultStorage
                    ConfigResultStorage.py
                    CsvModule.py
                    SaveResult.py
                    SaveWeight.py
                    SelectStorageMethod.py
                    __init__.py




## Edit record
- 每次改版，請延續此表格紀錄修改內容

| Branch name       | Push Date       | Editor                    |Editor server         | comment                              |
|-------------------|-----------------|---------------------------|----------------------|--------------------------------------|
| OtisChang_0304    | 2022.03.04 | OtisChang           | 39394 | 合併WeiShan的程式碼，將多模型版本整併 |
| OtisChang_0307    | 2022.03.09 | OtisChang           | 39394 | 1. 已測試多模型載入預權重訓練<br>2. 修正valid無法使用train正規化值的問題<br>3. 修正相關顯示問題<br>4. 後處理過門程式與方法主程式拆分<br>5. show_wrong_file 模組修正完成<br>6. 標準差計算模組batch size會些微影響計算的結果，待修正 |
| v1.0.0            | 2022.03.11 | OtisChang           | 39394 |  |
| WeiShan_20220309  | 2022.04.07 | WeiShan             | 4318  | 新增前處理方法，尚未測試 |
| OtisChang_20220407| 2022.04.15 | OtisChang           | 39394 | 1. 新增資料擴增方法，並完成參數型態與極限值測試<br>2. 修改 SelectTransform |
| WeiShan_20220407  | 2022.04.15 | WeiShan             | 4318  | 1. 新增前處理方法並做完單元測試<br>2. 新增SaveUnknown到ResultStorage模組 <br> |
| OtisChang_20220418| 2022.04.21 | OtisChang           | 39394 | 1. 合併前處理及資料擴增方法並處理順序問題 (SelectTransform)<br>2. 資料擴增獨立成單一function (SelectTransform) <br>3. 處理前處理ColoJitter參數random問題 <br>4. 修正coding culture問題 (fstring: '', dict: ""等) <br>5.簡少valid記憶體使用 (MainProcess) <br>6. 新增onnx自動打包模組功能 (ResultStorage) <br>7. 整併 save_epoch_acc_json 模組進 SaveAcc.py <br>8. 整併SaveUnknown.py|
| v1.1.0            | 2022.04.21 | OtisChang           | 39394 |  |
| WeiShan_20220421  | 2022.04.27 | WeiShan             | 4318  | 升級unknown的csv儲存選擇功能 |
| OtisChang_20220428| 2022.05.06 | OtisChang           | 39394 | 1. unknown 整併 <br>2. showRate 之 OK/NG 改為可輸入多類 <br>3.  saveAcc 去除多餘欄位 + 開switch + 訓練代數太少問題修正 <br>4. cfMatrix 訓練代數太少問題修正 |
| v1.1.1            | 2022.05.06 | OtisChang           | 39394 | [說明文件](https://hackmd.io/@ShanYang/ByUEETgUc/https%3A%2F%2Fhackmd.io%2F%40ShanYang%2FByndETxUq) |
| OtisChang_20220506| 2022.05.20 | OtisChang           | 39394 | 1. onnx_pack 測試，須給定 channel 和 input size 初始值 <br>2. CustomModel(ScriptModel) 可載入進行 retrain / test /inference <br>3. 新訓練時，權重儲存可選擇 DictPth / ScriptPth / Onnx <br>4. checkpoint 新增紀錄 optimizer 狀態 <br>5. normalize 儲存模組，提供使用者 4 種內建值，也可記錄使用者輸入或是自動計算 <br>6. 資料擴增模組中 4 個使用 RandomAffine 之方法多開出自訂顏色填充功能 <br>7. SaveOnnxModel 併入 SaveWeight 模組中 |
| WeiShan_20220506  | 2022.05.19 | WeiShan             | 4318  | **saveResult功能合併：**<br> 1. unknownFiler <br>2. savePredictResult <br>3. wrongFile  <br> **confidence_threshold 新增多類別多卡控** |
| OtisChang_20220523| 2022.05.23 | OtisChang, WeiShan  | 39394, 4318 | 1. 修改 resnet 中參數格式，將 bool 改成 None 來判斷，確保 ScriptPth 正常儲存(威杉) <br>2. evalation 劃分出去(威杉) <br>3. normalization 模組移到前處理，時間戳記改UUID形式 <br>4. 測試所有模型儲存 ScriptPth 是否正常，測試 ScriptPth 準確率正確 |
| v1.1.2            | 2022.05.23 | OtisChang           | 39394 |  |
| OtisChang_20220524| 2022.05.24 | OtisChang           | 39394 | 整併A model<br>1. 混淆矩陣除了顯示百分比還可選擇顯示資料數量 |
| WeiShan_20220520  | 2022.05.24 | WeiShan             | 4318  | 新增MAMA的模型(csp_resnet18) |
| v1.1.3            | 2022.05.30 | ShanYang            | 39394 | 1. [說明文件](http://mamcwiki/books/d6baf/chapter/v113) <br>2. System Test，相關Bug Report見Issue |
| OtisChang_20220525| 2022.05.27 | OtisChang           | 39394 | 1. 修正系統測試問題(resize的防呆機制) |
| WeiShan_20220524  | 2022.06.07 | WeiShan             | 4318  | 新增csp_restnet系列：[文件說明](https://hackmd.io/@gamania6503/BkQAxxmd5/edit) |
| ShanYang_20220530 | 2022.06.08 | ShanYang            | 39394 | 整合Evaluation: Acc/ ClsAcc/ ClsNum/ Leakage/ Overkill/ DefectAcc/ DrawPlot |
| ShanYang_20220609 | 2022.06.15 | ShanYang            | 39394 | 1. 整合Postprocess: ConfidenceFilter/ UnknownFilter <br>2. 整合ResultStorage: saveResult|
| v1.1.4            | 2022.06.15 | ShanYang            | 39394 | 1. [說明文件](http://mamcwiki/books/d6baf/chapter/v114) <br>2. System Test，相關Bug Report見Issue |
| OtisChang_20220531| 2022.06.16 | OtisChang           | 39394 | 1. 新平台需求 Part 1-1 (合併解決衝突但 develop 並未更版)|
| WeiShan_20220613  | 2022.06.21 | WeiShan             | 4318  | 新增資料清理模組, [說明文件](https://hackmd.io/@gamania6503/BJLbWcVwc/edit)|
| v1.2.0            | 2022.07.01 | WeiShan             | 4318  | |
| OtisChang_20220531| 2022.07.05 | OtisChang           | 39394 | 1. 新平台需求 Part 2-1 (合併解決衝突但 develop 並未更版)|
| OtisChang_20220531| 2022.07.11 | OtisChang           | 39394 | 1. 新平台需求 Part 2-2 (合併解決衝突但 develop 並未更版) <br> 2. 新平台需求 Part 1, 2 完成|
| ShanYang_20220711 | 2022.07.12 | ShanYang, OtisChang | 39394 | 1. 後處理參數移出結果儲存模組 <br> 2. 除 0 bug 修復|
| v1.3.0            | 2022.07.12 | OtisChang           | 39394 | |
| OtisChang_20220712| 2022.07.19 | OtisChang           | 39394 | 1. V1.3.0 架構修改 <br> 2. onnx, scriptPth 轉換流程獨立 <br> 3. 自動生成 .ini <br> 4. utils下新增資料夾結構AiResource|
| WeiShan_20220621  | 2022.07.19 | WeiShan             | 4318  | 物件偵測基本模塊 (包含: 訓練、測試、推論)|
| v2.0.0            | 2022.07.20 | WeiShan             | 4318  | |
| OtisChang_20220719| 2022.07.26 | OtisChang           | 39394 | 1. (7/21) 解決更換 miniforge 導致的 matplotlib 無法使用 Qt 畫圖問題 <br>2. (7/26) V1.3.0 架構修改完成 <br>3. (7/26) 自動生成.ini <br>4. (7/26) onnx 及 scriptPth 轉換流程獨立 <br>5. 新增一資料夾 AiResource <br>6. 混淆矩陣除以 0 問題解決 <br>7. (v1.4.0) 傳入字串呼叫 function & 自由更換前處理、資料擴增順序 <br>8. (v1.4.0) 因應前處理、資料擴增參數格式修改，set_normalize 功能修改 <br>9. (v1.4.0) SelectTransform 架構及串接修改 <br>10. (v1.4.0) 新增 PreprocessMethod 及 AugmentationMethod，繼承 pytorch 方法並改寫 <br>11. (code review) ResultStorage, Evaluation, PostProcess 改list和大寫駝峰 <br>12. (code review) Config.json 順序改為使用流程 <br>13. (code review) MainCls.py 新增 Deployment 獨立功能|
| v2.0.0 (v1.4.0 更新) | 2022.08.09 | OtisChang             | 39394  | |
| WeiShan_20220720 | 2022.08.09 | WeiShan|4318|1. 結構調整為與檢測模組相同 <br>2. 將物件偵測config改json並做順序修改 <br>3. 物件偵測模組化 <br>4. 新增結果儲存功能 <br> 5. 新增混淆矩陣功能 <br>6. 部分模塊使用分類模組的套件 <br> 7. 解決 【CR.20220809】v2.0.1、【CR.20220719】的bug issues問題 
| v2.0.1 | 2022.08.10 | WeiShan| 4318||
| OtisChang_20220809   | 2022.08.09 | OtisChang             | 39394  | 1. config switch 改為 order <br>2. config 全部改回 dict <br>3. SelectTransform.py 修改讀取方式，新增 dict 排序功能 <br>4. 主流程及相關程式修改，補上新註解 |
| WeiShan_20220811 | 2022.08.19| WeiShan | 4318 | 1. DataSplit 自動將切分完的結果資料移動到config中的train, test, valid的使用路徑下 <br>2. AnnotationTransfer 不需要再輸入imageShape尺寸, 會自動抓路徑下的影像判別影像大小|
| v2.0.2 | 2022.08.19 | WeiShan | 4318 | |.
| WeiShan_20220819 | 2022.08.23 | WeiShan | 4318 | 1.config 父類別(class)建立<br>2. config 子類別(class)建立-偵測 <br>3. config 子類別(class)建立 - 分類|
| OtisChang_20220809 | 2022.08.23 | OtisChang | 39394 | 1. config.json 參數名稱修改及相關程式修改<br>2. config 子類別(class)建立 - 分類<br>3. v2.1.0 套件資料夾架構拆分及整併|
| WeiShan_20220823 | 2022.08.25 | WeiShan | 4318 | 1. v2.1.0 套件資料夾拆分與整併修改完成 <br> 2. 分類與偵測模組結構確立 |
| v2.1.0 | 2022.08.25 | WeiShan | 4318 | |
| WeiShan_20220825 | 2022.08.30 | WeiShan | 4318 | 1. datasetClean修改成使用selectDatasetCleanMethod.py模塊做使用 |
| v2.1.1 | 2022.08.30 | WeiShan | 4318　| |
| WeiShan_20220830 | 2022.09.01 | WeiShan | 39394 | 1. sampleInference exe撰寫 <br>2. sampleInference exe打包, 檔案皆在mamcdatabase裡面 <br>3. deploy功能撰寫 <br>4. pyd自動打包功能撰寫|
| v2.1.2 | 2022.09.14 | WeiShan | 4318 | |
| WeiShan_20220920 | 2022.09.21 | WeiShan | 4318 | 1. 刪除annotation未使用到的參數 <br>2. 修改註解|
| v2.1.3 | 2022.09.21 | WeiShan | 4318 | | 
| v2.1.4 | 2022.10.24 | ChadYCLu | 39394 | 1. 調整pretrain功能,改為可以直接讀取輸出層前半部權重,N個分類都可以使用 <br> 2. Test、Inference 加入resize調整的修正 <br> 3. BUG修正
| v2.1.4 | 2022.11.16 | OtisChang | 39394 | 1. Bug 修正(生成 .ini 順序問題修正) |
| v2.2.0 | 2022.12.05 | TomWCHsu | 4318 | 1. Bug 修正(權重綁定GPU id) <br> 2. 根據User硬體，權重自動切換GPU、CPU inference <br> 3. 新增五隻Detection模型 ssdlite320_mobilenet_v3_large、ssd300_vgg16、fasterrcnn_mobilenet_v3_large_320_fpn、fasterrcnn_mobilenet_v3_large_fpn、fasterrcnn_resnet50_fpn|
| v2.3.0 | 2023.02.01 | TomWCHsu | 4318 | 1. 新增 Preprocess & Augmentation|
