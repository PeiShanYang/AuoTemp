from utils import MAMC_model
import argparse

# python main.py --image_folder_path=./dataset --model_path=./sample.onnx --unknown_threshold=0 --csv_name=sample --cfg sample.json --ini sample.ini
parser = argparse.ArgumentParser(description='please enter image_folder_path, model_path, unknown_threshold and csv_name')
parser.add_argument('--image_folder_path', type=str)
parser.add_argument('--model_path', type=str)
parser.add_argument('--unknown_threshold', type=float, default=0.99)
parser.add_argument('--csv_name', type=str, default='00000000000000')
parser.add_argument('--cfg', type=str)
parser.add_argument('--ini', type=str)

if __name__ == '__main__':
    arg = parser.parse_args()
    finalResult = MAMC_model.inference(arg.image_folder_path, arg.unknown_threshold, arg.model_path, arg.csv_name, arg.cfg, arg.ini)
    for i in range(len(finalResult['FileName'])):
        print("FileName: {:20s} / Prediction: {:15s} / Prediction Name: {:15s}".format(finalResult['FileName'][i], finalResult['Prediction'][i], finalResult['Prediction_Name'][i]))
        print("Confidence: {}".format(finalResult['Confidence'][i]))