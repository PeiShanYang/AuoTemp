from typing import List, Tuple, Dict, Optional, Union

import torch
import torchvision
from torch import nn, Tensor
from torchvision.transforms import functional as F, InterpolationMode, transforms as T
from PIL import Image

# def _flip_coco_person_keypoints(kps, width):
#     flip_inds = [0, 2, 1, 4, 3, 6, 5, 8, 7, 10, 9, 12, 11, 14, 13, 16, 15]
#     flipped_data = kps[:, flip_inds]
#     flipped_data[..., 0] = width - flipped_data[..., 0]
#     # Maintain COCO convention that if visibility == 0, then x, y = 0
#     inds = flipped_data[..., 2] == 0
#     flipped_data[inds] = 0
#     return flipped_data

def _is_tensor_a_torch_image(x: Tensor) -> bool:
    return x.ndim >= 2

def _assert_image_tensor(img: Tensor) -> None:
    if not _is_tensor_a_torch_image(img):
        raise TypeError("Tensor is not a torch image.")

def get_dimensions(img: Tensor) -> List[int]:
    _assert_image_tensor(img)
    channels = 1 if img.ndim == 2 else img.shape[-3]
    height, width = img.shape[-2:]
    return [channels, height, width]

class Compose:
    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, image, target):
        for t in self.transforms:
            image, target = t(image, target)
        return image, target

class RandomHorizontalFlip(T.RandomHorizontalFlip):
    """
    inherit RandomHorizontalFlip in transforms and process the parameters
    """
    def __init__(self, probability, **kwarg):
        super().__init__(p=probability, **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.hflip(image)
            if target.get('boxes') is not None:
                _, _, width = get_dimensions(image)
                target["boxes"][:, [0, 2]] = width - target["boxes"][:, [2, 0]]
                # if "masks" in target:
                #     target["masks"] = target["masks"].flip(-1)
                # if "keypoints" in target:
                #     keypoints = target["keypoints"]
                #     keypoints = _flip_coco_person_keypoints(keypoints, width)
                #     target["keypoints"] = keypoints
        return image, target

class RandomVerticalFlip(T.RandomVerticalFlip):
    """
    inherit RandomVerticalFlip in transforms and process the parameters
    """
    def __init__(self, probability, **kwarg):
        super().__init__(p=probability, **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.vflip(image)
            if target.get('boxes') is not None:
                _, height, _ = get_dimensions(image)
                target["boxes"][:, [1, 3]] = height - target["boxes"][:, [3, 1]]
        return image, target

class RandomEqualize(T.RandomEqualize):
    """
    inherit Equalize in transforms and process the parameters
    """
    def __init__(self, probability, **kwarg):
        super().__init__(p=probability, **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.equalize(image)
        return image, target

class RandomPosterize(T.RandomPosterize):
    """
    inherit Posterize in transforms and process the parameters
    """
    def __init__(self, bits, probability, **kwarg):
        super().__init__(bits=bits, p=probability, **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.posterize(image, self.bits)
        return image, target

class RandomSolarize(T.RandomSolarize):
    """
    inherit Solarize in transforms and process the parameters
    """
    def __init__(self, threshold, probability, **kwarg):
        super().__init__(threshold=threshold, p=probability, **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.solarize(image, self.threshold)
        return image, target

class RandomAdjustSharpness(T.RandomAdjustSharpness):
    """
    inherit AdjustSharpness in transforms and process the parameters
    """
    def __init__(self, sharpnessFactor, probability, **kwarg):
        super().__init__(sharpness_factor=sharpnessFactor, p=probability, **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.adjust_sharpness(image, self.sharpness_factor)
        return image, target

class RandomAutocontrast(T.RandomAutocontrast):
    """
    inherit Autocontrast in transforms and process the parameters
    """
    def __init__(self, probability, **kwarg):
        super().__init__(p=probability, **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.autocontrast(image)
        return image, target

class RandomErasing(T.RandomErasing):
    """
    inherit RandomErasing in transforms and process the parameters
    """
    def __init__(self, probability, value, **kwarg):
        # valueRGB = [x / 255 for x in value]
        super().__init__(p=probability, value=value, **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        x, y, h, w, v = self.get_params(image, scale=self.scale, ratio=self.ratio, value=self.value)
        if torch.rand(1) < self.p:
            image = F.erase(image, x, y, h, w, v, self.inplace)
        return image, target

class RandomBrightness(T.ColorJitter):
    """
    inherit RandomBrightness in transforms and process the parameters
    """
    def __init__(self, probability, brightness, **kwarg):
        super().__init__(brightness=[brightness[0], brightness[1]], **kwarg)
        self.p = probability

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.adjust_brightness(image, float(torch.empty(1).uniform_(self.brightness[0], self.brightness[1])))
        return image, target

class RandomContrast(T.ColorJitter):
    """
    inherit RandomContrast in transforms and process the parameters
    """
    def __init__(self, probability, contrast, **kwarg):
        super().__init__(contrast=[contrast[0], contrast[1]], **kwarg)
        self.p = probability

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.adjust_contrast(image, float(torch.empty(1).uniform_(self.contrast[0], self.contrast[1])))
        return image, target

class RandomSaturation(T.ColorJitter):
    """
    inherit RandomSaturation in transforms and process the parameters
    """
    def __init__(self, probability, saturation, **kwarg):
        super().__init__(saturation=[saturation[0], saturation[1]], **kwarg)
        self.p = probability

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.adjust_saturation(image, float(torch.empty(1).uniform_(self.saturation[0], self.saturation[1])))
        return image, target

class RandomHue(T.ColorJitter):
    """
    inherit RandomHue in transforms and process the parameters
    """
    def __init__(self, probability, hue, **kwarg):
        super().__init__(hue=[hue[0], hue[1]], **kwarg)
        self.p = probability

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if torch.rand(1) < self.p:
            image = F.adjust_hue(image, float(torch.empty(1).uniform_(self.hue[0], self.hue[1])))
        return image, target

class PILToTensor(nn.Module):
    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        image = F.pil_to_tensor(image)
        return image, target

class ConvertImageDtype(nn.Module):
    def __init__(self, dtype: torch.dtype) -> None:
        super().__init__()
        self.dtype = dtype

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        image = F.convert_image_dtype(image, self.dtype)
        return image, target


class RandomIoUCrop(nn.Module):
    """
    inherit RandomIoUCrop in transforms and process the parameters
    """
    def __init__(
        self,
        minScale: float = 0.3,
        maxScale: float = 1.0,
        minAspectRatio: float = 0.5,
        maxAspectRatio: float = 2.0,
        samplerOption: Optional[List[float]] = None,
        trials: int = 40
    ):
        super().__init__()
        # Configuration similar to https://github.com/weiliu89/caffe/blob/ssd/examples/ssd/ssd_coco.py#L89-L174
        self.min_scale = minScale
        self.max_scale = maxScale
        self.min_aspect_ratio = minAspectRatio
        self.max_aspect_ratio = maxAspectRatio
        if samplerOption is None:
            samplerOption = [0.0, 0.1, 0.3, 0.5, 0.7, 0.9, 1.0]
        self.options = samplerOption
        self.trials = trials

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if target is None:
            raise ValueError("The targets can't be None for this transform.")

        if isinstance(image, torch.Tensor):
            if image.ndimension() not in {2, 3}:
                raise ValueError(f"image should be 2/3 dimensional. Got {image.ndimension()} dimensions.")
            elif image.ndimension() == 2:
                image = image.unsqueeze(0)

        _, orig_h, orig_w = get_dimensions(image)

        while True:
            # sample an option
            idx = int(torch.randint(low=0, high=len(self.options), size=(1,)))
            min_jaccard_overlap = self.options[idx]
            if min_jaccard_overlap >= 1.0:  # a value larger than 1 encodes the leave as-is option
                return image, target

            for _ in range(self.trials):
                # check the aspect ratio limitations
                r = self.min_scale + (self.max_scale - self.min_scale) * torch.rand(2)
                new_w = int(orig_w * r[0])
                new_h = int(orig_h * r[1])
                aspect_ratio = new_w / new_h
                if not (self.min_aspect_ratio <= aspect_ratio <= self.max_aspect_ratio):
                    continue

                # check for 0 area crops
                r = torch.rand(2)
                left = int((orig_w - new_w) * r[0])
                top = int((orig_h - new_h) * r[1])
                right = left + new_w
                bottom = top + new_h
                if left == right or top == bottom:
                    continue

                # check for any valid boxes with centers within the crop area
                cx = 0.5 * (target["boxes"][:, 0] + target["boxes"][:, 2])
                cy = 0.5 * (target["boxes"][:, 1] + target["boxes"][:, 3])
                is_within_crop_area = (left < cx) & (cx < right) & (top < cy) & (cy < bottom)
                if not is_within_crop_area.any():
                    continue

                # check at least 1 box with jaccard limitations
                boxes = target["boxes"][is_within_crop_area]
                ious = torchvision.ops.boxes.box_iou(
                    boxes, torch.tensor([[left, top, right, bottom]], dtype=boxes.dtype, device=boxes.device)
                )
                if ious.max() < min_jaccard_overlap:
                    continue

                # keep only valid boxes and perform cropping
                target["boxes"] = boxes
                target["labels"] = target["labels"][is_within_crop_area]
                target["boxes"][:, 0::2] -= left
                target["boxes"][:, 1::2] -= top
                target["boxes"][:, 0::2].clamp_(min=0, max=new_w)
                target["boxes"][:, 1::2].clamp_(min=0, max=new_h)
                image = F.crop(image, top, left, new_h, new_w)

                return image, target


# class RandomZoomOut(nn.Module):
#     def __init__(
#         self, 
#         fill: Optional[List[float]] = None, 
#         sideRange: Tuple[float, float] = (1.0, 4.0), 
#         probability: float = 0.5,
#         **kwarg
#     ):
#         super().__init__(**kwarg)
#         if fill is None:
#             fill = [0.0, 0.0, 0.0]
#         self.fill = fill
#         self.side_range = sideRange
#         if sideRange[0] < 1.0 or sideRange[0] > sideRange[1]:
#             raise ValueError(f"Invalid canvas side range provided {sideRange}.")
#         self.p = probability

#     @torch.jit.unused
#     def _get_fill_value(self, is_pil):
#         # type: (bool) -> int
#         # We fake the type to make it work on JIT
#         return tuple(int(x) for x in self.fill) if is_pil else 0

#     def forward(
#         self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
#     ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
#         if isinstance(image, torch.Tensor):
#             if image.ndimension() not in {2, 3}:
#                 raise ValueError(f"image should be 2/3 dimensional. Got {image.ndimension()} dimensions.")
#             elif image.ndimension() == 2:
#                 image = image.unsqueeze(0)

#         if torch.rand(1) >= self.p:
#             return image, target

#         _, orig_h, orig_w = get_dimensions(image)

#         r = self.side_range[0] + torch.rand(1) * (self.side_range[1] - self.side_range[0])
#         canvas_width = int(orig_w * r)
#         canvas_height = int(orig_h * r)

#         r = torch.rand(2)
#         left = int((canvas_width - orig_w) * r[0])
#         top = int((canvas_height - orig_h) * r[1])
#         right = canvas_width - (left + orig_w)
#         bottom = canvas_height - (top + orig_h)

#         if torch.jit.is_scripting():
#             fill = 0
#         else:
#             fill = self._get_fill_value(F._is_pil_image(image))

#         image = F.pad(image, [left, top, right, bottom], fill=fill)
#         if isinstance(image, torch.Tensor):
#             # PyTorch's pad supports only integers on fill. So we need to overwrite the colour
#             v = torch.tensor(self.fill, device=image.device, dtype=image.dtype).view(-1, 1, 1)
#             image[..., :top, :] = image[..., :, :left] = image[..., (top + orig_h) :, :] = image[
#                 ..., :, (left + orig_w) :
#             ] = v

#         if target.get('boxes') is not None:
#             target["boxes"][:, 0::2] += left
#             target["boxes"][:, 1::2] += top

#         return image, target


# class RandomPhotometricDistort(nn.Module):
#     def __init__(
#         self,
#         contrast: Tuple[float] = (0.0, 0.0),
#         saturation: Tuple[float] = (0.0, 0.0),
#         hue: Tuple[float] = (0.0, 0.0),
#         brightness: Tuple[float] = (0.0, 0.0),
#         probability: float = 0.5
#     ):
#         super().__init__()
#         self._brightness = T.ColorJitter(brightness=brightness)
#         self._contrast = T.ColorJitter(contrast=contrast)
#         self._hue = T.ColorJitter(hue=hue)
#         self._saturation = T.ColorJitter(saturation=saturation)
#         self.p = probability

#     def forward(
#         self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
#     ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
#         if isinstance(image, torch.Tensor):
#             if image.ndimension() not in {2, 3}:
#                 raise ValueError(f"image should be 2/3 dimensional. Got {image.ndimension()} dimensions.")
#             elif image.ndimension() == 2:
#                 image = image.unsqueeze(0)

#         r = torch.rand(7)

#         if r[0] < self.p:
#             image = self._brightness(image)

#         contrast_before = r[1] < 0.5
#         if contrast_before:
#             if r[2] < self.p:
#                 image = self._contrast(image)

#         if r[3] < self.p:
#             image = self._saturation(image)

#         if r[4] < self.p:
#             image = self._hue(image)

#         if not contrast_before:
#             if r[5] < self.p:
#                 image = self._contrast(image)

#         if r[6] < self.p:
#             channels, _, _ = get_dimensions(image)
#             permutation = torch.randperm(channels)

#             is_pil = F._is_pil_image(image)
#             if is_pil:
#                 image = F.pil_to_tensor(image)
#                 image = F.convert_image_dtype(image)
#             image = image[..., permutation, :, :]
#             if is_pil:
#                 image = F.to_pil_image(image)

#         return image, target

class ScaleJitter(nn.Module):
    """Randomly resizes the image and its bounding boxes  within the specified scale range.
    The class implements the Scale Jitter augmentation as described in the paper
    `"Simple Copy-Paste is a Strong Data Augmentation Method for Instance Segmentation" <https://arxiv.org/abs/2012.07177>`_.

    Args:
        target_size (tuple of ints): The target size for the transform provided in (height, weight) format.
        scale_range (tuple of ints): scaling factor interval, e.g (a, b), then scale is randomly sampled from the
            range a <= scale <= b.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.BILINEAR``.
    """

    def __init__(
        self,
        targetSize: Tuple[int, int],
        scaleRange: Tuple[float, float] = (0.1, 2.0),
        interpolation: InterpolationMode = InterpolationMode.BILINEAR,
        **kwarg
    ):
        super().__init__(**kwarg)
        self.target_size = targetSize
        self.scale_range = scaleRange
        self.interpolation = getattr(InterpolationMode, interpolation)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        if isinstance(image, torch.Tensor):
            if image.ndimension() not in {2, 3}:
                raise ValueError(f"image should be 2/3 dimensional. Got {image.ndimension()} dimensions.")
            elif image.ndimension() == 2:
                image = image.unsqueeze(0)

        _, orig_height, orig_width = get_dimensions(image)

        scale = self.scale_range[0] + torch.rand(1) * (self.scale_range[1] - self.scale_range[0])
        r = min(self.target_size[1] / orig_height, self.target_size[0] / orig_width) * scale
        new_width = int(orig_width * r)
        new_height = int(orig_height * r)

        image = F.resize(image, [new_height, new_width], interpolation=self.interpolation)

        if target.get('boxes') is not None:
            target["boxes"][:, 0::2] *= new_width / orig_width
            target["boxes"][:, 1::2] *= new_height / orig_height
            if "masks" in target:
                target["masks"] = F.resize(
                    target["masks"], [new_height, new_width], interpolation=InterpolationMode.NEAREST
                )

        return image, target


class FixedSizeCrop(nn.Module):
    """
    inherit FixedSizeCrop in transforms and process the parameters
    """
    def __init__(
        self, 
        size, 
        fill=0, 
        paddingMode="constant",
        **kwarg
    ):
        super().__init__(**kwarg)
        size = tuple(T._setup_size(size, error_msg="Please provide only two dimensions (h, w) for size."))
        self.crop_height = size[0]
        self.crop_width = size[1]
        self.fill = sum(fill)/3  # TODO: Fill is currently respected only on PIL. Apply tensor patch.
        self.padding_mode = paddingMode

    def _pad(self, img, target, padding):
        # Taken from the functional_tensor.py pad
        if isinstance(padding, int):
            pad_left = pad_right = pad_top = pad_bottom = padding
        elif len(padding) == 1:
            pad_left = pad_right = pad_top = pad_bottom = padding[0]
        elif len(padding) == 2:
            pad_left = pad_right = padding[0]
            pad_top = pad_bottom = padding[1]
        else:
            pad_left = padding[0]
            pad_top = padding[1]
            pad_right = padding[2]
            pad_bottom = padding[3]

        padding = [pad_left, pad_top, pad_right, pad_bottom]
        img = F.pad(img, padding, self.fill, self.padding_mode)
        if target.get('boxes') is not None:
            target["boxes"][:, 0::2] += pad_left
            target["boxes"][:, 1::2] += pad_top
            if "masks" in target:
                target["masks"] = F.pad(target["masks"], padding, 0, "constant")

        return img, target

    def _crop(self, img, target, top, left, height, width):
        img = F.crop(img, top, left, height, width)
        if target.get('boxes') is not None:
            boxes = target["boxes"]
            boxes[:, 0::2] -= left
            boxes[:, 1::2] -= top
            boxes[:, 0::2].clamp_(min=0, max=width)
            boxes[:, 1::2].clamp_(min=0, max=height)

            is_valid = (boxes[:, 0] < boxes[:, 2]) & (boxes[:, 1] < boxes[:, 3])

            target["boxes"] = boxes[is_valid]
            target["labels"] = target["labels"][is_valid]
            if "masks" in target:
                target["masks"] = F.crop(target["masks"][is_valid], top, left, height, width)

        return img, target

    def forward(self, img, target=None):
        _, height, width = get_dimensions(img)
        new_height = min(height, self.crop_height)
        new_width = min(width, self.crop_width)

        if new_height != height or new_width != width:
            offset_height = max(height - self.crop_height, 0)
            offset_width = max(width - self.crop_width, 0)

            r = torch.rand(1)
            top = int(offset_height * r)
            left = int(offset_width * r)

            img, target = self._crop(img, target, top, left, new_height, new_width)

        pad_bottom = max(self.crop_height - new_height, 0)
        pad_right = max(self.crop_width - new_width, 0)
        if pad_bottom != 0 or pad_right != 0:
            img, target = self._pad(img, target, [0, 0, pad_right, pad_bottom])

        return img, target


class RandomShortestSize(nn.Module):
    """
    inherit FixedSizeCrop in transforms and process the parameters
    """
    def __init__(
        self,
        minSize: Union[List[int], Tuple[int], int],
        maxSize: int,
        interpolation: InterpolationMode,
        **kwarg
    ):
        super().__init__(**kwarg)
        self.min_size = [minSize] if isinstance(minSize, int) else list(minSize)
        self.max_size = maxSize
        self.interpolation = getattr(InterpolationMode, interpolation)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        _, orig_height, orig_width = get_dimensions(image)

        min_size = self.min_size[torch.randint(len(self.min_size), (1,)).item()]
        r = min(min_size / min(orig_height, orig_width), self.max_size / max(orig_height, orig_width))

        new_width = int(orig_width * r)
        new_height = int(orig_height * r)

        image = F.resize(image, [new_height, new_width], interpolation=self.interpolation)

        if target.get('boxes') is not None:
            target["boxes"][:, 0::2] *= new_width / orig_width
            target["boxes"][:, 1::2] *= new_height / orig_height
            if "masks" in target:
                target["masks"] = F.resize(
                    target["masks"], [new_height, new_width], interpolation=InterpolationMode.NEAREST
                )

        return image, target