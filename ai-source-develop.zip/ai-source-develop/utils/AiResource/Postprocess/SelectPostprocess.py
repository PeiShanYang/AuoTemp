# -*- coding: utf-8 -*-

"""
Created on Jun Tue 14 22:00:00 2022
"""
from ..ModelService.PytorchDetectionModel.ConfigPreprocess import PreprocessPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPostprocess import \
    PostprcessPara
from .ConfigPostprocess import PostProcessPara
from .ModulePostprocess.Cls.ConfidenceFilter import confidence_filter
from .ModulePostprocess.Cls.UnknownFilter import unknown_filter
from .ModulePostprocess.Det.ScaleBboxImage import scale_bbox_image

def cls_select_postprocess(resultList:list, postProcessPara:PostProcessPara) -> list:
    """
    According to configs in ConfigPostprocess, select the post processing method.

    Args:
        resultList: result list form model
        postProcessPara: include all post process filters parameters
    Return:
        resultList: after post-processing
    """
    if postProcessPara.confidenceFilter["order"]:
        resultList = confidence_filter(resultList, **postProcessPara.confidenceFilter["parameters"])
    if postProcessPara.unknownFilter["order"]:
        resultList = unknown_filter(resultList, **postProcessPara.unknownFilter["parameters"])

    return resultList

def det_select_postprocess(resultList:list, postProcessPara:PostprcessPara, prePara: PreprocessPara) -> list:
    """
    According to configs in ConfigPostprocess, select the post processing method.

    Args:
        resultList: result list form model
        postProcessPara: include all post process filters parameters
        prePara: Parameters include all preprocess methods
    Return:
        resultList: after post-processing
    """
    if postProcessPara.unResize["order"]:
        if prePara.preprocessPara['Resize']['order'] > 0:
            resultList = scale_bbox_image(resultList, prePara)
        else:
            raise BaseException('You did not resize pic before, it can not allow using unresize')

    return resultList