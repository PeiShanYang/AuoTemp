import numpy as np
import torch
from ..DrawPlot import plot_confusion_matrix
import os 

def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath: the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)  

class ConfusionMatrix:
    def __init__(self, labelClass, conf=0.25, iouThres=0.5) -> None:
        self.matrix = np.zeros((len(labelClass)+1, len(labelClass)+1))
        self.labelClass = labelClass
        self.ClassNumber = len(labelClass)
        self.conf = conf
        self.iouThres = iouThres
        pass

    def process(self, predictions, targets):
        """
        Return intersection-over-union (Jaccard index) of boxes.
        Both sets of boxes are expected to be in (x1, y1, x2, y2) format.
        Arguments:
            predictions (Array[N, 6]), x1, y1, x2, y2, conf, class
            targets (Array[M, 5]), class, x1, y1, x2, y2
        Returns:
            None, updates confusion matrix accordingly
        """
        predictions = torch.cat((predictions['boxes'], 
                                    torch.unsqueeze(predictions['scores'], 1), 
                                    torch.unsqueeze(predictions['labels'], 1)
                                ), 1).cpu()

        targets = torch.cat((torch.unsqueeze(targets['labels'], 1), targets['boxes']), 1).cpu()
        
        predictions = predictions[predictions[:, 4] > self.conf]
       
        gtClasses = targets[:, 0].int()
        dtClasses = predictions[:, 5].int()
        iou = self.box_iou(targets[:, 1:], predictions[:, :4])
        iouQualified = torch.where(iou > self.iouThres)    # iouQualified[0]是相對應到解答框的編號, iouQualified[1]是按照預測框的順序編號 
        
        if iouQualified[0].shape[0]:
            matches = torch.cat(
                        (torch.stack(iouQualified, 1), 
                        iou[iouQualified[0], iouQualified[1]][:, None])
                            , 1).cpu().numpy()  # [iouQualified[0] iouQualified[1] iou]
            
            if iouQualified[0].shape[0] > 1:
                # 取得最終每種預測框與所有gt框中iou最大的那個, 預測框唯一且gt框也唯一
                matches = matches[matches[:, 2].argsort()[::-1]]  # 依照iou排序
                matches = matches[np.unique(matches[:, 1], return_index=True)[1]]   # 取第二列中各框首次出現(不同預測框)的行(即每一种預測框中iou最大的那個)
                matches = matches[matches[:, 2].argsort()[::-1]]
                matches = matches[np.unique(matches[:, 0], return_index=True)[1]]   # 取第一列中各框首次出現(不同gt框)的行(即每一種gt框中iou最大的那个)   
        else:
            matches = np.zeros((0, 3))

        hasMatches = matches.shape[0] > 0
        m0, m1, _ = matches.transpose().astype(int) # m0: 滿足條件(正样本)的gt框index, m1: 滿足條件(正样本)的pred框index

        for i, gtClass in enumerate(gtClasses):
            gtMatchOrNot = m0 == i
            if hasMatches and sum(gtMatchOrNot) == 1:
                # sum(gtMatchOrNot)=1 說明gt[i]這個真實框被預測到了, 但不代表一定是類別相同, 可能是TP或者FP
                self.matrix[gtClass, dtClasses[m1[gtMatchOrNot]]] += 1  # correct TP or FP
            else:
                self.matrix[gtClass, 0] += 1  # background FP
                # self.matrix[self.ClassNumber, gtClass] += 1  # background FP

        if hasMatches:
            for i, dc in enumerate(dtClasses):
                if not any(m1 == i):
                    self.matrix[0, dc] += 1  # background FN
                    # self.matrix[dc, self.ClassNumber] += 1  # background FN

    def matrix(self):
        return self.matrix

    def tp_fp_fn(self):
        tp = self.matrix.diagonal()  # true positives
        fp = self.matrix.sum(0) - tp  # false positives
        fn = self.matrix.sum(1) - tp  # false negatives (missed detections)
        return tp[:-1], fp[:-1], fn[:-1]  # remove background class

    def print(self):
        for i in range(self.ClassNumber + 1):
            print(' '.join(map(str, self.matrix[i])))

    @classmethod
    def box_iou(cls, box1, box2, eps=1e-7):
        # https://github.com/pytorch/vision/blob/master/torchvision/ops/boxes.py
        """
        Return intersection-over-union (Jaccard index) of boxes.
        Both sets of boxes are expected to be in (x1, y1, x2, y2) format.
        Arguments:
            box1 (Tensor[N, 4])
            box2 (Tensor[M, 4])
        Returns:
            iou (Tensor[N, M]): the NxM matrix containing the pairwise
                IoU values for every element in boxes1 and boxes2
        """
        # inter(N,M) = (rb(N,M,2) - lt(N,M,2)).clamp(0).prod(2)
        lt = torch.max(box1[:, None, :2], box2[:, :2])  # [N,M,2]
        rb = torch.min(box1[:, None, 2:], box2[:, 2:])  # [N,M,2]
        inter = (rb - lt).clamp(0).prod(2)
        # (a1, a2), (b1, b2) = box1[:, None].chunk(2, 2), box2.chunk(2, 1)
        # inter = (torch.min(a2, b2) - torch.max(a1, b1)).clamp(0).prod(2)
        union = (cls.box_area(box1.T)[:, None] + cls.box_area(box2.T) - inter + eps)
        # IoU = inter / (area1 + area2 - inter)
        return inter / union

    @staticmethod
    def box_area(box):
        # box = xyxy(4,n)
        return (box[2] - box[0]) * (box[3] - box[1])


def draw_confusion_matrix(
    result:list, 
    classLabel:dict, 
    outputPath:str, 
    title:str='Confusion matrix', 
    showNumber:bool=False):
    """
    Draw detection confusion matrix 

    Args:
        result (list): result item. Defaults to None.
        classLabel (dict): number corresponds to category 
        outputPath (str): output path
        title (str, optional): title of the figure
        showNumber (bool, optional): if True show in number. Defaults to False.
    """
    create_folder(outputPath)
    classNameList = ['__background__', *[classLabel[i] for i in sorted(classLabel.keys())]]
    matrixResult = result[-1]['matrix']
    plot_confusion_matrix(cfMatrix=matrixResult,
                          className=classNameList,
                          showNumber=showNumber,
                          title=title,
                          outputPath=outputPath)