from numpy import ndarray
import json, os

def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath: the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)    

def write_loss_txt(outputPath:str, task:str, loss:float, epochRecord:str=None):
    """
    Args:
        outputPath (str): output path
        task (str): "Train"
        loss (float): calculate average each epoch sum of loss
        epochRecord (str, optional): record epoch. Defaults to None.
    
    Output:
        mAP record for evaluation file (txt)
    """
    create_folder(outputPath)
    if epochRecord != None:
        if int(epochRecord.split('/')[0])==1:
            with open(os.path.join(outputPath, f'{task}Loss.txt'), 'w') as f:
                f.write(f'{task} epoch {epochRecord}\n')
                f.write(f'Loss = {loss}\n')
                f.write('\n')
        else:
            with open(os.path.join(outputPath, f'{task}Loss.txt'), 'a+') as f:
                f.seek(0)
                lines = f.readlines()
                if int(lines[len(lines)-3].split()[2]) >= int(epochRecord.split('/')[0]):
                    for i in range(len(lines)-3, -1, -3):
                        if int(lines[i].split()[2]) == int(epochRecord.split('/')[0]):
                            lines = lines[0:i]
                            f.truncate(0)
                            f.writelines(lines)
                            break
                        
                f.write(f'{task} epoch {epochRecord}\n')
                f.write(f'Loss = {loss}\n')
                f.write('\n')

def write_loss_json(
    outputPath:str,
    task:str,
    loss:float,
    epochRecord:str=None
) -> None:
    """
    Save evaluation rate to json

    Args:
        outputPath: the path wants to save json file
        task: Train
        loss (float): calculate average each epoch sum of loss
        epochRecord (str, optional): record epoch. Defaults to None.

    Return:
        Save TrainLoss.json
    """

    if loss != None:
        create_folder(outputPath)
        jsonFilePath = f'./{outputPath}/{task}Loss.json'

        ##### Save each record ##### 
        epochDict = {}
        epochDict[task] = {}
        
        if loss:
            epochDict[task]["Loss"] = loss

        ##### Save record to json#####
        infoDict = {}
        if epochRecord != None:
            epoch = int(epochRecord.split('/')[0])
            totalEpoch = int(epochRecord.split('/')[1])

            if epoch > 1:
                with open(jsonFilePath, 'r') as accJson:
                    infoDict = json.load(accJson)

            epochDict["model"] = {
            "epoch": epoch,
            "total": totalEpoch
            }

        if task != 'Test':
            infoDict[str(epoch)] = epochDict
        else:
            infoDict[task] = epochDict

        with open(jsonFilePath, 'w') as accJson:
            json.dump(infoDict, accJson, indent=4)