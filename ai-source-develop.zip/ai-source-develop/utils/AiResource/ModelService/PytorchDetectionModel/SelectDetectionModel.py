import os
import torch.nn as nn
import torch
import torchvision
from torchvision.models import detection
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.models.detection.retinanet import RetinaNetHead
from torchvision.models.detection.rpn import AnchorGenerator
from .SelectBackbone import select_backbone
from .ConfigPytorchModel import ModelPara, PathPara
from utils.AiResource.AiModel import YoloModel
from typing import Tuple

def optimizer_to(optim, device):
    # move optimizer to device
    for param in optim.state.values():
        # Not sure there are any global tensors in the state dict
        if isinstance(param, torch.Tensor):
            param.data = param.data.to(device)
            if param._grad is not None:
                param._grad.data = param._grad.data.to(device)
        elif isinstance(param, dict):
            for subparam in param.values():
                if isinstance(subparam, torch.Tensor):
                    subparam.data = subparam.data.to(device)
                    if subparam._grad is not None:
                        subparam._grad.data = subparam._grad.data.to(device)
    return optim

def det_resume(
    task: str,
    model: nn.Module,
    weightPath: str,
    optimizer:torch.functional,
    scheduler:torch.functional,
    device: torch.device,
) -> nn.Module:
    """
    Resume interrupted training from epoch, optimizer, and scheduler.

    Args:
        model (nn.Module): pytorch model structure
        weightPath (str): weighted directory path for train or weighted file path for other task
        optimizer: the entire optimizer
        scheduler: scheduler use for adjusting learning rate
    Return:
        last training epoch, pytorch model, optimizer and scheduler with weight (nn.Module).
    """
    if task == 'Resume':
        ### check if checkpoint Weight exists
        if not os.path.isfile(os.path.join(weightPath,'Checkpoint.pth')):
            raise ValueError('No Checkpoint weight is existed!')

        checkpoint = torch.load(os.path.join(weightPath,'Checkpoint.pth'),
        map_location=lambda storage, loc: storage.cuda(torch.cuda._utils._get_device_index(device, True)) if torch.cuda.is_available() else storage)
        model.load_state_dict(checkpoint['model'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        optimizer = optimizer_to(optimizer, device)
        scheduler.load_state_dict(checkpoint['scheduler'])
        startEpoch = checkpoint['epoch'] + 1
        bestPrecision = checkpoint['bestEval1']
        bestRecall = checkpoint['bestEval2']
        counter = checkpoint['counter']
        return model, startEpoch, bestPrecision, bestRecall, counter, optimizer, scheduler
    else:
        startEpoch = 0
        bestPrecision = 0.0
        bestRecall = 0.0
        counter = 0
        return model, startEpoch, bestPrecision, bestRecall, counter, optimizer, scheduler

def create_base_model(    
    modelPara: ModelPara,
    pathPara: PathPara,
    task: str, 
    numClasses: int,
    )->  Tuple[nn.Module, str]:
    """
    create base model from your config 

    Args:
        modelPara  (ModelPara): Parameters include one stage, two stage, torchvision model
        pathPara   (PathPara) : Include valid, train, test, inference data Path
        task       (str)      : "Train" / "Test" / "Inference" 
        numClasses (int)      : class number

    Returns:
        model     (nn.Module): model
        modelName (str)      : model name
    """
    
    if modelPara.oneStage["switch"]:
        backbone = select_backbone(pathPara, task,
                            modelPara.oneStage["backboneStructure"], 
                            modelPara.oneStage["backbonePretrained"]
                            ).features
        backbone.out_channels = 576
        anchor_generator = AnchorGenerator(sizes=((128, 256, 512),),
                                    aspect_ratios=((0.5, 1.0, 2.0),))

        modelName = modelPara.oneStage['modelStructure']
        method = getattr(torchvision.models.detection, modelName)
        model  = method(backbone,
                    min_size=1000, max_size=1000,
                    anchor_generator=anchor_generator, 
                    num_classes=numClasses)
                    
    elif modelPara.twoStage["switch"]:
        backbone = select_backbone(pathPara, task,
                                    modelPara.twoStage["backboneStructure"], 
                                    modelPara.twoStage["backbonePretrained"]
                                    ).features
        backbone.out_channels = 576
        anchor_generator = AnchorGenerator(sizes=((128, 256, 512),),
                                    aspect_ratios=((0.5, 1.0, 2.0),))

        roi_pooler = torchvision.ops.MultiScaleRoIAlign(featmap_names=['0'],
                                                    output_size=7,
                                                    sampling_ratio=2)
        modelName = modelPara.twoStage['modelStructure']

        method = getattr(detection, modelName)
        model  = method(backbone,
                    min_size=1000, max_size=1000,
                    num_classes=numClasses,
                    rpn_anchor_generator=anchor_generator,
                    box_roi_pool=roi_pooler)

    elif modelPara.pytorchModel["switch"]:
        modelName = modelPara.pytorchModel['modelStructure']
        if modelName.startswith('yolo'):
            method = getattr(YoloModel, modelName)
        else:
            method = getattr(detection, modelName)
        model  = method(pretrained=False, pretrained_backbone=False, num_classes=numClasses)
    return model, modelName

def select_model(
    modelPara: ModelPara,
    pathPara: PathPara,
    task: str, 
    numClasses: int,
    cudaDevice: torch.device
    )-> nn.Module:
    """
    Selecting model and loading the pretrained waight

    Args:
        modelPara  (ModelPara): Parameters include one stage, two stage, torchvision model
        pathPara   (PathPara) : Include valid, train, test, inference data Path
        task       (str)      : "Train" / "Test" / "Inference" 
        numClasses (int)      : class number

    Returns:
        model (nn.Module) 
    """
    model, modelName = create_base_model(modelPara, pathPara, task, numClasses)

    # load pretrain weight or weight and setting predictor
    if task == 'Train' or task == 'Resume':
        if modelPara.pytorchModel["modelPretrained"] and not \
            modelPara.twoStage["switch"] and not \
            modelPara.oneStage["switch"]:
            model = load_model_weight(modelPara, pathPara, model, task, cudaDevice, modelPara.pytorchModel["modelPretrained"])
        
        model = select_predictor(model, modelName, numClasses)

    elif task != 'Train':
        model = select_predictor(model, modelName, numClasses)
        model = load_model_weight(modelPara, pathPara, model, task, cudaDevice)

    return model

def select_predictor(model: nn.modules, modelName: str, numClasses: int) -> nn.modules:
    """
    Selecting predictor for one stage or two stage

    Args:
        model      (nn.modules): pytorch model structure
        modelName  (str)       : pytorch model name
        numClasses (int)       : class number

    Returns:
        model (nn.modules)
    """
    if modelName.lower().startswith('fasterrcnn'):
        in_features = model.roi_heads.box_predictor.cls_score.in_features
        model.roi_heads.box_predictor = FastRCNNPredictor(in_features, numClasses)

    # elif modelName.lower().startswith('retinanet'):
    #     model.roi_heads.box_predictor = RetinaNetHead(in_features, 9, numClasses)

    return model


def load_model_weight(
    modelPara: ModelPara,
    pathPara: PathPara,
    model: nn.Module, 
    task: str,
    cudaDevice: torch.device,
    pretrained=False,
)-> nn.modules:
    """
    According to different task (Train / Test / Inference / Retrain), load the model weight
    Args:
        modelPara  (DetModelPara)  : Parameters include one stage, two stage, torchvision model
        pathPara   (DetPathPara)   : Include valid, train, test, inference data Path
        model      (nn.Module)     : model
        task       (str)           : "Train" / "Test" / "Inference" 
        pretrained (bool, optional): using pretrained weighted or not. Defaults to False.

    Raises:
        ValueError : No pre-trained weight is available for your model structure
        ValueError : CustomModel can only used for "Retrain" task

    Returns:
        model (nn.module)
    """
    if task == 'Train':
        if modelPara.pytorchModel["modelStructure"] == 'CustomModel':
            raise ValueError(f'CustomModel can only used for "Retrain" task')

        if not pretrained or task == 'Resume':
            pass
        else:
            if modelPara.pytorchModel["modelPretrained"] and not \
                os.path.isfile(
                    os.path.join(pathPara.weightPath['pretrainedWeightPath'], 
                                modelPara.pytorchModel["modelStructure"]+'.pth')
                                ):       # check pretrianed Weight exists

                raise ValueError(f'No pre-trained weight is available for model type {modelPara.pytorchModel["modelPretrained"]}')

            # elif modelPara.pytorchModel["modelPretrained"]:
            else:
                pretrainWeight = torch.load(
                        os.path.join(pathPara.weightPath['pretrainedWeightPath'], 
                                    modelPara.pytorchModel["modelStructure"]+'.pth'))
                modelDict = model.state_dict()

                for (k1,v1),(k2,v2) in zip(pretrainWeight.items(), modelDict.items()):

                    if (k1 == k2) and (v1.shape == v2.shape):
                        modelDict[k1]=v1

                model.load_state_dict(modelDict)

    # elif task == 'Retrain':
    #     if cfgModel.model["structure"] == 'CustomModel':
    #         model = torch.jit.load(cfgModel.customModel)
    #     else:
    #         model.load_state_dict(torch.load(ClsPath.customModel), strict=False)

    else:
        if modelPara.pytorchModel["modelPretrained"] == 'CustomModel':
            model = torch.jit.load(pathPara.weightPath['customModel'])
        else:
            model.load_state_dict(
                torch.load(pathPara.weightPath['evaluatedWeight'],
                map_location=lambda storage, loc: storage.cuda(torch.cuda._utils._get_device_index(cudaDevice, True)) if torch.cuda.is_available() else storage
                ), strict=True)

    return model