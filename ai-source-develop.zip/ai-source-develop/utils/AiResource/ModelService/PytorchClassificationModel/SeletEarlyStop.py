from .ConfigModelService import EarlyStopPara

def cls_select_earlystop(earlyStopPara: EarlyStopPara, accuracy:float, loss:float, 
                         bestAcc:float, bestLoss:float, counter:int):
    """
    According to configs in ConfigModelService, select monitor evaluation to stop training.

    Args:
        earlystopPara: point out the monitor evaluation and its correspond setting
        accuracy: monitor the accuracy and stop training when it reaches a certain level 
        loss: monitor the loss and stop training when it reaches a certain level
        bestAcc: best evaluation score till now
        bestLoss: best loss till now
        counter: count the number of times exceeded currently
    Return:
        The boolean value of stopping training
    """
    patience = 0
    earlyStop = False
    # Monitoring both accuracy and loss
    if earlyStopPara.accuracyAndLoss['switch']:
        patience = earlyStopPara.accuracyAndLoss['patience']
        if accuracy <= bestAcc and loss > bestLoss:
            counter += 1
            if counter >= patience:
                earlyStop = True
        elif accuracy <= bestAcc or loss > bestLoss:
            pass
        else:
            counter = 0

    # Monitoring only accuracy
    elif earlyStopPara.accuracy['switch']:
        patience = earlyStopPara.accuracy['patience']
        if accuracy <= bestAcc:
            counter += 1
            if counter >= patience:
                earlyStop = True
        else:
            counter = 0

    # Monitoring only loss
    elif earlyStopPara.loss['switch']:
        patience = earlyStopPara.loss['patience']
        if loss > bestLoss:
            counter += 1
            if counter >= patience:
                earlyStop = True
        else:
            counter = 0

    # Updating both accuracy and loss
    if accuracy > bestAcc:
        bestAcc = accuracy
    if loss < bestLoss:
        bestLoss = loss

    return earlyStop, bestAcc, bestLoss, counter, patience