from distutils.version import LooseVersion

import torch.functional
import torch.nn as nn
import torch.optim as OptimizerMethod

from .ConfigModelService import OptimizerPara


def cls_select_optimizer(
    optimizerPara: OptimizerPara,
    lr: float,
    model: nn.Module
) -> torch.functional:
    """
    According to configs in ConfigModelService, select and set up optimizer.
    Optimizer: SGD, Adam, Adadelta, AdamW, NAdam
    Args:
        optimizerPara: point out the selected optimizer and its correspond setting
        lr: learning rate that updating model parameters
        model: pytorch model
    Return:
        optimizer
    """
    if optimizerPara.SGD["switch"]:
        method = getattr(OptimizerMethod, 'SGD')
        optimizer = method(params=model.parameters(), 
                           lr=lr,
                           momentum=optimizerPara.SGD["momentum"],
                           dampening=optimizerPara.SGD["dampening"],
                           weight_decay=optimizerPara.SGD["weightDecay"],
                           nesterov=optimizerPara.SGD["nesterov"],
                           )
        
    elif optimizerPara.Adam["switch"]:
        method = getattr(OptimizerMethod, 'Adam')
        optimizer = method(params=model.parameters(), 
                           lr=lr,
                           betas=optimizerPara.Adam["betas"],
                           eps=optimizerPara.Adam["eps"],
                           weight_decay=optimizerPara.Adam["weightDecay"],
                           amsgrad=optimizerPara.Adam["amsgrad"],
                           )

    elif optimizerPara.Adadelta["switch"]:
        method = getattr(OptimizerMethod, 'Adadelta')
        optimizer = method(params=model.parameters(), 
                           lr=lr,
                           rho=optimizerPara.Adadelta["rho"],
                           eps=optimizerPara.Adadelta["eps"],
                           weight_decay=optimizerPara.Adadelta["weightDecay"],
                           )
    
    elif optimizerPara.AdamW["switch"]:
        method = getattr(OptimizerMethod, 'AdamW')
        optimizer = method(params=model.parameters(), 
                           lr=lr,
                           betas=optimizerPara.AdamW["betas"],
                           eps=optimizerPara.AdamW["eps"],
                           weight_decay=optimizerPara.AdamW["weightDecay"],
                           amsgrad=optimizerPara.AdamW["amsgrad"],
                           )
    
    elif optimizerPara.NAdam["switch"]:
        if LooseVersion(torch.__version__) < '1.10.0':
            raise BaseException(f'NAdam needs torch version >= 1.10.0. But the torch version is {torch.__version__}.')
        else:
            method = getattr(OptimizerMethod, 'NAdam')
            optimizer = method(params=model.parameters(), 
                            lr=lr,
                            betas=optimizerPara.NAdam["betas"],
                            eps=optimizerPara.NAdam["eps"],
                            weight_decay=optimizerPara.NAdam["weightDecay"],
                            momentum_decay=optimizerPara.NAdam["momentumDecay"]
                            )
    
    return optimizer
