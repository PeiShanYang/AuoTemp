import collections
import torch
from torchvision import transforms
from .ConfigSetting import PreprocessPara, DetPostProcessPara, ResultStorage, InferencePara
from . import PreprocessMethod
from . import PostprocessMethod
from . import SaveResultMethod
import os
from PIL import Image
from torch.utils.data import Dataset
import pathlib

#### tools ####
def det_sort_dict_by_value(sortDict: dict) -> dict:
    """
    Sort Dict according to value["order"], the order should be non-negative integer
    1. value["order"] is 0, meaning not used.
    2. value["order"] most be greater than 0
    3. value["order"] most be integer
    4. value["order"] can not be repeated

    Args:
        sortDict (dict): {key: {"order": num}, ...}
    
    return:
        resultDict (dict): sorted dict
    """
    resultDict = collections.OrderedDict()
    _recordOrder = []
    for key, value in sortDict.items():
        # 1. unused
        if value["order"] == 0:
            continue

        # 2&3. check if value["order"] is non-negative integer
        if value["order"] < 0 or not isinstance(value["order"], int):
            raise ValueError(f'The order of "{key}" in main/ConfigCls.json should be a non-negative integer.')
        
        # 4. check value["order"] is not repeated
        if value["order"] not in _recordOrder:
            _recordOrder.append(value["order"])
        else:
            raise ValueError(f'The order of "{[k for k, v in sortDict.items() if v["order"] == value["order"]]}" in main/ConfigCls.json is the same as other operation.')
        
        # keep used dict
        resultDict[key] = value
    
    resultDict = dict(sorted(resultDict.items(), key=lambda item: item[1]["order"]))

    # resize setting
    # if sortDict.get('Resize') != None and sortDict['Resize']['order'] == 0:
    #     resultDict["Resize"] = {"order": len(resultDict)+1, "parameters": {"size": [512, 512], "interpolation": "BILINEAR"}}

    return resultDict


#### preprocess ####
def det_set_preprocess_transform(prePara: dict) -> list:
    """
    set preprocess transform: according to preprocessPara, setting transform module.
    
    Args:
        preprocessPara: a dict that include selected preprocess setting
    Return:
        preTransformList: preprocess transform list
    """
    preTransformList = []
    for method, config in prePara.items():
        transformsMethod = getattr(PreprocessMethod, method)(**config["parameters"])
        if method == "Resize":
            preTransformList.insert(0, transformsMethod)
        else:
            preTransformList.append(transformsMethod)
    return preTransformList

def get_eval_transform(prePara: PreprocessPara):
    """
    Set test or inference transform: according to preprocessPara, setting transform module.

    Args:
        prePara: including all preprocess setting
    Return:
        dataTransforms: valid or test or inference transform
    """
    preDict = det_sort_dict_by_value(prePara)
    transformList = det_set_preprocess_transform(preDict)
    transformList.append(PreprocessMethod.PILToTensor())
    transformList.append(PreprocessMethod.ConvertImageDtype(torch.float))
    dataTransforms = PreprocessMethod.Compose(transformList)
    return dataTransforms

#### postprocess ####
def det_select_postprocess(resultList:list, inferencePara:InferencePara, postProcessPara:DetPostProcessPara, prePara: PreprocessPara) -> list:
    """
    According to configs in ConfigPostprocess, select the post processing method.

    Args:
        resultList: result list form model
        postProcessPara: include all post process filters parameters
    Return:
        resultList: after post-processing
    """
    if prePara.preprocessPara['Resize']['order'] > 0:
        if postProcessPara.unResize["order"]:
            resultList = PostprocessMethod.scale_bbox_image(resultList, prePara)
    elif postProcessPara.unResize["order"]:
        raise BaseException('You did not resize pic before, it can not allow using unresize')

    #### remove redundant images
    redundant = len(os.listdir(os.path.abspath(inferencePara.pathPara)))%inferencePara.batchSize
    if redundant > 0:
        del resultList[-redundant:]
    
    return resultList

#### result saving ####
def det_save_result(
    resultStorage: ResultStorage,
    classLabel:dict,
    outputPath:str, 
    resultList:list,
    saveFileName:str
    ):
    """
    save detection result 

    Args:
        resultStorage (DetResultStoragePara): Parameters include all result Storaged methods
        task (str): "Test" / "Inference" 
        classLabel (dict): number corresponds to category include background
        outputPath (str): output path
        result (list): result every item 
            [
            "image"       (PIL) : image
            "boxes"   (ndarray) : predict the coordinates of box
            "labels"  (ndarray) : predict box of category
            "scores"  (ndarray) : predict box confidence score
            "imageName"   (str) : image name
            "imageScaler"(tuple): image size scale to input size
            "iou"         (str) : iou for every predict box
            ]
    """

    resultSaver = SaveResultMethod.DetResultSaver(outputPath, saveFileName, classLabel)
    resultSaver.write_result_csv(resultList, resultStorage.resultStorage["scoreThreshold"])
    
    if resultStorage.resultStorage["drawResultImage"]["switch"]:
        SaveResultMethod.draw_box(resultList, 
            os.path.join(outputPath, f"{saveFileName}ImageResult"), 
            classLabel,
            resultStorage.resultStorage['scoreThreshold'], 
            resultStorage.resultStorage["drawResultImage"]["lineThickness"])

#### dataset ####
class DetectionDataset(torch.utils.data.Dataset):
    def __init__(self, rootDir:str, batchSize:int, transform:transforms.Compose=None, hasNotBackground:bool=False):
        """
        Custom Dataset of detection dataset
        Args:
            rootDir (str): Image and Annotation file root path
            transform (transforms.Compose, optional): for detection transform function. Defaults to None.
            hasNotBackground (bool, optional): label include background or not. Defaults to False.
            isInference (bool, optional): task type is inference or not. Defaults to False.
        """
        self.rootDir = os.path.abspath(rootDir)
        self.transforms = transform
        self.hasNotBackground = hasNotBackground
        self.batchSize = batchSize
        self.image = list(sorted(os.listdir(rootDir))) 

    def __getitem__(self, idx):
        target = {}
        try:
            imagePath = os.path.join(self.rootDir, self.image[idx])
            img = Image.open(imagePath).convert("RGB")

            target["imageOgSize"] = torch.tensor(img.size)
            target["imageName"] = self.image[idx]
        
            if self.transforms is not None:
                img, target = self.transforms(img, target)
        except:
            imagePath = os.path.join(self.rootDir, self.image[0])
            img = Image.open(imagePath).convert("RGB")

            target["imageOgSize"] = torch.tensor(img.size)
            target["imageName"] = f'redundant_{idx}'

            if self.transforms is not None:
                img, target = self.transforms(img, target)

        return img, target

    def __len__(self):
        return len(self.image) + (self.batchSize - (len(self.image) % self.batchSize))