class InferencePara:
    def __init__(self, cudaDevice:int, batchSize:int, pathPara:str, classNameDict:dict, csvSave:dict, onnxModelName:str) ->None:
        self.cudaDevice = cudaDevice
        self.batchSize = batchSize
        self.pathPara = pathPara
        self.classNameDict = {int(key):value for key, value in classNameDict.items()}
        self.csvSave       = csvSave
        self.onnxModelName = onnxModelName

    @classmethod
    def create_from_dict(cls, inferencePara: dict):
        return cls(**inferencePara)

    @classmethod
    def create_from_ini(cls, inferencePara: dict):
        return cls(inferencePara["cudaDevice"], inferencePara["batchSize"], inferencePara["pathPara"],
                    inferencePara["classNameDict"], inferencePara["csvSaveName"])


class PostProcessPara:
    def __init__(self) -> None:
        pass

class DetPostProcessPara(PostProcessPara):
    def __init__(self, nms: dict, unResize: dict) -> None:
        self.nms = nms
        self.unResize = unResize

    @classmethod
    def create_from_dict(cls, postProcessPara: dict):
        return cls(**postProcessPara)

    @classmethod
    def create_from_ini(cls, postProcessPara: dict):
        return cls(postProcessPara["nms"], postProcessPara["unResize"])


class PreprocessPara:
    def __init__(self, preprocessPara: dict) -> None:
        self.preprocessPara = preprocessPara

    @classmethod
    def create_from_dict(cls, preprocessPara: dict):
        return cls(preprocessPara)

    # @classmethod
    # def create_from_ini(cls, preprocessPara: dict):
    #     return cls(preprocessPara)

class ResultStorage:
    def __init__(self, resultStorage: dict) -> None:
        self.resultStorage = resultStorage

    @classmethod
    def create_from_dict(cls, resultStorage: dict):
        return cls(resultStorage)