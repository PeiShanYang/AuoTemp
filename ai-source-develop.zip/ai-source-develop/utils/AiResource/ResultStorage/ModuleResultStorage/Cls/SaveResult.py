# -*- coding: utf-8 -*-

"""
Created on Jun Tue 14 22:00:00 2022
"""
import configparser
import os

from ..CsvModule import CsvHandler


class ResultCsv():
    def __init__(
        self,
        result:dict,
        count:int,
        mode:str,
        outputPath:str,
        classNameList:list
    ) -> None:
        """
        Save result
            1. Wrong result into csv file
            2. Filter out images with scores below the threshold 
            3. Output test result into csv file, file name : Test_result.csv or Inference_result.csv.

        Args:
            result: result from model 
            count: use to record current file
            mode: task - test/ inference
            outputPath: outputPath
            classNameList: class name List
        """
        self.filename = result["filename"]
        self.predict = result["predict"]
        self.label = result["label"]
        self.confidence = result["confidence"]
        self.output = result["output"]
        self.mode = mode
        self.count = count
        self.outputPath = outputPath
        self.classNameList = classNameList
        self.create_folder()

    def create_folder(self) -> None:
        """
        create written path
        """
        if not os.path.isdir(self.outputPath):
            os.makedirs(self.outputPath)

    def result_csv(self) -> CsvHandler:
        """
        create result csv file
        
        Returns:
            CsvHandler class for result csv
        """
        if self.mode == "Test":
            fileName = 'Test_result.csv'
            title = ['filename', 'groundTruth', 'prediction']
        elif self.mode == "Inference":
            fileName = 'Inference_result.csv'
            title = ['filename', 'prediction']
        title.extend(self.classNameList)
        resultCsv = CsvHandler(fileName, self.outputPath, title)
        if self.count == 0:
            resultCsv.create_csv()
        return resultCsv

    def wrong_csv(self) -> CsvHandler:
        """
        create wrong prediction csv file
        
        Returns:
            CsvHandler class for wrong prediction csv
        """
        fileName = 'Test_wrong_file.csv'
        title = ['wrongFilename', 'groundTruth', 'prediction']
        title.extend(self.classNameList)
        wrongCsv = CsvHandler(fileName, self.outputPath, title)
        if self.count == 0:
            wrongCsv.create_csv()
        return wrongCsv

    def unknown_csv(self) -> CsvHandler:
        """
        create unkwon csv file
        
        Returns:
            CsvHandler class for unknown csv
        """
        if self.mode == "Test":
            fileName = f'Test_filter.csv' 
            title = ['filename', 'groundTruth', 'prediction', 'score']
        elif self.mode == "Inference":
            fileName = f'Inference_filter.csv'
            title = ['filename', 'prediction', 'score']
        unknownCsv = CsvHandler(fileName, self.outputPath, title)
        if self.count == 0:
            unknownCsv.create_csv() 
        return unknownCsv

    def write_result(self) -> None:
        """
        generate result csv
        """
        resultCsv = self.result_csv()
        if self.mode == "Test":
            result = [self.filename, self.label, self.predict]
        else:
            result = [self.filename, self.predict]
        for className in self.classNameList:
            result.append(f'{self.output[className]:.6f}')
        resultCsv.write_csv(result, 'a')

    def write_wrong(self) -> None:
        """
        generate wrong prediction csv
        """
        wrongCsv =  self.wrong_csv()
        if self.label != self.predict:
            result =  [self.filename, self.label, self.predict]
            for className in self.classNameList:
                result.append(f'{self.output[className]:.6f}')
            wrongCsv.write_csv(result, 'a')   
    
    def write_unknown(self) -> None:
        """
        generate unknown filtered out csv
        """
        unknownCsv =  self.unknown_csv()
        if self.mode == "Test":
            result =  [self.filename, self.label, self.predict, f'{self.confidence:.6f}']
        else:
            result =  [self.filename, self.predict, f'{self.confidence:.6f}']
        if not self.predict in self.classNameList:
            unknownCsv.write_csv(result, 'a')

def write_ini_file(filePath:str, title:str, content:dict, writeMode:str='a') -> None:
    """
    write dict content into ini file

    Args:
        fileName: file name of ini file
        title: [title] of the content
        content: detail content
        writeMode: 'a' for add new content, 'w' for rewrite content
    """
    iniConfigParser = configparser.ConfigParser()
    iniConfigParser.optionxform = str
    iniConfigParser[title] = {}
    if os.path.splitext(filePath)[-1] != '.ini':
        filePath = filePath + '.ini'

    for key, value in content.items():
        iniConfigParser[title][str(key)] = str(value)
    with open(filePath, writeMode) as file:
        iniConfigParser.write(file)
