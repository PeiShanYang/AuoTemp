from flask import Blueprint
from utils.LoggerResource.ConfigLogger import Logger

prefix = '/user'
blueprintApp = Blueprint(prefix, __name__)


@blueprintApp.route('/info')
def info():
    """
    get user information
    """
    return "info !!!"

@blueprintApp.route('/fav')
def fav():
    """
    get favorite pages of user
    """
    return "fav !!!"