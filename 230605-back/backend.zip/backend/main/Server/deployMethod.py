from flask import Blueprint
from utils.LoggerResource.ConfigLogger import Logger

prefix = '/deployMethod'
blueprintApp = Blueprint(prefix, __name__)



@blueprintApp.route('/<string:methodName>/args', methods=['POST', 'GET'])
def get_deployed_args(methodName: str):
    """
    get all necessary arguments of the deploy method
    """
    return f"get_deployed_args with {methodName} !!!"


@blueprintApp.route('/<string:methodName>/deploy/<int:deploymentId>', methods=['POST'])
def execute_deployment(methodName: str, deploymentId: int):
    """
    execute deployment with the deploy method
    """
    return f"execute_deployment with {methodName}, {deploymentId} !!!"