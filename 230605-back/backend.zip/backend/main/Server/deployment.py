from flask import Blueprint, request
from utils.LoggerResource.ConfigLogger import Logger
from utils.DatabaseResource import deploymentDb

prefix = "/deployment"
blueprintApp = Blueprint(prefix, __name__)
deploymentDbHandler = deploymentDb.DeploymentDb()


@blueprintApp.route("/get-list", methods=["POST"])
def get_list():
    """
    get deployment list of project
    """
    ### Get input variable
    data = request.get_json()
    projectName = data["projectName"]
    experimentName = data["experimentName"]
    pipelineName = data["pipelineName"]
    ### Check if the project exists
    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    ### Project does not exist
    if not ok:
        return Logger.responseError(0, 'Get list failed / ' + message)
    ### is experimentName
    if experimentName != '':
        ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
        if not ok:
            return Logger.responseError(0, 'Get list failed / ' + message)
        ### is pipelineName
        if pipelineName != '':
            ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
            if not ok:
                return Logger.responseError(0, 'Get list failed / ' + message)
            deploymentsList = deploymentDbHandler.generate_list(
                projectName, experimentName=experimentName, pipelineName=pipelineName
            )
        else:
            deploymentsList = deploymentDbHandler.generate_list(projectName, experimentName=experimentName)
    else:
        deploymentsList = deploymentDbHandler.generate_list(projectName)
    return Logger.responseDebug(1, "Get list success", deploymentsList)


# @blueprintApp.route("/preview-list", methods=["POST"])
# def preview_list():
#     """
#     preview deployment list in info page
#     """
#     ### Get input variable
#     data = request.get_json()
#     projectName = data["projectName"]
#     experimentName = data["experimentName"]
#     pipelineName = data["pipelineName"]
#     ### Check if the project exists
#     ok, message = deploymentDbHandler.check_project_name_existed(projectName)
#     ### Project does not exist
#     if not ok:
#         return Logger.responseError(0, message + ", please select other project name")
#     ### is experimentName
#     if experimentName != "":
#         ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
#         if not ok:
#             return Logger.responseError(0, message + ", please select other experiment name")
#         ### is pipelineName
#         if pipelineName != "":
#             ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
#             if not ok:
#                 return Logger.responseError(0, message + ", please select other pipeline name")
#             deploymentsList = deploymentDbHandler.generate_list(
#                 projectName, experimentName=experimentName, pipelineName=pipelineName, returnCurrentNum=4
#             )
#         else:
#             deploymentsList = deploymentDbHandler.generate_list(projectName, experimentName=experimentName, returnCurrentNum=4)
#     else:
#         deploymentsList = deploymentDbHandler.generate_list(projectName, returnCurrentNum=4)
#     ### 4 current deployments in the output project if exist
#     return Logger.responseDebug(1, "Preview deployments list success", deploymentsList)


@blueprintApp.route("/create", methods=["POST"])
def create():
    """Create a new deployment or rename deployment"""
    ### Get input variable
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName, deploymentRename = (
        data["projectName"],
        data["experimentName"],
        data["pipelineName"],
        data["deploymentName"],
        data["deploymentRename"],
    )
    ### Check if the project exists
    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the experiment exists
    ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    ### experiment name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the pipeline exists
    ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    ### Pipeline name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the deployment exists
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    ### Deployment name existed or deployment name not existed and need to reaname, return error message
    if (ok and deploymentRename == "") or (not ok and deploymentRename != ""):
        return Logger.responseError(0, 'Create failed / Incorrect rename situation')
    ### Deployment name is new, create pipeline
    if deploymentRename == "":
        ok, message = deploymentDbHandler.create_deployment(projectName, experimentName, pipelineName, deploymentName)
    ### Deployment name is old, execute Rename
    else:
        ### Check if the rename deployment exists
        ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentRename)
        ### Deployment name is old, execute Rename
        if not ok:
            ok, message = deploymentDbHandler.deployment_rename(projectName, experimentName, pipelineName, deploymentName, deploymentRename)
        ### deployment name same as deployment rename
        elif deploymentName == deploymentRename:
            return Logger.responseDebug(1, "Check name correct")
        ### Deployment rename existed, return error message
        else:
            return Logger.responseError(0, message + ", please rename with other deployment name")
    if ok:
        return Logger.responseDebug(1, 'Create success')
    return Logger.responseError(0, 'Create or rename failed')


@blueprintApp.route("/delete", methods=["POST"])
def delete():
    """
    delete deployment
    """
    ### Get input variable
    data = request.get_json()
    deleteList = data["deleteList"]
    for delete in deleteList:
        projectName, experimentName, pipelineName, deploymentName = (
            delete["projectName"],
            delete["experimentName"],
            delete["pipelineName"],
            delete["deploymentName"],
        )
        ### Check if the project exists
        ok, message = deploymentDbHandler.check_project_name_existed(projectName)
        ### Project does not exist
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ### Check if the experiment exists
        ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
        ### Experiment does not exist
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ### Check if the pipeline exists
        ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
        ### Pipeline does not exist
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ### Get pipeline ID
        pipelineId = deploymentDbHandler.read_value_with_cond(
            "project, experiment, pipeline",
            "pipeline_id",
            f'project.project_id = experiment.project_id\
                                                      and experiment.experiment_id = pipeline.experiment_id\
                                                      and project.project_name = "{projectName}"\
                                                      and experiment.experiment_name = "{experimentName}"\
                                                      and pipeline.pipeline_name = "{pipelineName}"',
        )
        ### Delete deployment
        deploymentDbHandler.delete_value("deployment", f'pipeline_id="{pipelineId}" and deployment_name="{deploymentName}"')
    return Logger.responseDebug(1, f"Delete success")


@blueprintApp.route('/set-abstract', methods=['POST'])
def set_abstract():
    """Save abstract into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "deploymentName": deployment name,
        "deploymentAbstract": deployment abstract
    }
    Returns:
        tuple[0]: 0: save abstract failed, 1: save abstract success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName, deploymentAbstract \
                = data["projectName"], data["experimentName"], data["pipelineName"], data["deploymentName"], data["deploymentAbstract"]

    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')

    ### Get pipeline id
    pipelineId = deploymentDbHandler.get_pipeline_id(projectName, experimentName, pipelineName)
    ### update experiment abstract
    ok, message = deploymentDbHandler.update_deployment_abstract(pipelineId, deploymentName, deploymentAbstract)

    return Logger.responseDebug(ok, message)


@blueprintApp.route('/add-favorite', methods=['POST'])
def add_favorite():
    """Add favorite deployment into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "deploymentName": deployment name
    }

    Returns:
        tuple[0]: 0: add favorite deployment failed, 1: add favorite deployment success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName \
                = data["projectName"], data["experimentName"], data["pipelineName"], data["deploymentName"]

    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')
    ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')
    ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')

    ### Update column name created to 1
    code, message = deploymentDbHandler.add_favorite(deploymentName)

    return Logger.responseDebug(code, message)
