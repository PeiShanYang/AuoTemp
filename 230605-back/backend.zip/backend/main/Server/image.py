from flask import Blueprint
from utils.LoggerResource.ConfigLogger import Logger
from flask import send_from_directory

prefix = '/image'
blueprintApp = Blueprint(prefix, __name__)



@blueprintApp.route('/transform-preview/<int:imageId>')
def transform_preview(imageId):
    """
    preview image after transform
    """
    return f"transform_preview with {imageId} !!!"


@blueprintApp.route('/show-img/<path:path>', methods=['GET'])
def show_img(path):
    """Give url and show corresponding image

    Args:
        path (path): image path

    Returns:
        image show on web
    """
    rootPath, filePath = path.split("/", 1)
    return send_from_directory(rootPath, path=filePath)