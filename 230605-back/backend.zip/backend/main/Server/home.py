from flask import Blueprint
from utils.LoggerResource.ConfigLogger import Logger

prefix = '/home'
blueprintApp = Blueprint(prefix, __name__)


@blueprintApp.route('/pipeline-running')
def pipeline_running():
    """
    get user-visible running or waiting pipelines
    """
    return "pipeline-running"

@blueprintApp.route('/deployment-service')
def deployment_service():
    """
    get deployments that build as service
    """
    return "deployment-service"

@blueprintApp.route('/modify-category')
def modify_category():
    """
    """
    return "modify-category"


@blueprintApp.route('/get-list')
def get_list():
    """
    """
    return "get-list"


@blueprintApp.route('/add-favorite')
def add_favorite():
    """
    """
    return "add-favorite"