from flask import Blueprint
from utils.LoggerResource.ConfigLogger import Logger


prefix = '/'
blueprintApp = Blueprint(prefix, __name__)


@blueprintApp.route('/login')
def login():
    return Logger.responseDebug(code=1, message="in ./root/login")

@blueprintApp.route('/signup')
def signup():
    return Logger.responseInfo(code=1, message="in ./root/signup")

@blueprintApp.route('/refresh-token')
def refresh_token():
    return Logger.responseInfo(code=1, message="in ./root/refresh-token")

@blueprintApp.route('/forget-password/send-code')
def send_code():
    return Logger.responseDebug(code=1, message="in ./root/send-code")

@blueprintApp.route('/forget-password/check-code')
def check_code():
    return Logger.responseWarning(code=1, message="in ./root/check-code")

@blueprintApp.route('/forget-password/set-password')
def set_password():
    return Logger.responseError(code=1, message="in ./root/set-password")