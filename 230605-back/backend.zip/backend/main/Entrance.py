import os
import configparser
from importlib import import_module
from flask import Flask
from flask_cors import CORS
from utils.DatabaseResource import BasicDb
from utils.LoggerResource.ConfigLogger import Logger
basicSettingDb = BasicDb()

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False
CORS(app)

def register(serverPath: str='main/Server'):
    serverList = [serverName for serverName in os.listdir(serverPath)
                  if serverName != "__init__.py" and os.path.isfile(os.path.join(serverPath, serverName))]
    importPath = serverPath.replace('/', '.')
    for serverName in serverList:
        server = import_module(f'{importPath}.{serverName.rstrip(".py")}')
        app.register_blueprint(server.blueprintApp, url_prefix=server.prefix)

# @app.after_request
# def after_request(response):
#   response.headers.add('Access-Control-Allow-Origin', '*')
#   response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization,DataBase')
#   response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
#   return response

def basic_setting():
    try:
        config = configparser.ConfigParser()
        config.read('./input/ProcessMonitor.ini')
        hostId = config["serverConnection"]["host"]
        portId = config.getint("serverConnection", "port")
        basicSettingDb.delete_value('basic_setting', f'1=1')
        basicSettingDb.insert_value('basic_setting (basic_setting_id, monitor_time, gpu_usage_threshold, output_root, sample_config_cls, sample_config_det, model_transform, host_id, port_id)',
                                    f'("{basicSettingDb.generate_uid("basic_setting")}", "{config.getint("processMonitor", "monitorTime")}", "{config.getint("processMonitor", "gpuUsageThreshold")}",\
                                    "{config["processMonitor"]["outputRoot"]}", "{config["processMonitor"]["sampleConfigCls"]}", "{config["processMonitor"]["sampleConfigDet"]}",\
                                    "{config["processMonitor"]["modelTransform"]}", "{hostId}", "{portId}")')
        return hostId, portId
    except Exception as err:
        Logger.responseError(0, "basic setting error: " + err)


def main():
    hostId, portId = basic_setting()
    register()
    app.run(host=hostId, port=portId)

if __name__ == '__main__':
    main()