import json

def load_json_config(configPath):
    try:
        with open(configPath) as configFile:
            configDict = json.load(configFile)
    except:
        raise BaseException('json file not found. Please check if the file name is "Config.json".')

    return configDict

if __name__ == '__main__':
    load_json_config()
