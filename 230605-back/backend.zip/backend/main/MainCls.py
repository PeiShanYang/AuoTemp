# -*- coding: utf-8 -*-

"""
Created on Wed Jun 27 17:00:00 2022
"""
import os

from utils.AiResource.DatasetClean import SelectDatasetCleanMethod
from utils.AiResource.DatasetClean.ConfigDataClean import DataCleanPara
from utils.AiResource.Deploy.ConfigDeployment import ClsDeploymentPara
from utils.AiResource.Evaluation import SelectEvaluationMethod
from utils.AiResource.Evaluation.ConfigEvaluation import ClsEvaluationPara
from utils.AiResource.ModelService.PytorchClassificationModel import (
    MainProcess, SelectModel)
from utils.AiResource.ModelService.PytorchClassificationModel.ConfigAugmentation import \
    AugmentationPara
from utils.AiResource.ModelService.PytorchClassificationModel.ConfigModelService import (
    LearningRatePara, LossFunctionPara, OptimizerPara, SchedulerPara)
from utils.AiResource.ModelService.PytorchClassificationModel.ConfigPreprocess import \
    PreprocessPara
from utils.AiResource.ModelService.PytorchClassificationModel.ConfigPytorchModel import (
    ModelPara, PathPara, ServicePara)
from utils.AiResource.Postprocess import SelectPostprocess
from utils.AiResource.Postprocess.ConfigPostprocess import ClsPostProcessPara
from utils.AiResource.ResultStorage import SelectStorageMethod
from utils.AiResource.ResultStorage.ConfigResultStorage import \
    ClsResultStoragePara
from utils.AiResource.Deploy.SelectDeploymentMethod import Cls_generate_deploy_file
from main.ConfigLoader import load_json_config

from .Config import ClsBasicSettingPara, PrivateSettingPara


def train(configDict: dict) -> list:
    '''
    Call training module
    '''
    print("Step 0: Create config object from dict.")
    basicSettingPara = ClsBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    dataCleanPara = DataCleanPara.create_from_dict(configDict["ConfigDataClean"]["dataClean"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    preprocessPara = PreprocessPara.create_from_dict(configDict["ConfigPreprocess"]["preprocessPara"])
    augPara = AugmentationPara.create_from_dict(configDict["ConfigAugmentation"]["augmentationPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    lossFunction = LossFunctionPara.create_from_dict(configDict["ConfigModelService"]["lossFunctionPara"])
    optimizerPara = OptimizerPara.create_from_dict(configDict["ConfigModelService"]["optimizerPara"])
    learningRate = LearningRatePara.create_from_dict(configDict["ConfigModelService"]["learningRatePara"])
    schedulerPara = SchedulerPara.create_from_dict(configDict["ConfigModelService"]["schedulerPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    evaluationPara = ClsEvaluationPara.create_from_dict(configDict["ConfigEvaluation"]["evaluationPara"])
    resultStoragePara = ClsResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])

    print("Step 1: Split dataset")
    SelectDatasetCleanMethod.cls_select_dataset_clean(dataCleanPara, pathPara)

    print("Step 2: Train AI model")
    classNameList = MainProcess.train(
        basicSettingPara,
        privateSettingPara,
        pathPara,
        preprocessPara,
        augPara,
        modelPara,
        lossFunction,
        optimizerPara,
        learningRate,
        schedulerPara,
        servicePara,
        evaluationPara,
        resultStoragePara
    )

    return classNameList


def test(configDict: dict) -> None:
    '''
    Call testing module
    '''
    print("Step 0: Create config object from dict.")
    basicSettingPara = ClsBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    preprocessPara = PreprocessPara.create_from_dict(configDict["ConfigPreprocess"]["preprocessPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    postProcessPara = ClsPostProcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])
    evaluationPara = ClsEvaluationPara.create_from_dict(configDict["ConfigEvaluation"]["evaluationPara"])
    resultStoragePara = ClsResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    print("Step 1: AI model Testing")
    resultList = MainProcess.test(
        basicSettingPara,
        pathPara,
        preprocessPara,
        modelPara,
        servicePara,
    )

    print("Step 2: Post-processing")
    resultList = SelectPostprocess.cls_select_postprocess(resultList, postProcessPara)

    print("Step 3: Evaluating")
    classNameList = []
    for folder in os.listdir(pathPara.testPath):
        if os.path.isdir(os.path.join(pathPara.testPath, folder)):
            classNameList.append(folder)
    SelectEvaluationMethod.cls_test_evaluation(evaluationPara, privateSettingPara.outputPath, resultList, classNameList)

    print("Step 4: Result Saveing")
    SelectStorageMethod.cls_save_result(resultStoragePara, resultList, classNameList, privateSettingPara.outputPath, basicSettingPara.task)


def inference(configDict: dict) -> None:
    '''
    Call inference module
    '''
    print("Step 0: Create config object from dict.")
    basicSettingPara = ClsBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    preprocessPara = PreprocessPara.create_from_dict(configDict["ConfigPreprocess"]["preprocessPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    postProcessPara = ClsPostProcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])
    resultStoragePara = ClsResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    print("Step 1: AI model Inference")
    resultList = MainProcess.inference(
        basicSettingPara,
        pathPara,
        preprocessPara,
        modelPara,
        servicePara
    )
    print("Step 2: Post-processing")
    resultList = SelectPostprocess.cls_select_postprocess(resultList, postProcessPara)

    print("Step 3: Result Saveing")
    SelectStorageMethod.cls_save_result(resultStoragePara, resultList, basicSettingPara.classNameList, privateSettingPara.outputPath, basicSettingPara.task)


def transfer_annotation(configDict: dict) -> None:
    print("Step 0: Create dataCleanPara object")
    dataCleanPara = DataCleanPara.create_from_dict(configDict["ConfigDataClean"]["dataClean"])
    print("Step 1: Annotation transfer")
    SelectDatasetCleanMethod.select_annotation_transfer(dataCleanPara)


def deployment(configDict: dict, classNameList: list) -> None:
    print("===========================================================")
    print("----------------------- deployment ------------------------")
    print("Step 0: Create config object from dict.")
    basicSettingPara = ClsBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    preprocessPara = PreprocessPara.create_from_dict(configDict["ConfigPreprocess"]["preprocessPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    postProcessPara = ClsPostProcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])
    resultStoragePara = ClsResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    deploymentPara = ClsDeploymentPara.create_from_dict(configDict["ConfigDeployment"]["Deployment"])

    resultStoragePara.saveClassIniFile["switch"] = deploymentPara.saveIniFile
    print("Step 1: Save class name into ini file")
    SelectStorageMethod.cls_save_ini_file(resultStoragePara, privateSettingPara.outputPath,
                                      classNameList, postProcessPara.unknownFilter)

    print("Step 2: transfer model into onnx or scriptPth file")
    weightPath = os.path.join(privateSettingPara.outputPath, 'BestDictPth.pth')
    model = SelectModel.cls_select_model("Deployment", modelPara.model, weightPath, len(basicSettingPara.classNameList), preprocessPara.preprocessPara["Resize"]["parameters"]["size"])
    SelectStorageMethod.cls_transform_model(resultStoragePara, modelPara.model["structure"],
                                        model, servicePara.cudaDevice, privateSettingPara.outputPath, preprocessPara.preprocessPara["Resize"]["parameters"]["size"])

    print(f"Step 3: Generate deployed file into '{deploymentPara.deployPath}'")
    Cls_generate_deploy_file(deploymentPara, preprocessPara, postProcessPara, privateSettingPara.outputPath, basicSettingPara.classNameList, resultStoragePara.saveClassIniFile["fileName"])


def main(configPath):
    '''
    根據config中的task, 選擇對應程式執行
    '''
    configDict = load_json_config(configPath)
    basicSettingPara = configDict["Config"]["basicSettingPara"]
    print(f'......... Project: {basicSettingPara["projectID"]}, Experiment: {basicSettingPara["experimentID"]}, Mode: {basicSettingPara["task"]} .........')
    if basicSettingPara["task"] == 'Train':
        classNameList = train(configDict)
        # deployment(configDict, classNameList)
    elif basicSettingPara["task"] == 'Test':
        test(configDict)
    elif basicSettingPara["task"] == 'Inference':
        inference(configDict)
    elif basicSettingPara["task"] == 'Retrain':
        train(configDict)
    elif basicSettingPara["task"] == 'AnnotationTransfer':
        transfer_annotation(configDict)
    elif basicSettingPara["task"] == 'Deployment':
        deployment(configDict, configDict["Config"]["basicSettingPara"]["classNameList"])
    else:
        raise BaseException("Please set up the correct task mode in config/Config.py.")
