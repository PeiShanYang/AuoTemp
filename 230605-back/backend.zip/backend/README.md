# SALA 2 backend

## 檔案目錄

    │  enter.bat
    │  enter.py
    │  README.md
    │
    ├─input
    │  ├─CustomModel
    │  │      Put_your_customModel_weight_here.txt
    │  │
    │  ├─Data
    │  │      Put_your_data_here.txt
    │  │
    │  └─PretrainedWeight
    │          Put_pretrained_weight_here.txt
    │
    ├─main
    │  │  Config.py
    │  │  ConfigCls.json
    │  │  ConfigDet.json
    │  │  ConfigLoader.py
    │  │  Entrance.py
    │  │  MainCls.py
    │  │  MainDet.py
    │  │
    │  └─Server
    │      dataset.py
    │      deployment.py
    │      deployMethod.py
    │      experiment.py
    │      home.py
    │      image.py
    │      labelTool.py
    │      pipeline.py
    │      project.py
    │      root.py
    │      user.py
    │      __init__.py
    │
    ├─sampleConfig
    │      ConfigCls.json
    │      ConfigDet.json
    │
    └─utils
        ├─AiResource
        │  ├─AiModel
        │  │      alexnet.py
        │  │      cbam_resnet.py
        │  │      csp_resnet.py
        │  │      densenet.py
        │  │      efficientnet.py
        │  │      mnasnet.py
        │  │      mobilenetv3.py
        │  │      regnet.py
        │  │      resnet.py
        │  │      resnetModule.py
        │  │      se_cbam_resnet.py
        │  │      se_resnet.py
        │  │      shufflenetv2.py
        │  │      torchFuture.py
        │  │      vgg.py
        │  │      __init__.py
        │  │
        │  ├─DataAugmentation
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModuleAugmentation
        │  │      │  __init__.py
        │  │      │
        │  │      ├─Cls
        │  │      │      AugmentationMethod.py
        │  │      │      ResizeImage.py
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  ├─DatasetClean
        │  │  │  ConfigDataClean.py
        │  │  │  SelectDatasetCleanMethod.py
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModuleDatasetClean
        │  │      │  AnnotationTransfer.py
        │  │      │  BasicFileProcess.py
        │  │      │  DataSplit.py
        │  │      │
        │  │      ├─Cls
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  ├─Deploy
        │  │  │  ConfigDeployment.py
        │  │  │  SelectDeploymentMethod.py
        │  │  │
        │  │  ├─ModuleDeploy
        │  │  │  │  PyToPyd.py
        │  │  │  │  Tool.py
        │  │  │  │
        │  │  │  ├─Cls
        │  │  │  │      FileSetting.py
        │  │  │  │      __init__.py
        │  │  │  │
        │  │  │  └─Det
        │  │  │          __init__.py
        │  │  │
        │  │  └─package
        │  │      ├─exe
        │  │      │  ├─deployment
        │  │      │  │      Put_your_exe_here
        │  │      │  │
        │  │      │  └─sampleCode
        │  │      │      │  AULOGO.ico
        │  │      │      │  main.py
        │  │      │      │  main.spec
        │  │      │      │
        │  │      │      └─utils
        │  │      │              ConfigSetting.py
        │  │      │              PostprocessMethod.py
        │  │      │              PreprocessMethod.py
        │  │      │              sampleInference.py
        │  │      │              SaveResultMethod.py
        │  │      │              SelectInference.py
        │  │      │
        │  │      └─pyd
        │  │          │  main.py
        │  │          │
        │  │          └─utils
        │  │                  ConfigSetting.py
        │  │                  PostprocessMethod.py
        │  │                  PreprocessMethod.py
        │  │                  sampleInference.py
        │  │                  SaveResultMethod.py
        │  │                  SelectInference.py
        │  │
        │  ├─Evaluation
        │  │  │  ConfigEvaluation.py
        │  │  │  SelectEvaluationMethod.py
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModuleEvaluation
        │  │      │  DrawPlot.py
        │  │      │
        │  │      ├─Cls
        │  │      │      EvaluationMethod.py
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              coco_eval.py
        │  │              coco_utils.py
        │  │              SaveConfusionMatrix.py
        │  │              SaveMapTxt.py
        │  │              __init__.py
        │  │
        │  ├─ModelService
        │  │  ├─PytorchClassificationModel
        │  │  │      ConfigAugmentation.py
        │  │  │      ConfigModelService.py
        │  │  │      ConfigPreprocess.py
        │  │  │      ConfigPytorchModel.py
        │  │  │      CustomDataset.py
        │  │  │      MainProcess.py
        │  │  │      SelectLossFunction.py
        │  │  │      SelectModel.py
        │  │  │      SelectOptimizer.py
        │  │  │      SelectScheduler.py
        │  │  │      SelectTransform.py
        │  │  │      __init__.py
        │  │  │
        │  │  └─PytorchDetectionModel
        │  │      │  ConfigAugmentation.py
        │  │      │  ConfigModelService.py
        │  │      │  ConfigPostprocess.py
        │  │      │  ConfigPreprocess.py
        │  │      │  ConfigPytorchModel.py
        │  │      │  CustomDataset.py
        │  │      │  MainProcess.py
        │  │      │  SelectBackbone.py
        │  │      │  SelectDetectionModel.py
        │  │      │  SelectOptimizer.py
        │  │      │  SelectPostprocess.py
        │  │      │  SelectScaler.py
        │  │      │  SelectScheduler.py
        │  │      │  __init__.py
        │  │      │
        │  │      └─package
        │  │              engine.py
        │  │              group_by_aspect_ratio.py
        │  │              presets.py
        │  │              transforms.py
        │  │              utils.py
        │  │
        │  ├─Others
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModuleOthers
        │  │      │  feature_visualize.py
        │  │      │
        │  │      ├─Cls
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  ├─Postprocess
        │  │  │  ConfigPostprocess.py
        │  │  │  SelectPostprocess.py
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModulePostprocess
        │  │      ├─Cls
        │  │      │      ConfidenceFilter.py
        │  │      │      UnknownFilter.py
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  ├─Preprocess
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModulePreprocess
        │  │      ├─Cls
        │  │      │      normalizeRecord.json
        │  │      │      NormalizeValueCalculate.py
        │  │      │      PreprocessMethod.py
        │  │      │      SelectNormalization.py
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  └─ResultStorage
        │      │  ConfigResultStorage.py
        │      │  SelectStorageMethod.py
        │      │  __init__.py
        │      │
        │      └─ModuleResultStorage
        │          │  CsvModule.py
        │          │  __init__.py
        │          │
        │          ├─Cls
        │          │      SaveResult.py
        │          │      SaveWeight.py
        │          │      __init__.py
        │          │
        │          └─Det
        │                  drawBox.py
        │                  SaveDetResult.py
        │                  __init__.py
        │
        ├─ApiResource
        │      datasetUtil.py
        │      projectUtil.py
        │      __init__.py
        │
        ├─DatabaseResource
        |      databaseModule
        |      labelToolDb.py
        |      projectDb.py
        |      __init__.py
        |
        └─LoggerResource
                │  ConfigLogger.py
                │
                └─ModuleLogger
                  │      ConsoleLogger.py
                  │      FileLogger.py
                  │      LoggerFunc.py
                  │      __init__.py
                  │
                  └─DBLogger
                          Base.py
                          CsvLogger.py
                          MariaLogger.py
                          __init__.py



## Edit record
- 每次改版，請延續此表格紀錄修改內容

| Branch name          | Push Date       | Editor              | Editor server | comment                             |
|----------------------|-----------------|---------------------|---------------|-------------------------------------|
| OtisChang_20220915   | 2022.09.15      | OtisChang           | 39394         | 1. SALA 2 初版<br> 2. 取自瑕疵檢測模組 v2.1.2<br> 3. 已加入 api 模版於 ./main/Server<br> 4. ./main/Entrance.py 建立 blueprint  |
| OtisChang_20221024   | 2022.10.24      | OtisChang           | 39394         | 1. 同步瑕疵檢測模組版本至 v2.1.4 |
| OtisChang_20221024   | 2022.11.11      | OtisChang           | 39394         | 1. 同步瑕疵檢測模組版本至 v2.1.4 (已修復部分 bug) |
