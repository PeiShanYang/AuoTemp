import copy
from logging import Formatter, Handler, LogRecord
import os
from typing import Any, List

from .Base import DBLogConfig

line = "{levelname}, {levelno}, {asctime}, {message}\n"


class CsvLogger(Handler):
    def __init__(self, config: DBLogConfig):
        super().__init__()

        self.setFormatter(Formatter(
            datefmt='%Y-%m-%d %H:%M:%S'
        ))

        self.setLevel(config.level)

        self.create_file()

    def emit(self, record: LogRecord):
        try:
            recordTemp = self.format(record)
            with open('db.csv', 'a', encoding='UTF-8') as fout:
                fout.write(line.format(**recordTemp.__dict__))
        except Exception:
            self.handleError(recordTemp)

    def format(self, record: LogRecord):
        recordTemp = copy.deepcopy(record)
        recordTemp.asctime = self.formatter.formatTime(record, self.formatter.datefmt)
        msgs: List[Any] = record.msg
        recordTemp.message = " ".join([str(m) for m in msgs])
        recordTemp.pathname = recordTemp.pathname.replace("\\", "/")
        return recordTemp

    def create_file(self):
        if not os.path.isfile("./db.csv"):
            with open("db.csv", "w", encoding="utf-8") as fout:
                fout.write(line.format(
                    levelname = "levelname",
                    levelno = "levelno",
                    asctime = "asctime",
                    message = "message",
                ))
