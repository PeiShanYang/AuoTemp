from . import BasicDb
import random


class ExperimentDb(BasicDb):
    """Database query method of experiment"""

    def insert_experiment(self, experimentId, experimentName, projectId):
        """Store experiment name into database

        Args:
            experimentId (str): experiment id
            experimentName (str): experiment name
            project_id (str): project id
        """
        insertSQL = f"""
        INSERT INTO
            experiment (experiment_id, experiment_name, project_id)
        VALUES
            ("{experimentId}", "{experimentName}", "{projectId}")
        """
        self.my.ExecNoQuery(insertSQL)

    def check_project_name_existed(self, projectName):
        """check if the project name has existed in database or not

        Args:
            projectName (str): project name

        Returns:
            tuple[0]: 0: project name is not existed, 1: project name has existed
            tuple[1]: log message
        """
        if self.check_value_exist("project", f'project_name="{projectName}"'):
            return 1, f"The project name ${projectName}$ has existed"
        return 0, f"The project name ${projectName}$ is not existed"

    def get_experiment(self, projectName: str, returnCurrentNum: int = None):
        """
        Get returnCurrentNum experiments of project id
            returnCurrentNum=None, then all experiments
        Args:
            projectName (str): project name
            returnCurrentNum (int): num of data to get by order

        Returns:
            dataframe: dataframe for sql callback
        """
        ### get project id
        projectId = self.read_value_with_cond(
            tableName="project", selectColumn="project_id", condition=f'project_name="{projectName}"'
        )
        ### generate sql command
        sql = f"""
        SELECT
            experiment_name, update_time
        FROM
            experiment
        WHERE
            project_id = "{projectId}"
        """
        if returnCurrentNum:
            sql = (
                sql
                + f"""
            ORDER BY
                update_time DESC
            LIMIT
                {returnCurrentNum}
            """
            )
        else:
            sql = (
                sql
                + f"""
            ORDER BY
                update_time DESC
            """
            )
        return self.my.ExecQuery(sql)

    def generate_list(self, projectName, returnCurrentNum=None):
        """
        Generate list

        Args:
            projectName (str): project name
            returnCurrentNum (int): num of data to get by order, None: all data by order

        Returns:
            dict: list dict
        """
        ### get experiment dataframe
        experimentDf = self.get_experiment(projectName, returnCurrentNum=returnCurrentNum)
        ### get experiment_name and update_time array
        experimentNameArr = experimentDf.experiment_name.values
        experimentUpdateTimeArr = experimentDf.update_time.values
        ### generate data dictionary
        dataList = list()
        if returnCurrentNum:
            for i in range(len(experimentNameArr)):
                dataList.append({"name": experimentNameArr[i]})
        else:
            for i in range(len(experimentNameArr)):
                randBool = bool(random.getrandbits(1))
                experimentUpdateTime = str(experimentUpdateTimeArr[i]).replace("T", " ")
                experimentUpdateTime = experimentUpdateTime.split(".")[0]
                dataList.append(
                    {
                        "experimentName": experimentNameArr[i],
                        "creator": "someone",
                        "updateTime": experimentUpdateTime,
                        "favorite": randBool,
                    }
                )
        dataDict = {"list": dataList}
        return dataDict

    def check_experiment_name_existed(self, projectName, experimentName):
        """check if the experiment name has existed in database or not

        Args:
            projectName (str): project name
            experimentName (str): experiment name

        Returns:
            tuple[0]: 0: experiment name is not existed, 1: experiment name has existed
            tuple[1]: log message
        """
        ### return operation
        if self.check_value_exist('project, experiment',
                    f'project.project_id = experiment.project_id\
                    and project.project_name = "{projectName}"\
                    and experiment.experiment_name = "{experimentName}"'):
            return 1, f"The experiment name ${experimentName}$ has existed"
        return 0, f"The experiment name ${experimentName}$ is not existed"

    def create_experiment(self, projectName, experimentName):
        """Create experiment

        Args:
            projectName (str): project name
            experimentName (str): experiment name

        Returns:
            tuple[0]: 0: create experiment failed, 1: create experiment success
            tuple[1]: log message
        """
        ### generate experiment id
        experimentId = self.generate_uid("experiment")
        try:
            ### get project id
            projectId = self.read_value_with_cond(
                tableName="project", selectColumn="project_id", condition=f'project_name="{projectName}"'
            )
            ### create experiment
            self.insert_experiment(experimentId, experimentName, projectId)
            return 1, "Create experiment success"
        except:
            return 0, "Create experiment failed"

    def add_favorite(self, projectId, experimentName):
        """Add favorite experiment into database

        Args:
            projectId (str): project id
            experimentName (str): experiment name

        Returns:
            tuple[0]: 1: add favorite success
            tuple[1]: log message
        """
        # memo = self.read_value_with_cond("experiment", "memo", f'project_id="{projectId}" AND experiment_name="{experimentName}"')
        # self.update_value_with_cond("experiment", f'memo="{0 if(memo=="1") else 1}"',
        #                             f'project_id="{projectId}" AND experiment_name="{experimentName}"')
        return 1, "Add favorite success"

    def update_experiment_key_and_created(self, projectId, experimentName, experimentKey):
        """Update experiment key and created column

        Args:
            projectId (str): project id
            experimentName (str): experiment name
            experimentKey (str): experiment key

        Returns:
            tuple[0]: 0: set experiment key failed, 1: set experiment key success
            tuple[1]: log message
        """
        try:
            self.update_value_with_cond(
                "experiment",
                f'experiment_key="{experimentKey}", created=0',
                f'project_id="{projectId}" AND experiment_name="{experimentName}"',
            )
            return 1, "Set experiment key success"
        except Exception as message:
            return 0, f"Set experiment key failed"


    def get_experiment_info(self, projectName, experimentName):
        """Get experiment information

        Args:
            projectName (str): project name
            experimentName (str): experiment name

        Returns:
            dict: project and experiment information (project_task, experiment_id, experiment_key, abstract, and created)
        """
        info = self.read_value_with_cond("project, experiment", "project.project_task, experiment.experiment_id, \
                                        experiment.experiment_key, experiment.abstract, experiment.created",
                                        f"project.project_id = experiment.project_id \
                                        and project.project_name='{projectName}' \
                                        and experiment.experiment_name='{experimentName}'").to_dict('records')[0]
        info['experiment_key'] = "" if info['experiment_key'] == None or info['experiment_key'] == "None" \
                            else info['experiment_key']
        info['abstract'] = "" if info['abstract'] == None or info['abstract'] == "None" \
                            else info['abstract']
        info['created'] = int(info['created'])
        return info


    def get_project_task(self, projectId):
        """Get project task

        Args:
            projectId (str): project id

        Raises:
            Exception: Project task is empty

        Returns:
            str: project task
        """
        projectTask = self.read_value_with_cond("project", "project_task", f"project_id='{projectId}'")
        if projectTask is None:
            raise Exception("Project task is empty")
        return projectTask

    def experiment_rename(self, projectName, experimentName, experimentRename):
        """Rename experiment

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            experimentRename (str): experiment rename
        """
        try:
            self.update_value_with_cond(
                "project, experiment",
                f'experiment.experiment_name="{experimentRename}"',
                f'project.project_id = experiment.project_id\
                                          and project.project_name = "{projectName}"\
                                          and experiment.experiment_name="{experimentName}"',
            )
            return 1, "Rename experiment success"
        except:
            return 0, "Rename experiment failed"
    
    def update_experiment_abstract(self, projectId, experimentName, experimentAbstract):
        """Update abstract column of experiment database

        Args:
            projectId (str): project ID
            experimentName (str): experiment name
            experimentAbstract (str): experiment abstract
        """
        message = self.update_value_with_cond("experiment", f"abstract='{experimentAbstract}'",
                                        f"experiment_name='{experimentName}' AND project_id='{projectId}'")
        if 'Data too long' in message:
            return 0, 'The content of the abstract is too long, the limit is 500 words'
        return 1, 'Save abstract success'
