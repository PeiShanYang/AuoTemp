from . import BasicDb

class ProcessDb(BasicDb):
    def get_basic_info(self, pipelineId):
        """get basic information

        1. projectId: read DB (experimentId -> 'experiment')
        2. experimentId: read DB (pipelineId -> 'pipeline')
        3. classNameList: read DB, cls -> [] det -> {} (projectId -> datasetId -> 'label_class')
        4. cudaDevice: read DB (pipelineId -> 'pipeline')

        Args:
            pipelineId (str): pipeline id
        Returns:
            basicSettingPara (dict): {
                projectID: project ID
                experimentID: experiment ID
                classNameList: class name list
            }
        """
        sql = f'''
        SELECT
            project.project_task, experiment.project_id, pipeline.experiment_id, dataset.dataset_id
        FROM
            project, experiment, pipeline, dataset
        WHERE
            dataset.project_id = project.project_id
            AND project.project_id = experiment.project_id
            AND experiment.experiment_id = pipeline.experiment_id
            AND pipeline.pipeline_id = "{pipelineId}"

        '''
        dfSelect = self.my.DfSelect(sql)
        info = dfSelect.to_dict('record')[0]
        basicSettingPara = {}
        if info['project_task'] == 'classification':
            basicSettingPara["classNameList"] = self.get_class_list(info['project_task'], info['dataset_id'])
        elif info['project_task'] == 'detection':
            basicSettingPara["classNameDict"] = self.get_class_list(info['project_task'], info['dataset_id'])
        basicSettingPara["projectID"] = info["project_id"]
        basicSettingPara["experimentID"] = info["experiment_id"]

        return basicSettingPara

    def get_class_list(self, projectTask, datasetId):
        """get class list

        Args:
            datasetId (str): dataset ID
            projectTask (str): project task
        """
        classList = self.read_value_with_cond('label_class',
                                                  'label_class.class_name',
                                                  f'dataset_id="{datasetId}"')
        if projectTask == 'detection':
            classNameList = {}
            if isinstance(classList, list):
                for i, name in enumerate(classList):
                    classNameList[i] = name
            else:
                classNameList['0'] = classList
            return classNameList

        elif projectTask == 'classification':
            return classList


    def get_dataset_id(self, pipelineId):
        """get dataset ID by pipelineId


        Args:
            pipelineId (str): pipeline ID

        Returns:
            str: dataset ID
        """
        datasetId = self.read_value_with_cond('dataset, project, experiment, pipeline',
                                              'dataset_id',
                                              f'dataset.project_id=project.project_id \
                                                AND project.project_id=experiment.project_id \
                                                AND experiment.experiment_id=pipeline.experiment_id \
                                                AND pipeline.pipeline_id="{pipelineId}"')
        return datasetId


    def get_label_class(self, task, datasetId):
        """get label class by datasetId

        Args:
            datasetId (str): dataset ID

        Returns:
            cls: {class_id: class_name, ....}
            det: {class_id: '0', ....}
        """
        labelList = self.read_value_with_cond('label_class',
                                               'class_name, class_id',
                                               f'label_class.dataset_id="{datasetId}"')
        classList = {}
        if task == 'classification':
            for label in labelList.to_dict('records'):
                classList[label["class_id"]] = label["class_name"]
        elif task == 'detection':
            for i, label in enumerate(labelList.to_dict('records')):
                classList[label["class_id"]] = str(i)
        return classList


    def get_cls_label_info(self, datasetId):
        """get all image label information of classification

        Args:
            datasetId (str): dataset ID
        """
        labelInfoList = self.read_value_with_cond('image, label',
                                  'image.image_name, image.image_pth, image.task, label.class_id',
                                  f'image.image_id=label.image_id \
                                  AND image.dataset_id="{datasetId}"')
        return labelInfoList.to_dict('records')


    def get_det_label_info(self, datasetId):
        """get all image label information of detection

        Args:
            datasetId (str): dataset ID
        """
        sql = f'''
        SELECT
	        image.image_name, image.image_pth, image.task, label.class_id, label.x1, label.y1, label.x2, label.y2
        FROM
            image
        LEFT JOIN
            label
        ON
            image.image_id=label.image_id
        WHERE
            image.dataset_id="{datasetId}"
        '''
        labelInfoList = self.my.DfSelect(sql)
        return labelInfoList.to_dict('records')
