import os
import csv
import collections
from . import BasicDb
import pynvml


class ProcessMonitorDb(BasicDb):
    """Database query method of processMonitor"""

    def get_basic_setting(self):
        """Get basic setting information from database

        Returns:
            tuple[0]: 0: read failed, 1: read success
            tuple[1]: error message or dict of monitor_time, gpu_usage_threshold, output_root
        """
        info = self.read_value_with_cond('basic_setting', 'monitor_time, gpu_usage_threshold, output_root', f'1=1')
        if info.empty:
            return 0, 'Basic setting not found'
        return 1, info.to_dict('records')[0]

    def load_db_pipeline(self, gpuId=None):
        """read database.pipeline and generate gpu job queue from pipeline status = -2 and positive integer
           status = -2 Wait for test, must be the first pipeline in queue
           status = positive integer Wait for train, sort by number from small to large
        Args:
            gpuId (int or None): gpu ID, if gpuId is None get all GPU job list

        Returns:
            gpuJobList (dict):
        {
        0: deque([[pipeline_id, state, project_task, experimentKey], [pipeline_id, state, project_task, experimentKey]]),
        1: deque([[pipeline_id, state, project_task, experimentKey]]),
        2: deque([[pipeline_id, state, project_task, experimentKey]]),
        3: deque([[pipeline_id, state, project_task, experimentKey]])
        })
        """
        if gpuId == None:
            pynvml.nvmlInit()
            deviceCount = pynvml.nvmlDeviceGetCount()
            gpuId = list(range(deviceCount))
        else:
            gpuId = [gpuId]

        gpuJobList = collections.defaultdict(collections.deque)

        for id in gpuId:
            SQLStatement = f"""
                        SELECT project.project_task, experiment.experiment_key, pipeline.pipeline_id, pipeline.status
                        FROM project, experiment, pipeline
                        WHERE project.project_id = experiment.project_id
                            and experiment.experiment_id = pipeline.experiment_id
                            and pipeline.gpu_id = '{id}'
                            and (pipeline.status = -2 or pipeline.status > 0)
                        ORDER BY pipeline.status
                        """
            allInfo = self.my.ExecQuery(SQLStatement)
            for info in allInfo.to_dict("records"):
                gpuJobList[id].append([info['pipeline_id'], "Wait for test" if info['status'] == "-2" else "Wait for train",
                                    info['project_task'], info['experiment_key']])

        return gpuJobList


    def get_max_score(self, row):
        """get max score of confidence

        Args:
            row (collections.OrderedDict):
                format: (OrderedDict) [('filename', '123.JPG'), ('Ground truth', 'REPAIRABLE'), ...]
                - key: DB field name
                - value: corresponding value

        Returns:
            str: max score
        """
        startIndex = list(row.keys()).index("prediction") + 1   ### Get index after the "prediction" field name
        return max(list(row.values())[startIndex: ])


    def get_class_id(self, pipelineId):
        """Get label name and ID from DB (label_class table)

        Args:
            pipelineId (str): pipeline id

        Returns:
            classList (dict): {'className': 'classId'}
        """
        classId = self.read_value_with_cond('project, experiment, pipeline, dataset, label_class',
                                               'label_class.class_id, label_class.class_name',
                                                f'pipeline.pipeline_id="{pipelineId}" \
                                                and pipeline.experiment_id=experiment.experiment_id \
                                                and experiment.project_id=project.project_id \
                                                and project.project_id=dataset.project_id \
                                                and dataset.dataset_id=label_class.dataset_id')
        classList = {}
        for info in classId.to_dict('records'):
            classList[info['class_name']] = info['class_id']
        return classList


    def deal_result_csv(self, projectTask, pipelineId, pipelinePath):
        """Write Test_result.csv content into DB (result table)

        Args:
            projectTask (str): classification or detection
            pipelineId (str): pipeline id
            pipelinePath (str): pipeline local folder path
        """
        DBFieldValue = []   ### The data structure put into the DB field
        with open(os.path.join(pipelinePath, 'Test_result.csv')) as file:
            reader = csv.DictReader(file)
            csvData = list(reader)
            classList = self.get_class_id(pipelineId)
            if len(csvData) != 0:
                if projectTask == 'classification':
                    for row in csvData:
                        resultId = self.generate_uid('result')
                        classId = classList[row["prediction"]] if row["prediction"] in classList.keys() else row["prediction"]
                        DBFieldValue.append((resultId, pipelineId, row["filename"], classId, self.get_max_score(row)))
                    self.insert_value('result (result_id, pipeline_id, image_name, prediction_class_id, score)',
                                    ', '.join(f'{val}' for val in DBFieldValue))

                elif projectTask == 'detection':
                    for row in csvData:
                        resultId = self.generate_uid('result')
                        classId = classList[row["prediction"]] if row["prediction"] in classList.keys() else row["prediction"]
                        DBFieldValue.append((resultId, pipelineId, row["filename"], classId, row["x1"], row["y1"], row["x2"], row["y2"],
                                        self.get_max_score(row)))
                    self.insert_value('result (result_id, pipeline_id, image_name, prediction_class_id, x1, y1, x2, y2, score)',
                                    ', '.join(f'{val}' for val in DBFieldValue))


    def save_result(self, task, projectTask, pipelineId, pipelinePath):
        """save test or train result to database (pipeline_output)
            classification:
                Train: save TrainAcc.json, ValidAcc.json, path of BestDictPth.pth
                Test : save TestAcc.json, Test_result.csv (image_result), path of confusionMatrix.jpg
            detection:
                Train: save TrainMap.json, ValidMap.json, path of BestDictPth.pth
                Test : save TestMap.json, Test_result.csv (image_result), path of confusionMatrix.jpg

        Args:
            task (str): Train or Test
            projectTask (str): classification or detection
            pipelineId (str): pipeline ID
            pipelinePath (str): file path

        Returns:
            List: missing files or extra files
        """
        if task == 'Train':
            if projectTask == 'classification':
                needFileNames = {'train_record': 'TrainLoss.json', 'valid_record': 'ValidAcc.json', 'best_dict_pth_path': 'BestDictPth.pth'}
            elif projectTask == 'detection':
                needFileNames = {'train_record': 'TrainLoss.json', 'valid_record': 'ValidMap.json', 'best_dict_pth_path': 'BestDictPth.pth'}
        elif task == 'Test':
            if projectTask == 'classification':
                needFileNames = {'test_record': 'TestAcc.json', 'cf_matrix_path': 'ConfusionMatrix.jpg', 'csv': 'Test_result.csv'}
            elif projectTask == 'detection':
                needFileNames = {'test_record': 'TestMap.json', 'cf_matrix_path': 'ConfusionMatrix.jpg', 'csv': 'Test_result.csv'}

        for _, _, fileNames in os.walk(pipelinePath):
            for fileName in fileNames:
                if fileName in needFileNames.values():
                    ### Get the corresponding key by fileName in needFileNames dict
                    fileNameKey = list(needFileNames.keys())[list(needFileNames.values()).index(fileName)]

                    ### Save json content into database
                    if fileName.endswith('json'):
                        with open(os.path.join(pipelinePath, fileName), 'r') as f:
                            self.update_value_with_cond(
                                'pipeline_output',
                                f"{fileNameKey}='{f.read()}'",
                                f"pipeline_id='{pipelineId}'"
                        )
                    ### Save path into database
                    elif not fileName.endswith('csv'):
                        filePath = os.path.join(pipelinePath, fileName).replace('\\', '/')
                        self.update_value_with_cond(
                            'pipeline_output',
                            f"{fileNameKey}='{filePath}'",
                            f"pipeline_id='{pipelineId}'"
                        )
        ### Save csv content into database
        if task == 'Test':
            self.deal_result_csv(projectTask, pipelineId, pipelinePath)


    def save_error_db(self, pipelineId, errorFilePath):
        """Save message in error.txt to database

        Args:
            pipelineId (str): pipeline ID
            errorFilePath (str): path of error file
        """
        with open(errorFilePath, 'r') as file:
            content = file.read()
            content = content.replace('"', '$')
            content = content.replace("'", "$")
            self.update_value_with_cond('pipeline_output', f'error_log="{content}"', f'pipeline_id="{pipelineId}"')


    def update_state(self, pipelineId, state):
        """update pipeline state in database

        Args:
            pipelineId (str): pipeline ID
            state (int): state number
        """
        self.update_value_with_cond('pipeline', f'status="{state}"', f'pipeline_id="{pipelineId}"')


    def create_pipeline_output(self, pipelineId):
        """Create pipeline output row to record result

        Args:
            pipelineId (str): pipeline ID
        """
        if not self.check_value_exist('pipeline_output', f'pipeline_id="{pipelineId}"'):
            pipelineOutputId = self.generate_uid('pipeline_output')
            self.insert_value('pipeline_output (pipeline_output_id, pipeline_id)', f'("{pipelineOutputId}", "{pipelineId}")')
