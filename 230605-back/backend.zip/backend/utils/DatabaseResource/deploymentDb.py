from . import BasicDb
import random


class DeploymentDb(BasicDb):
    """Database query method of deployment"""

    def check_project_name_existed(self, projectName):
        """check if the project name has existed in database or not

        Args:
            projectName (str): project name

        Returns:
            tuple[0]: 0: project name is not existed, 1: project name has existed
            tuple[1]: log message
        """
        if self.check_value_exist("project", f'project_name="{projectName}"'):
            return 1, f"The project name ${projectName}$ has existed"
        return 0, f"The project name ${projectName}$ is not existed"

    def check_experiment_name_existed(self, projectName, experimentName):
        """Check if the experiment name has existed in database or not

        Args:
            projectName (str): project name
            experimentName (str): experiment name

        Returns:
            tuple[0]: 0: experiment name is not existed, 1: experiment name has existed
            tuple[1]: log message
        """
        ### return operation
        if self.check_value_exist('project, experiment',
                    f'project.project_id = experiment.project_id\
                    and project.project_name = "{projectName}"\
                    and experiment.experiment_name = "{experimentName}"'):
            return 1, f"The experiment name ${experimentName}$ has existed"
        return 0, f"The experiment name ${experimentName}$ is not existed"


    def check_pipeline_name_existed(self, projectName, experimentName, pipelineName):
        """Check if the pipeline name has existed in database or not

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipeline (str): pipeline name

        Returns:
            tuple[0]: 0: pipeline name is not existed, 1: pipeline name has existed
            tuple[1]: log message
        """
        if self.check_value_exist('project, experiment, pipeline',
                        f'project.project_id = experiment.project_id\
                        and experiment.experiment_id = pipeline.experiment_id\
                        and project.project_name = "{projectName}"\
                        and experiment.experiment_name = "{experimentName}"\
                        and pipeline.pipeline_name = "{pipelineName}"'):
            return 1, f"The pipeline name ${pipelineName}$ has existed"
        return 0, f"The pipeline name ${pipelineName}$ is not existed"


    def check_deployment_name_existed(self, projectName, experimentName, pipelineName, deploymentName):
        """Check if the deployment name has existed in database or not

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name
            deploymentName (str): deployment name

        Returns:
            tuple[0]: 0: deployment name is not existed, 1: deployment name has existed
            tuple[1]: log message
        """
        ### Get deployment name
        if self.check_value_exist('project, experiment, pipeline, deployment',
                        f'project.project_id = experiment.project_id\
                        and experiment.experiment_id = pipeline.experiment_id\
                        and pipeline.pipeline_id = deployment.pipeline_id\
                        and project.project_name = "{projectName}"\
                        and experiment.experiment_name = "{experimentName}"\
                        and pipeline.pipeline_name = "{pipelineName}"\
                        and deployment.deployment_name = "{deploymentName}"'):
            return 1, f"The deployment name ${deploymentName}$ has existed"
        return 0, f"The deployment name ${deploymentName}$ is not existed"


    def get_pipeline_id(self, projectName, experimentName, pipelineName):
        """Get pipeline id by projectName, experimentName, and pipelineName

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name

        Returns:
            str: pipeline id
        """
        ### get project id
        projectId = self.read_value_with_cond(tableName="project", selectColumn="project_id", condition=f'project_name="{projectName}"')
        ### get experiment id
        experimentId = self.read_value_with_cond(tableName="experiment", selectColumn="experiment_id", condition=f'project_id="{projectId}" and experiment_name="{experimentName}"')
        ### get pipeline id
        pipelineId = self.read_value_with_cond(tableName='pipeline', selectColumn='pipeline_id', condition=f'pipeline_name="{pipelineName}" and experiment_id="{experimentId}"')
        return pipelineId


    def get_deployment(
        self, projectName: str, experimentName: str = None, pipelineName: str = None, returnCurrentNum: int = None
    ):
        """Get all deployments of pipeline id, experiment id and project id

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name
            returnCurrentNum (int): num of data to get by order

        Returns:
            dataframe: dataframe for sql callback
        """
        ### get project id
        projectId = self.read_value_with_cond(
            tableName="project", selectColumn="project_id", condition=f'project_name="{projectName}"'
        )
        ### is experimentName
        if experimentName:
            experimentId = self.read_value_with_cond(
                tableName="experiment",
                selectColumn="experiment_id",
                condition=f'experiment_name="{experimentName}" and project_id="{projectId}"',
            )
            if pipelineName:
                pipelineId = self.read_value_with_cond(
                    tableName="pipeline",
                    selectColumn="pipeline_id",
                    condition=f'pipeline_name="{pipelineName}" and experiment_id="{experimentId}"',
                )
                sql = f"""
                SELECT
                    deployment_name, update_time
                FROM
                    deployment
                WHERE
                    pipeline_id = "{pipelineId}"
                """
            else:
                sql = f"""
                SELECT
                    pipeline_name, deployment_name, deployment.update_time
                FROM
                    pipeline, deployment
                WHERE
                    pipeline.pipeline_id = deployment.pipeline_id
                    AND experiment_id = "{experimentId}"
                """
        else:
            sql = f"""
            SELECT
                experiment_name, pipeline_name, deployment_name, deployment.update_time
            FROM
                experiment, pipeline, deployment
            WHERE
                experiment.experiment_id = pipeline.experiment_id
                AND pipeline.pipeline_id = deployment.pipeline_id
                AND project_id = "{projectId}"
            """
        if returnCurrentNum:
            sql = (
                sql
                + f"""
            ORDER BY
                deployment.update_time DESC
            LIMIT
                {returnCurrentNum}
            """
            )
        else:
            sql = (
                sql
                + f"""
            ORDER BY
                deployment.update_time DESC
            """
            )
        return self.my.ExecQuery(sql)

    def generate_list(self, projectName, experimentName=None, pipelineName=None, returnCurrentNum=None):
        """Generate list

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name
            returnCurrentNum (int): num of data to get by order, None: all data by order

        Returns:
            dict: list dict
        """
        ### get deployment dataframe
        deploymentDf = self.get_deployment(
            projectName, experimentName=experimentName, pipelineName=pipelineName, returnCurrentNum=returnCurrentNum
        )
        ### get deployment_name and update_time array
        deploymentNameArr = deploymentDf.deployment_name.values
        deploymentUpdateTimeArr = deploymentDf.update_time.values
        ### generate data dictionary
        dataList = list()
        if returnCurrentNum:
            for i in range(len(deploymentNameArr)):
                dataList.append({"name": deploymentNameArr[i]})
        elif pipelineName:
            for i in range(len(deploymentNameArr)):
                randBool = bool(random.getrandbits(1))
                deploymentUpdateTime = str(deploymentUpdateTimeArr[i]).replace("T", " ")
                deploymentUpdateTime = deploymentUpdateTime.split(".")[0]
                dataList.append(
                    {
                        "deploymentName": deploymentNameArr[i],
                        "creator": "someone",
                        "updateTime": deploymentUpdateTime,
                        "favorite": randBool,
                    }
                )
        elif experimentName:
            ### get pipeline_name
            pipelineNameArr = deploymentDf.pipeline_name.values
            for i in range(len(deploymentNameArr)):
                randBool = bool(random.getrandbits(1))
                deploymentUpdateTime = str(deploymentUpdateTimeArr[i]).replace("T", " ")
                deploymentUpdateTime = deploymentUpdateTime.split(".")[0]
                dataList.append(
                    {
                        "pipelineName": pipelineNameArr[i],
                        "deploymentName": deploymentNameArr[i],
                        "creator": "someone",
                        "updateTime": deploymentUpdateTime,
                        "favorite": randBool,
                    }
                )
        else:
            ### get experiment_name
            experimentNameArr = deploymentDf.experiment_name.values
            ### get pipeline_name
            pipelineNameArr = deploymentDf.pipeline_name.values
            for i in range(len(deploymentNameArr)):
                randBool = bool(random.getrandbits(1))
                deploymentUpdateTime = str(deploymentUpdateTimeArr[i]).replace("T", " ")
                deploymentUpdateTime = deploymentUpdateTime.split(".")[0]
                dataList.append(
                    {
                        "experimentName": experimentNameArr[i],
                        "pipelineName": pipelineNameArr[i],
                        "deploymentName": deploymentNameArr[i],
                        "creator": "someone",
                        "updateTime": deploymentUpdateTime,
                        "favorite": randBool,
                    }
                )
        dataDict = {"list": dataList}
        return dataDict


    def add_favorite(self, deploymentName):
        """Add favorite deployment into database

        Args:
            deploymentName (str): deployment name

        Returns:
            tuple[0]: 0: add favorite deployment failed, 1: add favorite deployment success
            tuple[1]: log message
        """
        try:
            # self.insert_value('user_favorite_page (username, page_id, page_type, favorite_name)', \
            #                 f'(SELECT username as username FROM user WHERE username = "Otis"), "someone1", "project", "{projectName}"')
            return 1, 'Add favorite success'
        except:
            return 0, 'Add favorite failed'

    def insert_deployment(self, deploymentId, deploymentName, pipelineId):
        """Store pipeline name into database

        Args:
            deploymentId (str): deployment id
            deploymentName (str): deployment name
            pipelineId (str): pipeline id
            methodType (str): method type
        """
        insertSQL = f"""
        INSERT INTO
            deployment (deployment_id, deployment_name, pipeline_id)
        VALUES
            ("{deploymentId}", "{deploymentName}", "{pipelineId}")
        """
        self.my.ExecNoQuery(insertSQL)

    def create_deployment(self, projectName, experimentName, pipelineName, deploymentName):
        """Create deployment

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name
            deploymentName (str): deployment name

        Returns:
            tuple[0]: 0: create deployment failed, 1: create deployment success
            tuple[1]: log message
        """
        ### Generate deployment id
        deploymentId = self.generate_uid("deployment")
        try:
            ### Get pipeline id
            pipelineId = self.read_value_with_cond(
                tableName="project, experiment, pipeline",
                selectColumn="pipeline.pipeline_id",
                condition=f'project.project_id = experiment.project_id\
                            and experiment.experiment_id = pipeline.experiment_id\
                            and project.project_name="{projectName}"\
                            and experiment.experiment_name="{experimentName}"\
                            and pipeline.pipeline_name="{pipelineName}"',
            )
            ### Create pipeline
            self.insert_deployment(deploymentId, deploymentName, pipelineId)
            return 1, "Create deployment success"
        except:
            return 0, "Create deployment failed"

    def deployment_rename(self, projectName, experimentName, pipelineName, deploymentName, deploymentRename):
        """Rename deployment

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name
            deploymentName (str): deployment name
            deploymentRename (str): deployment rename
        """
        try:
            self.update_value_with_cond(
                "project, experiment, pipeline, deployment",
                f'deployment.deployment_name="{deploymentRename}"',
                f'project.project_id = experiment.project_id\
                  and experiment.experiment_id = pipeline.experiment_id\
                  and pipeline.pipeline_id = deployment.pipeline_id\
                  and project.project_name = "{projectName}"\
                  and experiment.experiment_name = "{experimentName}"\
                  and pipeline.pipeline_name = "{pipelineName}"\
                  and deployment.deployment_name = "{deploymentName}"',
            )
            return 1, "Rename deployment success"
        except:
            return 0, "Rename deployment failed"
    
    def update_deployment_abstract(self, pipelineId, deploymentName, deploymentAbstract):
        """Update abstract column of deployment database

        Args:
            pipelineId (str): pipeline ID
            deploymentName (str): deployment name
            deploymentAbstract (str): deployment abstract
        """
        message = self.update_value_with_cond("deployment", f"abstract='{deploymentAbstract}'",
                                        f"deployment_name='{deploymentName}' AND pipeline_id='{pipelineId}'")
        if 'Data too long' in message:
            return 0, 'The content of the abstract is too long, the limit is 500 words'
        return 1, 'Save abstract success'
