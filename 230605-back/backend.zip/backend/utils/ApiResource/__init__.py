import jwt

KEY = 'AUO-SALA2'
ALGORITHM = 'HS256'

def encode_key(config):
    """Encode config

    Args:
        config (dict): experiment config

    Returns:
        tuple[0]: False: encode config failed, True: encode result
        tuple[1]: log message
    """
    try:
        token = jwt.encode(config, KEY, algorithm=ALGORITHM)
        return True, token
    except:
        return False, 'Encode config failed'

def decode_key(token):
    """Decode config

    Args:
        token (str): experiment key

    Returns:
        tuple[0]: False: decode key failed, True: experiment config
        tuple[1]: log message
    """
    try:
        config = jwt.decode(token, KEY, algorithms=[ALGORITHM])
        return True, config
    except:
        return False, 'Decode key failed'
