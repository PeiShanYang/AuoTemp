config = {
    "ConfigPreprocess": {
        "preprocessPara": {
            "GaussianBlur": {
                "description": "對影像做高斯模糊",
                "order": 0,
                "parameters": {
                    "kernelSize": {
                        "type": "list",
                        "default": [3, 3],
                        "enums": {
                            "3x3": [3, 3],
                            "5x5": [5, 5],
                            "7x7": [7, 7],
                            "9x9": [9, 9],
                            "11x11": [11, 11]
                        }
                    },
                    "sigma": {
                        "type": "float",
                        "default": 1,
                        "min": 0,
                        "max": 10,
                    }
                }
            },
            "Brightness": {
                "description": "對影像做亮度調整",
                "order": 0,
                "parameters": {
                    "brightness": {
                        "type": "float",
                        "default": 1.1,
                        "min": 0,
                        "max": 10,
                    }
                }
            },
            "Contrast": {
                "description": "對影像做對比度調整",
                "order": 0,
                "parameters": {
                    "contrast": {
                        "type": "float",
                        "default": 1.1,
                        "min": 0,
                        "max": 10,
                    }
                }
            },
            "Saturation": {
                "description": "對影像做飽和度調整",
                "order": 0,
                "parameters": {
                    "saturation": {
                        "type": "float",
                        "default": 1.1,
                        "min": 0,
                        "max": 10,
                    }
                }
            },
            "Hue": {
                "description": "對影像做色調調整",
                "order": 0,
                "parameters": {
                    "hue": {
                        "type": "float",
                        "default": 0.05,
                        "min": -0.5,
                        "max": 0.5,
                    }
                }
            }
        }
    },
    "ConfigAugmentation": {
        "augmentationPara": {
            "RandomHorizontalFlip": {
                "description": "以給定的機率隨機對影像做水平翻轉",
                "order": 1,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    }
                }
            },
            "RandomVerticalFlip": {
                "description": "以給定的機率隨機對影像做垂直翻轉",
                "order": 2,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    }
                }
            },
            "RandomEqualize": {
                "description": "以給定的機率隨機對影像做直方圖平均",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    }
                }
            },
            "RandomPosterize": {
                "description": "以給定的機率隨機對影像減少通道位數以達到色調分離",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "bits": {
                        "type": "int",
                        "default": 4,
                        "max": 8,
                        "min": 0
                    }
                }
            },
            "RandomSolarize": {
                "description": "以給定的機率隨機對影像進行曝光",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "threshold": {
                        "type": "int",
                        "default": 127,
                        "max": 255,
                        "min": 0
                    }
                }
            },
            "RandomAdjustSharpness": {
                "description": "以給定的機率隨機對影像做銳度調整",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "sharpnessFactor": {
                        "type": "int",
                        "default": 2,
                        "max": 5,
                        "min": 0
                    }
                }
            },
            "RandomAutocontrast": {
                "description": "以給定的機率隨機對影像進行最大對比調整",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    }
                }
            },
            "RandomErasing": {
                "description": "在給定範圍內產生一個矩形，隨機對影像做遮罩",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "scale": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.02,
                                "max": 1,
                                "min": 0,
                            },
                            "max": {
                                "type": "float",
                                "default": 0.33,
                                "max": 1,
                                "min": 0,
                            }
                        },
                        "display": "erasingSizeRatio"
                    },
                    "ratio": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.3,
                                "min": 0,
                                "max": 2
                            },
                            "max": {
                                "type": "float",
                                "default": 3.3,
                                "min": 0,
                                "max": 2
                            }
                        },
                        "display": "lengthWidthRatio"
                    },
                    "value": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        },
                        "display": "fill"
                    }
                }
            },
            "RandomBrightness": {
                "description": "在給定亮度範圍內隨機對影像做亮度調整",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "brightness": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 10
                            },
                            "max": {
                                "type": "float",
                                "default": 1.5,
                                "min": 0,
                                "max": 10
                            }
                        }
                    }
                }
            },
            "RandomContrast": {
                "description": "在給定對比度範圍內隨機對影像對比度調整",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "contrast": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 10
                            },
                            "max": {
                                "type": "float",
                                "default": 1.5,
                                "min": 0,
                                "max": 10
                            }
                        }
                    }
                }
            },
            "RandomSaturation": {
                "description": "在給定飽和度範圍內隨機對影像做飽和度調整",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "saturation": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 10
                            },
                            "max": {
                                "type": "float",
                                "default": 1.5,
                                "min": 0,
                                "max": 10
                            }
                        }
                    }
                }
            },
            "RandomHue": {
                "description": "在給定色調範圍內隨機對影像做色調調整",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "hue": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": -0.05,
                                "max": 0.5,
                                "min": -0.5,
                            },
                            "max": {
                                "type": "float",
                                "default": 0.05,
                                "max": 0.5,
                                "min": -0.5,
                            }
                        }
                    }
                }
            },
            "RandomIoUCrop": {
                "description": "對目標隨機框選不同大小的框",
                "order": 0,
                "parameters": {
                    "trials": {
                        "type": "int",
                        "default": 40,
                        "max": 100,
                        "min": 1,
                    }
                }
            },
            "ScaleJitter": {
                "description": "對影像隨機框選不同大小的框",
                "order": 0,
                "parameters": {
                    "targetSize": {
                        "type": "list",
                        "default": [128, 128],
                        "enums": {
                            "128x128": [128, 128],
                            "224x224": [224, 224],
                            "256x256": [256, 256],
                            "512x512": [512, 512]
                        }
                    },
                    "scaleRange": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.1,
                                "max": 5,
                                "min": 0.1,
                            },
                            "max": {
                                "type": "float",
                                "default": 2,
                                "max": 5,
                                "min": 0.1,
                            }
                        }
                    },
                    "interpolation": {
                        "type": "string",
                        "default": "BILINEAR",
                        "enums": {
                            "BILINEAR": "BILINEAR",
                            "NEAREST": "NEAREST",
                            "BICUBIC": "BICUBIC"
                        }
                    }
                }
            },
            "FixedSizeCrop": {
                "description": "對影像隨機框選相同大小的框",
                "order": 0,
                "parameters": {
                    "size": {
                        "type": "list",
                        "default": [128, 128],
                        "enums": {
                            "128x128": [128, 128],
                            "224x224": [224, 224],
                            "256x256": [256, 256],
                            "512x512": [512, 512]
                        }
                    },
                    "fill": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        }
                    },
                    "paddingMode": {
                        "type": "string",
                        "default": "constant",
                        "enums": {
                            "constant": "constant",
                            "edge": "edge",
                            "reflect": "reflect",
                            "symmetric": "symmetric",
                        }
                    }
                }
            },
            "RandomShortestSize": {
                "description": "對影像隨機框選相同大小的框",
                "order": 0,
                "parameters": {
                    "interpolation": {
                        "type": "string",
                        "default": "BILINEAR",
                        "enums": {
                            "BILINEAR": "BILINEAR",
                            "NEAREST": "NEAREST",
                            "BICUBIC": "BICUBIC"
                        }
                    }
                }
            }
        }
    },
    "ConfigModelService": {
        "learningRatePara": {
            "learningRate": {
                "type": "float",
                "default": 0.001,
                "min": 0,
                "max": 1
            }
        },
        "optimizerPara": {
            "optimizer": {
                "type": "string",
                "default": "SGD",
                "enums": {
                    "SGD": "SGD"
                }
            }
        },
        "schedulerPara": {
            "scheduler": {
                "type": "string",
                "default": "multiStepLR",
                "enums": {
                    "multiStepLR": "multiStepLR"
                }
            }
        }
    },
    "ConfigPytorchModel": {
        "modelPara": {
            "model": {
                "structure": {
                    "type": "string",
                    "default": "auo_onestage_antidegeneration_model",
                    "enums": {
                        "auo_onestage_classic_model": "auo_onestage_classic_model",
                        "auo_onestage_litghten_model": "auo_onestage_litghten_model",
                        "auo_twostage_antidegeneration_model": "auo_twostage_antidegeneration_model",
                        "auo_onestage_antidegeneration_model": "auo_onestage_antidegeneration_model"
                    }
                },
                "pretrained": {
                    "type": "boolean",
                    "default": True
                }
            }
        },
        "servicePara": {
            "batchSize": {
                "type": "int",
                "default": 4,
                "min": 1,
                "max": 256,
                "unit": "/batch"
            },
            "epochs": {
                "type": "int",
                "default": 10,
                "min": 1,
                "max": 1000,
                "unit": "epochs"
            }
        }
    },
    "ConfigPostprocess": {
        "postProcessPara": {
            "nms": {
                "description": "非最大值抑制",
                "order": 1,
                "parameters": {
                    "iouTreshold": {
                        "type": "float",
                        "default": 0.3,
                        "min": 0,
                        "max": 1
                    }
                }
            }
        }
    }
}
