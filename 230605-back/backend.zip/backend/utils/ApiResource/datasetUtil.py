import os

def have_same_split_rate(originalSplitRate, splitRate):
    """Check that original split rate is the same as split rate to be updated

    Args:
        originalSplitRate (dict): original split rate
            - key: split type (Train, Test, and Valid)
            - value: split rate
        splitRate (dict): split rate to be updated
            - key: split type (Train, Test, and Valid)
            - value: split rate
    Returns:
        boolean: return True if there are same rate, Otherwise, return False
    """
    return all(list(map(lambda x, y: originalSplitRate.get(x) == splitRate.get(y), originalSplitRate, splitRate)))


def remove_non_image_files(fileNames):
    """Remove non-image files

    Args:
        fileNames (list): file names including non-image file in a single folder

    Returns:
        list: file names excluding non-image file in a single folder
    """
    legalFileTypes = ['.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff']
    chara = '~!#$%^&*{[]}\\/?:;"<>|\'\n\a\b\f\r\t\v'
    tempFileNames = fileNames.copy()
    for fileName in tempFileNames:
        if sum([fileName.lower().endswith(legalFileType) for legalFileType in legalFileTypes]) != 1 or (set(fileName) & set(chara)):
            fileNames.remove(fileName)
    return fileNames


def is_legal_split(dirNames, listOfLegalSplitType):
    """ YY program

    Args:
        dirNames (_type_): _description_
        listOfLegalSplitType (_type_): _description_

    Returns:
        _type_: _description_
    """
    return all([legalSplitType in dirNames for legalSplitType in listOfLegalSplitType])


def calculate_split_rate(imgNumsOfSplitType):
    """Calculate split rate for each split type

    Args:
        imgNumsOfSplitType (dict): numbers of image of Train, Test, and Valid
            - key: split type (Train, Test, and Valid)
            - value: numbers of image

    Returns:
        dict: split rate for each split type. ex. {'Train': train_rate, 'Test': test_rate, 'Valid': valid_rate}
            - key: split type (Train, Test, and Valid)
            - value: split rate
    """
    allImgNums = 0
    for imgNums in imgNumsOfSplitType.values():
        allImgNums += imgNums

    valid_rate = round(imgNumsOfSplitType.get("Valid")/allImgNums*100)
    test_rate = round(imgNumsOfSplitType.get("Test")/allImgNums*100)
    train_rate = 100 - (valid_rate + test_rate)

    return {'Train': train_rate, 'Test': test_rate, 'Valid': valid_rate}


def get_dataset_info(datasetPath):
    """Get image imformation in dataset folder

    Args:
        datasetPath (str): dataset folder path

    Returns:
        - classifiedInfo (dict): classified file imformation: key (str): folder path, value (list): image names
        - listOfClassifiedName (set): list of class name
        - imgNumsOfSplitType (dict): numbers of image of Train, Test, and Valid: key (str): split type, value (list): the number of images
    """
    classifiedInfo = {}   ### key (str): folder path , value (list): image names
    listOfClassifiedName = set()   ### Save all classification name
    imgNumsOfSplitType = {'Train': 0, 'Test': 0, 'Valid': 0}   ### Record numbers of image of Train, Test, and Valid
    for splitType in ['Train','Test','Valid']:   ### first folder level(Folder name is Train, Test, or Valid)
        for clsName in os.listdir(os.path.join(datasetPath, splitType)):   ### second folder level(Folder name is classification name)
            if os.path.isfile(clsName):
                continue
            imageNames =  remove_non_image_files(os.listdir(os.path.join(datasetPath, splitType, clsName)))   ### Get all image name
            if len(imageNames) > 0:
                classifiedInfo[os.path.join(datasetPath, splitType, clsName)] = imageNames
                listOfClassifiedName.add(clsName)
                imgNumsOfSplitType[splitType] += len(imageNames)

    return classifiedInfo, listOfClassifiedName, imgNumsOfSplitType


def have_split_rate(splitRate):
    """Check split rate is not empty and return split rate

    Args:
        splitRate (dict): split rate

    Returns:
        tuple[0]: 0: split rate incorrect, 1: split rate
        tuple[1]: 0: log message, 1: split rate
    """
    listOfLegalSplitRateType = ['train_rate', 'valid_rate', 'test_rate']
    numOfStandard = sum([splitRate.get(SplitRateType) != 'None' and \
                         splitRate.get(SplitRateType) != None and \
                         splitRate.get(SplitRateType) != '' \
                         for SplitRateType in listOfLegalSplitRateType])
    ### existed all value
    if numOfStandard == 3:
        return 1, {"Train": int(splitRate.get('train_rate')), "Valid": int(splitRate.get('valid_rate')),
                    "Test": int(splitRate.get('test_rate'))}
    ### existed no value
    elif numOfStandard == 0:
        return 1, {"Train": 0 , "Valid": 0, "Test": 0}
    else:
        return 0, 'Split rate incorrect'


def check_special_characters(file): # TC:O(N) SC:O(1)
    """ Check if special character is in the file name or folder name

    Args:
        file (str): file name or folder name

    Returns:
        boolean
    """
    chara = '~!#$%^&*{[]}\\?:;"<>|\'\n\a\b\f\r\t\v'
    for chars in chara:
        if chars in file:
            return False
    return True


def img_check(file): # TC:O(1) SC:O(1)
    """ Check if image file (or path) is legal

    Args:
        file (str): file name or path

    Returns:
        boolean
    """
    filetype = ['.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff']
    for ft in filetype:
        if file.lower().endswith(ft):
            if check_special_characters(os.path.split(file)[-1]):
                return True
    return False


def img_folder_check(path): # TC:O(N) SC:O(1)
    """ check if any image existed in the folder

    Args:
        path (str): folder pathh

    Returns:
        boolean
    """
    count = 0
    for img in os.listdir(path):
        if os.path.isdir(path + "/" + img):
            return False
        else:
            if img_check(img):
                count += 1
    return count >= 1
