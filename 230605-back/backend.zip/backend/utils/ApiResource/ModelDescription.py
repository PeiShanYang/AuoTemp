modelDescription = {
    "auo_tiny_focus_model": {
        "opendataAcc": "★☆☆☆☆",
        "easeOfUsage": "★☆☆☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "小型網路，靈活卷積尺寸及層數，可適用多樣特徵。"
    },
    "auo_small_convolution_model_a": {
        "opendataAcc": "★★☆☆☆",
        "easeOfUsage": "★★☆☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "基於小卷積模型的改進，以利加速收斂、減少過擬合並提高模型準確性。"
    },
    "auo_small_convolution_model_b": {
        "opendataAcc": "★★☆☆☆",
        "easeOfUsage": "★★☆☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "基於小卷積模型的改進，以利加速收斂、減少過擬合並提高模型準確性。"
    },
    "auo_small_convolution_model_c": {
        "opendataAcc": "★★☆☆☆",
        "easeOfUsage": "★★☆☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "基於小卷積模型的改進，以利加速收斂、減少過擬合並提高模型準確性。"
    },
    "auo_small_convolution_model_d": {
        "opendataAcc": "★★☆☆☆",
        "easeOfUsage": "★★☆☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "基於小卷積模型的改進，以利加速收斂、減少過擬合並提高模型準確性。"
    },
    "auo_classic_deep_model_a": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★☆☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "固定卷積數量與架構，增加網路深度，取得更深層特徵。"
    },
    "auo_classic_deep_model_b": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★☆☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "固定卷積數量與架構，增加網路深度，取得更深層特徵。"
    },
    "auo_classic_deep_model_c": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★☆☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "固定卷積數量與架構，增加網路深度，取得更深層特徵。"
    },
    "auo_anti_degeneration_model_a": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "深度網路，加強卷積層連結，保留底層特徵資訊，並提升可訓練程度。"
    },
    "auo_anti_degeneration_model_b": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "深度網路，加強卷積層連結，保留底層特徵資訊，並提升可訓練程度。"
    },
    "auo_anti_degeneration_model_c": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "深度網路，加強卷積層連結，保留底層特徵資訊，並提升可訓練程度。"
    },
    "auo_anti_degeneration_model_d": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "深度網路，加強卷積層連結，保留底層特徵資訊，並提升可訓練程度。"
    },
    "auo_anti_degeneration_model_e": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "深度網路，加強卷積層連結，保留底層特徵資訊，並提升可訓練程度。"
    },
    "auo_transform_aggregate_model_a": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於抗退化模型，通過將多分支的卷積運算合併，已提高速度。"
    },
    "auo_transform_aggregate_model_b": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於抗退化模型，通過將多分支的卷積運算合併，已提高速度。"
    },
    "auo_feature_widen_model_a": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "模型有更深且更多的特徵數量，提高模型的泛化能力和準確性。"
    },
    "auo_feature_widen_model_b": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "模型有更深且更多的特徵數量，提高模型的泛化能力和準確性。"
    },
    "auo_cross_connection_model": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於抗退化模型，通過將多分支的卷積運算合併，已提高速度。"
    },
    "auo_narrow_intensive_model_a": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "透過密度連接所有特徵圖，提高特徵復用率，減少信息的丟失。"
    },
    "auo_narrow_intensive_model_b": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "透過密度連接所有特徵圖，提高特徵復用率，減少信息的丟失。"
    },
    "auo_narrow_intensive_model_c": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "透過密度連接所有特徵圖，提高特徵復用率，減少信息的丟失。"
    },
    "auo_narrow_intensive_model_d": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "透過密度連接所有特徵圖，提高特徵復用率，減少信息的丟失。"
    },
    "auo_group_convolution_model_a": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "利用分組卷積的特性，由不同深度與寬度組合權衡兼具精度與效率的模型。"
    },
    "auo_group_convolution_model_b": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "利用分組卷積的特性，由不同深度與寬度組合權衡兼具精度與效率的模型。"
    },
    "auo_group_convolution_model_c": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "利用分組卷積的特性，由不同深度與寬度組合權衡兼具精度與效率的模型。"
    },
    "auo_group_convolution_model_d": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "利用分組卷積的特性，由不同深度與寬度組合權衡兼具精度與效率的模型。"
    },
    "auo_group_convolution_model_e": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "利用分組卷積的特性，由不同深度與寬度組合權衡兼具精度與效率的模型。"
    },
    "auo_group_convolution_model_f": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "利用分組卷積的特性，由不同深度與寬度組合權衡兼具精度與效率的模型。"
    },
    "auo_group_convolution_model_g": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "利用分組卷積的特性，由不同深度與寬度組合權衡兼具精度與效率的模型。"
    },
    "auo_unrestricted_powerful_model_a": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於分群卷積模型，加上特徵萃取模組，提升模型準確率。"
    },
    "auo_unrestricted_powerful_model_b": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於分群卷積模型，加上特徵萃取模組，提升模型準確率。"
    },
    "auo_unrestricted_powerful_model_c": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於分群卷積模型，加上特徵萃取模組，提升模型準確率。"
    },
    "auo_unrestricted_powerful_model_d": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於分群卷積模型，加上特徵萃取模組，提升模型準確率。"
    },
    "auo_unrestricted_powerful_model_e": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於分群卷積模型，加上特徵萃取模組，提升模型準確率。"
    },
    "auo_unrestricted_powerful_model_f": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於分群卷積模型，加上特徵萃取模組，提升模型準確率。"
    },
    "auo_unrestricted_powerful_model_g": {
        "opendataAcc": "★★★★☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "基於分群卷積模型，加上特徵萃取模組，提升模型準確率。"
    },
    "auo_faster_convergency_model_a": {
        "opendataAcc": "★★★★★",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "對於深度、寬度、解析度進行優化結構，讓模型達到更好地效率。"
    },
    "auo_faster_convergency_model_b": {
        "opendataAcc": "★★★★★",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "對於深度、寬度、解析度進行優化結構，讓模型達到更好地效率。"
    },
    "auo_faster_convergency_model_c": {
        "opendataAcc": "★★★★★",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "對於深度、寬度、解析度進行優化結構，讓模型達到更好地效率。"
    },
    "auo_faster_convergency_model_d": {
        "opendataAcc": "★★★★★",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "對於深度、寬度、解析度進行優化結構，讓模型達到更好地效率。"
    },
    "auo_faster_convergency_model_e": {
        "opendataAcc": "★★★★★",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "對於深度、寬度、解析度進行優化結構，讓模型達到更好地效率。"
    },
    "auo_faster_convergency_model_f": {
        "opendataAcc": "★★★★★",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "對於深度、寬度、解析度進行優化結構，讓模型達到更好地效率。"
    },
    "auo_faster_convergency_model_g": {
        "opendataAcc": "★★★★★",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "對於深度、寬度、解析度進行優化結構，讓模型達到更好地效率。"
    },
    "auo_faster_convergency_model_h": {
        "opendataAcc": "★★★★★",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "對於深度、寬度、解析度進行優化結構，讓模型達到更好地效率。"
    },
    "auo_cpu_optimization_model_a": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★★☆",
        "introduction": "因應硬體性能有限時，模型保有最大限度準確率下，提升 CPU 運算效率。"
    },
    "auo_cpu_optimization_model_b": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★★☆",
        "introduction": "因應硬體性能有限時，模型保有最大限度準確率下，提升 CPU 運算效率。"
    },
    "auo_accelerate_computing_model_a": {
        "opendataAcc": "★★☆☆☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★★★",
        "introduction": "模型設計原則希望最大化提升模型 GPU 運行效率。"
    },
    "auo_accelerate_computing_model_b": {
        "opendataAcc": "★★☆☆☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★★★",
        "introduction": "模型設計原則希望最大化提升模型 GPU 運行效率。"
    },
    "auo_lighten_efficient_model_a": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★★☆",
        "introduction": "透過自動搜索演算法，設計出輕量化的神經網路模型。"
    },
    "auo_lighten_efficient_model_b": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★★★☆",
        "introduction": "透過自動搜索演算法，設計出輕量化的神經網路模型。"
    },
    "auo_onestage_classic_model": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★☆☆☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "單階段的目標檢測演算法，不需要生成候選區域，計算量小，檢測速度快。"
    },
    "auo_onestage_litghten_model": {
        "opendataAcc": "★★☆☆☆",
        "easeOfUsage": "★☆☆☆☆",
        "trainSpeed": "★★★★☆",
        "introduction": "使用輕量化骨幹網路，檢測速度更快。"
    },
    "auo_twostage_antidegeneration_model": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★★☆☆",
        "trainSpeed": "★★☆☆☆",
        "introduction": "因使用兩階段檢測算法，整體檢測準確率較高。"
    },
    "auo_onestage_antidegeneration_model": {
        "opendataAcc": "★★★☆☆",
        "easeOfUsage": "★★★★☆",
        "trainSpeed": "★★★☆☆",
        "introduction": "通過類別不平衡演算法，對於正負樣本的處理更加平衡，提升模型檢測率。"
    },
}
