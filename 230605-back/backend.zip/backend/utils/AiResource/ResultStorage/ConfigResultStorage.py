# -*- coding: utf-8 -*-

"""
Created on Mon Jun 15 17:00:00 2022
"""

### Choose result storage method ###
class ResultStoragePara:
    def __init__(self,
        saveFinalDictPth:dict,
        saveFinalScriptPth:dict,
        saveBestDictPth:dict,
        saveBestScriptPth:dict,
        saveCheckpoint:dict,
    ) -> None:

        """
            saveFinalDictPth (dict):{
                    "switch": (int) 0: disable, 1: enable
                }
            saveFinalScriptPth (dict): {
                    "switch": (int) 0: disable, 1: enable
                }
            saveBestDictPth (dict): {
                    "switch": (int) 0: disable, 1: enable
                }
            saveBestScriptPth (dict): {
                    "switch": (int) 0: disable, 1: enable
                }
            saveCheckpoint (dict): {
                    "switch": (int) 0: disable, 1: enable
                    "saveIter": (int) save checkpoint weight for every 'saveIter' epochs
                }
        """
        self.saveFinalDictPth    = saveFinalDictPth
        self.saveFinalScriptPth  = saveFinalScriptPth
        self.saveBestDictPth     = saveBestDictPth
        self.saveBestScriptPth   = saveBestScriptPth
        self.saveCheckpoint      = saveCheckpoint


class ClsResultStoragePara(ResultStoragePara):
    def __init__(self, saveFinalDictPth: dict, saveFinalScriptPth: dict, saveFinalOnnx: dict,
                       saveBestDictPth: dict, saveBestScriptPth: dict, saveBestOnnx: dict,
                       saveCheckpoint: dict, savePredictResult: dict, saveWrongFile: dict,
                       saveUnknownFile: dict, saveClassIniFile: dict) -> None:
        """
        # Save final model in onnx file
        saveFinalOnnx: {
            "switch": (int) 0: disable, 1: enable
        }

        # Save best model in onnx file.
        saveBestOnnx: {
            "switch": (int) 0: disable, 1: enable
        }

        # Save test or inference result in csv file
        savePredictResult: {
            "switch": (int) 0: disable, 1: enable
        }

        # Save file name of wrong predicted images
        saveWrongFile {
            "switch": (int) 0: disable, 1: enable
        }

        # Save file name of Unknown
        saveUnknownFile: {
            "switch": (int) 0: disable, 1: enable
        }

        # Save all class names into ini file
        saveClassIniFile: {
            "switch": (int) 0: disable, 1: enable
            "fileName": (str) ini file name
        }
        """
        super().__init__(saveFinalDictPth, saveFinalScriptPth,
                        saveBestDictPth, saveBestScriptPth,
                        saveCheckpoint)

        self.saveFinalOnnx       = saveFinalOnnx
        self.saveBestOnnx        = saveBestOnnx
        self.savePredictResult   = savePredictResult
        self.saveWrongFile       = saveWrongFile
        self.saveUnknownFile     = saveUnknownFile
        self.saveClassIniFile    = saveClassIniFile

    @classmethod
    def create_from_dict(cls, resultStorage:list):
        """
        resultStorage: {
            # Save final weight (.pth)
            "saveFinalDictPth": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Save final model in torch script (.pth)
            "saveFinalScriptPth": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Save final model in onnx file
            "saveFinalOnnx": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Save best weight (.pth)
            "saveBestDictPth": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Save best model into torch script (.pth)
            "saveBestScriptPth": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Save best model in onnx file.
            "saveBestOnnx": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Save checkpoint weight for every 'saveIter' epochs
            "saveCheckpoint": (dict) {
                "switch"  : (int) 0: disable, 1: enable
                "saveIter": (int) save checkpoint weight for every 'saveIter' epochs
            }

            # Save test or inference result in csv file
            "savePredictResult": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Save file name of wrong predicted images
            "saveWrongFile": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Save file name of Unknown
            "saveUnknownFile": (dict) {
                "switch": (int) 0: disable, 1: enable
            }
        }
        """
        return cls(**resultStorage)


class DetResultStoragePara(ResultStoragePara):
    def __init__(self, saveFinalDictPth:dict, saveFinalScriptPth:dict, saveFinalOnnx: dict,
                       saveBestDictPth:dict, saveBestScriptPth:dict, saveBestOnnx: dict,
                       saveCheckpoint:dict, saveClassIniFile: dict, scoreThreshold:float,
                       iouTreshold:float,  saveResultCsv:dict, drawResultImage:dict) -> None:
        """
            scoreThreshold (float): confidence socre threshold
            iouTreshold (float):  prediction and solution area of interscetion union ratio
            saveResultCsv (dict):{
                    "switch"  : (int) 0: disable, 1: enable
            }
            drawResultImage (dict): {
                    "switch"  : (int) 0: disable, 1: enable
                    "lineThickness": (int) 2
            }
        """
        super().__init__(saveFinalDictPth, saveFinalScriptPth,
                        saveBestDictPth, saveBestScriptPth,
                        saveCheckpoint)
        self.saveFinalOnnx       = saveFinalOnnx
        self.saveBestOnnx        = saveBestOnnx
        self.scoreThreshold      = scoreThreshold
        self.iouTreshold         = iouTreshold
        self.saveResultCsv       = saveResultCsv
        self.saveClassIniFile    = saveClassIniFile
        self.drawResultImage     = drawResultImage

    @classmethod
    def create_from_dict(cls, resultStorage:dict) -> None:
        """
        # Save final weight (.pth)
        resultStorage["saveFinalDictPth"]: (dict) {
            "switch": (int) 0: disable, 1: enable
        }

        # Save final model in torch script (.pth)
        resultStorage["saveFinalScriptPth"]: (dict) {
            "switch": (int) 0: disable, 1: enable
        }

        # Save best weight (.pth)
        resultStorage["saveBestDictPth"]: (dict) {
            "switch": (int) 0: disable, 1: enable
        }

        # Save best model into torch script (.pth)
        resultStorage["saveBestScriptPth"]: (dcit) {
            "switch": (int) 0: disable, 1: enable
        }

        # Save checkpoint weight for every 'saveIter' epochs
        resultStorage["saveCheckpoint"]: (dict) {
            "switch"  : (int) 0: disable, 1: enable
            "saveIter": (int) save checkpoint weight for every 'saveIter' epochs
        }

        resultStorage["scoreThreshold"]: (float) confidence socre threshold
        resultStorage["iouTreshold"]   : (float) prediction and solution area of interscetion union ratio

        # Save detection result to csv file
        resultStorage["saveResultCsv"]: (dict) {
            "switch"  : (int) 0: disable, 1: enable
        }
        # Plot the result on th image
        resultStorage["drawResultImage"]: (dict){
            "switch" : (int) 0: disable, 1: enable
        }
        """
        return cls(**resultStorage)
