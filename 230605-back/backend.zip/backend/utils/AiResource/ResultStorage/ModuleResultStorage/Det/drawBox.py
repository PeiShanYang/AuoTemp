import collections
import PIL
import PIL.ImageDraw as ImageDraw
import PIL.ImageFont as ImageFont
import numpy as np
import os

STANDARD_COLORS = [
    'AliceBlue', 'Chartreuse', 'Aqua', 'Aquamarine', 'Azure', 'Beige', 'Bisque',
    'BlanchedAlmond', 'BlueViolet', 'BurlyWood', 'CadetBlue', 'AntiqueWhite',
    'Chocolate', 'Coral', 'CornflowerBlue', 'Cornsilk', 'Crimson', 'Cyan',
    'DarkCyan', 'DarkGoldenRod', 'DarkGrey', 'DarkKhaki', 'DarkOrange',
    'DarkOrchid', 'DarkSalmon', 'DarkSeaGreen', 'DarkTurquoise', 'DarkViolet',
    'DeepPink', 'DeepSkyBlue', 'DodgerBlue', 'FireBrick', 'FloralWhite',
    'ForestGreen', 'Fuchsia', 'Gainsboro', 'GhostWhite', 'Gold', 'GoldenRod',
    'Salmon', 'Tan', 'HoneyDew', 'HotPink', 'IndianRed', 'Ivory', 'Khaki',
    'Lavender', 'LavenderBlush', 'LawnGreen', 'LemonChiffon', 'LightBlue',
    'LightCoral', 'LightCyan', 'LightGoldenRodYellow', 'LightGray', 'LightGrey',
    'LightGreen', 'LightPink', 'LightSalmon', 'LightSeaGreen', 'LightSkyBlue',
    'LightSlateGray', 'LightSlateGrey', 'LightSteelBlue', 'LightYellow', 'Lime',
    'LimeGreen', 'Linen', 'Magenta', 'MediumAquaMarine', 'MediumOrchid',
    'MediumPurple', 'MediumSeaGreen', 'MediumSlateBlue', 'MediumSpringGreen',
    'MediumTurquoise', 'MediumVioletRed', 'MintCream', 'MistyRose', 'Moccasin',
    'NavajoWhite', 'OldLace', 'Olive', 'OliveDrab', 'Orange', 'OrangeRed',
    'Orchid', 'PaleGoldenRod', 'PaleGreen', 'PaleTurquoise', 'PaleVioletRed',
    'PapayaWhip', 'PeachPuff', 'Peru', 'Pink', 'Plum', 'PowderBlue', 'Purple',
    'Red', 'RosyBrown', 'RoyalBlue', 'SaddleBrown', 'Green', 'SandyBrown',
    'SeaGreen', 'SeaShell', 'Sienna', 'Silver', 'SkyBlue', 'SlateBlue',
    'SlateGray', 'SlateGrey', 'Snow', 'SpringGreen', 'SteelBlue', 'GreenYellow',
    'Teal', 'Thistle', 'Tomato', 'Turquoise', 'Violet', 'Wheat', 'White',
    'WhiteSmoke', 'Yellow', 'YellowGreen'
]

def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath: the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)   

def filter_low_thresh(
    predDict:dict, 
    classLabel:dict, 
    threshold:float,
    boxToDisplayStrMap:dict, 
    boxToColorMap:dict
):
    """
    Filter out confidence scores below the lower threshold, and record display dict  
    Args:
        predDict (dict): [
                "boxes"   (ndarray) : predict the coordinates of box
                "labels"  (ndarray) : predict box of category
                "scores"  (ndarray) : predict box confidence score
            ]
        classLabel (dict): number corresponds to category 
        threshold (float): confidence socre threshold. Defaults to 0.5.
        boxToDisplayStrMap (dict): box item for display record
        boxToColorMap (dict): class name item for color record
    """
    boxes = predDict["boxes"]
    classes = predDict["labels"]
    scores = predDict["scores"]
    
    for i in range(boxes.shape[0]):
        if scores[i] > threshold:
            box = tuple(boxes[i].tolist())
            if classes[i] in classLabel.keys():
                labelName = classLabel[classes[i]]
            else:
                labelName = 'N/A'
            displayStr = str(labelName)
            displayStr = '{}: {}%'.format(displayStr, int(100 * scores[i]))
            boxToDisplayStrMap[box].append(displayStr)
            boxToColorMap[box] = STANDARD_COLORS[
                classes[i] % len(STANDARD_COLORS)]
        else:
            break


def draw_text(
    draw:ImageDraw, 
    boxToDisplayStrMap:dict, 
    box:list, 
    color:str):
    """
    box class txt drawn on image

    Args:
        draw (ImageDraw): image can drawing type
        boxToDisplayStrMap (dict): box item for display record
        box (list): x1, y1, x2, y2
        color (str): color name in [STANDARD_COLORS]
    """
    try:
        # font = ImageFont.truetype('arial.ttf', 24)
        font = ImageFont.truetype("./calibril.ttf", 15)
    except IOError:
        font = ImageFont.load_default()

    left, top, right, bottom = box

    displayStrHeights = [font.getsize(ds)[1] for ds in boxToDisplayStrMap[box]]
    totalDisplayStrHeight = (1 + 2 * 0.05) * sum(displayStrHeights)

    if top > totalDisplayStrHeight:
        textBottom = top
    else:
        textBottom = bottom + totalDisplayStrHeight
    # Reverse list and print from bottom to top.
    for displayStr in boxToDisplayStrMap[box][::-1]:
        textWidth, textHeight = font.getsize(displayStr)
        margin = np.ceil(0.05 * textHeight)
        draw.rectangle([(left, textBottom - textHeight - 2 * margin),
                        (left + textWidth, textBottom)], fill=color)
        draw.text((left + margin, textBottom - textHeight - margin),
                  displayStr,
                  fill='black',
                  font=font)
        textBottom -= textHeight - 2 * margin

# def draw_text2(draw, boxToDisplayStrMap, box, color):
#     try:
#         # font = ImageFont.truetype('arial.ttf', 24)
#         font = ImageFont.truetype("./calibril.ttf", 15)
#     except IOError:
#         font = ImageFont.load_default()
    
#     for displayStr in boxToDisplayStrMap[box][::-1]:
#         textWidth, textHeight = font.getsize(displayStr)
#         textboxLocation = [box[0], box[1] - textHeight, box[0] + textWidth + 4., box[1]]
#         textLocation = [box[0] + 2., box[1] - textHeight]
#         draw.rectangle(xy= textboxLocation, fill=color )
#         draw.text(xy=textLocation, text=displayStr, fill='black', font=font)


def draw_box_tool(
    predDict:dict, 
    classLabel:dict, 
    threshold:float=0.5, 
    lineThickness:int=8
)-> PIL:
    """
    draw box to image tool

    Args:
        predDict (dict): 
            [
                "image"       (PIL) : image
                "boxes"   (ndarray) : predict the coordinates of box
                "labels"  (ndarray) : predict box of category
                "scores"  (ndarray) : predict box confidence score
                "imageName"   (str) : image name
            ]
        classLabel (dict):  number corresponds to category 
        threshold (float, optional): confidence socre threshold. Defaults to 0.5.
        lineThickness (int, optional): The thickness of the box drawn on the image. Defaults to 8.

    Returns:
        after drawn on the image (PIL) 
    """
    # collections.defaultdict　: can build dict without key and value
    boxToDisplayStrMap = collections.defaultdict(list)
    boxToColorMap = collections.defaultdict(str)

    filter_low_thresh(predDict, classLabel, threshold, boxToDisplayStrMap, boxToColorMap)

    # Draw all boxes onto image.
    imageResult = predDict["image"].copy()
    drawImage = ImageDraw.Draw(imageResult)
    for box, color in boxToColorMap.items():
        drawImage.rectangle(xy=box, width=lineThickness, outline=color)
        draw_text(drawImage, boxToDisplayStrMap, box, color)
    # return draw
    return imageResult
    


def draw_box(
    predDictList:list, 
    outputPath:str, 
    classLabel:dict, 
    threshold:float=0.5, 
    lineThickness:int=8
):
    """
    draw predict box to image

    Args:
        predDictList (list): for every item
        [
            "image"       (PIL) : image
            "boxes"   (ndarray) : predict the coordinates of box
            "labels"  (ndarray) : predict box of category
            "scores"  (ndarray) : predict box confidence score
            "imageName"   (str) : image name
        ]
        outputPath (str): output path
        classLabel (dict): number corresponds to category 
        threshold (float, optional): confidence socre threshold. Defaults to 0.5.
        lineThickness (int, optional): The thickness of the box drawn on the image. Defaults to 8.
    """
    create_folder(outputPath)
    for predDict in predDictList:
        drawImage = draw_box_tool(predDict, classLabel, threshold, lineThickness)
        drawImage.save(os.path.join(outputPath, predDict["imageName"]))