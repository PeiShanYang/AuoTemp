import os
from matplotlib.transforms import Bbox
import numpy as np
from ..CsvModule import CsvHandler

class DetResultSaver:
    def __init__(self, outputPath:str, fileName:str, task:str, classLabel:dict) -> None:
        """
        create detection result object for saving result

        Args:
            outputPath (str): output path
            fileName (str): file name
            task (str): "Test" / "Inference"
            classLabel (dict): number corresponds to category
        """
        self.outputPath = outputPath
        self.fileName = fileName
        self.task = task
        self.classLabel = classLabel
        self.create_folder(outputPath)

        if task in ["Test", "Inference"]:
            title = ['filename', 'prediction', 'x1', 'y1', 'x2', 'y2', 'score']
            if task == "Test":
                title.append('iou')
            self.ResultCsv = CsvHandler(f'{task}_{fileName}.csv', outputPath, title)
            self.ResultCsv.create_csv()

    @staticmethod
    def create_folder(folderPath:str) -> None:
        """
        Create storaged folder

        Args:
            folderPath: the path wants to create
        """
        if not os.path.isdir(folderPath):
            os.makedirs(folderPath)


    def write_result_csv(self, result:list, scoreThreshold:float=0.3, iouThr:float=0.5):
        """
        write result to csv file

        Args:
            result (list): [
                "image"       (PIL) : image
                "boxes"   (ndarray) : predict the coordinates of box
                "labels"  (ndarray) : predict box of category
                "scores"  (ndarray) : predict box confidence score
                "imageName"   (str) : image name
                "iou"         (str) : iou for every predict box ]
            scoreThreshold (float, optional): confidence score threshold. Defaults to 0.3.
            iouThr (float, optional): iou threshold. Defaults to 0.5.
        """
        for resultItem in result:
            imageName = resultItem["imageName"]
            if len(resultItem["boxes"]) != 0:
                boxes = np.around(resultItem["boxes"]).astype(int)
                labels = resultItem["labels"]
                scores = resultItem["scores"]
                if self.task == 'Test':
                    try:
                        iou = resultItem["iou"]
                        iouMax, _ = iou.max(0)  # 每個預測框最大的iou
                    except:
                        iouMax = [0.0 for _ in range(iou.shape[1])]  # label的txt為空但有預測匡，給定iou = 0.0
                scoreQualified = np.where(scores > scoreThreshold)
                for boxPosition in scoreQualified[0]:
                    resultList = [imageName, self.classLabel[labels[boxPosition]], *boxes[boxPosition], np.round(scores[boxPosition], 2)]
                    if self.task == 'Test':
                        if iouMax[boxPosition] < iouThr:
                            continue
                        else:
                            resultList.append(round(float(iouMax[boxPosition]),3))
                    self.ResultCsv.write_csv(resultList, 'a')
