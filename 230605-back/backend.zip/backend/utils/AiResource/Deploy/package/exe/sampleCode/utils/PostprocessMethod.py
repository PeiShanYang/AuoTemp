
def confidence_filter(resultList: list, threshold: dict) -> list:
    '''
        Filter the specified category, and select the confidence score higher than the threshold, 
        otherwise select the next highest result, and output the result with the highest score

        Args:
            resultList: model output result
            [{
                'filename': 'BUMP_184_TOP_ok_70_31.bmp',
                'label': 'OK',
                'predict': 'OK',
                'confidence': 0.9999998807907104
                'output': {
                    'NG': 8.45041796537771e-08,
                    'OK': 0.9999998807907104
                    }
            }, {...}
            ]
            threshold: [class: confidence score threshold]            
        Return:
            resultList: Filtered new output results
    '''
    for result in resultList:
        (oriResultPredict, oriResultConfidence) = (result["predict"], result["confidence"])
        while result["predict"] in threshold.keys():
            if result["confidence"] >= threshold[result["predict"]]:
                break
            else:
                result["output"][result["predict"]] = 0
                resultClassOrder = sorted(result["output"].items(), key=lambda x:(x[1]), reverse=True)
                result["predict"], result["confidence"] = resultClassOrder[0]
                if result["confidence"] == 0:
                    (result["predict"], result["confidence"]) = (oriResultPredict, oriResultConfidence)
                    break
    return resultList


def unknown_filter(resultList: list, threshold: dict, reverse: bool=False) -> list:
    '''
        Filter the specified category and determine a new category

        Args:
            resultList: model output result
            [{
                'filename': 'BUMP_184_TOP_ok_70_31.bmp',
                'label': 'OK',
                'predict': 'OK',
                'confidence': 0.9999998807907104
                'output': {
                    'NG': 8.45041796537771e-08,
                    'OK': 0.9999998807907104
                    }
            }, {...}
            ]
            threshold: [class: confidence score threshold]         
            reverse: ascending or descending power   
        Return:
            resultList: Filtered new output results
    '''
    filterClassOrder = sorted(threshold.items(), key=lambda x:(x[1]), reverse=(not reverse))
    for result in resultList:
        for filterClass in filterClassOrder:
            if (not reverse and result["confidence"] < filterClass[1]) or (reverse and result["confidence"] > filterClass[1]):
                (result["predict"], result["confidence"]) = filterClass
    return resultList