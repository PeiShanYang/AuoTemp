from utils.AiResource.ModelService.PytorchClassificationModel.ConfigPreprocess import \
    PreprocessPara
from utils.AiResource.Deploy.ConfigDeployment import ClsDeploymentPara
from utils.AiResource.Postprocess.ConfigPostprocess import ClsPostProcessPara
from .ModuleDeploy.Cls.FileSetting import DepolyConfigJsonSetting, write_mainPy
from .ModuleDeploy.Tool import write_json, create_folder
from .ModuleDeploy.PyToPyd import py_to_pyd
import os, shutil


def Cls_generate_deploy_file(
    deploymentPara:ClsDeploymentPara, 
    preprocessPara:PreprocessPara, 
    postProcessPara:ClsPostProcessPara, 
    outputPath:str,
    classNameList:list,
    iniFileName:str) -> None:
    """Generate classification deployment files

    Args:
        deploymentPara (ClsDeploymentPara): deploy para from ConfigCls.json
        preprocessPara (PreprocessPara): preprocess para from ConfigCls.json
        postProcessPara (ClsPostProcessPara): post-Process para from ConfigCls.json
        outputPath (str): model and ini file path
        classNameList (list): give class list 
        iniFileName (str): ini file name

    Return:
        deployment file: onnx&config, pyd or exe files
    """
    
    fileName = deploymentPara.deployName
    deployOutputPath = deploymentPara.deployPath

    if deploymentPara.deployMode == 0:
        create_folder(deployOutputPath)
        print('Deployment mode 0: only generate config file and onnx')
    elif deploymentPara.deployMode == 1:
        shutil.copytree(f'./utils/AiResource/Deploy/package/pyd/utils', f'{deployOutputPath}/utils')
        os.rename(f'{deployOutputPath}/utils/sampleInference.py', f'{deployOutputPath}/utils/{fileName}.py')
        py_to_pyd(f'{deployOutputPath}/utils' , f'{deployOutputPath}/utils')
        write_mainPy(fileName, deployOutputPath)
        print('Deployment mode 1: generate pyd file, config file and onnx')
    elif deploymentPara.deployMode == 2:
        shutil.copytree(f'./utils/AiResource/Deploy/package/exe/deployment', f'{deployOutputPath}')
        os.rename(f'{deployOutputPath}/sampleInference.exe', f'{deployOutputPath}/{fileName}.exe')
        print('Deployment mode 1: generate exe file, config file and onnx')
    else:
        raise BaseException(f'your deployMode is {deploymentPara.deployMode} not in our deployMode, \
                deployMode:0 -> onnx&config,  1 -> pyd, 2 -> exe')

    create_folder(f'{deployOutputPath}/image')
    configJson = DepolyConfigJsonSetting(preprocessPara, postProcessPara, fileName, classNameList)
    write_json(configJson.config_json_item(), "deployConfig", deployOutputPath)
    
    os.rename(os.path.join(outputPath, 'BestOnnx.onnx'), os.path.join(deployOutputPath, f'{fileName}.onnx'))
    if deploymentPara.saveIniFile:
        shutil.copy(os.path.join(outputPath, iniFileName), os.path.join(deployOutputPath, f'{fileName}.ini'))
    
    print(f'Generate deployment file complete !!')



