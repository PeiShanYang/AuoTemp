# -*- coding: utf-8 -*-

"""
The function of DataClean package haven't completely developed.
"""


class DataCleanPara:
    def __init__(self, taskType:int, dataState:dict, onlyLabelTransfer:dict) -> None:
        """
        taskType: 0: classification, 1:Detection       
        dataState: {
            "switch"        (int) : 0: disable, 1: enable
            "inputPath"     (str) : input path, if taskType is 1, the subfolder most be Image and Annotation
            "outputPath"    (str) : output path, the result is that the dataset split into Train, Test, Valid folders
            "dataSplit"     (list): [trainPer(float), validPer(float), testPer(float)] data percentage of train, valid and test, the list sum must be 1.0
            "classNameDict" (dict): {classNumber(str): className(str), ....} the class name corresponding to the number
        }
        onlyLabelTransfer: {
            "switch"         (int) : 0: disable, 1: enable
            "inputLabelPath" (str) : Annotation data input path
            "outputPath"     (str) : Annotation converted output path
            "classNameDict"  (dict): {classNumber(str): className(str), ....} the class name corresponding to the number
            "inputImagePath" (str) : input image path, defaults to None.
            "transferType"   (str) : "bbox_xml", "yolo_txt" or "bbox_txt" the format you want to convert to 
        }
        """
        self.taskType = taskType
        self.dataState = dataState
        self.onlyLabelTransfer = onlyLabelTransfer
    
    @classmethod
    def create_from_dict(cls, dataClean:dict):
        """
        dataClean["taskType"]  (int): 0: classification, 1:Detection
        
        dataClean["dataState"] (dict): {
            "switch"        (int) :  0: disable, 1: enable
            "inputPath"     (str) :  input path, if taskType is 1, the subfolder most be Image and Annotation
            "outputPath"    (str) :  output path, the result is that the dataset split into Train, Test, Valid folders
            "dataSplit"     (list):  [trainPer(float), validPer(float), testPer(float)] data percentage of train, valid and test, the list sum must be 1.0
            "classNameDict" (dict):  {classNumber(str): className(str), ....} the class name corresponding to the number
        }

        dataClean["onlyLabelTransfer"] (dict): {
            "switch"         (int) :  0: disable, 1: enable
            "inputLabelPath" (str) :  Annotation data input path
            "outputPath"     (str) :  Annotation converted output path
            "classNameDict"  (dict):  {classNumber(str): className(str), ....} the class name corresponding to the number
            "inputImagePath" (str) :  input image path, defaults to None.
            "transferType"   (str) :  "bbox_xml", "yolo_txt" or "bbox_txt" the format you want to convert to 
        }
        """
        return cls(**dataClean)
