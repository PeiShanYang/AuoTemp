# -*- coding: utf-8 -*-

"""
Created on Thur July 28 10:00:00 2022
"""
class PreprocessPara:
    def __init__(self, preprocessPara: dict) -> None:
        """
        preprocessPara: {
            # In train task, mean and std can be calculated automatically if necessary
            GaussianBlur: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "kernelSize": (list) [height(int), width(int)], (int or sequence) should be an odd and positive number and must be smaller than image size
                    "sigma"     : (float) in (0, 2**127]
                }
            }
            Brightness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "brightness": (float) in [0, 2**127]
                }    
            }
            Contrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "contrast": (float) in [0, 2**127]
                }
            }
            Saturation: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "saturation": (float) in [0, 2**127]
                } 
            }
            Hue: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "hue": (float) in [-0.5, 0.5]
                }
            }
        }
        """
        self.preprocessPara = preprocessPara

    @classmethod
    def create_from_dict(cls, preprocessPara: dict):
        """
        preprocessPara: {
            # In train task, mean and std can be calculated automatically if necessary
            GaussianBlur: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "kernelSize": (list) [height(int), width(int)], (int or sequence) should be an odd and positive number and must be smaller than image size
                    "sigma"     : (float) in (0, 2**127]
                }
            }
            Brightness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "brightness": (float) in [0, 2**127]
                }    
            }
            Contrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "contrast": (float) in [0, 2**127]
                }
            }
            Saturation: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "saturation": (float) in [0, 2**127]
                } 
            }
            Hue: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "hue": (float) in [-0.5, 0.5]
                }
            }
        }
        """
        return cls(preprocessPara)