import torch, math
from ... import AiModel
from torch import nn
from distutils.version import LooseVersion
import os
from .ConfigPytorchModel import PathPara

def check_input_size(imgSize, modelName, structureList, checkSize):
    width, height = imgSize[0], imgSize[1]
    for layer in structureList:
        width = math.ceil((width + 2 * layer[2] - layer[0] + 1) / layer[1])
        height = math.ceil((height + 2 * layer[2] - layer[0] + 1) / layer[1])
    if (width % checkSize != 0) or (height % checkSize != 0):
        raise ValueError(f'Please set resize["switch"]: True and resize["imageSize"]: [224, 244] in config/ConfigPreprocess to make sure that {modelName} backbone can be packed correctly.')

def select_backbone(
    pathPara: PathPara, 
    task: str, 
    backboneName: str, 
    backbonePretrained: int, 
    imgSize: int=224):
    """
    Selecting backbone and loading the pretrained weight.
    Args:
        pathPara           (PathPara)     : Parameters include one stage, two stage, torchvision model
        task               (str)          : "Train" / "Test" / "Inference" / "Retrain"
        backboneName       (str)          : backbone model structure Name
        backbonePretrained (int)          : using backbone pretrained weight or not
        imgSize            (int, optional): input image size. Defaults to 224.

    Returns:
        backbone (nn.module)
    """
    # check if the vgg, alexnet backbone can be pack into Onnx
    if backboneName.startswith('vgg'):
        structureList = [[3, 1, 1], [3, 1, 1], [2, 2, 0],
                        [3, 1, 1], [3, 1, 1], [2, 2, 0], 
                        [3, 1, 1], [3, 1, 1], [3, 1, 1],
                        [2, 2, 0], [3, 1, 1], [3, 1, 1],
                        [3, 1, 1], [2, 2, 0], [3, 1, 1],
                        [3, 1, 1], [3, 1, 1], [2, 2, 0]]
        check_input_size(imgSize, backboneName, structureList, 7)
    
    elif backboneName.startswith('alexnet'):
        structureList = [[11, 4, 2], [3, 2, 0], [5, 1, 2], [3, 2, 0],
                        [3, 1, 1], [3, 1, 1], [3, 1, 1], [3, 2, 0]]
        check_input_size(imgSize, backboneName, structureList, 6)

    if backboneName.startswith('efficientnet'):
        if LooseVersion(torch.__version__) < LooseVersion('1.10.0'):
            raise BaseException(f'efficientnet needs torch version >= 1.10.0. But the torch version is {torch.__version__}.')
        else:
            from ...AiModel import efficientnet
            method = getattr(efficientnet, backboneName)
            backbone = method(pretrained=False)
    
    elif backboneName == 'CustomModel':
        backbone = None
    
    else:
        method = getattr(AiModel, backboneName)
        backbone = method(pretrained=False)
    
    backbone = load_model_weight(pathPara, backbone, task, backbonePretrained, backboneName)
    return backbone


def load_model_weight(
    pathPara: PathPara, 
    backbone: nn.modules, 
    task: str, 
    pretrained: int, 
    backboneName: str
    )-> nn.Module:
    """
    According to Train load the backbone weight

    Args:
        pathPara     (PathPara)  : Parameters include one stage, two stage, torchvision model
        backbone     (nn.modules): backbone
        task         (str)       : "Train" / "Test" / "Inference" / "Retrain"
        pretrained   (int)       : using pretrained weight or not
        backboneName (str)       : backbone name

    Raises:
        ValueError: CustomModel can only used for "Retrain" task
        ValueError: No pre-trained weight is available for backbone type "backboneName"

    Returns:
        backbone (nn.Module)
    """
    if task == 'Train':
        print(pathPara.weightPath['pretrainedWeightPath'], backboneName+'.pth')
        if backboneName == 'CustomModel':
            raise ValueError(f'CustomModel can only used for "Retrain" task')
        
        elif not pretrained:
            pass

        elif pretrained and not os.path.isfile(os.path.join(pathPara.weightPath['pretrainedWeightPath'], backboneName+'.pth')):       # check pretrianed Weight exists
            raise ValueError(f'No pre-trained weight is available for backbone type {backboneName}')   
            
        elif pretrained and not backboneName.startswith('densenet'): 
            
            backbone.load_state_dict(
                torch.load(
                    os.path.join(pathPara.weightPath['pretrainedWeightPath'], backboneName+'.pth')
                ), strict=True)
    
    # elif task == 'Retrain':
    #     if cfgModel.backbone["structure"] == 'CustomModel':
    #         backbone = torch.jit.load(ClsPath.customModel)
    #     else:
    #         backbone.load_state_dict(torch.load(ClsPath.customModel), strict=False)

    # else:
    #     if cfgModel.backbone["structure"] == 'CustomModel':
    #         backbone = torch.jit.load(ClsPath.weightPath)
    #     else:
    #         backbone.load_state_dict(torch.load(ClsPath.weightPath), strict=False)
        
    return backbone