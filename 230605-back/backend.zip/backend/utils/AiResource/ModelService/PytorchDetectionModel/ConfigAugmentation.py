# -*- coding: utf-8 -*-

"""
Created on Thur July 28 10:00:00 2022
"""
import sys
sys.path.append(".")

class AugmentationPara:
    def __init__(self, augmentationPara: dict) -> None:
        """
        augmentationPara: {
            RandomHorizontalFlip: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖隨機水平翻轉的機率, 範圍[0, 1]
                }
            }
            RandomVerticalFlip: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖隨機垂直翻轉的機率, 範圍[0, 1]
                }
            }
            RandomEqualize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖隨機進行直方圖均衡化的機率, 範圍[0, 1]
                }
            }
            RandomBrightness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "brightness": (list) [min(float), max(float)] 亮度隨機調整的範圍, min <= max, 範圍[0, 2**127]
                    "probability": (float) 每張圖隨機進行的機率, 範圍[0, 1]
                }
            }
            RandomContrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "contrast": (list) [min(float), max(float)] 對比度隨機調整的範圍, min <= max, 範圍[0, 2**127]
                    "probability": (float) 每張圖隨機進行的機率, 範圍[0, 1]
                }
            }
            RandomSaturation: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "saturation": (list) [min(float), max(float)] 飽和度隨機調整的範圍, min <= max, 範圍[0, 2**127]
                    "probability": (float) 每張圖隨機進行的機率, 範圍[0, 1]
                }
            }
            RandomHue: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "hue": (list) [min(float), max(float)] 色調隨機調整的範圍, min <= max, 範圍[-0.5, 0.5]
                    "probability": (float) 每張圖隨機進行的機率, 範圍[0, 1]
                }
            }
            RandomErasing: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖片會使用隨機遮罩的機率, 範圍[0, 1]
                    "scale"      : (list) [x(float), y(float)] 從此範圍隨機選擇遮罩區域與輸入圖像的比例, x <= y, 範圍[0, 1]
                    "ratio"      : (list) [m(float), n(float)] 從此範圍中隨機選擇遮罩區域的長寬比, m <= n, 範圍[0, 2**62]
                    "value"      : (list/str) [R(int), G(int), B(int)] / "random" 遮罩使用的顏色, R, G, B 範圍[0, 255] 或選擇 "random"
                }
            }
            RandomPosterize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "bits"       : (int) 每個通道減少的bits數, 範圍[0, 8]
                    "probability": (float) 每張圖減少通道的機率, 範圍[0, 1]
                }
            }
            RandomSolarize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "threshold"  : (int) 高於閥值則進行色彩反轉, 範圍[0, 255]
                    "probability": (float) 每張圖進行色彩反轉的機率, 範圍[0, 1]
                }
            }
            RandomAdjustSharpness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "sharpnessFactor"  : (float) 必須 >= 0, 銳化倍數 - 0: 模糊, 1: 原圖, 2:增加銳化程度兩倍
                    "probability": (float) 每張圖進行銳化調整的機率, 範圍[0, 1]
                }
            }
            RandomAutocontrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖自動調整對比度的機率, 範圍[0, 1]
                }
            }
            RandomIoUCrop: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "minScale": (float) 圖像最小縮放率, min_scale <= max_scale, 範圍[0, 2**14]
                    "maxScale": (float) 圖像最大縮放率, min_scale < max_scale ≤ 1, 範圍[0, 2**14]
                    "minAspectRatio": (float) 限制圖像最小縮放率, min_scale < min_aspect_ratio, 範圍[0, 2**14]
                    "maxAspectRatio": (float) 限制圖像最大縮放率, max_scale < max_aspect_ratio, 範圍[0, 2**14]
                    "samplerOption": (list) 給定隨機IoU閥值樣本, 範圍[0, 1]
                    "trials": (int) 重複進行次數, 範圍[0, 2**14]
                }
            }
            ScaleJitter: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "targetSize": (float) 圖像裁剪大小, 範圍[2**14, 2**14]
                    "scaleRange": (float) 調整圖像大小範圍, 範圍[0, 2**14]
                    "minAspectRatio": (float) 限制圖像最小縮放率, min_scale < min_aspect_ratio, 範圍[0, 2**14]
                    "interpolation": (str) 透視變換的插值方式, 選項: "BILINEAR", "NEAREST", "BICUBIC"
                }
            }
            FixedSizeCrop: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "size": (float) 圖像裁剪大小, 範圍[2**14, 2**14]
                    "fill": (list) [R(int), G(int), B(int)] 透視變換後圖像區外的像素填充值, R, G, B 範圍[0, 255]
                    "minAspectRatio": (float) 限制圖像最小縮放率, min_scale < min_aspect_ratio, 範圍[0, 2**14]
                    "padding_mode": (str) 變換的填充值方式, 選項: "constant", "edge", "reflect", or "symmetric"
                }
            }
            RandomShortestSize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "minSize": (list) 短邊隨機候選值, 範圍[0, 2**14]
                    "maxSize": (int) 最大長邊值, 範圍[0, 2**14]
                    "interpolation": (str) 透視變換的插值方式, 選項: "BILINEAR", "NEAREST", "BICUBIC"
                }
            }
        }
        """
        self.augmentationPara = augmentationPara

    @classmethod
    def create_from_dict(cls, augmentationPara: dict):
        """
        augmentationPara: {
            RandomHorizontalFlip: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖隨機水平翻轉的機率, 範圍[0, 1]
                }
            }
            RandomVerticalFlip: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖隨機垂直翻轉的機率, 範圍[0, 1]
                }
            }
            RandomEqualize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖隨機進行直方圖均衡化的機率, 範圍[0, 1]
                }
            }
            RandomBrightness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "brightness": (list) [min(float), max(float)] 亮度隨機調整的範圍, min <= max, 範圍[0, 2**127]
                    "probability": (float) 每張圖隨機進行的機率, 範圍[0, 1]
                }
            }
            RandomContrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "contrast": (list) [min(float), max(float)] 對比度隨機調整的範圍, min <= max, 範圍[0, 2**127]
                    "probability": (float) 每張圖隨機進行的機率, 範圍[0, 1]
                }
            }
            RandomSaturation: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "saturation": (list) [min(float), max(float)] 飽和度隨機調整的範圍, min <= max, 範圍[0, 2**127]
                    "probability": (float) 每張圖隨機進行的機率, 範圍[0, 1]
                }
            }
            RandomHue: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "hue": (list) [min(float), max(float)] 色調隨機調整的範圍, min <= max, 範圍[-0.5, 0.5]
                    "probability": (float) 每張圖隨機進行的機率, 範圍[0, 1]
                }
            }
            RandomErasing: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖片會使用隨機遮罩的機率, 範圍[0, 1]
                    "scale"      : (list) [x(float), y(float)] 從此範圍隨機選擇遮罩區域與輸入圖像的比例, x <= y, 範圍[0, 1]
                    "ratio"      : (list) [m(float), n(float)] 從此範圍中隨機選擇遮罩區域的長寬比, m <= n, 範圍[0, 2**62]
                    "value"      : (list/str) [R(int), G(int), B(int)] / "random" 遮罩使用的顏色, R, G, B 範圍[0, 255] 或選擇 "random"
                }
            }
            RandomPosterize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "bits"       : (int) 每個通道減少的bits數, 範圍[0, 8]
                    "probability": (float) 每張圖減少通道的機率, 範圍[0, 1]
                }
            }
            RandomSolarize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "threshold"  : (int) 高於閥值則進行色彩反轉, 範圍[0, 255]
                    "probability": (float) 每張圖進行色彩反轉的機率, 範圍[0, 1]
                }
            }
            RandomAdjustSharpness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "sharpnessFactor"  : (float) 必須 >= 0, 銳化倍數 - 0: 模糊, 1: 原圖, 2:增加銳化程度兩倍
                    "probability": (float) 每張圖進行銳化調整的機率, 範圍[0, 1]
                }
            }
            RandomAutocontrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "probability": (float) 每張圖自動調整對比度的機率, 範圍[0, 1]
                }
            }
            RandomIoUCrop: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "minScale": (float) 圖像最小縮放率, min_scale <= max_scale, 範圍[0, 2**14]
                    "maxScale": (float) 圖像最大縮放率, min_scale < max_scale ≤ 1, 範圍[0, 2**14]
                    "minAspectRatio": (float) 限制圖像最小縮放率, min_scale < min_aspect_ratio, 範圍[0, 2**14]
                    "maxAspectRatio": (float) 限制圖像最大縮放率, max_scale < max_aspect_ratio, 範圍[0, 2**14]
                    "samplerOption": (list) 給定隨機IoU閥值樣本, 範圍[0, 1]
                    "trials": (int) 重複進行次數, 範圍[0, 2**14]
                }
            }
            ScaleJitter: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "targetSize": (float) 圖像裁剪大小, 範圍[2**14, 2**14]
                    "scaleRange": (float) 調整圖像大小範圍, 範圍[0, 2**14]
                    "minAspectRatio": (float) 限制圖像最小縮放率, min_scale < min_aspect_ratio, 範圍[0, 2**14]
                    "interpolation": (str) 透視變換的插值方式, 選項: "BILINEAR", "NEAREST", "BICUBIC"
                }
            }
            FixedSizeCrop: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "size": (float) 圖像裁剪大小, 範圍[2**14, 2**14]
                    "fill": (list) [R(int), G(int), B(int)] 透視變換後圖像區外的像素填充值, R, G, B 範圍[0, 255]
                    "minAspectRatio": (float) 限制圖像最小縮放率, min_scale < min_aspect_ratio, 範圍[0, 2**14]
                    "padding_mode": (str) 變換的填充值方式, 選項: "constant", "edge", "reflect", or "symmetric"
                }
            }
            RandomShortestSize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "minSize": (list) 短邊隨機候選值, 範圍[0, 2**14]
                    "maxSize": (int) 最大長邊值, 範圍[0, 2**14]
                    "interpolation": (str) 透視變換的插值方式, 選項: "BILINEAR", "NEAREST", "BICUBIC"
                }
            }
        }
        """
        return cls(augmentationPara)