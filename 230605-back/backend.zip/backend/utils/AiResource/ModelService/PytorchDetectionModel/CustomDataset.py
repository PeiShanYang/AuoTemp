import torch
import os
from torch.utils.data import RandomSampler, SequentialSampler, BatchSampler
from PIL import Image
from PIL import ImageFile
from .package.group_by_aspect_ratio import GroupedBatchSampler, create_aspect_ratio_groups
from torchvision import transforms
import pathlib
ImageFile.LOAD_TRUNCATED_IMAGES = True

class DetectionDataset(torch.utils.data.Dataset):
    def __init__(self, rootDir:str, transform:transforms.Compose=None, hasNotBackground:bool=False, isInference:bool=False):
        """
        Custom Dataset of detection dataset
        Args:
            rootDir (str): Image and Annotation file root path
            transform (transforms.Compose, optional): for detection transform function. Defaults to None.
            hasNotBackground (bool, optional): label include background or not. Defaults to False.
            isInference (bool, optional): task type is inference or not. Defaults to False.
        """
        self.rootDir = os.path.abspath(rootDir)
        self.transforms = transform
        self.hasNotBackground = hasNotBackground
        self.isInference = isInference
        if not isInference:
            self.image = list(sorted(os.listdir(os.path.join(rootDir, "Image")))) 
        else:
            self.image = list(sorted(os.listdir(rootDir))) 
        # self.annotation = list(sorted(os.listdir(os.path.join(rootDir, "Annotation"))))

    def __getitem__(self, idx):
        target = {}
        if not self.isInference:
            imagePath = os.path.join(self.rootDir, "Image", self.image[idx])
            img = Image.open(imagePath).convert("RGB")
            annoPath = os.path.join(
                self.rootDir, 
                "Annotation", 
                f'{self.image[idx].replace(pathlib.Path(self.image[idx]).suffix, ".txt")}')
            objects = open(annoPath, 'r').read().splitlines()
            target = self.target_form(objects, idx)
        else:
            imagePath = os.path.join(self.rootDir, self.image[idx])
            img = Image.open(imagePath).convert("RGB")

        target["imageName"] = self.image[idx]
        if self.transforms is not None:
            img, target = self.transforms(img, target)
        return img, target

    def __len__(self):
        return len(self.image)

    def target_form(self, objects, idx):
        target = {}
        image_id = torch.tensor([idx])
        numObj = len(objects)
        
        boxes = []
        labels = []
        for obj in objects:
            obj = obj.strip().split(' ')
            labels.append(int(obj[0]))
            boxes.append([int(obj[i]) for i in range(1,5)])

        if self.hasNotBackground:
            labels = [i+1 for i in labels]
        # convert everything into a torch.Tensor
        labels = torch.as_tensor(labels, dtype=torch.int64)
        if numObj == 0:
            boxes = torch.zeros((0, 4), dtype=torch.float32)
        else:    
            boxes = torch.as_tensor(boxes, dtype=torch.float32)
        
        # masks = torch.as_tensor(masks, dtype=torch.uint8)
        area = (boxes[:, 3] - boxes[:, 1]) * (boxes[:, 2] - boxes[:, 0])
        # suppose all instances are not crowd
        iscrowd = torch.zeros((numObj,), dtype=torch.int64)
        
        target["boxes"] = boxes
        target["labels"] = labels
        # target["masks"] = masks
        target["image_id"] = image_id
        target["area"] = area
        target["iscrowd"] = iscrowd

        return target

    @staticmethod
    def collate_fn(batch):
        return tuple(zip(*batch))


def create_sample_batch(dataset:torch.tensor, batchSize:int, isTrainData:bool=False, aspectRatioGroupFactor:int=3):
    """for create dataloader using smapler batch by image aspect ratio

    Args:
        dataset (torch.tensor): using custom Dataset of after  DetectionDataset function
        batchSize (int): setting batch size
        isTrainData (bool, optional): Is for training data or not. Defaults to False.
        aspectRatioGroupFactor (int, optional): . Defaults to 3.
    """
    if isTrainData:
        samlper = RandomSampler(dataset)  # 隨機採樣
        if aspectRatioGroupFactor >= 0:
            # 包裝成一個採樣器產生小批量資料, 盡可能接近原始採樣器的排序
            groupIds = create_aspect_ratio_groups(dataset, k=aspectRatioGroupFactor)
            batchSample = GroupedBatchSampler(samlper, groupIds, batchSize)
        else:
            batchSample = BatchSampler(samlper, batchSize, drop_last=True)   # 批次取樣訓練
      
        return batchSample
    else:
        sample = SequentialSampler(dataset)  # 按照順序對數據採樣
        return sample

    