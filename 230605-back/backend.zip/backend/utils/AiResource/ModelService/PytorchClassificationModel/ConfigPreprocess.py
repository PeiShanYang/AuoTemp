# -*- coding: utf-8 -*-

"""
Created on Mon Jun 15 17:00:00 2022
"""

class PreprocessPara:
    def __init__(self, preprocessPara: dict) -> None:
        """
        preprocessPara: {
            # In train task, mean and std can be calculated automatically if necessary
            Normalize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "mode": (str) select "ImageNet", "CIFAR10, "MNIST, "VRS" or input a new one. If you give null, a name in UID will be given
                    "mean": (list) [R(float), G(float), B(float)] give a mean value list if you input a new mode name, R, G, B in [0, 1]
                    "std" : (list) [R(float), G(float), B(float)] give a std value list if you input a new mode name, R, G, B in [0, 1]
                }
            }
            Resize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "imageSize"    : (list) [height(int), width(int)], 3090 GPU memory limit: [2**14, 2**14]
                    "interpolation": (str) "BILINEAR", "NEAREST", or "BICUBIC"
                }
            }
            CenterCrop: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "size": (list) [height(int), width(int)], (sequence or int) Don't exceed the MAX_IMAGE_PIXELS(178956970 ~= [13377, 13377])pixels
                }
            }
            Pad: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "padding"    : (list) [x1(int), y1(int), x2(int), y2(int)], The limit value is different according to different equipment
                    "fill"       : (list) [R(int), G(int), B(int)],  (int or RGB(tuple))
                    "paddingMode": (str) "constant", "edge", "reflect", or "symmetric"
                }
            }
            GaussianBlur: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "kernelSize": (list) [height(int), width(int)], (int or sequence) should be an odd and positive number and must be smaller than image size
                    "sigma"     : (float) in (0, 2**127]
                }
            }
            Brightness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "brightness": (float) in [0, 2**127]
                }    
            }
            Contrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "contrast": (float) in [0, 2**127]
                }
            }
            Saturation: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "saturation": (float) in [0, 2**127]
                } 
            }
            Hue: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "hue": (float) in [-0.5, 0.5]
                }
            }
        }
        """
        self.preprocessPara = preprocessPara

        
    @classmethod
    def create_from_dict(cls, preprocessPara: dict):
        """
        preprocessPara: {
            # In train task, mean and std can be calculated automatically if necessary
            Normalize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "mode": (str) select "ImageNet", "CIFAR10, "MNIST, "VRS" or input a new one. If you give null, a name in UID will be given
                    "mean": (list) [R(float), G(float), B(float)] give a mean value list if you input a new mode name, R, G, B in [0, 1]
                    "std" : (list) [R(float), G(float), B(float)] give a std value list if you input a new mode name, R, G, B in [0, 1]
                }
            }
            Resize: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "imageSize"    : (list) [height(int), width(int)], 3090 GPU memory limit: [2**14, 2**14]
                    "interpolation": (str) "BILINEAR", "NEAREST", or "BICUBIC"
                }
            }
            CenterCrop: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "size": (list) [height(int), width(int)], (sequence or int) Don't exceed the MAX_IMAGE_PIXELS(178956970 ~= [13377, 13377])pixels
                }
            }
            Pad: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "padding"    : (list) [x1(int), y1(int), x2(int), y2(int)], The limit value is different according to different equipment
                    "fill"       : (list) [R(int), G(int), B(int)],  (int or RGB(tuple))
                    "paddingMode": (str) "constant", "edge", "reflect", or "symmetric"
                }
            }
            GaussianBlur: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "kernelSize": (list) [height(int), width(int)], (int or sequence) should be an odd and positive number and must be smaller than image size
                    "sigma"     : (float) in (0, 2**127]
                }
            }
            Brightness: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "brightness": (float) in [0, 2**127]
                }    
            }
            Contrast: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "contrast": (float) in [0, 2**127]
                }
            }
            Saturation: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "saturation": (float) in [0, 2**127]
                } 
            }
            Hue: (dict) {
                "order"     : (int) 0: disable, or give a non-negative integer as an operation order
                "parameters": {
                    "hue": (float) in [-0.5, 0.5]
                }
            }
        }
        """
        return cls(preprocessPara)