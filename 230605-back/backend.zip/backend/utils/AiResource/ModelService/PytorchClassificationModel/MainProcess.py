import os
import time

import torch
import torch.nn as nn
from main.Config import BasicSettingPara, PrivateSettingPara
from torch.utils.data import DataLoader
from ...Preprocess.ModulePreprocess.Cls.SelectNormalization import set_normalize

from ...Evaluation import SelectEvaluationMethod
from ...Evaluation.ConfigEvaluation import ClsEvaluationPara
from ...ResultStorage import SelectStorageMethod
from ...ResultStorage.ConfigResultStorage import ClsResultStoragePara
from .ConfigAugmentation import AugmentationPara
from .ConfigModelService import LearningRatePara, LossFunctionPara, OptimizerPara, SchedulerPara
from .ConfigPreprocess import PreprocessPara
from .ConfigPytorchModel import ServicePara, PathPara, ModelPara
from .CustomDataset import ImageDataset, InferenceDataset
from .SelectLossFunction import cls_select_loss_function
from .SelectModel import cls_select_model
from .SelectOptimizer import cls_select_optimizer
from .SelectScheduler import cls_select_scheduler
from .SelectTransform import cls_select_train_transform, cls_select_transform, cls_select_valid_transform

os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

### REPRODUCIBILITY
torch.manual_seed(0)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False


def train(
    basicSettingPara: BasicSettingPara,
    privateSettingPara: PrivateSettingPara,
    pathPara: PathPara,
    prePara: PreprocessPara,
    augPara: AugmentationPara,
    modelPara: ModelPara,
    lossFunctionPara: LossFunctionPara,
    optimizerPara: OptimizerPara,
    learningRatePara: LearningRatePara,
    schedulerPara: SchedulerPara,
    servicePara: ServicePara,
    evaluationPara: ClsEvaluationPara,
    resultStoragePara: ClsResultStoragePara
) -> list:
    """
    Training procedure: Use training data for model training, and record epoch acc, best weight, and draw validation curve.
    Args:
        basicSettingPara  : record task attribute
        privateSettingPara: record output path
        pathPara          : Include valid, train, test, inference data Path
        prePara           : Parameters include all preprocess methods
        augPara           : Parameters include all augmentation methods
        modelPara         : attribute model = {"structure": str, "pretrained": bool}
        lossFunctionPara  : attribute lossFunction: str
        optimizerPara     : Parameters include all optimizers
        learningRatePara  : attribute learningRate: float
        schedulerPara     : Parameters include all schedulers
        servicePara      : Parameters include cudaDevice, batch size and total epochs
        evaluationPara    : Parameters include all evaluation methods
        resultStoragePara : Parameters include all result Storaged methods
    Return:
        weight.pth : best weight during training
        TrainAcc.json, TrainAcc.txt, ValidAcc.json, ValidAcc.txt and ValidAcc.jpg: for saving training record
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')

    ##### Prepare data #####
    normalizedValue = set_normalize(basicSettingPara.task, prePara.preprocessPara["Normalize"], prePara.preprocessPara["Resize"], pathPara.trainPath)
    trainTransform = cls_select_train_transform(prePara.preprocessPara, augPara.augmentationPara, normalizedValue)
    trainSet = ImageDataset(pathPara.trainPath, trainTransform)
    trainLoader = DataLoader(dataset=trainSet, batch_size=servicePara.batchSize, shuffle=True, num_workers=4)
    print('Number of class : ', trainSet.numClasses)

    ##### Load model #####
    if prePara.preprocessPara["Resize"]["order"] > 0 and isinstance(prePara.preprocessPara["Resize"]["order"], int):
        imgSize = prePara.preprocessPara["Resize"]["parameters"]["size"]
    else:
        imgSize = trainSet.imgSize
    if basicSettingPara.task == 'Train':
        model = cls_select_model(basicSettingPara.task, modelPara.model, pathPara.weightPath["pretrainedWeightPath"], trainSet.numClasses, imgSize)
    elif basicSettingPara.task == 'Retrain':
        model = cls_select_model(basicSettingPara.task, modelPara.model, pathPara.weightPath["customModel"], trainSet.numClasses, imgSize)
    model = model.to(cudaDevice)

    ##### Define loss, optimizer, scheduler #####
    criterion = cls_select_loss_function(lossFunctionPara)
    optimizer = cls_select_optimizer(optimizerPara, learningRatePara.learningRate, model)
    scheduler = cls_select_scheduler(schedulerPara, optimizer)

    ##### Start training #####
    accRecord = []
    bestAcc = 0
    for epoch in range(servicePara.epochs):
        localtime = time.asctime(time.localtime(time.time()))
        lineLength = len('Epoch: {}/{} --- < Starting Time : {} >'.format(epoch + 1, servicePara.epochs, localtime))
        singleLine = '-' * (int(lineLength/2) - 3)
        print('=' * lineLength)
        print(singleLine + ' train ' + singleLine)
        print('Epoch: {}/{} --- < Starting Time : {} >'.format(epoch + 1, servicePara.epochs, localtime))
        trainCorrect = 0
        model.train()
        for data in trainLoader:
            inputs, labels = data[0].to(cudaDevice), data[1].to(cudaDevice)
            outputs = run_model(model, inputs)
            optimizer.zero_grad()
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            _, preds = torch.max(outputs.data, 1)
            trainCorrect += torch.sum(preds == labels)

        ##### Save training evaluation into txt or json file #####
        SelectEvaluationMethod.cls_select_train_evaluation(evaluationPara, privateSettingPara.outputPath, totalNumbers=len(trainSet),
                                                       totalCorrect=trainCorrect, totalEpoch=servicePara.epochs, epoch=epoch)

        ##### Validation #####
        print(singleLine + ' valid ' + singleLine)
        validAcc = valid(evaluationPara, privateSettingPara, pathPara, prePara,
                         servicePara, cudaDevice, model, epoch, normalizedValue)

        ##### Record for drawing curve #####
        accRecord.append(validAcc)

        ##### Modify learning rate #####
        scheduler.step()

        ##### Save weight #####
        bestAcc = SelectStorageMethod.cls_save_model(basicSettingPara.task, resultStoragePara, modelPara.model["structure"], model, optimizer,
                                                 cudaDevice, bestAcc, validAcc, epoch, servicePara.epochs, privateSettingPara.outputPath,
                                                 prePara.preprocessPara["Resize"]["parameters"]["size"])
        ##### Draw Curve #####
        SelectEvaluationMethod.cls_select_valid_plot(evaluationPara, accRecord, privateSettingPara.outputPath)

    return trainSet.className


def valid(
    evaluationPara: ClsEvaluationPara,
    privateSettingPara: PrivateSettingPara,
    pathPara: PathPara,
    prePara: PreprocessPara,
    servicePara: ServicePara,
    device: torch.device,
    model: nn.Module,
    epoch: int,
    normalizedValue: dict,
) -> None:
    """
    Validation procedure: Use validation data for model verification.

    Args:
        evaluationPara    : Parameters include all evaluation methods
        privateSettingPara: record output path
        pathPara       : Include valid, train, test, inference data Path
        prePara           : Parameters include all preprocess methods
        servicePara      : Parameters include batch size and total epochs
        device            : GPU device.
        model             : The model used for verification.
        epoch             : Current epoch of the model.
        normalizedValue   : {"mean": list, "std": list}
    Return:
        Return validation accuracy
        ValidAcc.json, ValidAcc.txt and ValidAcc.jpg: for saving training record
    """
    validTransform = cls_select_valid_transform(prePara.preprocessPara, normalizedValue)
    validSet = ImageDataset(pathPara.validPath, validTransform)
    validLoader = DataLoader(dataset=validSet, batch_size=servicePara.batchSize, shuffle=False, num_workers=4)

    classCorrect = [0.] * validSet.numClasses
    classTotal = [0.] * validSet.numClasses
    totalCorrect = 0
    total = 0
    model.eval()
    with torch.no_grad():
        for data in validLoader:
            inputs, labels = data[0].to(device), data[1].to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs.data, 1)

            ##### Record the result #####
            total += labels.size(0)
            totalCorrect += (predicted == labels).sum().item()
            c = (predicted == labels)
            for i in range(labels.size(0)):
                classCorrect[labels[i]] += c[i].item()
                classTotal[labels[i]] += 1

    ##### Save validation record #####
    SelectEvaluationMethod.cls_select_evaluation(evaluationPara, privateSettingPara.outputPath, task='Valid', totalNumbers=len(validSet), totalCorrect=totalCorrect,
                                             perClassNumbers=classTotal, perClassCorrect=classCorrect, className=validSet.className,
                                             totalEpoch=servicePara.epochs, epoch=epoch)
    if total == 0:
        return 0
    else:
        return float(100 * totalCorrect / total)


def test(
    basicSettingPara: BasicSettingPara,
    pathPara: PathPara,
    prePara: PreprocessPara,
    modelPara: ModelPara,
    servicePara: ServicePara,
) -> list:
    """
    Testing procedure: Use test data for model verification, and output the predicted result csv and confusion matrix.

    Args:
        basicSettingPara : record task attribute
        pathPara      : Include valid, train, test, inference data Path
        prePara          : Parameters include all preprocess methods
        modelPara        : attribute model = {"structure": str, "pretrained": bool}
        servicePara     : Parameters include batch size and total epochs
    Return:
        resultList: model predicts result
        perResultDict = {
            "filename": filename,
            "label": label className,
            "predict": predict className,
            "confidence": confidence score,
            "output": confDict - confidence from all classes
        }
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')
    normalizedValue = set_normalize(basicSettingPara.task, prePara.preprocessPara["Normalize"])
    testTransform = cls_select_transform(prePara.preprocessPara, normalizedValue)
    testSet = ImageDataset(pathPara.testPath, testTransform)
    testLoader = DataLoader(dataset=testSet, batch_size=1, shuffle=False, num_workers=4)

    ##### Model define #####
    if prePara.preprocessPara["Resize"]["order"] > 0 and isinstance(prePara.preprocessPara["Resize"]["order"], int):
        imgSize = prePara.preprocessPara["Resize"]["parameters"]["size"]
    else:
        imgSize = testSet.imgSize
    model = cls_select_model(basicSettingPara.task, modelPara.model, pathPara.weightPath["evaluatedWeight"], testSet.numClasses, imgSize)
    model = model.to(cudaDevice)
    model.eval()
    print('Number of class : ', testSet.numClasses)
    resultList = []
    with torch.no_grad():
        for filenameCount, data in enumerate(testLoader):
            inputs, labels = data[0].to(cudaDevice), data[1].to(cudaDevice)
            outputs = run_model(model, inputs)
            outputs = outputs[0][:testSet.numClasses]
            outputs = outputs[None, :]
            _, predicted = torch.max(outputs, 1)
            confidence = torch.nn.functional.softmax(outputs, dim=1)

            ##### record each score for each class #####
            confDict = {}
            for classNameCount, conf in enumerate(confidence[0]):
                confDict[testSet.className[classNameCount]] = float(conf)

            ##### record each result #####
            perResultDict = {
                "filename": testSet.filename[filenameCount],
                "label": testSet.className[labels[0]],
                "predict": testSet.className[predicted[0]],
                "confidence": float(confidence[0][predicted[0]]),
                "output": confDict
            }
            resultList.append(perResultDict)
    return resultList


def inference(
    basicSettingPara: BasicSettingPara,
    pathPara: PathPara,
    prePara: PreprocessPara,
    modelPara: ModelPara,
    servicePara: ServicePara
) -> None:
    """
    Inference procedure: Use trained model for classifying inference data, and output the result csv.

    Args:
        basicSettingPara : record task attribute
        pathPara      : Include valid, train, test, inference data Path
        prePara          : Parameters include all preprocess methods
        modelPara        : attribute model = {"structure": str, "pretrained": bool}
        servicePara     : Parameters include batch size and total epochs
    Return:
        resultList: model predicts result
        perResultDict = {
            "filename": filename,
            "label": label className,
            "predict": predict className,
            "confidence": confidence score,
            "output": confDict - confidence from all classes
        }
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')
    # normalizePara = pickup_method_para(prePara.preprocessPara, ["Normalize"])
    normalizedValue = set_normalize(basicSettingPara.task, prePara.preprocessPara["Normalize"])
    inferenceTransform = cls_select_transform(prePara.preprocessPara, normalizedValue)
    dataSet = InferenceDataset(pathPara.inferencePath, inferenceTransform)
    dataLoader = DataLoader(dataset=dataSet, batch_size=1, shuffle=False, num_workers=4)

    ##### Load model #####
    if prePara.preprocessPara["Resize"]["order"] > 0 and isinstance(prePara.preprocessPara["Resize"]["order"], int):
        imgSize = prePara.preprocessPara["Resize"]["parameters"]["size"]
    model = cls_select_model(basicSettingPara.task, modelPara.model, pathPara.weightPath["evaluatedWeight"], len(basicSettingPara.classNameList), imgSize)
    model = model.to(cudaDevice)
    model.eval()

    className = basicSettingPara.classNameList
    className.sort()
    className.sort(key=lambda x:x)
    print('Number of class : ', len(className))
    resultList = []
    with torch.no_grad():
        for filenameCount, data in enumerate(dataLoader):
            inputs, labels = data[0].to(cudaDevice), data[1].to(cudaDevice)
            outputs = run_model(model, inputs)

            outputs = outputs[0][:len(className)]
            outputs = outputs[None, :]
            _, predicted = torch.max(outputs, 1)
            confidence = torch.nn.functional.softmax(outputs, dim=1)

            ##### record each score for each class #####
            confDict = {}
            for classNameCount, conf in enumerate(confidence[0]):
                confDict[className[classNameCount]] = float(conf)

            ##### record each result #####
            perResultDict = {
                "filename": dataSet.filename[filenameCount],
                "predict": className[predicted[0]],
                "label": None,
                "confidence": float(confidence[0][predicted[0]]),
                "output": confDict
            }

            resultList.append(perResultDict)
    return resultList


def run_model(model: nn.Module, inputs: torch.Tensor):
    """
    Run model with inputs and return output

    Args:
        model: model with weight
        inputs: input tensor

    Return:
        outputs: output tensor from model
    """
    try:
        outputs = model(inputs)
    except:
        raise ValueError(f'Try reducing batchSize or setting resize["switch"]: True and resize["imageSize"]: [224, 244] '+
                          'in main/ConfigCls.json to make sure that model can be trained correctly.')
    return outputs