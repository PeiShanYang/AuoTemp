from numpy import ndarray
import json, os

def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath: the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)    

def write_mAP_txt(outputPath:str, task:str, cocoEval:ndarray, epochRecord:str=None):
    """
    Args:
        outputPath (str): output path
        task (str): "Train" / "Valid" / "Test" / "Inference" 
        cocoEval (ndarray, optional): evaluate result for coco data form. Defaults to None.
        epochRecord (str, optional): record epoch. Defaults to None.
    
    Output:
        mAP record for evaluation file (txt)
    """
    create_folder(outputPath)
    if epochRecord != None:
        if int(epochRecord.split('/')[0])==1:
            mode = 'w'
        else:
            mode = 'a'
    else:
        mode = 'w'

    with open(os.path.join(outputPath, f'{task}Map.txt'), mode) as f:
        # f.write(f'{task}:\n')  
        if epochRecord != None:
            f.write(f'{task} epoch {epochRecord}\n')
        else:
            f.write(f'{task}\n') 
        f.write(f'recall    = {cocoEval[9]}\n')
        f.write(f'precision = {cocoEval[0]}\n')
        f.write(f"""Average Precision  (AP) @[ IoU=0.50:0.95 | area=   all | maxDets=100 ] = {cocoEval[0]}
Average Precision  (AP) @[ IoU=0.50      | area=   all | maxDets=100 ] = {cocoEval[1]}
Average Precision  (AP) @[ IoU=0.75      | area=   all | maxDets=100 ] = {cocoEval[2]}
Average Precision  (AP) @[ IoU=0.50:0.95 | area= small | maxDets=100 ] = {cocoEval[3]}
Average Precision  (AP) @[ IoU=0.50:0.95 | area=medium | maxDets=100 ] = {cocoEval[4]}
Average Precision  (AP) @[ IoU=0.50:0.95 | area= large | maxDets=100 ] = {cocoEval[5]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area=   all | maxDets=  1 ] = {cocoEval[6]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area=   all | maxDets= 10 ] = {cocoEval[7]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area=   all | maxDets=100 ] = {cocoEval[8]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area= small | maxDets=100 ] = {cocoEval[9]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area=medium | maxDets=100 ] = {cocoEval[10]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area= large | maxDets=100 ] = {cocoEval[11]}\n
""")

def write_mAP_json(
    outputPath:str,
    task:str,
    cocoEval:ndarray,
    epochRecord:str=None
) -> None:
    """
    Save evaluation rate to json

    Args:
        outputPath: the path wants to save txt file
        task: Train, Valid or Test
        cocoEval (ndarray, optional): evaluate result for coco data form. Defaults to None.
        epochRecord (str, optional): record epoch. Defaults to None.

    Return:
        Save TrainMap.json, ValidMap.json or TestMap.json
    """

    if cocoEval.any() != None:
        create_folder(outputPath)
        jsonFilePath = f'./{outputPath}/{task}Map.json'

        ##### Save each record ##### 
        epochDict = {}
        epochDict[task] = {}
        if task == 'Valid' or 'Test':
            epochDict[task]["recall"] = cocoEval[9]
        # if cocoEval.any():
            epochDict[task]["precision"] = cocoEval[0]

        ##### Save record to json#####
        infoDict = {}
        if epochRecord != None:
            epoch = int(epochRecord.split('/')[0])
            totalEpoch = int(epochRecord.split('/')[1])

            if epoch > 1:
                with open(jsonFilePath, 'r') as accJson:
                    infoDict = json.load(accJson)

            epochDict["model"] = {
            "epoch": epoch,
            "total": totalEpoch
            }

        if task == 'Train':
            if epochDict[task].get("coco") != None:
                del epochDict[task]["coco"]
        else:
            epochDict[task]["coco"] = {
            "AP_0.50_0.95": cocoEval[0],
            "AP_0.50": cocoEval[1],
            "AP_0.75": cocoEval[2],
            "AP_small": cocoEval[3],
            "AP_medium": cocoEval[4],
            "AP_large": cocoEval[5],
            "AR_1": cocoEval[6],
            "AR_10": cocoEval[7],
            "AR_100": cocoEval[8],
            "AR_small": cocoEval[9],
            "AR_medium": cocoEval[10],
            "AR_large": cocoEval[11]
            }

        if task != 'Test':
            infoDict[str(epoch)] = epochDict
        else:
            infoDict[task] = epochDict

        with open(jsonFilePath, 'w') as accJson:
            json.dump(infoDict, accJson, indent=4)