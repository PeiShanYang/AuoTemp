# -*- coding: utf-8 -*-

"""
Created on Mon Jun 15 17:00:00 2022
"""

class EvaluationPara:
    def __init__(self, 
        drawConfusionMatrix: dict,
        ) -> None:
        """
            ##### Draw confusion matrix for test task
            drawConfusionMatrix (dict): {
                "switch"     (int): 0: disable, 1: enable
                "showNumber" (int): 0: disable, 1: enable, show data amount of each cell
            }
        """
        self.drawConfusionMatrix = drawConfusionMatrix
        pass

class ClsEvaluationPara(EvaluationPara):
    def __init__(self, accuracy: dict, accOfClasses: dict, numOfClasses: dict,
                       otherClsRate: dict, drawAccCurve: dict, drawConfusionMatrix: dict) -> None:
        """
        # Calculate total accuracy
        accuracy: {
            "switch"  : (int) 0: disable, 1: enable
            "mode"    : (list) ['Train', 'Valid', 'Test'] 'Train', 'Valid' or 'Test'
            "saveTxt" : (int) 0: disable, 1: enable, save in txt file
            "saveJson": (int) 0: disable, 1: enable, save in json file
        }

        # Calculate individual class accuracy
        accOfClasses: {
            "switch"  : (int) 0: disable, 1: enable
            "mode"    : (list) ['Valid', 'Test'], 'Valid' or 'Test'
            "saveTxt" : (int) 0: disable, 1: enable, save in txt file
            "saveJson": (int) 0: disable, 1: enable, save in json file
        }

        # Calcalate amount of total images and correctly predicted images in individual class
        numOfClasses: {
            "switch": (int) 0: disable, 1: enable
            "mode"    : (list) ['Valid', 'Test'], 'Valid' or 'Test'
            "saveTxt" : (int) 0: disable, 1: enable, save in txt file
            "saveJson": (int) 0: disable, 1: enable, save in json file
        }

        # Calcalate leakage rate, overkill rate and accuracy of defect classes
        otherClsRate: {
            "switch"  : (int) 0: disable, 1: enable
            "posClass": (list) ['Pass'], positive class name list
            "negClass": (list) ['Short'], negative class name list
            "saveTxt" : (int) 0: disable, 1: enable, save in txt file
            "saveJson": (int) 0: disable, 1: enable, save in json file
        }

        # Save validation accuracy curve in jpg
        drawAccCurve: {
            "switch": (int) 0: disable, 1: enable
        }

        """
        super().__init__(drawConfusionMatrix)
        self.accuracy = accuracy
        self.accOfClasses = accOfClasses
        self.numOfClasses = numOfClasses
        self.otherClsRate = otherClsRate
        self.drawAccCurve = drawAccCurve
        
    @classmethod
    def create_from_dict(cls, evaluationPara:dict):
        """
        evaluationPara: {
            # Calculate total accuracy
            "accuracy": (dict) {
                "switch"  : (int) 0: disable, 1: enable
                "mode"    : (list) ['Train', 'Valid', 'Test'] 'Train', 'Valid' or 'Test'
                "saveTxt" : (int) 0: disable, 1: enable, save in txt file
                "saveJson": (int) 0: disable, 1: enable, save in json file
            }
            # Calculate individual class accuracy
            "accOfClasses": (dict) {
                "switch"  : (int) 0: disable, 1: enable
                "mode"    : (list) ['Valid', 'Test'], 'Valid' or 'Test'
                "saveTxt" : (int) 0: disable, 1: enable, save in txt file
                "saveJson": (int) 0: disable, 1: enable, save in json file
            }

            # Calcalate amount of total images and correctly predicted images in individual class
            "numOfClasses": (dict) {
                "switch"  : (int) 0: disable, 1: enable
                "mode"    : (list) ['Valid', 'Test'], 'Valid' or 'Test'
                "saveTxt" : (int) 0: disable, 1: enable, save in txt file
                "saveJson": (int) 0: disable, 1: enable, save in json file
            }

            # Calcalate leakage rate, overkill rate and accuracy of defect classes
            "otherClsRate": (dict) {
                "switch"  : (int) 0: disable, 1: enable
                "posClass": (list) ['Pass'], positive class name list
                "negClass": (list) ['Short'], negative class name list
                "saveTxt" : (int) 0: disable, 1: enable, save in txt file
                "saveJson": (int) 0: disable, 1: enable, save in json file
            }

            # Save validation accuracy curve in jpg
            "drawAccCurve": (dict) {
                "switch": (int) 0: disable, 1: enable
            }

            # Draw confusion matrix for test task
            "drawConfusionMatrix": (dict) {
                "switch"    : (int) 0: disable, 1: enable
                "showNumber": (int) 0: disable, 1: enable, show data amount of each cell
            }
        }
        """
        return cls(**evaluationPara)

class DetEvaluationPara(EvaluationPara):
    def __init__(self, 
            drawConfusionMatrix: dict,
            Map: dict,
        ) -> None:
        """
        Args:
            Map (dict): {
                "switch" (int) : 0: disable, 1: enable
                "mode"   (list): ['Train', 'Valid', 'Test'] 'Train', 'Valid' or 'Test'
                "saveTxt" : (int) 0: disable, 1: enable, save in txt file
                "saveJson": (int) 0: disable, 1: enable, save in json file
            }    
        """
        super().__init__(drawConfusionMatrix)
        self.Map = Map
        pass 
       
    @classmethod
    def create_from_dict(cls, evaluationPara: dict):
        """
        Args:
            evaluationPara["drawConfusionMatrix"] (dict): {
                "switch"     (int): 0: disable, 1: enable
                "showNumber" (int): 0: disable, 1: enable, show data amount of each cell
            }

            evaluationPara["Map"] (dict): {
                "switch" (int) : 0: disable, 1: enable
                "mode"   (list): ['Train', 'Valid', 'Test'] 'Train', 'Valid' or 'Test'
                "saveTxt" : (int) 0: disable, 1: enable, save in txt file
                "saveJson": (int) 0: disable, 1: enable, save in json file
            }
            
        """
        return cls(**evaluationPara)
