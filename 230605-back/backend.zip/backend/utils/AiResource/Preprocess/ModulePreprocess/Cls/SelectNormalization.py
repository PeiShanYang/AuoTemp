import json
from datetime import datetime

from .NormalizeValueCalculate import calculate_std_mean


def load_dict_from_json(jsonFilePath: str) -> dict:
    """
    Load dict from json file

    Args:
        jsonFilePath: json file path
    
    Return:
        infoDict: dict in json file
    """
    with open(jsonFilePath, 'r') as f:
        try:
            infoDict = json.load(f)
        except:
            raise BaseException('Something went wrong while loading normalizeRecord.json')
    return infoDict

def save_dict_to_json(
    jsonFilePath: str,
    infoDict: dict
) -> None:
    """
    Save dict into json file

    Args:
        jsonFilePath: file path of json
        infoDict: dict that want to save into json
    """
    with open(jsonFilePath, 'w') as f:
        json.dump(infoDict, f, indent=4)

def set_normalize(
    task:str,
    normalizePara: dict,
    resizePara: dict=None,
    dataPath: str=None
) -> dict:
    """
    According to the task, normalizePara and resizePara, return normalization value.
    
    Args:
        task: 'train' / 'test' / 'inference'
        normalizePara: {"name": 'Normalize', "switch": bool, "mode": str, "parameters": {"mean": list, "std": list}}
        resizePara: {"name": 'Resize', "switch": bool, "parameters": {"imageSize": list, "interpolation": str}}
        dataPath: train data path
    Return:
        normalization: normalized value that user selected, user input
    """
    mode, mean, std = normalizePara["parameters"]["mode"], normalizePara["parameters"]["mean"], normalizePara["parameters"]["std"]
    jsonFilePath = './utils/AiResource/Preprocess/ModulePreprocess/Cls/normalizeRecord.json'
    if task == "Train":
        infoDict = load_dict_from_json(jsonFilePath)
        time = (datetime.now().strftime('%Y%m%d%H%M%S%f'))
        try:
            normalization = infoDict[mode]
        except:
            if isinstance(mean, list) and isinstance(std, list):
                if len(mean) == 3 and len(std) == 3:
                    normalization = {"mean": mean, "std": std}
                    key = mode if mode is not None else f'userInput_{time}'
                else:
                    raise ValueError('["mean"] and ["std"] value must include three values [R, G, B].')
                
            else:
                mean, std = calculate_std_mean(dataPath, resizePara)
                normalization = {"mean": mean, "std": std}
                key = mode if mode is not None else f'autoCalculate_{time}'
            
            infoDict[key] = normalization
            save_dict_to_json(jsonFilePath, infoDict)
    else:
        infoDict = load_dict_from_json(jsonFilePath)
        try:
            normalization = infoDict[mode]
        except:
            if isinstance(mean, list) and isinstance(std, list):
                if len(mean) == 3 and len(std) == 3:
                    normalization = {"mean": mean, "std": std}
                else:
                    raise ValueError('["mean"] and ["std"] value must include three values [R, G, B].')
            else:
                raise BaseException(f'Can not find "{mode}" normalization and got no input of maen and std.')

    return normalization
