# -*- coding: utf-8 -*-


from main.MainCls import main as clsMain
from main.MainDet import main as detMain
from main.Entrance import main

clsConfig = './/main//ConfigCls.json'
detConfig = './/main//ConfigDet.json'

if __name__ == "__main__":
    # clsMain(clsConfig)
    # detMain(detConfig)
    main()
