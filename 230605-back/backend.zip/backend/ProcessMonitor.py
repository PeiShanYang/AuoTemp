import threading
import time, os
import pynvml
import shutil
from utils.LoggerResource.ConfigLogger import Logger
from subprocess import Popen, PIPE
from utils.DatabaseResource import processMonitorDb

# state
#  null            : unassign
#  positive integer: Wait for train
#  0               : Done
# -1               : Train
# -2               : Wait for test
# -3               : Test
# -4               : incorrect finish

monitorDbHandler = processMonitorDb.ProcessMonitorDb()

def check_basic_setting():
    """Check and get basic setting information

    Returns:
        info['monitor_time']: monitor time
        info['gpu_usage_threshold']: gpu usage threshold
        info['output_root']: output root
    """
    ok, info = monitorDbHandler.get_basic_setting()
    if not ok:
        Logger.responseError(0, info)
        exit()
    return info['monitor_time'], info['gpu_usage_threshold'], info['output_root']

def create_folder(folderPath):
    """ create pipeline folder

    Args:
        folderPath (str): folder path
    """
    if os.path.isdir(folderPath):
        shutil.rmtree(folderPath)
    os.makedirs(folderPath)


def save_error_log(filePath, error):
    """save error message into error.txt

    Args:
        filePath (str): pipeline output path
        error (str): error message
    """
    errorFile = os.path.join(filePath, 'error.txt')
    with open(errorFile, 'w') as f:
        f.write(error)


def process(state, outputRoot, pipelineId, projectTask, experimentKey, pipelinePath):
    """create and run process according to state

    Args:
        state (str): Train or Test
        outputRoot (str): output root path
        pipelineId (str): pipeline ID from database
        projectTask (str): project task
        experimentKey (str): experiment key to get config
        pipelinePath (str): pipeline output path
    """
    try:
        if state == 'Train':
            create_folder(pipelinePath)
            _, stderr = Popen(f"python ./TrainProcess.py -r {outputRoot} -p {pipelineId} -t {projectTask} -k {experimentKey}", stdout=PIPE, stderr=PIPE).communicate()
        elif state == 'Test':
            _, stderr = Popen(f"python ./TestProcess.py -r {outputRoot} -p {pipelineId} -t {projectTask} -k {experimentKey}", stdout=PIPE, stderr=PIPE).communicate()
        stderr = str(stderr)
        if ('TrainProcess' in stderr) or ('TestProcess' in stderr):
            save_error_log(pipelinePath, stderr)
    except Exception as err:
        save_error_log(pipelinePath, f"unexpected error: {err}")


def test_finish_correct(outputRoot, pipelineId):
    """Check if test process finish correctly
    correctly finish  : Test_result.csv existed and error.txt do not existed
    incorrectly finish: other situation

    Args:
        outputRoot (str): output root path
        pipelineId (str): pipeline id
    """
    if os.path.isfile(os.path.join(outputRoot, pipelineId, "Test_result.csv")) and not os.path.isfile(
        os.path.join(outputRoot, pipelineId, "error.txt")
    ):
        print(f'(ProcessMonitor) test finish correct {pipelineId}')
        return True
    print(f'(ProcessMonitor) test finish incorrect {pipelineId}')
    return False


def train_finish_correct(outputRoot, pipelineId, projectTask):
    """Check if train process finish correctly
    correctly finish  : epoch in ValidAcc.json(cls) or ValidMap.json equal to total epoch
                        and error.txt do not existed
    incorrectly finish: other situation

    Args:
        outputRoot (str): output root path
        pipelineId (str): pipeline id
        projectTask (str): project task
    """
    if projectTask == "classification":
        if os.path.isfile(os.path.join(outputRoot, pipelineId, "ValidAcc.json")) and \
            not os.path.isfile(os.path.join(outputRoot, pipelineId, "error.txt")):
            print(f'(ProcessMonitor) train finish correct {pipelineId}')
            return True
    elif projectTask == "detection":
        if os.path.isfile(os.path.join(outputRoot, pipelineId, "ValidMap.json")) and \
            not os.path.isfile(os.path.join(outputRoot, pipelineId, "error.txt")):
            print(f'(ProcessMonitor) train finish correct {pipelineId}')
            return True
    print(f'(ProcessMonitor) train finish incorrect {pipelineId}')
    return False


def delete_local_file(pipelinePath):
    """Delete most local file after record into database
       only leave BestDictPth.pth, ConfusionMatrix.jpg

    Args:
        pipelinePath (str): pipeline output path
    """
    retainList = ['BestDictPth.pth', 'ConfusionMatrix.jpg', 'ConfigCls.json', 'ConfigDet.json']
    for fileName in os.listdir(pipelinePath):
        if fileName not in retainList:
            filePath = os.path.join(pipelinePath, fileName)
            if os.path.isdir(filePath):
                shutil.rmtree(filePath)
            elif os.path.isfile(filePath):
                os.remove(filePath)


def check_threads_done(gpuId, gpuSituation):
    """check if gpu with gpuId is idle

    Args:
        gpuId (str): gpu ID
        gpuSituation (list): gpu situation
        gpuSituation:  [(gpuId0, pipelineId, projectTask, <Thread(Thread-1, started 620620)>, state),
                        (gpuId1, pipelineId, projectTask, <Thread(Thread-2, started 608924)>, state), ...]

    Returns:
        boolean: True or False
    """
    for id, _, _, _, _ in gpuSituation:
        if id == gpuId:
            return False
    return True


def get_gpu_memory_usage(deviceId):
    """Get the current gpu usage.

    Args:
        deviceId (str): gpu device ID

    Returns:
        float: gpu memory usage percentage
    """
    pynvml.nvmlInit()
    gpuDevice = pynvml.nvmlDeviceGetHandleByIndex(deviceId)
    totalMemory = pynvml.nvmlDeviceGetMemoryInfo(gpuDevice).total
    usedMemory = pynvml.nvmlDeviceGetMemoryInfo(gpuDevice).used
    if totalMemory == 0:
        return 100
    return usedMemory / totalMemory * 100


def add_gpu_situation(gpuSituation, gpuId, pipelineId, projectTask, thread, state):
    """record assigned task into gpuSituation both in list and database and update pipeline state

    Args:
        gpuSituation (list): gpu situation recorder
        gpuId (int): gpu id
        pipelineId (str): pipeline id
        projectTask (str): classification or detection
        thread (str): thread number
        state (int): state
    """
    gpuSituation.append((gpuId, pipelineId, projectTask, thread, state))
    monitorDbHandler.update_state(pipelineId, state)
    gpuSituationId = monitorDbHandler.generate_uid("gpu_situation")
    monitorDbHandler.insert_value('gpu_situation (gpu_situation_id, pipeline_id, gpu_id, thread, state)', f'("{gpuSituationId}", "{pipelineId}", "{gpuId}", "{thread}", "{state}")') # add to gpu situation


def remove_gpu_situation(gpuSituation, gpuId, pipelineId, projectTask, thread, state):
    """record assigned task into gpuSituation

    Args:
        gpuSituation (list): gpu situation recorder
        gpuId (int): gpu id
        pipelineId (str): pipeline id
        thread (str): thread number
        state (str): state
    """
    if monitorDbHandler.check_value_exist('gpu_situation', f'pipeline_id="{pipelineId}"'):
        gpuSituation.remove((gpuId, pipelineId, projectTask, thread, state))
        monitorDbHandler.delete_value('gpu_situation', f'pipeline_id="{pipelineId}"')


def initial_gpu_situation(outputRoot):
    """Check if gpu situation in database is empty:
        empty    : start monitor
        not empty: clean gpu situation, save incorrect finish pipeline, and delete local files

    Args:
        outputRoot (str): output root path
    """
    gpuTable = monitorDbHandler.read_value_with_cond('gpu_situation', '*', '1=1')
    if not gpuTable.empty:
        for pipeline in gpuTable.to_dict('records'):
            pipelineId, gpuId, state, updateTime = pipeline["pipeline_id"], pipeline["gpu_id"], pipeline["state"], pipeline["update_time"]
            errorLog = f'fatal error: pipeline suspend in state {state} on gpu {gpuId} at time {updateTime}'
            monitorDbHandler.update_value_with_cond('pipeline_output', f'error_log="{errorLog}"', f'pipeline_id="{pipelineId}"')
            monitorDbHandler.update_value_with_cond('pipeline', f'status="{-4}"', f'pipeline_id="{pipelineId}"')
            monitorDbHandler.delete_value('gpu_situation', f'pipeline_id="{pipelineId}"')
            delete_local_file(os.path.join(outputRoot, pipelineId))


def assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId=None):
    """Check database and assign new process to gpu if gpu is idle

    Args:
        outputRoot (str): output root path
        gpuUsageThreshold (int): percentage of gpu usage threshold
        gpuSituation (list): gpu situation record
        gpuId (str or None): gpu ID
    """
    gpuJobList = monitorDbHandler.load_db_pipeline(gpuId)
    for gpu, queue in gpuJobList.items():
        if get_gpu_memory_usage(gpu) < gpuUsageThreshold:  # less then 5%
            pipelineId, state, projectTask, experimentKey = queue.popleft()
            if state == "Wait for test":
                pipelinePath = os.path.join(outputRoot, pipelineId)
                testThread = threading.Thread(target=process, args=("Test", outputRoot, pipelineId, projectTask, experimentKey, pipelinePath))
                add_gpu_situation(gpuSituation, gpu, pipelineId, projectTask, testThread, -3)
                testThread.start()

            elif state == "Wait for train":
                if check_threads_done(gpu, gpuSituation):
                    pipelinePath = os.path.join(outputRoot, pipelineId)
                    monitorDbHandler.create_pipeline_output(pipelineId)
                    trainThread = threading.Thread(target=process, args=("Train", outputRoot, pipelineId, projectTask, experimentKey, pipelinePath))
                    add_gpu_situation(gpuSituation, gpu, pipelineId, projectTask, trainThread, -1)
                    trainThread.start()
        else:
            print(f"GPU: {gpu} running...") # debug purpose

if __name__ == "__main__":
    monitorTime, gpuUsageThreshold, outputRoot = check_basic_setting()

    # Initial monitorDbHandler and gpuSituation: [(gpuId, pipelineId, projectTask, thread, state), ....]
    initial_gpu_situation(outputRoot)
    gpuSituation = []
    count = 0
    while True:
        print("(ProcessMonitor) round: ", count)
        print("(ProcessMonitor) gpuSituation: ", gpuSituation)
        ### check process running on gpu

        for gpuId, pipelineId, projectTask, thread, state in gpuSituation.copy():
            pipelinePath = os.path.join(outputRoot, pipelineId)
            if state == -3: # Test
                if not thread.is_alive():
                    remove_gpu_situation(gpuSituation, gpuId, pipelineId, projectTask, thread, state)
                    if test_finish_correct(outputRoot, pipelineId):
                        monitorDbHandler.save_result('Test', projectTask, pipelineId, pipelinePath)
                        monitorDbHandler.update_state(pipelineId, 0)
                    else:
                        monitorDbHandler.save_error_db(pipelineId, os.path.join(pipelinePath, 'error.txt'))
                        monitorDbHandler.update_state(pipelineId, -4)
                    delete_local_file(pipelinePath)
                    assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId)

            elif state == -1: # Train
                monitorDbHandler.save_result('Train', projectTask, pipelineId, pipelinePath)
                if not thread.is_alive():
                    remove_gpu_situation(gpuSituation, gpuId, pipelineId, projectTask, thread, state)
                    if train_finish_correct(outputRoot, pipelineId, projectTask):
                        monitorDbHandler.save_result('Train', projectTask, pipelineId, pipelinePath)
                        monitorDbHandler.update_state(pipelineId, -2)
                    else:
                        monitorDbHandler.save_error_db(pipelineId, os.path.join(pipelinePath, 'error.txt'))
                        monitorDbHandler.update_state(pipelineId, -4)
                        delete_local_file(pipelinePath)
                    assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId)


        ### assign process to gpu
        assign_process(outputRoot, gpuUsageThreshold, gpuSituation)

        ### wait 30 second for next monitor round
        print(f"(ProcessMonitor) Sleep {monitorTime} second")
        time.sleep(monitorTime)
        count += 1
