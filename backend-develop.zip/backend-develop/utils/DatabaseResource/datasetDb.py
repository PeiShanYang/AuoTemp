import os
import random
import numpy as np
from cv2 import cv2
from . import BasicDb
from utils.ApiResource import datasetUtil
import xml.etree.ElementTree as ET
from decimal import Decimal, ROUND_HALF_UP

class DatasetDb(BasicDb):
    """Database query method of labelTool
    """

    def update_project_split_rate(self, projectName, splitRate):
        """Update the three column (train_rate, valid_rate and test_rate) of project database

        Args:
            projectName (str): project name
            splitRate (dict): three types of split rate (Train, Valid and Test)
                - key: split type (Train, Test, and Valid)
                - value: split rate
        """
        trainRate =splitRate.get('Train')
        validRate = splitRate.get('Valid')
        testRate = splitRate.get('Test')
        self.update_value_with_cond('project', f'train_rate="{trainRate}",  \
                                valid_rate="{validRate}", test_rate="{testRate}"', f'project_name="{projectName}"')


    def update_image_task(self, imageIdOfSplit):
        """Update the column of task on image table

        Args:
            imageIdOfSplit (dict): image id list of the three split types, {'Train': [image id1, image id2], 'Valid': [image id3], 'Test': [image id4]}
                - key (str): split type
                - value (list): image id
        """
        for splitType, imageId in imageIdOfSplit.items():
            if(len(imageId) > 1): ### many images are assigned to this split type
                self.update_value_with_cond('image', f'task="{splitType}"', f'image_id in {tuple(imageId)}')
            else:
                self.update_value_with_cond('image', f'task="{splitType}"', f'image_id="{imageId[0]}"')


    def get_all_image_id_of_dataset(self, datasetId):
        """Get all image id of this dataset

        Args:
            datasetId (str): dataset id

        Raises:
            Exception: This dataset does not have any image

        Returns:
            list: all image id of this dataset
        """
        allImageId = self.read_value_with_cond("image", "image_id", f"dataset_id='{datasetId}'")
        if allImageId is None:
            raise Exception("This dataset does not have any image")
        random.shuffle(allImageId)
        return allImageId


    def get_split_rate(self, projectName):
        """Get split rate of this project

        Args:
            projectName (str): project name

        Returns:
            tuple[0]: 0: split rate incorrect, 1: split rate
            tuple[1]: 0: log message, 1: split rate
        """
        splitRate = self.read_value_with_cond('project', 'train_rate, valid_rate, test_rate',
                                                    f'project_name="{projectName}"')
        splitRate = splitRate.to_dict('records')[0]
        ok, data = datasetUtil.have_split_rate(splitRate)
        return ok, data


    def insert_proj_dataset(self, insertValue):
        """Insert dataset information into dataset DB

        Args:
            insertValue (str): insert value
        """
        InsertSQL = f'''
        INSERT INTO
            dataset (dataset_id, dataset_name, image_path, annotation_path, annotation_type, project_id)
        VALUES
            ({insertValue})
        '''
        self.my.ExecNoQuery(InsertSQL)


    def remove_existing_dataset_db(self, projectName):
        """Remove existing dataset of project name

        Args:
            projectName (str): project name
        """
        projectId = self.read_value_with_cond('project', 'project_id', f'project_name="{projectName}"')
        self.delete_value('dataset', f"project_id='{projectId}'")


    def remove_existing_label_class_db(self, projectName):
        """Remove existing label_class of project name

        Args:
            projectName (str): project name
        """
        projectId = self.read_value_with_cond('project', 'project_id', f'project_name="{projectName}"')
        datasetId = self.read_value_with_cond('dataset', 'dataset_id', f'project_id="{projectId}"')
        self.delete_value('label_class', f"dataset_id='{datasetId}'")


    def save_proj_dataset(self, projectTask, projectName, imgPath, antType='', antPath=''):
        """Save dataset information into dataset DB

        Args:
            projectTask (str): project task
            projectName (str): project name
            imgPath (str): image path
            antType (str, optional): annotation type. Defaults to ''.
            antPath (str, optional): annotation path. Defaults to ''.

        Returns:
            tuple[0]: 0: save project dataset failed, 1: save project dataset success
            tuple[1]: log message
        """
        datasetId = self.generate_uid('dataset')

        projectId = self.read_value_with_cond('project', 'project_id', f'project_name="{projectName}"')
        if projectTask not in ["classification", "detection"]:
            raise Exception('Save project dataset failed / ProjectTask is not classification or detection')
        self.insert_proj_dataset(f'"{datasetId}", "{projectName}", "{imgPath}", "{antPath}", "{antType}", "{projectId}"')
        return 1, 'Save project dataset success'


    def get_dataset_id(self, projectId):
        """Get dataset id of this project

        Args:
            projectId (str): project id

        Returns:
            str: dataset id
        """
        datasetId = self.read_value_with_cond("dataset", "dataset_id", f"project_id='{projectId}'")
        return datasetId

    # ### ?????
    # def check(imgPath: str):
    #     import os
    #     list = ['Test', 'Train', 'Valid']
    #     dict = {'split': False, 'classification': False}
    #     classificationName = {}
    #     for dirPath, dirNames, fileNames in os.walk('D://Users/Otischang/SALA2_Test/data/Stage1'):
    #         if dirNames is not None:
    #             if all([name in dirNames for name in list]):
    #                 dict['split'] = True
    #             else:
    #                 dict['classification'] = True
    #                 for name in dirNames:
    #                     classificationName.setdefault(os.path.join(dirPath, name), [])

    #         if (fileNames is not None) and (dirPath in classificationName):
    #             classificationName[dirPath] = fileNames


    def check_project_name_existed(self, projectName):
        """Check if the project name has existed in database or not

        Args:
            projectName (str): project name

        Returns:
            tuple[0]: 0: project name is not existed, 1: project name has existed
            tuple[1]: log message
        """
        if self.check_value_exist("project", f'project_name="{projectName}"'):
            return 1, f"The project name ${projectName}$ has existed"
        return 0, f"The project name ${projectName}$ is not existed"


    def check_dataset_name_existed(self, datasetName):
        """Check if the dataset name has existed in database or not

        Args:
            datasetName (str): dataset name

        Returns:
            tuple[0]: 0: dataset name is not existed, 1: dataset name has existed
            tuple[1]: log message
        """
        if self.check_value_exist('dataset', f'dataset_name="{datasetName}"'):
            return 1, f'The dataset name ${datasetName}$ has existed'
        return 0, f'The dataset name ${datasetName}$ is not existed'


    def write_into_label_db(self, labelDBFieldValue):
        """Write multiple label into database

        Args:
            labelDBFieldValue (list):
                - item (tuple): (label id, image id, class id, memo)
        """
        self.insert_value('label (label_id, image_id, class_id, memo)',
                                    ', '.join(f'{val}' for val in labelDBFieldValue))


    def multiple_value_write_into_image_db(self, imageDBFieldValue, isSplit):
        """Write multiple image information into database

        Args:
            imageDBFieldValue (list):
                - item (tuple): (image id, file name, file path, dataset id, task(optional))
            isSplit (bool): the value is True if is a split dataset; Otherwise, the value is False
        """
        if isSplit:
            self.insert_value('image (image_id, image_name, image_pth, dataset_id, task)',
                                        ', '.join(f'{val}' for val in imageDBFieldValue))
        else:
            self.insert_value('image (image_id, image_name, image_pth, dataset_id)',
                                        ', '.join(f'{val}' for val in imageDBFieldValue))


    def deal_with_unclassifiedInfo(self, unclassifiedInfo: dict, datasetId: str) -> None:
        """Write unclassified image information into database

        Args:
            unclassifiedInfo (dict): unclassified information
                - key (str): folder path
                - value (list): list of file names
            datasetId (str): dataset id

        Returns:
            tuple[0]: 1: unclassified information is upload into database
            tuple[1]: log message
        """
        imageDBFieldValue = []   ### The value put into the image DB field
        for folderPath, fileNames in unclassifiedInfo.items():
            for fileName in fileNames:
                imageId = self.generate_uid('image')
                filePath = os.path.join(folderPath, fileName).replace('\\', '/')
                imageDBFieldValue.append((imageId, fileName, filePath, datasetId))

        self.multiple_value_write_into_image_db(imageDBFieldValue, False)
        return 1, "Unclassified information is upload into database"


    def deal_with_classifiedInfo(self, projectName, datasetId, classifiedInfo, listOfClassifiedName, isSplit):
        """Write classified image information and label into database

        Args:
            projectName (str): project name
            datasetId (str): dataset id
            classifiedInfo (dict): classified information
            listOfClassifiedName (list): list of class names
            isSplit (bool): the value is True if is a split dataset; Otherwise, the value is False
        Returns:
            tuple[0]: 1: classified information is upload into database
            tuple[1]: log message
        """
        nameTolabelClassId = {}   ### Record classified name correspond to label_class id. key: classified name, value: label_class id
        ### write into label_class DB
        for classifiedName in listOfClassifiedName:
            labelClassId = self.generate_uid('label_class')
            self.insert_value("label_class", f"('{labelClassId}', '{classifiedName}', '{datasetId}', '{projectName}')")
            nameTolabelClassId[classifiedName] = labelClassId

        imageDBFieldValue = []   ### The value put into the image DB field
        labelDBFieldValue = []   ### The value put into the label DB field
        for folderPath, fileNames in classifiedInfo.items():

            classifiedName = folderPath.split(os.sep)[-1]

            if isSplit:

                splitType = folderPath.split(os.sep)[-2]

                for fileName in fileNames:
                    imageId = self.generate_uid('image')
                    labelId = self.generate_uid('label')
                    filePath = os.path.join(folderPath, fileName).replace('\\', '/')
                    imageDBFieldValue.append((imageId, fileName, filePath, datasetId, splitType))
                    labelDBFieldValue.append((labelId, imageId, nameTolabelClassId.get(classifiedName), 'classification'))

            else:
                for fileName in fileNames:
                    imageId = self.generate_uid('image')
                    labelId = self.generate_uid('label')
                    filePath = os.path.join(folderPath, fileName).replace('\\', '/')
                    imageDBFieldValue.append((imageId, fileName, filePath, datasetId))
                    labelDBFieldValue.append((labelId, imageId, nameTolabelClassId.get(classifiedName),'classification'))

        self.multiple_value_write_into_image_db(imageDBFieldValue, isSplit)
        self.write_into_label_db(labelDBFieldValue)

        return 1, "Classified information is upload into database"


    def dataset_folder_path_to_img_list(self, datasetFolderPath, templateFloderNameList):
        """Dataset to image list.

        Args:
            datasetFolderPath (str): dataset folder path.
            templateFloderNameList (str): template floder name list.

        Returns:
            tuple[0]: 0: does not match template folder structure, 1: conforms to the template folder structure.
            tuple[1]: img floder path list.
        """
        folderNameList = os.listdir(datasetFolderPath)
        templateFlag = True
        ### Confirm whether the all template folder exists
        for templateFloderName in templateFloderNameList:
            if templateFloderName not in folderNameList:
                templateFlag = False
                break
        imgFloderPathList = list()
        ### The folder contains Train, Valid, Test three folders
        if templateFlag:
            for templateFloderName in templateFloderNameList:
                imgfolderPath = os.path.join(datasetFolderPath, templateFloderName)
                imgFloderPathList.append(imgfolderPath)
        ### The folder not contains Train, Valid, Test three folders
        else:
            for root, _, _ in os.walk(datasetFolderPath):
                imgFloderPathList.append(root)
        return templateFlag, imgFloderPathList

    def upload_img(self, datasetId, datasetFolderPath, templateFloderNameList = ["Train", "Valid", "Test"]):
        """Upload img.

        Args:
            datasetId (str): dataset ID.
            datasetFolderPath (str): dataset folder path.
            templateFloderNameList (list, optional): template floder name list. Defaults to ["Train", "Valid", "Test"].

      Returns:
            tuple[0]: 0: upload image fail, 1: upload image success.
            tuple[1]: log message.
        """
        templateFlag, imgFloderPathList = self.dataset_folder_path_to_img_list(datasetFolderPath, templateFloderNameList)
        for imgFloderPath in imgFloderPathList:
            imgNameList = self.img_folder_to_filename_list(imgFloderPath)
            for imgName in imgNameList:
                imgPath = os.path.join(imgFloderPath, imgName)
                imgPath = imgPath.replace("\\","/") # Solve the problem that the DB cannot be displayed normally
                if templateFlag:
                    templateFloderName = imgFloderPath.split("\\")[-1]
                    self.insert_img_info(imgName, imgPath, datasetId, task = templateFloderName)
                else:
                    self.insert_img_info(imgName, imgPath, datasetId)
        return 1, "Upload image success"

    def upload_img_and_ant(self, projectName, datasetId, datasetFolderPath, antFolderPath, antType, templateFloderNameList = ["Train", "Valid", "Test"]):
        """Upload image and annotation.

        Args:
            projectName (str): project name.
            datasetId (str): dataset ID.
            datasetFolderPath (str): dataset folder path.
            antFolderPath (str): annotation folder path.
            antType (str): annotation type.
            templateFloderNameList (list, optional): template floder name list. Defaults to ["Train", "Valid", "Test"].

        Returns:
            tuple[0]: 0: upload image and annotation fail, 1: upload image and annotation success.
            tuple[1]: log message.
        """
        if antType == "yolo_txt" or antType == "bbox_txt":
            antExtension = ".txt"
        elif antType == "bbox_xml":
            antExtension = ".xml"
        templateFlag, imgFloderPathList = self.dataset_folder_path_to_img_list(datasetFolderPath, templateFloderNameList)
        for imgFloderPath in imgFloderPathList:
            imgNameList = self.img_folder_to_filename_list(imgFloderPath)
            for imgName in imgNameList:
                imgPath = os.path.join(imgFloderPath, imgName)
                antName = os.path.splitext(imgName)[0] + antExtension
                antPath = imgPath.replace(datasetFolderPath, antFolderPath).replace(imgName, antName)
                imgPath = imgPath.replace("\\","/") # Solve the problem that the DB cannot be displayed normally
                antPath = antPath.replace("\\","/") # Solve the problem that the DB cannot be displayed normally
                img = cv2.imread(imgPath)
                imgH, imgW, _ = img.shape
                if templateFlag:
                    templateFloderName = imgFloderPath.split("\\")[-1]
                    imgId = self.insert_img_info(imgName, imgPath, datasetId, height=imgH, width=imgW, task=templateFloderName)
                else:
                    imgId = self.insert_img_info(imgName, imgPath, datasetId, height=imgH, width=imgW)
                if os.path.isfile(antPath):
                    legalAntList = self.get_legal_ant(antPath, antType, imgW, imgH)
                    if len(legalAntList) > 0:
                        for legalAnt in legalAntList:
                            labelName, x1, y1, x2, y2 = legalAnt
                            clsId = self.insert_label_cls_info(labelName, datasetId, projectName)
                            self.insert_label_info(projectName, imgId, clsId, x1, y1, x2, y2)
        return 1, "Upload image and annotation success"

    def get_legal_ant(self, antFilePath, antType, imgW, imgH):
        """Get legal labels.

        Args:
            antFilePath (str): annotation file path.
            antType (str): annotation type.
            imgW (int): image width.
            imgH (int): image height.

        Returns:
            list: legal annotation List. example: [[labelName, xmin, ymin, xmax, ymax], ...].
        """
        legalAntList = []
        if antType == "yolo_txt" or antType == "bbox_txt":
            antList = self.get_ant_txt_data(antFilePath)
            for ant in antList:
                labelName, param1, param2, param3, param4 = ant
                if antType == "yolo_txt" and self.is_yolo_format(labelName, param1, param2, param3, param4):
                    x1, y1, x2, y2 = self.yolo2bbox(np.array([param1, param2, param3, param4],dtype=np.float64), imgW, imgH)
                elif antType == "bbox_txt" and self.is_bbox_format(antType, labelName, param1, param2, param3, param4, imgW, imgH):
                    x1, y1, x2, y2 = param1, param2, param3, param4
                else:
                    continue
                ok, xmin, ymin, xmax, ymax = self.double_check_ant(x1, y1, x2, y2)
                if not ok: continue
                legalAntList.append([labelName, xmin, ymin, xmax, ymax])
        elif antType == "bbox_xml":
            antList = self.get_ant_xml_data(antFilePath)
            for ant in antList:
                labelName, param1, param2, param3, param4 = ant
                if self.is_bbox_format(antType, labelName, param1, param2, param3, param4, imgW, imgH):
                    ok, xmin, ymin, xmax, ymax = self.double_check_ant(param1, param2, param3, param4)
                    if not ok: continue
                    legalAntList.append([labelName, xmin, ymin, xmax, ymax])
        return legalAntList

    def double_check_ant(self, x1, y1, x2, y2):
        """make sure annotation is correct (x1 < x2, y1 < y2)
        Args:
            x1 (int)
            y1 (int)
            x2 (int)
            y2 (int)

        Returns:
            boolean and int: ok message and correct annotation coordinate
        """
        ok = True
        if x1 == x2 or y1 == y2:
            ok = False
        return ok, min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)
    

    def get_ant_txt_data(self, antFilePath):
        """Get the data in the annotation txt.

        Args:
            filePath (str): annotation file Path.

        Returns:
            list: annotation txt data. example: [[labelName, param1, param2, param3, param4], ...].
        """
        antList = list()
        with open(antFilePath, 'r', newline='') as txt:
            datas = txt.readlines()
            for data in datas:
                try:
                    labelName, param1, param2, param3, param4 = data.strip().split(' ')
                    antList.append([labelName, param1, param2, param3, param4])
                except:
                    continue
        return antList

    def get_ant_xml_data(self, filePath):
        """Get the data in the annotation xml.

        Args:
            filePath (str): file Path.

        Returns:
            list: annotation xml data. example: [[labelName, xmin, ymin, xmax, ymax], ...].
        """
        xmlTree = ET.parse(filePath)
        xmlRoot = xmlTree.getroot()
        antList = list()
        for xmlObj in xmlRoot.findall('object'):
            try:
                labelName = xmlObj.find('name').text
                bndbox = xmlObj.find('bndbox')
                xmin = bndbox.find('xmin').text
                ymin = bndbox.find('ymin').text
                xmax = bndbox.find('xmax').text
                ymax = bndbox.find('ymax').text
                antList.append([labelName, xmin, ymin, xmax, ymax])
            except:
                continue
        return antList

    def is_yolo_format(self, label, x, y, w, h):
        """Confirm whether it is legal YOLO format.

        Args:
            label (str): box label name.
            x (str): box center coordinate x.
            y (str): box center coordinate y.
            w (str): box width.
            h (str): box height.

        Returns:
            bool: is it legal.
        """
        if (label.isalpha() or label.isdigit()) and self.is_float(x) and self.is_float(y) and self.is_float(w) and self.is_float(h):
            x, y, w, h = float(x), float(y), float(w), float(h)
            if x > 0 and y > 0 and w > 0 and h > 0:
                if x < 1 and y < 1 and w <= 1 and h <= 1 and x + w / 2 <= 1 and x - w / 2 >= 0 and y + h / 2 <= 1 and y - h / 2 >= 0:
                    return True
        return False

    def is_bbox_format(self, antType, label, xmin, ymin, xmax, ymax, imgW, imgH):
        """Confirm whether it is legal bounding box format.

        Args:
            label (str): box label name.
            xmin (str): box upper left coordinate x.
            ymin (str): box upper left coordinate y.
            xmax (str): box lower right coordinate x.
            ymax (str): box lower right coordinate y.
            imgW (int): image width.
            imgH (int): image height.

        Returns:
            bool: is it legal.
        """
        if antType == "bbox_xml":
            if (label.isalpha() or label.isdigit()) and xmin.isdigit() and ymin.isdigit() and xmax.isdigit() and ymax.isdigit():
                xmin, ymin, xmax, ymax = int(xmin), int(ymin), int(xmax), int(ymax)
                if xmin < xmax and ymin < ymax:
                    if xmin >= 0 and ymin >= 0 and xmax <= imgW and ymax <= imgH:
                        return True
        if antType == "bbox_txt":
            if label.isdigit() and xmin.isdigit() and ymin.isdigit() and xmax.isdigit() and ymax.isdigit():
                xmin, ymin, xmax, ymax = int(xmin), int(ymin), int(xmax), int(ymax)
                if xmin < xmax and ymin < ymax:
                    if xmin >= 0 and ymin >= 0 and xmax <= imgW and ymax <= imgH:
                        return True
        return False

    def img_folder_to_filename_list(self, imgFolderPath):
        '''將所有待檢測之圖片路徑存成陣列

        Args:
            imgFolderPath (str): 待檢測資料夾路徑

        Return:
            imgPathList (str): 待檢測圖片路徑之陣列
        '''
        imgNameList = []
        filenameList = os.listdir(imgFolderPath)
        for filename in filenameList:
            if filename.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
                imgNameList.append(filename)
        return imgNameList

    def insert_img_info(self, imgName, imgPath, datasetId, height=0, width=0, task=""):
        """Store image information into database.

        Args:
            imgName (str): image name.
            imgPath (str): image path.
            datasetId (str): dataset id.
            height (int, optional): image length. Defaults to 0.
            width (int, optional): image width. Defaults to 0.
            task (str, optional): task. Defaults to None.

        Returns:
            str: image ID.
        """
        ### Generate image ID
        imgId = self.generate_uid('image')
        ### Insert to DB
        if task != "":
            insertSQL = f'''
            INSERT INTO
                image (image_id, image_name, image_pth, dataset_id, length, width, task)
            VALUES
                ("{imgId}", "{imgName}", "{imgPath}", "{datasetId}", "{height}", "{width}", "{task}")
            '''
        else:
            insertSQL = f'''
            INSERT INTO
                image (image_id, image_name, image_pth, dataset_id, length, width)
            VALUES
                ("{imgId}", "{imgName}", "{imgPath}", "{datasetId}", "{height}", "{width}")
            '''
        self.my.ExecNoQuery(insertSQL)
        return imgId

    def insert_label_info(self, projectName, imgId, clsId, x1, y1, x2, y2):
        """Store label information into database.

        Args:
            projectName (str): project name.
            imgId (str): image ID.
            clsId (str): class ID.
            x1 (str): upper left coordinate x.
            y1 (str): upper left coordinate y.
            x2 (str): lower right coordinate x.
            y2 (str): lower right coordinate y.

        Returns:
            str: label ID.
        """
        ### Generate label ID
        labelId = self.generate_uid('label')
        ### Get project task
        memo = self.read_value_with_cond("project", "project_task", f"project_name='{projectName}'")
        ### Insert to DB
        insertSQL = f'''
        INSERT INTO
            label (label_id, image_id, class_id, x1, y1, x2, y2, memo)
        VALUES
            ("{labelId}", "{imgId}", "{clsId}", "{x1}", "{y1}", "{x2}", "{y2}", "{memo}")
        '''
        self.my.ExecNoQuery(insertSQL)
        return labelId

    def insert_label_cls_info(self, clsName, datasetId, memo):
        """Store label class information into database.

        Args:
            clsName (str): class name.
            datasetId (str): dataset ID.
            memo (str): memo.

        Returns:
            str: label class ID.
        """
        ### Get label class ID
        labelClsId = self.read_value_with_cond("label_class", "class_id", f'dataset_id="{datasetId}" and class_name="{clsName}"')
        if labelClsId == None: # This Label class not exists
            ### Generate label class ID
            labelClsId = self.generate_uid('label_class')
            ### Insert to DB
            insertSQL = f'''
            INSERT INTO
                label_class (class_id, class_name, dataset_id, memo)
            VALUES
                ("{labelClsId}", "{clsName}", "{datasetId}", "{memo}")
            '''
            self.my.ExecNoQuery(insertSQL)
            return labelClsId
        ### This Label class exists
        return labelClsId

    def yolo2bbox(self, bboxArr, imgW, imgH):
        """YOLO 座標轉 Bbox 座標

        Args:
            bboxArr (np.array): YOLO 座標
            imgW (int): 圖片的寬
            imgH (int): 圖片的高

        Returns:
            np.array: Bbox 座標
        """
        ### 數學計算
        bboxWArr = bboxArr[..., 2] * imgW
        bboxHArr = bboxArr[..., 3] * imgH
        bboxX1Arr = bboxArr[..., 0] * imgW - 0.5 * bboxWArr
        bboxY1Arr = bboxArr[..., 1] * imgH - 0.5 * bboxHArr
        bboxX2Arr = bboxX1Arr + bboxWArr
        bboxY2Arr = bboxY1Arr + bboxHArr
        ### 將一維矩陣轉換維二維矩陣
        bboxX1Arr = bboxX1Arr.reshape(-1, 1)
        bboxY1Arr = bboxY1Arr.reshape(-1, 1)
        bboxX2Arr = bboxX2Arr.reshape(-1, 1)
        bboxY2Arr = bboxY2Arr.reshape(-1, 1)
        ### 矩陣拼接
        transBboxArr = np.concatenate((bboxX1Arr, bboxY1Arr, bboxX2Arr, bboxY2Arr), axis=1)
        ### 去除多餘維度
        transBboxArr = np.squeeze(transBboxArr).astype(int)
        return transBboxArr

    def is_float(self, str):
        """Determine whether it is a floating point number.

        Args:
            str (str): str

        Returns:
            bool: 0: not a floating point number, 1: is a floating point number.
        """
        strList = str.split('.')
        if len(strList) <= 1 or len(strList) > 2:
            return False
        else:
            for str in strList:
                if not str.isdigit():
                    return False
        return True


    def get_image_nums_of_split(self, classId, imageNum, splitRate, projectName, projectTask):
        """Get the number of images of the three split types

        Args:
            classId (str): class id
            imageNum (int): the number of images
            splitRate (dict): split rate, ex. {"train": 80, "valid": 10, "test": 10}
                - key (str): split type
                - value (int): split rate
            projectName (str): project name
            projectTask (str): project task

        Raises:
            Exception: The split type exist zero image

        Returns:
            dict: the number of images of the three split types, ex.{'Train': 5, 'Valid': 2, 'Test': 3}
                - key (str): split type
                - value (int): the number of images
        """
        ### Calculate the number of images that can be obtained by the three split types
        valid_image_nums = int(Decimal(str(imageNum*splitRate.get('Valid')/100)).quantize(0, ROUND_HALF_UP))
        test_image_nums = int(Decimal(str(imageNum*splitRate.get('Test')/100)).quantize(0, ROUND_HALF_UP))
        train_image_nums = imageNum - (valid_image_nums + test_image_nums)
        imageNumsOfSplit = {'Train': train_image_nums, 'Valid': valid_image_nums, 'Test': test_image_nums}

        ### Check if there is a split type with zero image
        splitTypeWithZeroImage = tuple(filter(lambda splitType: imageNumsOfSplit.get(splitType) <= 0, imageNumsOfSplit))
        if(len(splitTypeWithZeroImage) > 0):
            self.update_project_split_rate(projectName, {"Train": "", "Valid": "", "Test": ""})
            if projectTask == 'classification':
                className = self.read_value_with_cond("label_class", "class_name", f'class_id="{classId}"')
                raise Exception(f"The ${' and '.join(splitTypeWithZeroImage)} set of class ${className}$ have no image under this split rate")
            else:
                raise Exception(f"The ${' and '.join(splitTypeWithZeroImage)} set have no image under the set split rate")
        return imageNumsOfSplit


    @staticmethod
    def assign_image_id_to_split(allImageId, imageNumsOfSplit, imageIdOfSplit):
        """assign image id to the three split types

        Args:
            allImageId (str): all image id of class
            imageNumsOfSplit (dict): the number of images of the three split types, ex.{'Train': 5, 'Valid': 2, 'Test': 3}
                - key (str): split type
                - value (int): the number of images
            imageIdOfSplit (dict): image id list of the three split types, {'Train': [id1, id2], 'Valid': [id3], 'Test': [id4]}
                - key (str): split type
                - value (list): image id
        """
        startIndex = 0
        for splitType, imageNums in imageNumsOfSplit.items():
            ### Put image id to list one by one
            for imageId in allImageId[startIndex : startIndex+imageNums]:
                imageIdOfSplit[splitType].append(imageId)
            startIndex += imageNums

    def get_image_list(self, projectTask, datasetId):
        """Get image id list of each class

        Args:
            projectTask (str): project task
            datasetId (str): dataset ID

        Returns:
            allImageIdofClass (dict): image list of each class
                classification: {'classA': [image id1, image id2], 'classB':[image id3, image id4], ...}
                detection: {"": [image id1, image id2, image id3, image id4]}
        """
        allImageIdOfClass = {}
        if projectTask == 'classification':
            classIdList = self.read_value_with_cond('label_class', 'class_id', f"dataset_id='{datasetId}'")
            classIdList = [classIdList] if isinstance(classIdList, str) else classIdList
            for classId in classIdList:
                ### get all image id of class
                allImageId = self.read_value_with_cond('label', 'image_id', f"class_id='{classId}'")   ### get all image id of class
                if isinstance(allImageId, str): ### Only one image
                    allImageIdOfClass[classId] = [allImageId]
                elif isinstance(allImageId, list): ### Many images
                    allImageIdOfClass[classId] = allImageId ### ex. {"classA": [image id1, image id2], 'classB':[image id3, image id4]}
        elif projectTask == 'detection':
            ### Get all image id
            allImageId = self.get_all_image_id_of_dataset(datasetId)
            allImageIdOfClass[""] = allImageId ### ex. {"": [image id1, image id2, image id3, image id4]}
        return allImageIdOfClass

    def get_image_id_of_split(self, allImageIdOfClass, splitRate, projectName, projectTask):
        """Get all image id of the three split types by all class

        Args:
            allImageIdOfClass (dict): image id of class, ex. {"classA": [image id1, image id2], 'classB':[image id3, image id4]}
                - key (str): class name
                - value (list): image id
            splitRate (dict): split rate, ex. {"train": 80, "valid": 10, "test": 10}
                - key (str): split type
                - value (int): split rate
            projectName (str): project name
            projectTask (str): project task

        Returns:
            dict: respective image id of the three split types
                - key (str): split type
                - value (list): image id
        """
        imageIdOfSplit = {'Train': [], 'Valid': [], 'Test': []}
        try:
            for classId, allImageId in allImageIdOfClass.items():
                ### Get the number of images of the three split types
                imageNumsOfSplit = self.get_image_nums_of_split(classId, len(allImageId), splitRate, projectName, projectTask)

                ### Assign image id to the three split types
                DatasetDb.assign_image_id_to_split(allImageId, imageNumsOfSplit, imageIdOfSplit)
            return 1, imageIdOfSplit
        except Exception as err:
            return 0, err
