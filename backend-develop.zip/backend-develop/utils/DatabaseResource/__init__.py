#---------------------------------------------------------------------------
# 時間          修改者     內容
#------------- ---------  --------------------------------------------------
# 2022/9/20    JackLin    程式初始化
# 2022/9/21    JackLin    增加 DB, Table 初始化 store procedure
# 2022/9/26    OtisChang  物件化 DB 訪問程式
#---------------------------------------------------------------------------

import sys, time
import mariadb
import mysql.connector
from mysql.connector import Error
from datetime import datetime
from pandas import read_sql
from sqlalchemy import create_engine
from pandas import read_csv, read_sql_query


class mariaDB:
    '''
    操作 MariaDB 的class
    '''
    def __get(self):
        '''
        設定server & database
        '''
        self.SERVER = 'localhost'
        self.DATABASE = 'sala2'
        self.UID = 'root'
        self.PWD = '123456'
        self.PORT = 3306

    def __init__(self, SERVER='', DATABASE='', UID='', PWD='', PORT=0):
        '''
        操作 MariaDB 的class

        功能:     初始化配置信息
        SERVER:   数据服务器
        DATABASE: 数据库
        UID:      登录名
        PWD:      登录密码
        PORT:     PORT
        '''
        self.__get()
        if SERVER != '':
            self.SERVER = SERVER
        if DATABASE != '':
            self.DATABASE = DATABASE
        if UID != '':
            self.UID = UID
        if PWD != '':
            self.PWD = PWD
        if PORT != 0:
            self.PORT = PORT


    def __getConnect(self):
        '''
        功能: 利用配置信息連接MariaDB
        '''
        while True:
            try:
                self.conn = mysql.connector.connect(host=self.SERVER,
                                            database=self.DATABASE,
                                            user=self.UID,
                                            password=self.PWD,
                                            port=self.PORT)
                # cursor = self.conn.cursor()
                # cursor.execute("SET GLOBAL max_allowed_packet=1073741824")
                # cursor.execute('SET GLOBAL connect_timeout=28800')
                # cursor.execute('SET net_read_timeout=28800')
                # cursor.execute('SET interactive_timeout=28800')
                # cursor.execute('SET wait_timeout=28800')
                # self.conn = mariadb.connect(host=self.SERVER,
                #                             database=self.DATABASE,
                #                             user=self.UID,
                #                             password=self.PWD,
                #                             port=self.PORT)
                # cur = self.conn.cursor()
                break
            except Exception as ex:
                print('__getConnect: MariaDB connecting error,reason is: {}'.format(ex))
                # sys.exit()
            # return cur


    def __getConnect2(self):
        '''
        功能: 利用配置信息連接MariaDB
        '''
        try:
            self.conn = mysql.connector.connect(host=self.SERVER,
                                        database=self.DATABASE,
                                        user=self.UID,
                                        password=self.PWD,
                                        port=self.PORT)
            cur = self.conn.cursor()
            # cur.execute("SET GLOBAL max_allowed_packet=1073741824")
            # cur.execute('SET GLOBAL connect_timeout=28800')
            # cur.execute('SET interactive_timeout=28800')
            # cur.execute('SET wait_timeout=28800')
            # self.conn = mariadb.connect(host=self.SERVER,
            #                             database=self.DATABASE,
            #                             user=self.UID,
            #                             password=self.PWD,
            #                             port=self.PORT)
        except Error as ex:
            print('MariaDB connecting error,reason is:'.format(ex))
            sys.exit()
        return cur

    def ExecQuery(self, sql):
        '''
        功能: 執行查詢語句，返回结果集
        sql: 要執行的SQL語句
        '''
        self.__getConnect()
        # cur = self.__getConnect()
        try:
            data = read_sql_query(sql, self.conn)
            self.conn.close()
            return data
            # cur.execute(sql)
            # rows = cur.fetchall()
        except Error as ex:
            print('MariaDB.Error:{}'.format(ex))
            self.conn.close()
            sys.exit()
#        return rows

    def ExecNoQuery(self, sql):
        '''
        功能: 執行查詢語句, 如Create,Insert,Delete,update,drop等
        sql: 要執行的SQL語句
        '''
        cur = self.__getConnect2()
        try:
            cur.execute(sql)
            self.conn.commit()
            cur.close()
            self.conn.close()
        except Error as ex:
            print('MariaDB.Error:{}'.format(ex))
            cur.close()
            self.conn.close()
            return 'MariaDB.Error:{}'.format(ex)
        return 'success'

    def DfInsert(self, df, tableName):
        '''
        功能: 將pandas的dataframe寫入DB table
        '''
        try:
            engine = create_engine('mysql+pymysql://{}:{}@{}:{}/{}'.format(
                self.UID, self.PWD, self.SERVER, self.PORT, self.DATABASE))
            conn = engine.connect()
            df.to_sql(name=tableName, con=conn,
                      if_exists='append', index=False)
        finally:
            conn.close()

    def DfSelect(self, sqlSelect):
        '''
        功能: 將pandas的dataframe寫入DB table
        '''
        try:
            engine = create_engine('mysql+pymysql://{}:{}@{}:{}/{}'.format(
                self.UID, self.PWD, self.SERVER, self.PORT, self.DATABASE))
            conn = engine.connect()
            df = read_sql(sql=sqlSelect, con=conn)
            return df
        finally:
            conn.close()


class BasicDb():
    '''
    功能: MariaDB测试函数
    '''

    # 變數設定區
    def __init__(self,
                dbname='sala2',
                tableName='image',
                proc_initDB_name='initDB',
                proc_initTable_name='initTable'):
        self.my = mariaDB('127.0.0.1', 'sala2', 'root', '123456', 3306)
        self.dbname = dbname
        self.tableName = tableName
        self.proc_initDB_name = proc_initDB_name
        self.proc_initTable_name = proc_initTable_name
        self.serverHost = "10.96.152.244"
        self.serverPort = "5566"


    # 初始化資料庫 (所有資料會被清空)
    def __reset_db(self):
        initDBSQL = r'CALL {}.{}'.format(self.dbname, self.proc_initDB_name)
        self.my.ExecNoQuery(initDBSQL)


    # 初始化Table
    def __reset_table(self):
        initTableSQL = u'''CALL {}.{}('{}')'''.format(self.dbname, self.proc_initTable_name, self.tableName)
        self.my.ExecNoQuery(initTableSQL)


    # 附條件讀取
    def read_value_with_cond(self, tableName: str, selectColumn: str, condition: str):
        """依條件在指定表的指定欄位進行讀取
        ex.
            從 project 表中讀取 prject_name = 'AAA' 的 project_id
            read_value_with_cond('project', 'project_id', f'project_name="AAA"')

        Args:
            tableName (str): 表格名稱
            selectColumn (str): 指定要讀取的欄位
            condition (str): 條件

        Returns:
            result (dataframe, list, None): 回傳值
        """
        sql = f'''
        SELECT
            {selectColumn}
        FROM
            {tableName}
        WHERE
            {condition}
        '''
        result = []
        if selectColumn == '*' or (',' in selectColumn):
            dfSelect = self.my.DfSelect(sql)
            result = dfSelect
        else:
            rows = self.my.ExecQuery(sql)
            selectColumn = selectColumn.split('.')[-1] if '.' in selectColumn else selectColumn
            for row in rows[selectColumn]:
                result.append(row)
            if result == None or len(result) == 0 or (len(result) == 1 and result[0] == ''):
                result = None
            elif len(result) == 1:
                result = result[0]
        return result

    # 無條件讀取
    def read_column(self, tableName: str, selectColumn: str):
        """在指定表的指定欄位進行讀取
        ex.
            從 project 表中讀取所有 project_id
            read_column('project', 'project_id')

        Args:
            tableName (str): 表格名稱
            selectColumn (str): 指定要讀取的欄位

        Returns:
            result (dataframe, list, None): 回傳值
        """
        sql = f'''
        SELECT
            {selectColumn}
        FROM
            {self.dbname}.{tableName}
        '''
        result = []
        if selectColumn == '*' or (',' in selectColumn):
            dfSelect = self.my.DfSelect(sql)
            result = dfSelect
        else:
            rows = self.my.ExecQuery(sql)
            for row in rows[selectColumn]:
                result.append(row)
            if result == None or len(result) == 0 or (len(result) == 1 and result[0] == ''):
                result = None
            elif len(result) == 1:
                result = result[0]
        return result


    # 寫入一筆新資料
    def insert_value(self, tableName: str, insertValue: str):
        InsertSQL = f'''
        INSERT INTO
            {tableName}
        VALUES
            {insertValue}
        '''
        self.my.ExecNoQuery(InsertSQL)


    # 確認該筆資料是否存在
    def check_value_exist(self, tableName: str, condition: str):
        existSQL = f'''
        SELECT 1
        FROM
            {tableName}
        WHERE
            {condition} LIMIT 1
        '''
        exist = self.my.ExecQuery(existSQL)
        if exist.empty:
            return 0
        return exist.at[0, '1']


    # 刪除一筆資料
    def delete_value(self, tableName: str, condition: str):
        DeleteSQL = f'''
        DELETE FROM
            {tableName}
        WHERE
            {condition}
        '''
        self.my.ExecNoQuery(DeleteSQL)


    # 修改特定欄位值
    def update_value_with_cond(self, tableName: str, updateContent: str, condition: str):
        UpdateSQL = f'''
        UPDATE
            {tableName}
        SET
            {updateContent}
        WHERE
            {condition}
        '''
        message = self.my.ExecNoQuery(UpdateSQL)
        return message


    # 產生 unique ID
    def generate_uid(self, title):
        time.sleep(0.0000000001)
        return f"{title}_" + datetime.now().strftime("%Y%m%d%H%M%S%f") + str(time.time_ns())[11:]


    # 測試用 pandas 整包寫入
    # def write_table(self, tableName):
    #     df = read_csv(r'D:\\Users\\Otischang\\SALA2\\backend\\test.csv')
    #     self.my.DfInsert(df, tableName)


if __name__ == "__main__":
    pass
