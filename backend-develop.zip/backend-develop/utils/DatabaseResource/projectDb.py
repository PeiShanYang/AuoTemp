from . import BasicDb
import random, os


class ProjectDb(BasicDb):
    def get_project(self, returnCurrentNum: int = None):
        """
        Get returnCurrentNum experiments of project id
            returnCurrentNum=None, then all experiments
        Args:
            returnCurrentNum (int): num of data to get by order

        Returns:
            dataframe: dataframe for sql callback
        """
        ### generate sql command
        sql = f"""
        SELECT
            project_name, update_time
        FROM
            project
        """
        if returnCurrentNum:
            sql = (
                sql
                + f"""
            ORDER BY
                update_time DESC
            LIMIT
                {returnCurrentNum}
            """
            )
        else:
            sql = (
                sql
                + f"""
            ORDER BY
                update_time DESC
            """
            )
        return self.my.ExecQuery(sql)

    def generate_list(self, returnCurrentNum=None):
        """Get all project information

        Args:
            returnCurrentNum (int, optional): num of data to get by order. Defaults to None.

        Returns:
            tuple[0]: 0: get project list failed, 1: get project list success
            tuple[1]: log message
            tuple[2]: None or list:
                                - item (dict): all project information
        """
        try:
            ### Get all project name and update time
            projectDf = self.get_project(returnCurrentNum=returnCurrentNum)
            ### Collect all project information
            dataDict = []
            for _, row in projectDf.iterrows():
                dataDict.append(
                    {
                        "projectName": row["project_name"],
                        "creator": "someone1",
                        "updateTime": str(row["update_time"]),
                        "favorite": random.choice([True, False]),
                    }
                )
            return 1, "Get list success", dataDict
        except:
            return 0, "Get list failed", None


    def add_favorite(self, projectName: str):
        """Add favorite project into database

        Args:
            projectName (str): project name

        Returns:
            tuple[0]: 0: insert favorite project failed, 1: insert favorite project success
            tuple[1]: log message
        """
        try:
            # self.insert_value('user_favorite_page (username, page_id, page_type, favorite_name)', \
            #                 f'(SELECT username as username FROM user WHERE username = "Otis"), "someone1", "project", "{projectName}"')
            return 1, "Add favorite success"
        except:
            return 0, "Add favorite failed"

    def get_imgs_name_path(self, datasetId):
        """Get image name and path in same dataset from database

        Args:
            datasetId (str): datasei ID

        Returns:
            dfSelect: dataframe including all image information
        """
        sql = f"""
        SELECT
	        image_name, image_pth
        FROM
            image as img
        WHERE
            img.dataset_id = "{datasetId}"
        """
        dfSelect = self.my.DfSelect(sql)
        return dfSelect

    def get_dataset_rate(self, projectName):
        sql = f"""
        SELECT
            train_rate, valid_rate, test_rate
        FROM
            project
        WHERE
            project_name = "{projectName}"
        """
        dfSelect = self.my.DfSelect(sql)
        return dfSelect

    def check_project_name_existed(self, projectName):
        """check if the project name has existed in database or not

        Args:
            projectName (str): project name

        Returns:
            ok: 1: project name has existed, 0: project name is new
            message: log message
        """
        if self.check_value_exist("project", f'project_name="{projectName}"'):
            return 1, f"The project name ${projectName}$ has existed"
        return 0, f"The project name ${projectName}$ is not existed"

    def create_project(self, projectName):
        """create project

        Args:
            projectName (str): project name

        Returns:
            code and message
        """
        projectId = self.generate_uid("project")
        try:
            self.insert_value('project (project_id, project_name)', f'("{projectId}", "{projectName}")')
            return 1, "Create project success"
        except:
            return 0, "Create project failed"

    def save_project_task(self, projectName, projectTask):
        """save project task

        Args:
            projectName (str): project name
            projectTask (str): project task

        Returns:
            code and message
        """
        if projectTask not in ["classification", "detection"]:
            return 0, f"Task type ${projectTask}$ is not classification or detection"
        try:
            projectTaskDb = self.read_value_with_cond('project', 'project_task', f'project_name="{projectName}"')
            if projectTaskDb != None and projectTaskDb != projectTask:
                datasetId = self.read_value_with_cond('dataset, project', 'dataset_id', f'project.project_id=dataset.project_id\
                                                                                    AND project.project_name="{projectName}"')
                self.delete_value('label_class', f'dataset_id="{datasetId}"')
                self.delete_value('dataset', f'dataset_id="{datasetId}"')
                self.update_value_with_cond('project', f'train_rate="", valid_rate="", test_rate=""', f'project_name="{projectName}"')
            self.update_value_with_cond("project", f'project_task="{projectTask}"', f'project_name="{projectName}"')
            return 1, f"Project {projectName} save task {projectTask} success"
        except:
            return 0, "Process incorrect"

    def get_project_info(self, projectName):
        """get project info: task, abstract, created

        Args:
            projectName (str): project name

        Returns:
            info: project info
        """
        info = self.read_value_with_cond("project", "project_task, abstract, created", f'project_name="{projectName}"').to_dict('records')[0]
        info['project_task'] = '' if info['project_task'] == None or info['project_task'] == "None" \
                            else info['project_task']
        info['abstract'] = '' if info['abstract'] == None or info['abstract'] == "None" \
                            else info['abstract']
        info['created'] = int(info['created'])
        return info

    def get_img_path(self, projectName):
        """get dataset image path of corresponding project name

        Args:
            projectName (str): project name

        Returns:
            imgPath: image path
        """
        projectId = self.read_value_with_cond("project", "project_id", f'project_name="{projectName}"')
        imgPath = self.read_value_with_cond("dataset", "image_path", f'project_id="{projectId}"')
        if imgPath != None:
            imgPath = os.path.split(imgPath)[-1]
            return imgPath
        return ""

    def get_annotation_path(self, projectName):
        projectId = self.read_value_with_cond("project", "project_id", f'project_name="{projectName}"')
        antPath = self.read_value_with_cond("dataset", "annotation_path", f'project_id="{projectId}"')
        if antPath != None:
            antPath = os.path.split(antPath)[-1]
            return antPath
        return ""

    def get_split_rate(self, projectName):
        splitRate = self.get_dataset_rate(projectName)
        if None in splitRate.values or "" in splitRate.values or splitRate.empty or "None" in splitRate.values:
            return {"Train": 0, "Valid": 0, "Test": 0}
        return {
            "Train": int(splitRate["train_rate"][0]),
            "Valid": int(splitRate["valid_rate"][0]),
            "Test": int(splitRate["test_rate"][0]),
        }

    def get_islabel_split(self, projectName):
        projectId = self.read_value_with_cond("project", "project_id", f'project_name="{projectName}"')
        info = self.read_value_with_cond("dataset", "labeled, split", f'project_id="{projectId}"')
        if info.empty:
            return False, False
        isLabel = True if info["labeled"][0] == 1 else False
        isSplit = True if info["split"][0] == 1 else False
        return isLabel, isSplit

    def get_file_list(self, projectName, projectTask, host, port):
        projectId = self.read_value_with_cond("project", "project_id", f'project_name="{projectName}"')
        datasetId = self.read_value_with_cond("dataset", "dataset_id", f'project_id="{projectId}"')

        ### Do not need to get image list if any if-else case happened below
        if datasetId == None:
            return 1, ""
        elif projectTask == "":
            return 1, ""
        elif projectTask not in ["classification", "detection"]:
            return 0, "Project task should be classification or detection"

        return 1, self.get_img_list(datasetId, host, port)

    def get_url(self, imgPath, host, port):
        urlSuffix = imgPath.replace("\\", "/")
        url = f"http://{host}:{port}/image/show-img/{urlSuffix}"
        return url

    def get_img_list(self, datasetId, host, port):
        imgListDb = self.get_imgs_name_path(datasetId)
        imgList = []
        for i in range(len(imgListDb.index)):
            url = self.get_url(imgListDb["image_pth"][i], host, port)
            imgList.append({"fileName": imgListDb["image_name"][i], "url": url})
        return imgList

    def update_project_abstract(self, projectName, projectAbstract):
        """Update abstract column of project database

        Args:
            projectName (str): project name
            projectAbstract (str): project abstract
        """
        message = self.update_value_with_cond("project", f"abstract='{projectAbstract}'", f"project_name='{projectName}'")
        if 'Data too long' in message:
            return 0, 'The content of the abstract is too long, the limit is 500 words'
        return 1, 'Save abstract success'

    def project_rename(self, projectName, projectRename):
        """Rename project

        Args:
            projectName (str): project name
            projectRename (str): project name
        """
        try:
            self.update_value_with_cond("project", f'project_name="{projectRename}"', f'project_name="{projectName}"')
            return 1, "Rename project succeed"
        except:
            return 0, "Rename project failed"
