from . import BasicDb
import random
import re
from datetime import datetime
import time
import json
from decimal import Decimal, ROUND_HALF_UP

class PipelineDb(BasicDb):
    """Database query method of pipeline"""

    def check_gpu_available(self, deviceID, memPercentage, gpuUsageThres):
        """check GPU available

        Args:
            deviceID (str): gpu ID
            memPercentage (float): gpu memory usage
            gpuUsageThres (float): gpu memory uasge threshold

        Returns:
            int: 1: available, 0: unavailable
        """
        usingGpu = self.read_value_with_cond('gpu_situation', 'gpu_id', '1=1')
        if usingGpu == None:
            usingGpu = []
        elif isinstance(usingGpu, int):
            usingGpu = [usingGpu]
        if (memPercentage > gpuUsageThres) and (deviceID not in usingGpu):
            return 0
        return 1

    def check_project_name_existed(self, projectName):
        """check if the project name has existed in database or not

        Args:
            projectName (str): project name

        Returns:
            tuple[0]: 0: project name is not existed, 1: project name has existed
            tuple[1]: log message
        """
        if self.check_value_exist("project", f'project_name="{projectName}"'):
            return 1, f"The project name ${projectName}$ has existed"
        return 0, f"The project name ${projectName}$ is not existed"

    def check_experiment_name_existed(self, projectName, experimentName):
        """check if the experiment name has existed in database or not

        Args:
            projectName (str): project name
            experimentName (str): experiment name

        Returns:
            tuple[0]: 0: experiment name is not existed, 1: experiment name has existed
            tuple[1]: log message
        """
        ### return operation
        if self.check_value_exist('project, experiment',
                    f'project.project_id = experiment.project_id\
                    and project.project_name = "{projectName}"\
                    and experiment.experiment_name = "{experimentName}"'):
            return 1, f"The experiment name ${experimentName}$ has existed"
        return 0, f"The experiment name ${experimentName}$ is not existed"

    def check_pipeline_name_existed(self, projectName, experimentName, pipelineName):
        """Check if the pipeline name has existed in database or not

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name

        Returns:
            tuple[0]: 0: pipeline name is not existed, 1: pipeline name has existed
            tuple[1]: log message
        """
        if self.check_value_exist('project, experiment, pipeline',
                        f'project.project_id = experiment.project_id\
                        and experiment.experiment_id = pipeline.experiment_id\
                        and project.project_name = "{projectName}"\
                        and experiment.experiment_name = "{experimentName}"\
                        and pipeline.pipeline_name = "{pipelineName}"'):
            return 1, f"The pipeline name ${pipelineName}$ has existed"
        return 0, f"The pipeline name ${pipelineName}$ is not existed"

    def get_experiment_id(self, projectName, experimentName):
        """Get experiment id by project name and experiment name

        Args:
            projectName (str): project name
            experimentName (str): experiment name

        Returns:
            str: experiment id
        """
        projectId = self.read_value_with_cond("project", "project_id", f"project_name='{projectName}'")
        experimentId = self.read_value_with_cond("experiment", "experiment_id",
                                        f"project_id='{projectId}' AND experiment_name='{experimentName}'")
        return experimentId

    def get_pipeline(self, projectName: str, experimentName: str = None, returnCurrentNum: int = None):
        """Get all pipelines of experiment id and project id

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            returnCurrentNum (int): num of data to get by order

        Returns:
            dataframe: dataframe for sql callback
        """
        ### get project id
        projectId = self.read_value_with_cond(
            tableName="project", selectColumn="project_id", condition=f'project_name="{projectName}"'
        )
        ### is experimentName
        if experimentName:
            ### get experiment id
            experimentId = self.read_value_with_cond(
                tableName="experiment",
                selectColumn="experiment_id",
                condition=f'experiment_name="{experimentName}" and project_id="{projectId}"',
            )
            sql = f"""
            SELECT
                pipeline_name, update_time
            FROM
                pipeline
            WHERE
                experiment_id = "{experimentId}"
            """
        else:
            sql = f"""
            SELECT
                experiment_name, pipeline_name, pipeline.update_time
            FROM
                experiment, pipeline
            WHERE
                experiment.experiment_id = pipeline.experiment_id
                AND project_id = "{projectId}"
            """
        if returnCurrentNum:
            sql = (
                sql
                + f"""
            ORDER BY
                pipeline.update_time DESC
            LIMIT
                {returnCurrentNum}
            """
            )
        else:
            sql = (
                sql
                + f"""
            ORDER BY
                pipeline.update_time DESC
            """
            )
        return self.my.ExecQuery(sql)


    def calculate_execution_time(self, validRecordJson, createTime, updateTime):
        """Calculate pipeline execution time

        Args:
            validRecordJson (dict): valid record
            createTime (pandas._libs.tslibs.timestamps.Timestamp): pipeline create time
            updateTime (pandas._libs.tslibs.timestamps.Timestamp): pipeline update time

        Returns:
            float: pipeline execution time
        """
        lastEpochInfo = validRecordJson.get(list(validRecordJson.keys())[-1])
        exeTime = Decimal(str((updateTime - createTime).total_seconds() / 3600 / lastEpochInfo['model']['epoch']
                           * (lastEpochInfo['model']['total'] - lastEpochInfo['model']['epoch']))).quantize(Decimal('.00'), ROUND_HALF_UP)
        return float(exeTime)


    def calculate_execution_percentage(self, validRecordJson):
        """Calculate pipeline execution percentage

        Args:
            validRecordJson (dict): valid record

        Returns:
            float: pipeline execution percentage
        """
        lastEpochInfo = validRecordJson.get(list(validRecordJson.keys())[-1])
        # exePercentage = Decimal(str(lastEpochInfo['model']['epoch'] / lastEpochInfo['model']['total'])).quantize(Decimal('.00'), ROUND_HALF_UP)
        exePercentage = lastEpochInfo['model']['epoch'] / lastEpochInfo['model']['total']
        return float(exePercentage)


    def get_status(self, projectName, experimentName, pipelineName):
        """Get pipeline execution progress

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name

        Returns:
            float: pipeline execution progress
        """
        info = self.get_pipeline_info(projectName, experimentName, pipelineName)
        pipelineId, status = info['pipeline_id'], info['status']
        if status != None and int(status) == -4: ### pipeline stop incorrect
            return -1
        validRecord = self.read_value_with_cond('pipeline_output', 'valid_record', f'pipeline_id="{pipelineId}"')
        if validRecord in [None, '']: ### pipeline has not start
            return 0.0
        validRecordJson = json.loads(validRecord)
        return self.calculate_execution_percentage(validRecordJson) ### calculate pipeline percentage


    def generate_list(self, projectName, experimentName=None, returnCurrentNum=None):
        """Get all pipeline information

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            returnCurrentNum (int): num of data to get by order, None: all data by order

        Returns:
            list:
                - item (dict): all pipeline information
                    - key: (Optional) experimentName(str)、pipelineName(str)、
                    creator(str)、status(float)、updateTime(str)、favorite(bool)
        """
        ### Get pipeline_name and update_time
        pipelineDf = self.get_pipeline(projectName, experimentName=experimentName, returnCurrentNum=returnCurrentNum)
        ### get pipeline_name and update_time array
        pipelineNameArr = pipelineDf.pipeline_name.values
        pipelineUpdateTimeArr = pipelineDf.update_time.values
        ### generate data dictionary
        dataList = list()
        if returnCurrentNum:
            if experimentName:
                for i in range(len(pipelineNameArr)):
                    statusValue = self.get_status(projectName, experimentName, pipelineNameArr[i])
                    dataList.append({"name": pipelineNameArr[i], "status": statusValue})
            else:
                ### get experiment_name
                experimentNameArr = pipelineDf.experiment_name.values
                for i in range(len(pipelineNameArr)):
                    statusValue = self.get_status(projectName, experimentNameArr[i], pipelineNameArr[i])
                    dataList.append({"name": pipelineNameArr[i], "status": statusValue})

        elif experimentName:
            for i in range(len(pipelineNameArr)):
                randBool = bool(random.getrandbits(1))
                statusValue = self.get_status(projectName, experimentName, pipelineNameArr[i])
                pipelineUpdateTime = str(pipelineUpdateTimeArr[i]).replace("T", " ")
                pipelineUpdateTime = pipelineUpdateTime.split(".")[0]
                dataList.append(
                    {
                        "pipelineName": pipelineNameArr[i],
                        "creator": "someone",
                        "status": statusValue,
                        "updateTime": pipelineUpdateTime,
                        "favorite": randBool,
                    }
                )

        else:
            ### get experiment_name
            experimentNameArr = pipelineDf.experiment_name.values
            for i in range(len(pipelineNameArr)):
                randBool = bool(random.getrandbits(1))
                statusValue = self.get_status(projectName, experimentNameArr[i], pipelineNameArr[i])
                pipelineUpdateTime = str(pipelineUpdateTimeArr[i]).replace("T", " ")
                pipelineUpdateTime = pipelineUpdateTime.split(".")[0]
                dataList.append(
                    {
                        "experimentName": experimentNameArr[i],
                        "pipelineName": pipelineNameArr[i],
                        "creator": "someone",
                        "status": statusValue,
                        "updateTime": pipelineUpdateTime,
                        "favorite": randBool,
                    }
                )
        dataDict = {"list": dataList}
        return dataDict

    def add_favorite(self, pipelineName):
        """Add favorite pipeline into database

        Args:
            pipelineName (str): pipeline name

        Returns:
            tuple[0]: 0: Add favorite pipeline failed, 1: Add favorite pipeline success
            tuple[1]: log message
        """
        try:
            # self.insert_value('user_favorite_page (username, page_id, page_type, favorite_name)', \
            #                 f'(SELECT username as username FROM user WHERE username = "Otis"), "someone1", "project", "{projectName}"')
            return 1, 'Add favorite success'
        except:
            return 0, 'Add favorite failed'

    def insert_pipeline(self, pipelineId, pipelineName, experimentId):
        """Store pipeline name into database

        Args:
            pipelineId (str): pipeline id
            pipelineName (str): pipeline name
            experimentId (str): experiment id
        """
        insertSQL = f"""
        INSERT INTO
            pipeline (pipeline_id, pipeline_name, experiment_id)
        VALUES
            ("{pipelineId}", "{pipelineName}", "{experimentId}")
        """
        self.my.ExecNoQuery(insertSQL)

    def create_pipeline(self, projectName, experimentName, pipelineName):
        """Create pipeline

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name

        Returns:
            tuple[0]: 0: create pipeline failed, 1: create pipeline success
            tuple[1]: log message
        """
        ### Generate pipeline id
        pipelineId = self.generate_uid("pipeline")
        try:
            ### Get experiment id
            experimentId = self.read_value_with_cond(
                tableName="project, experiment",
                selectColumn="experiment.experiment_id",
                condition=f'project.project_id = experiment.project_id\
                            and project.project_name="{projectName}"\
                            and experiment.experiment_name="{experimentName}"',
            )
            ### Create pipeline
            self.insert_pipeline(pipelineId, pipelineName, experimentId)
            return 1, "Create pipeline success"
        except:
            return 0, "Create pipeline failed"

    def pipeline_rename(self, projectName, experimentName, pipelineName, pipelineRename):
        """Rename pipeline

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name
            pipelineRename (str): pipeline rename
        """
        try:
            self.update_value_with_cond(
                "project, experiment, pipeline",
                f'pipeline.pipeline_name="{pipelineRename}"',
                f'project.project_id = experiment.project_id\
                  and experiment.experiment_id = pipeline.experiment_id\
                  and project.project_name = "{projectName}"\
                  and experiment.experiment_name = "{experimentName}"\
                  and pipeline.pipeline_name = "{pipelineName}"',
            )
            return 1, "Rename pipeline success"
        except:
            return 0, "Rename pipeline failed"

    def get_process_num(self, gpuID):
        """get process number

        Args:
            gpuID (int or str): GPU ID

        Returns:
            int: process number
        """
        status = self.read_value_with_cond(
            "pipeline",
            "status",
            f'gpu_id = "{gpuID}"\
              and status != "{0}"\
              and status != "{-4}"'
        )
        if status == None:
            return 0
        elif type(status) == str:
            return 1
        else:
            return int(len(status))

    def update_gpu_id(self, projectName, experimentName, pipelineName, gpuID):
        """Update GPU ID

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name
            gpuID (str): GPU ID

        Returns:
            tuple[0]: 0: update GPU ID failed, 1: update GPU ID success
            tuple[1]: log message
        """
        try:
            self.update_value_with_cond(
                "project, experiment, pipeline",
                f'pipeline.gpu_id="{gpuID}", pipeline.created=0',
                f'project.project_id = experiment.project_id\
                and experiment.experiment_id = pipeline.experiment_id\
                and project.project_name = "{projectName}"\
                and experiment.experiment_name = "{experimentName}"\
                and pipeline.pipeline_name = "{pipelineName}"',
            )
            return 1, "Set GPU success"
        except:
            return 0, "Set GPU failed"


    def get_pipeline_info(self, projectName, experimentName, pipelineName):
        """Get pipeline information

        Args:
            projectName (str): project name
            experimentName (str): experiment name
            pipelineName (str): pipeline name

        Returns:
            dict: project and pipeline information (pipeline_id, gpu_id, status, abstract, created, and project_task)
        """
        info = self.read_value_with_cond("project, experiment, pipeline", "pipeline.pipeline_id, pipeline.gpu_id, \
                                        pipeline.status, pipeline.abstract, pipeline.created, project.project_task",
                                        f'project.project_id = experiment.project_id \
                                        and experiment.experiment_id = pipeline.experiment_id \
                                        and project.project_name = "{projectName}" \
                                        and experiment.experiment_name="{experimentName}" \
                                        and pipeline.pipeline_name="{pipelineName}"').to_dict('records')[0]
        info['created'] = int(info['created'])
        return info


    def get_experiment_info(self, projectName, experimentName):
        """Get experiment information

        Args:
            projectName (str): project name
            experimentName (str): experiment name

        Returns:
            dict: experiment information (experiment_id, experiment_key, and abstract)
        """
        info = self.read_value_with_cond("project, experiment", "experiment.experiment_id, \
                                        experiment.experiment_key, experiment.abstract",
                                        f"project.project_id = experiment.project_id \
                                        and project.project_name='{projectName}' \
                                        and experiment.experiment_name='{experimentName}'")
        return info.to_dict('records')[0]

    def get_project_info(self, projectName):
        """Get project information

        Args:
            projectName (str): project name

        Returns:
            dict: pipeline information (project_id, project_task, train_rate, valid_rate, test_rate, and abstract)
        """
        info = self.read_value_with_cond("project", "project_id, \
                            project_task, train_rate, valid_rate, test_rate, abstract", f"project_name='{projectName}'")

        return info.to_dict('records')[0]


    def check_pipeline_status(self, status, pipelineId):
        """Check pipeline status and return status message

        Args:
            status (str): pipeline status
            pipelineId (str): pipeline id

        Returns:
            tuple[0]: 0: status error,
            1: add status to pipeline success / the pipeline has finished /
            the pipeline has in line / the pipeline is running"/ the pipeline finished incorrect
            tuple[1]: log message
        """
        ### initial value
        code, message = 0, "status error"

        if status in [None, "", "None"]:
            ### Generate timestamp
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f") + str(time.time_ns())[11:]
            ### Update pipeline status
            self.update_value_with_cond("pipeline", f"status = {timestamp}", f"pipeline_id = '{pipelineId}'")
            code, message = 1, "Set pipeline status success"
        elif status == "0":
            code, message = 1, "The pipeline has finished"
        elif re.match(r'\d{28}$', status): ### Status value is timestamp
            code, message = 1, "The pipeline has in line"
        elif status == "-1":
            code, message = 1, "The pipeline is training"
        elif status == "-2":
            code, message = 1, "The pipeline is waiting to test"
        elif status == "-3":
            code, message = 1, "The pipeline is testing"
        elif status == "-4":
            errorMessage = self.read_value_with_cond("pipeline_output ", "error_log", f"pipeline_id = '{pipelineId}'")
            if errorMessage != None:
                code, message = 1, f"The pipeline finished incorrect, because ${errorMessage}$"
            else:
                code, message = 1, f"The pipeline finished incorrect"

        return code, message

    def update_pipeline_abstract(self, experimentId, pipelineName, pipelineAbstract):
        """Update abstract column of pipeline database

        Args:
            experimentId (str): experiment ID
            pipelineName (str): pipeline name
            pipelineAbstract (str): pipeline abstract
        """
        message = self.update_value_with_cond("pipeline", f"abstract='{pipelineAbstract}'",
                                        f"pipeline_name='{pipelineName}' AND experiment_id='{experimentId}'")
        if 'Data too long' in message:
            return 0, 'The content of the abstract is too long, the limit is 500 words'
        return 1, 'Save abstract success'
