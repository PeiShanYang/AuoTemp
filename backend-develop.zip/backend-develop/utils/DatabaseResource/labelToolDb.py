from . import BasicDb


class LabelToolDb(BasicDb):
    """Database query method of labelTool
    """
    def get_imgs_info_by_datasetId(self, datasetId):
        """Get image information in same dataset from database

        Args:
            datasetId (str): datasei ID

        Returns:
            dfSelect: dataframe including all image information
        """
        sql = f'''
        SELECT
	        image_name, image_pth, class_name
        from
            image as img
        LEFT JOIN
            label
        ON
            img.image_id = label.image_id
        LEFT JOIN
            label_class
        ON
            label.class_id = label_class.class_id
        WHERE
            img.dataset_id = "{datasetId}"
        '''
        dfSelect = self.my.DfSelect(sql)
        return dfSelect


    def get_img_info_det(self, datasetId, imageName):
        """Get image information in same dataset from database

        Args:
            datasetId (str): datasei ID

        Returns:
            dfSelect: dataframe including all image information
        """
        sql = f'''
        SELECT
	        image_pth, class_name, label_id, x1, y1, x2, y2
        from
            image as img
        LEFT JOIN
            label
        ON
            img.image_id = label.image_id
        LEFT JOIN
            label_class
        ON
            label.class_id = label_class.class_id
        WHERE
            img.dataset_id = "{datasetId}" AND image_name = "{imageName}"
        '''
        dfSelect = self.my.DfSelect(sql)
        return dfSelect


    def cls_insert_label(self, labelId, imageId, classId, memo):
        """Store image label into database

        Args:
            insertValue (tuple): (label_id: str, image_id: str, class_id: str, memo: str)
        """
        InsertSQL = f'''
        INSERT INTO
            label (label_id, image_id, class_id, memo)
        VALUES
            ("{labelId}", "{imageId}", "{classId}", "{memo}")
        '''
        self.my.ExecNoQuery(InsertSQL)


    def det_insert_label(self, labelId, imageId, classId, x1, y1, x2, y2, memo):
        """Store image detection label into database

        Args:
            insertValue (tuple): (label_id, image_id, class_id, x1, y1, x2, y2, memo)

        Returns:
            boolean: success: True, fail: False
        """
        InsertSQL = f'''
        INSERT INTO
            label (label_id, image_id, class_id, x1, y1, x2, y2, memo)
        VALUES
            ("{labelId}", "{imageId}", "{classId}", "{x1}", "{y1}", "{x2}", "{y2}", "{memo}")
        '''
        self.my.ExecNoQuery(InsertSQL)


    def det_get_label(self, imgInfo):
        labelList = []
        for i in range(len(imgInfo.index)):
            if imgInfo["class_name"][i] == None:
                return labelList
            labelList.append(
                {
                    "className": imgInfo["class_name"][i],
                    "labelId": imgInfo["label_id"][i],
                    "x1": int(imgInfo["x1"][i]),
                    "y1": int(imgInfo["y1"][i]),
                    "x2": int(imgInfo["x2"][i]),
                    "y2": int(imgInfo["y2"][i]),
                }
            )
        return labelList


    def cls_get_label(self, className):
        label = []
        if (className == None) or (className == 'NoLabel'):
                return label
        else:
            label = [{"className": className}]
        return label


    def get_url(self, imgPath, host, port):
        urlSuffix = imgPath.replace('\\', '/')
        url = f'http://{host}:{port}/image/show-img/{urlSuffix}'
        return url


    def cls_get_img_classname_list(self, datasetId, datasetName, host, port):
        """Get dataset name, file list, and class list in specific dataset name

        Args:
            datasetId (str): dataset ID
            datasetName (str): dataset name
            host (str): host ip position
            port (str): port number

        Returns:
            {"datasetName": datasetName, "fileList": imgList, "classList": classListDb}
        """
        classListDb = self.read_value_with_cond('label_class', 'class_name', f'dataset_id="{datasetId}"')
        imgListDb = self.get_imgs_info_by_datasetId(datasetId)

        imgList = []
        for i in range(len(imgListDb.index)):
            url = self.get_url(imgListDb["image_pth"][i], host, port)
            label = self.cls_get_label(imgListDb["class_name"][i])
            imgList.append({"fileName": imgListDb["image_name"][i],
                            "url": url,
                            "annotations": label})
        if isinstance(classListDb, str):
            classListDb = [classListDb]
        elif classListDb == None:
            classListDb = []
        return {"datasetName": datasetName, "fileList": imgList, "classList": classListDb}


    def det_get_img_classname_list(self, datasetId, datasetName, host, port):
        """Get dataset name, file list, and class list in specific dataset name

        Args:
            datasetId (str): dataset ID
            datasetName (str): dataset name
            host (str): host ip position
            port (str): port number

        Returns:
            {"datasetName": datasetName, "fileList": imgList, "classList": classListDb}
        """
        classListDb = self.read_value_with_cond('label_class', 'class_name', f'dataset_id="{datasetId}"')
        imgNameListDb = self.read_value_with_cond('image', 'image_name', f'dataset_id="{datasetId}"')

        imgList = []
        for imgName in imgNameListDb:
            imgInfo = self.get_img_info_det(datasetId, imgName)
            url = self.get_url(imgInfo["image_pth"][0], host, port)
            labelList = self.det_get_label(imgInfo)
            imgList.append({"fileName": imgName,
                            "url": url,
                            "annotations": labelList})
        if isinstance(classListDb, str):
            classListDb = [classListDb]
        elif classListDb == None:
            classListDb = []
        return {"datasetName": datasetName, "fileList": imgList, "classList": classListDb}


    def add_class_name(self, datasetNameDb, datasetIdDb, className):
        """Add new class name into database

        Args:
            datasetName (str): dataset name
            className (list): new class name list
        """
        classNameDb = self.read_value_with_cond('label_class', 'class_name', f'dataset_id="{datasetIdDb}"')
        if classNameDb == None:
            for name in className:
                classId = self.generate_uid("label_class")
                self.insert_value('label_class', f'("{classId}", "{name}", "{datasetIdDb}", "{datasetNameDb}")')
        else:
            for name in className:
                if name not in classNameDb:
                    classId = self.generate_uid("label_class")
                    self.insert_value('label_class', f'("{classId}", "{name}", "{datasetIdDb}", "{datasetNameDb}")')


    def delete_class_name(self, datasetIdDb, className):
        """Delete removed class name in database

        Args:
            datasetName (str): dataset name
            className (list): new class name list
        """
        classNameDb = self.read_value_with_cond('label_class', 'class_name', f'dataset_id="{datasetIdDb}"')
        if classNameDb != None:
            for name in classNameDb:
                if name not in className:
                    self.delete_value('label_class', f'class_name = "{name}" AND dataset_id="{datasetIdDb}"')


    def cls_save_label(self, datasetNameDb, imgList):
        """Save cls label into database

        Args:
            datasetNameDb (str): dataset name
            imgList (list): image information list
        """
        datasetId = self.read_value_with_cond('dataset', 'dataset_id', f'dataset_name="{datasetNameDb}"')
        for img in imgList:
            imgId = self.read_value_with_cond('image', 'image_id', f'image_name="{img["fileName"]}" AND dataset_id="{datasetId}"')
            ### front end do not return label
            if img["annotations"] == []:
                if self.check_value_exist('label', f'image_id="{imgId}"'): # delete existed label
                    self.delete_value('label', f'image_id="{imgId}"')
                else: # label do not exist originally
                    continue
            ### front end return label
            else:
                classId = self.read_value_with_cond('label_class', 'class_id', f'class_name="{img["annotations"][0]["className"]}" AND dataset_id="{datasetId}"')
                if classId == None:
                    return 0, f'The input class name ${img["annotations"][0]["className"]}$ is not existed'
                elif not self.check_value_exist('label', f'image_id="{imgId}"'): # add new label
                    labelId = self.generate_uid('label')
                    self.cls_insert_label(labelId, imgId, classId, "classification")
                else: # update existed label
                    self.update_value_with_cond('label', f'class_id="{classId}"', f'image_id="{imgId}"')
        return 1, 'Save classifiaction label success'

    def det_save_label(self, datasetNameDb, imgList):
        """Save det label into database

        Args:
            datasetNameDb (str): dataset name
            imgList (list): image information list

        Returns:
            logger message
        """
        datasetId = self.read_value_with_cond('dataset', 'dataset_id', f'dataset_name="{datasetNameDb}"')
        for img in imgList:
            imgId = self.read_value_with_cond('image', 'image_id', f'image_name="{img["fileName"]}" AND dataset_id="{datasetId}"')
            ### front end do not return label
            if img["annotations"] == []:
                if self.check_value_exist('label', f'image_id="{imgId}"'): # delete existed label of same image
                    self.delete_value('label', f'image_id="{imgId}"')
                else: # label do not exist originally
                    continue
            ### front end return label
            else:
                ### delete each one of Db label that user do not input this time
                ok, message = self.delete_det_label(img, imgId)
                if not ok: return 0, message

                for ant in img["annotations"]:
                    ok, xmin, ymin, xmax, ymax = self.double_check_ant(ant["x1"], ant["y1"], ant["x2"], ant["y2"])
                    if not ok: continue
                    classId = self.read_value_with_cond('label_class', 'class_id', f'class_name="{ant["className"]}" AND dataset_id="{datasetId}"')
                    if classId == None:
                        return 0, f'The input class name ${ant["className"]}$ of image ${img["fileName"]}$ is not existed in database'
                    if not self.check_value_exist('label', f'label_id="{ant["labelId"]}"'): # add new label
                        labelId = self.generate_uid('label')
                        self.det_insert_label(labelId, imgId, classId, xmin, ymin, xmax, ymax, "detection")
                    else: # update existed label
                        self.update_value_with_cond('label', f'class_id="{classId}", x1="{xmin}", y1="{ymin}", x2="{xmax}", y2="{ymax}"', f'label_id="{ant["labelId"]}"')
        return 1, 'Save detection label success'

    def double_check_ant(self, x1, y1, x2, y2):
        """make sure annotation is correct (x1 < x2, y1 < y2)
        Args:
            x1 (int)
            y1 (int)
            x2 (int)
            y2 (int)

        Returns:
            boolean and int: ok message and correct annotation coordinate
        """
        ok = True
        if x1 == x2 or y1 == y2:
            ok = False
        return ok, min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)
    
    def delete_det_label(self, img, imgId):
        sql = f'''
        SELECT
            label_id
        FROM
            label
        WHERE
            image_id="{imgId}"
        '''
        rows = self.my.ExecQuery(sql)
        labelIdList = []
        for row in rows["label_id"]:
            labelIdList.append(row)
        if labelIdList == None or len(labelIdList) == 0 or (len(labelIdList) == 1 and labelIdList[0] == ''):
            labelIdList = []
        for ant in img["annotations"]:
            if ant["labelId"] == '':
                continue
            elif ant["labelId"] != '' and ant["labelId"] in labelIdList:
                labelIdList.remove(ant["labelId"])
            else:
                return 0, f'LabelId {ant["labelId"]} is not existed in database'
        for remainId in labelIdList:
            self.delete_value('label', f'label_id="{remainId}"')
        return 1, 'Delete Db label that user do not input this time success'


    def get_project_id(self, projectName):
        projectId = self.read_value_with_cond('project', 'project_id', f'project_name="{projectName}"')
        if projectId == None: return 0, f'The project ID is not existed'
        return 1, projectId


    def get_dataset_name(self, projectId):
        datasetName = self.read_value_with_cond('dataset', 'dataset_name', f'project_id="{projectId}"')
        if datasetName == None: return 0, f'Dataset name is not existed'
        return 1, datasetName


    def get_dataset_id(self, projectId):
        datasetId = self.read_value_with_cond('dataset', 'dataset_id', f'project_id="{projectId}"')
        if datasetId == None: return 0, 'Dataset ID is not existed'
        if isinstance(datasetId, list): return 0, 'The project has more than one dataset'
        return 1, datasetId

if __name__ == "__main__":
    pass
