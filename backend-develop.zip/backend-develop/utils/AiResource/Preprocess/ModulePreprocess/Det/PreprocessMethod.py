from typing import List, Tuple, Dict, Optional, Union

import torch
from torch import Tensor
from torchvision.transforms import functional as F, transforms as TF, InterpolationMode

# from ....DataAugmentation.ModuleAugmentation.Det import AugmentationMethod
class Resize(TF.Resize):
    """
    inherit Resize in transforms and process the parameters
    """
    def __init__(self, interpolation, **kwarg):
        super().__init__(**kwarg)
        self.interpolation = getattr(InterpolationMode, interpolation)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        ogWidth, ogHeight = image.size
        image = F.resize(image, self.size, self.interpolation)
        if target.get('boxes') is not None:
            scalerX = self.size[0] / ogWidth
            scalerY = self.size[1] / ogHeight
            target["boxes"][:, [0, 2]] *= scalerX
            target["boxes"][:, [1, 3]] *= scalerY
        return image, target

class GaussianBlur(TF.GaussianBlur):
    """
    inherit GaussianBlur in transforms and process the parameters
    """
    def __init__(self, kernelSize, **kwarg):
        super().__init__(kernel_size=kernelSize, **kwarg)
    
    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        image = F.gaussian_blur(image, self.kernel_size, self.sigma)
        return image, target

class Brightness(TF.ColorJitter):
    """
    inherit Brightness in transforms and process the parameters
    """
    def __init__(self, brightness, **kwarg):
        super().__init__(brightness=[brightness, brightness], **kwarg)
    
    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        image = F.adjust_brightness(image, self.brightness[0])
        return image, target

class Contrast(TF.ColorJitter):
    """
    inherit Contrast in transforms and process the parameters
    """
    def __init__(self, contrast, **kwarg):
        super().__init__(contrast=[contrast, contrast], **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        image = F.adjust_contrast(image, self.contrast[0])
        return image, target

class Saturation(TF.ColorJitter):
    """
    inherit Saturation in transforms and process the parameters
    """
    def __init__(self, saturation, **kwarg):
        super().__init__(saturation=[saturation, saturation], **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        image = F.adjust_saturation(image, self.saturation[0])
        return image, target

class Hue(TF.ColorJitter):
    """
    inherit Hue in transforms and process the parameters
    """
    def __init__(self, hue, **kwarg):
        super().__init__(hue=[hue, hue], **kwarg)

    def forward(
        self, image: Tensor, target: Optional[Dict[str, Tensor]] = None
    ) -> Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        image = F.adjust_hue(image, self.hue[0])
        return image, target