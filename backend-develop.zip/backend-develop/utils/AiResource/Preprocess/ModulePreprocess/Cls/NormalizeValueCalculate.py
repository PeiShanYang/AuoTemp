# -*- coding: utf-8 -*-

"""
Created on Wed Jan 12 14:00:00 2022
@author: OtisChang
"""
import os

import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms


class ImageDataset(Dataset):
    """
    Custom Dataset of ImageDataset, which is used for train, valid and test
    """
    def __init__(self, rootDir, transform=None):
        self.rootDir = os.path.abspath(rootDir)
        self.x = []
        self.transform = transform
        self.className = os.listdir(self.rootDir)
        for _dir in self.className:
            fileList = os.listdir(os.path.join(self.rootDir, _dir))
            for file in fileList:
                try:
                    Image.open(os.path.join(self.rootDir, _dir, file))
                    self.x.append(os.path.join(self.rootDir, _dir, file))
                except:
                    continue

    def __len__(self):
        return len(self.x)

    def __getitem__(self, index):
        image = Image.open(self.x[index]).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image, 0


def calculate_std_mean(
    dataPath:str,
    resizePara: dict
) -> list:
    """
    calculate std and mean value of train data set
    
    Args:
        resizePara: {"name": 'Resize', "switch": bool, "parameters": {"imageSize": list, "interpolation": str}}
    Return:
        mean, std 
    """
    imgSize = resizePara["parameters"]["size"]
    if resizePara["switch"]:
        transform = transforms.Compose([transforms.Resize((imgSize[0], imgSize[1])), transforms.ToTensor()])
    else:
        transform = transforms.ToTensor()
    trainDataset = ImageDataset(dataPath, transform=transform)
    dataloader = DataLoader(dataset=trainDataset, batch_size=1, shuffle=False)
    channelsSum, channelsSquaredSum, numBatches = 0, 0, 0
    for data, _ in dataloader:
        # Mean over batch, height and width, but not over the channels
        channelsSum += torch.mean(data, dim=[0, 2, 3])
        channelsSquaredSum += torch.mean(data ** 2, dim=[0, 2, 3])
        numBatches += 1

    mean = channelsSum / numBatches
    std = (channelsSquaredSum / numBatches - mean ** 2) ** 0.5
    print(mean, std)
    return mean.tolist(), std.tolist()
