import torchvision.transforms as TF
from PIL import Image
from torchvision.transforms import InterpolationMode


class Resize(TF.Resize):
    """
    inherit Resize in transforms and process the parameters
    """
    def __init__(self, interpolation, **kwarg):
        super().__init__(**kwarg)
        self.interpolation = getattr(InterpolationMode, interpolation)

class CenterCrop(TF.CenterCrop):
    """
    inherit CenterCrop in transforms and process the parameters
    """
    def __init__(self, **kwarg):
        super().__init__(**kwarg)

class Pad(TF.Pad):
    """
    inherit Pad in transforms and process the parameters
    """
    def __init__(self, fill, paddingMode, **kwarg):
        super().__init__(fill=tuple(fill), padding_mode=paddingMode, **kwarg)

class GaussianBlur(TF.GaussianBlur):
    """
    inherit GaussianBlur in transforms and process the parameters
    """
    def __init__(self, kernelSize, **kwarg):
        super().__init__(kernel_size=kernelSize, **kwarg)

class Brightness(TF.ColorJitter):
    """
    inherit Brightness in transforms and process the parameters
    """
    def __init__(self, brightness, **kwarg):
        super().__init__(brightness=[brightness, brightness], **kwarg)

class Contrast(TF.ColorJitter):
    """
    inherit Contrast in transforms and process the parameters
    """
    def __init__(self, contrast, **kwarg):
        super().__init__(contrast=[contrast, contrast], **kwarg)

class Saturation(TF.ColorJitter):
    """
    inherit Saturation in transforms and process the parameters
    """
    def __init__(self, saturation, **kwarg):
        super().__init__(saturation=[saturation, saturation], **kwarg)

class Hue(TF.ColorJitter):
    """
    inherit Hue in transforms and process the parameters
    """
    def __init__(self, hue, **kwarg):
        super().__init__(hue=[hue, hue], **kwarg)