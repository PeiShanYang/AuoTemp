import collections

import torch

from ...DataAugmentation.ModuleAugmentation.Det import AugmentationMethod
from ...Preprocess.ModulePreprocess.Det import PreprocessMethod
from .ConfigAugmentation import AugmentationPara
from .ConfigPreprocess import PreprocessPara


def det_set_preprocess_transform(prePara: dict) -> list:
    """
    set preprocess transform: according to preprocessPara, setting transform module.
    
    Args:
        preprocessPara: a dict that include selected preprocess setting
    Return:
        preTransformList: preprocess transform list
    """
    preTransformList = []
    for method, config in prePara.items():
        transformsMethod = getattr(PreprocessMethod, method)(**config["parameters"])
        if method == "Resize":
            preTransformList.insert(0, transformsMethod)
        else:
            preTransformList.append(transformsMethod)
    return preTransformList

def det_set_augmentation_transform(
    augPara: dict,
    augTransformList: list,
) -> list:
    """
    set augmentation transform: according to augPara, setting augmentation module.
    Args:
        augPara: a list that include all augmentation setting
        augTransformList: transform list that wants to keep append
    Return:
        dataTransforms: augmentation transform
    """
    passMethod = {'RandomErasing': 0, 'RandomHorizontalFlip': 0, 'RandomVerticalFlip': 0, 'RandomIoUCrop': 0
        , 'ScaleJitter': 0, 'FixedSizeCrop': 0, 'RandomShortestSize': 0}
    annoTransformList = []
    augTransformList.append(AugmentationMethod.PILToTensor())
    for method, config in augPara.items():
        if passMethod.get(method)==None:
            transformsMethod = getattr(AugmentationMethod, method)(**config["parameters"])
            augTransformList.append(transformsMethod)
        elif method != 'RandomErasing':
            transformsAnnoMethod = getattr(AugmentationMethod, method)(**config["parameters"])
            annoTransformList.append(transformsAnnoMethod)
    
    if 'RandomErasing' in augPara:
        augTransformList.append(getattr(AugmentationMethod, 'RandomErasing')(**augPara["RandomErasing"]["parameters"]))
    augTransformList.extend(annoTransformList)
    augTransformList.append(AugmentationMethod.ConvertImageDtype(torch.float))

    return augTransformList

def det_sort_dict_by_value(sortDict: dict) -> dict:
    """
    Sort Dict according to value["order"], the order should be non-negative integer
    1. value["order"] is 0, meaning not used.
    2. value["order"] most be greater than 0
    3. value["order"] most be integer
    4. value["order"] can not be repeated

    Args:
        sortDict (dict): {key: {"order": num}, ...}
    
    return:
        resultDict (dict): sorted dict
    """
    resultDict = collections.OrderedDict()
    _recordOrder = []
    for key, value in sortDict.items():
        # 1. unused
        if value["order"] == 0:
            continue

        # 2&3. check if value["order"] is non-negative integer
        if value["order"] < 0 or not isinstance(value["order"], int):
            raise ValueError(f'The order of "{key}" in main/ConfigDet.json should be a non-negative integer.')
        
        # 4. check value["order"] is not repeated
        if value["order"] not in _recordOrder:
            _recordOrder.append(value["order"])
        else:
            raise ValueError(f'The order of "{[k for k, v in sortDict.items() if v["order"] == value["order"]]}" in main/ConfigDet.json is the same as other operation.')
        
        # keep used dict
        resultDict[key] = value
    
    resultDict = dict(sorted(resultDict.items(), key=lambda item: item[1]["order"]))

    # resize setting
    if sortDict.get('Resize') != None and sortDict['Resize']['order'] == 0:
        resultDict["Resize"] = {"order": len(resultDict)+1, "parameters": {"size": [512, 512], "interpolation": "BILINEAR"}}

    return resultDict

def get_train_transform(prePara: PreprocessPara, augPara: AugmentationPara):
    """
    Set train transform: according to preprocessPara and augPara, setting transform module.
    
    Args:
        prePara: including all preprocess setting
        augPara: including all augmentation setting
    Return:
        dataTransforms: train transform
    """
    preDict = det_sort_dict_by_value(prePara)
    transformList = det_set_preprocess_transform(preDict)
    augDict = det_sort_dict_by_value(augPara)
    transformList = det_set_augmentation_transform(augDict, transformList)
    dataTransforms = AugmentationMethod.Compose(transformList)
    return dataTransforms

def get_eval_transform(prePara: PreprocessPara):
    """
    Set test or inference transform: according to preprocessPara, setting transform module.

    Args:
        prePara: including all preprocess setting
    Return:
        dataTransforms: valid or test or inference transform
    """
    preDict = det_sort_dict_by_value(prePara)
    transformList = det_set_preprocess_transform(preDict)
    transformList.append(AugmentationMethod.PILToTensor())
    transformList.append(AugmentationMethod.ConvertImageDtype(torch.float))
    dataTransforms = AugmentationMethod.Compose(transformList)
    return dataTransforms
