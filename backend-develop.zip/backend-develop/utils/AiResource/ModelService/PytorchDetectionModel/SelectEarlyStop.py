from .ConfigModelService import EarlyStopPara

def det_select_earlystop(earlyStopPara:EarlyStopPara, precision:float, recall:float, 
                         bestPrecision:float, bestRecall:float, counter:int):
    """
    According to configs in ConfigModelService, select monitor evaluation to stop training.

    Args:
        earlystopPara: point out the monitor evaluation and its correspond setting
        Precision: monitor the map and stop training when it reaches a certain level 
        Recall: monitor the mar and stop training when it reaches a certain level
        bestPrecision: best evaluation score till now
        bestRecall: best evaluation score till now
        counter: count the number of times exceeded currently
    Return:
        The boolean value of stopping training
    """
    patience = 0
    earlyStop = False
    # Monitoring both map and mar
    if earlyStopPara.precisionAndRecall['switch']:
        patience = earlyStopPara.precisionAndRecall['patience']
        if precision <= bestPrecision and recall <= bestRecall:
            counter += 1
            if counter >= patience:
                earlyStop = True
        elif precision <= bestPrecision or recall <= bestRecall:
            pass
        else:
            counter = 0

    # Monitoring only precision
    elif earlyStopPara.precision['switch']:
        patience = earlyStopPara.precision['patience']
        if precision <= bestPrecision:
            counter += 1
            if counter >= patience:
                earlyStop = True
        else:
            counter = 0

    # Monitoring only mar
    elif earlyStopPara.recall['switch']:
        patience = earlyStopPara.recall['patience']
        if recall <= bestRecall:
            counter += 1
            if counter >= patience:
                earlyStop = True
        else:
            counter = 0

    # Updating both map and mar
    # if map > bestMap:
    #     bestMap = bestMap
    # if mar > bestMar:
    #     bestMar = bestMar

    return earlyStop, bestPrecision, bestRecall, counter, patience