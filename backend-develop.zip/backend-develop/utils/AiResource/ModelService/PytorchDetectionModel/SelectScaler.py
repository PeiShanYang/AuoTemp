import torch
from .ConfigModelService import ScalerPara

def select_scaler(scalerPara: ScalerPara):
   """
   Selecting scaler method

   Args:
      scalerPara (ScalerPara): Parameters include all scaler

   Returns:
      scaler
   """
   if scalerPara.amp['switch']:
      scaler = torch.cuda.amp.GradScaler() 
   else:
      scaler = None

   return scaler