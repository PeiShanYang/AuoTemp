from torch import tensor
from .ConfigPostprocess import PostprcessPara
from .package.engine import apply_nms

def select_postprecss(
    postprcessPara: PostprcessPara,
    prediction: tensor,
)-> tensor:
    """
    Selecting post precess method

    Args:
        postprcessPara (PostprcessPara): Parameters include all postprocee methods
        prediction             (tensor): after model predict result 

    Returns:
        prediction (tensor)
    """
    if postprcessPara.nms["switch"]:
        prediction = apply_nms(prediction, postprcessPara.nms["iouTreshold"])
        

    return prediction