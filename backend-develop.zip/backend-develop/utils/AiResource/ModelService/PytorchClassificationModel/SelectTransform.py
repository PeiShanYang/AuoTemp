# -*- coding: utf-8 -*-
"""
Created on Wed Jan 12 14:00:00 2022
@author: OtisChang
"""
import collections

from torchvision import transforms

from ...DataAugmentation.ModuleAugmentation.Cls import AugmentationMethod
from ...Preprocess.ModulePreprocess.Cls import PreprocessMethod
from .ConfigAugmentation import AugmentationPara
from .ConfigPreprocess import PreprocessPara


def cls_set_preprocess_transform(prePara: dict) -> list:
    """
    set preprocess transform: according to preprocessPara, setting transform module.
    
    Args:
        preprocessPara: a dict that include selected preprocess setting
    Return:
        preTransformList: preprocess transform list
    """
    preTransformList = []
    for method, config in prePara.items():
        if method != "Normalize":
            ### resize must do first
            if method == "Resize":
                transformsMethod = getattr(PreprocessMethod, method)(**config["parameters"])
                preTransformList.insert(0, transformsMethod)
            else:
                transformsMethod = getattr(PreprocessMethod, method)(**config["parameters"])
                preTransformList.append(transformsMethod)

    return preTransformList

def cls_set_augmentation_transform(
    augPara: dict,
    augTransformList: list,
    normalizeSwitch: int,
    normalizedValue: dict=None
) -> list:
    """
    set augmentation transform: according to augPara, setting augmentation module.
    Args:
        augPara: a list that include all augmentation setting
        augTransformList: transform list that wants to keep append
        normalizeSwitch: do normalized operation or not
        normalizedValue: {"mean": list, "std": list}
    Return:
        dataTransforms: augmentation transform
    """
    for method, config in augPara.items():
        if method != 'RandomErasing':
            transformsMethod = getattr(AugmentationMethod, method)(**config["parameters"])
            augTransformList.append(transformsMethod)
    augTransformList.append(transforms.ToTensor())
    
    if normalizeSwitch:
        augTransformList.append(transforms.Normalize(normalizedValue["mean"], normalizedValue["std"]))
    
    if 'RandomErasing' in augPara:
        transformsMethod = getattr(AugmentationMethod, 'RandomErasing')(**augPara["RandomErasing"]["parameters"])
        augTransformList.append(transformsMethod)
    return augTransformList



def cls_select_train_transform(
    prePara: PreprocessPara,
    augPara: AugmentationPara,
    normalizedValue: dict
) -> transforms.Compose:
    """
    Set train transform: according to preprocessPara and augPara, setting transform module.
    
    Args:
        prePara: including all preprocess setting
        augPara: including all augmentation setting
        normalizedValue: {"mean": list, "std": list}
    Return:
        dataTransforms: train transform
    """
    preDict = cls_sort_dict_by_value(prePara)
    transformList = cls_set_preprocess_transform(preDict)
    augDict = cls_sort_dict_by_value(augPara)
    transformList = cls_set_augmentation_transform(augDict, transformList, 
                                               prePara["Normalize"], normalizedValue)
    dataTransforms = transforms.Compose(transformList)

    return dataTransforms


def cls_select_valid_transform(
    prePara: PreprocessPara,
    normalizedValue: dict
) -> transforms.Compose:
    """
    Set validation transform: according to preprocessPara, setting transform module.
    
    Args:
        prePara: including all preprocess setting
        normalizedValue: {"mean": list, "std": list}
    Return:
        dataTransforms: validation transform
    """
    preprocessDict = cls_sort_dict_by_value(prePara)
    transformList = cls_set_preprocess_transform(preprocessDict)
    transformList.append(transforms.ToTensor())
    if prePara["Normalize"]["order"] > 0 and isinstance(prePara["Normalize"]["order"], int):
        transformList.append(transforms.Normalize(normalizedValue["mean"], normalizedValue["std"]))   

    dataTransforms = transforms.Compose(transformList)
    return dataTransforms


def cls_select_transform(
    prePara: PreprocessPara,
    normalizedValue: dict
) -> transforms.Compose:
    """
    Set test or inference transform: according to preprocessPara, setting transform module.

    Args:
        prePara: including all preprocess setting
        normalizedValue: {"mean": list, "std": list}
    Return:
        dataTransforms: test or inference transform
    """
    preprocessDict = cls_sort_dict_by_value(prePara)
    transformList = cls_set_preprocess_transform(preprocessDict)
    transformList.append(transforms.ToTensor())
    if prePara["Normalize"]["order"] > 0 and isinstance(prePara["Normalize"]["order"], int):
        transformList.append(transforms.Normalize(normalizedValue["mean"], normalizedValue["std"]))

    dataTransforms = transforms.Compose(transformList)
    return dataTransforms


def cls_sort_dict_by_value(sortDict: dict) -> dict:
    """
    Sort Dict according to value["order"], the order should be non-negative integer
    1. value["order"] is 0, meaning not used.
    2. value["order"] most be greater than 0
    3. value["order"] most be integer
    4. value["order"] can not be repeated

    Args:
        sortDict (dict): {key: {"order": num}, ...}
    
    return:
        resultDict (dict): sorted dict
    """
    resultDict = collections.OrderedDict()
    _recordOrder = []
    for key, value in sortDict.items():
        # 1. unused
        if value["order"] == 0:
            continue
        
        # 2&3. check if value["order"] is non-negative integer
        if value["order"] < 0 or not isinstance(value["order"], int):
            raise ValueError(f'The order of "{key}" in main/ConfigCls.json should be a non-negative integer.')
        
        # 4. check value["order"] is not repeated
        if value["order"] not in _recordOrder:
            _recordOrder.append(value["order"])
        else:
            raise ValueError(f'The order of "{[k for k, v in sortDict.items() if v["order"] == value["order"]]}" in main/ConfigCls.json is the same as other operation.')
        
        # keep used dict
        resultDict[key] = value
    
    resultDict = dict(sorted(resultDict.items(), key=lambda item: item[1]["order"]))

    if sortDict.get('Resize') != None and sortDict['Resize']['order'] == 0:
        resultDict["Resize"] = {"order": len(resultDict)+1, "parameters": {"size": [224, 224], "interpolation": "BILINEAR"}}

    return resultDict
