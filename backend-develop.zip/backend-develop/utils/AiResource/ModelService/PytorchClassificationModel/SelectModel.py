import math
import os
from distutils.version import LooseVersion

import torch
import torch.nn as nn
from utils.AiResource import AiModel

from .ConfigPytorchModel import ModelPara

def optimizer_to(optim, device):
    # move optimizer to device
    for param in optim.state.values():
        # Not sure there are any global tensors in the state dict
        if isinstance(param, torch.Tensor):
            param.data = param.data.to(device)
            if param._grad is not None:
                param._grad.data = param._grad.data.to(device)
        elif isinstance(param, dict):
            for subparam in param.values():
                if isinstance(subparam, torch.Tensor):
                    subparam.data = subparam.data.to(device)
                    if subparam._grad is not None:
                        subparam._grad.data = subparam._grad.data.to(device)
    return optim

def cls_resume(
    task: str,
    model: nn.Module,
    weightPath: str,
    optimizer: torch.functional,
    scheduler: torch.functional,
    device: torch.device,
) -> nn.Module:
    """
    Resume interrupted training from epoch, optimizer, and scheduler.

    Args:
        model (nn.Module): pytorch model structure
        weightPath (str): weighted directory path for train or weighted file path for other task
        optimizer: the entire optimizer
        scheduler: scheduler use for adjusting learning rate
    Return:
        last training epoch, pytorch model, optimizer and scheduler with weight (nn.Module).
    """
    if task == 'Resume':
        ### check if checkpoint Weight exists
        if not os.path.isfile(os.path.join(weightPath,'Checkpoint.pth')):
            raise ValueError('No Checkpoint weight is existed!')

        checkpoint = torch.load(os.path.join(weightPath,'Checkpoint.pth'),
        map_location=lambda storage, loc: storage.cuda(torch.cuda._utils._get_device_index(device, True)) if torch.cuda.is_available() else storage)
        model.load_state_dict(checkpoint['model'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        optimizer = optimizer_to(optimizer, device)
        scheduler.load_state_dict(checkpoint['scheduler'])
        startEpoch = checkpoint['epoch'] + 1
        bestAcc = checkpoint['bestEval1']
        bestLoss = checkpoint['bestEval2']
        counter = checkpoint['counter']
        return model, startEpoch, bestAcc, bestLoss, counter, optimizer, scheduler
    else:
        startEpoch = 0
        bestAcc = 0.0
        bestLoss = 1000.0
        counter = 0
        return model, startEpoch, bestAcc, bestLoss, counter, optimizer, scheduler

def cls_load_model_state(
    modelPara: ModelPara,
    weightPath: str,
    task: str,
    model: nn.Module=None
) -> nn.Module:
    """
    Resuming the training process start with  

    Args:
        selectedModel (SelectedModelPara): {"structure": modelName: str, "pretrained": bool}
        weightPath (str): weighted directory path for train or weighted file path for other task
        task (str): Train、Resume、Retrain、Test、Inference、Deployment
        model (nn.Module): pytorch model structure
    Return:
        pytorch model with weight (nn.Module).
    """
    if task == 'Train' or task == 'Retrain':

        if modelPara["structure"].startswith('densenet') or modelPara["structure"].startswith('resnet') or modelPara["structure"].startswith('shufflenet') or modelPara["structure"].startswith('vgg'):
            pretrainWeight = torch.load(os.path.join(weightPath))
            modelDict = model.state_dict()

            for k1, v1 in pretrainWeight.items():
                
                if  'denseblock' in k1:
                    param = k1.split(".")
                    k1 = ".".join(param[:-3] + [param[-3]+param[-2]] + [param[-1]])

                if 'classifier' not in k1 and 'fc' not in k1:
                    modelDict[k1] = v1

            model.load_state_dict(modelDict)

        else:
            pretrainWeight = torch.load(os.path.join(weightPath))
            modelDict = model.state_dict()

            for (k1,v1),(k2,v2) in zip(pretrainWeight.items(), modelDict.items()):

                if (k1==k2) and (v1.shape==v2.shape):
                    modelDict[k1]=v1

            model.load_state_dict(modelDict)
    
    elif task == 'Test' or task == 'Inference' or task == 'Deployment':

        model.load_state_dict(torch.load(os.path.join(weightPath)))
        
    return model


def cls_check_input_size(
    imgSize: list,
    modelName: str,
    structureList: list,
    checkSize: int
) -> None:
    """
    check if the model use AdaptiveAvgPool2d layer with the specific input imgSize

    Args:
        imgSize: input image size
        modelName: name of model
        structureList: 2D list which record each layer structure [kernel, stride, padding] before AdaptiveAvgPool2d.
        checkSize: the input size of layer after AdaptiveAvgPool2d
    """
    width, height = imgSize[0], imgSize[1]
    for layer in structureList:
        width = math.ceil((width + 2 * layer[2] - layer[0] + 1) / layer[1])
        height = math.ceil((height + 2 * layer[2] - layer[0] + 1) / layer[1])
    if (width % checkSize != 0) or (height % checkSize != 0):
        raise ValueError(f'Please set resize["switch"]: True and resize["imageSize"]: [224, 224] in config/ConfigPreprocess to make sure that {modelName} model can be packed correctly.')


def cls_select_model(
    task: str,
    modelPara: ModelPara,
    weightPath: str,
    numClasses: int,
    imgSize: list=[224, 224]
    ) -> nn.Module:
    """
    Selecting model and loading the pretrained weight.
    
    Args:
        task: "Train" / "Test" / "Inference" / "Retrain"
        modelPara: {"structure": modelName: str, "pretrained": bool}
        weightPath: weighted directory path for train or weighted file path for other task
        imgSize: input image size
    Return:
        model
    """

    # check if the vgg, alexnet model can be pack into Onnx
    if modelPara["structure"].startswith('vgg'):
        structureList = [[3, 1, 1], [3, 1, 1], [2, 2, 0],
                        [3, 1, 1], [3, 1, 1], [2, 2, 0], 
                        [3, 1, 1], [3, 1, 1], [3, 1, 1],
                        [2, 2, 0], [3, 1, 1], [3, 1, 1],
                        [3, 1, 1], [2, 2, 0], [3, 1, 1],
                        [3, 1, 1], [3, 1, 1], [2, 2, 0]]
        cls_check_input_size(imgSize, modelPara["structure"], structureList, 7)
    
    elif modelPara["structure"].startswith('alexnet'):
        structureList = [[11, 4, 2], [3, 2, 0], [5, 1, 2], [3, 2, 0],
                        [3, 1, 1], [3, 1, 1], [3, 1, 1], [3, 2, 0]]
        cls_check_input_size(imgSize, modelPara["structure"], structureList, 6)

    if modelPara["structure"].startswith('efficientnet') and LooseVersion(torch.__version__) < LooseVersion('1.10.0'):
        raise BaseException(f'efficientnet needs torch version >= 1.10.0. But the torch version is {torch.__version__}.')

    elif modelPara["structure"] == 'CustomModel':
        model = None
        return model
    
    method = getattr(AiModel, modelPara["structure"])
    model = method(pretrained=modelPara["pretrained"], num_classes=numClasses)
    model = cls_load_model_weight(task, modelPara, weightPath, model)
    return model


def cls_load_model_weight(
    task: str,
    modelPara: ModelPara,
    weightPath: str,
    model: nn.Module=None
) -> nn.Module:
    """
    According to different task (Train / Test / Inference / Retrain), load the model weight

    Args:
        task: "Train" / "Test" / "Inference" / "Resume" / "Retrain"
        modelPara: {"structure": modelName: str, "pretrained": bool}
        model: pytorch model structure
        weightPath: weighted directory path for train or weighted file path for other task
    Return:
        pytorch model with weight.
    """
    if task == 'Train' or task == 'Resume':
        pretrainedWeight = os.path.join(weightPath, modelPara["structure"]+'.pth')
        if modelPara["structure"] == 'CustomModel':
            raise ValueError(f'CustomModel can only used for "Retrain" task')       
        
        if not modelPara["pretrained"] or task == 'Resume':
            pass
        else:
            ### check if pretrianed Weight exists
            if not os.path.isfile(pretrainedWeight):
                raise ValueError(f'No pre-trained weight is available for model type {modelPara["structure"]}')
            ### check model structure is densenet or not and load weight
            else:
                model = cls_load_model_state(modelPara, pretrainedWeight, task, model)

    elif task == 'Retrain':
        if modelPara["structure"] == 'CustomModel':
            model = torch.jit.load(weightPath)
        else:
            try:
                model = cls_load_model_state(modelPara, weightPath, task, model)
            except:
                raise ValueError(f'If the retrained model is script pth file,'
                                  'please set ConfigPytorchModel["modelPara"]["model"]["structure"] as "CustomModel" in main/Config.json.')

    elif task == 'Deployment':
        model = cls_load_model_state(modelPara, weightPath, task, model)
        
    elif task == 'Test' or 'Inference':
        if modelPara["structure"] == 'CustomModel':
            model = torch.jit.load(weightPath)
        else:
            model = cls_load_model_state(modelPara, weightPath, task, model)    
    return model