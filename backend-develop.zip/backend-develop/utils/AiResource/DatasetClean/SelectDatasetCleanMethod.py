from utils.AiResource.DatasetClean.ConfigDataClean import DataCleanPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPytorchModel import PathPara
from utils.AiResource.DatasetClean.ModuleDatasetClean import DataSplit
from utils.AiResource.DatasetClean.ModuleDatasetClean.AnnotationTransfer import AnnotationTransfer


def det_select_dataset_clean(
    dataCleanPara: DataCleanPara,
    pathPara:PathPara,
):
    """select dataset clean for detection

    Args:
        dataCleanPara (DataCleanPara): 
            dataClean["dataState"] (dict): {
                "switch"        (int) :  0: disable, 1: enable
                "inputPath"     (str) :  input path, if taskType is 1, the subfolder most be Image and Annotation
                "outputPath"    (str) :  output path, the result is that the dataset split into Train, Test, Valid folders
                "dataSplit"     (list):  [trainPer(float), validPer(float), testPer(float)] data percentage of train, valid and test, the list sum must be 1.0
                "classNameDict" (dict):  {classNumber(str): className(str), ....} the class name corresponding to the number
            }
        pathPara (PathPara): 
            trainPath     (str): (str) Train data path
            validPath     (str): (str) Validation data path
            testPath      (str): (str) Test data path
            inferencePath (str): Inference data path
    """
    if dataCleanPara.dataState["switch"]:
        DataSplit.SplitMethodsSelection(taskType=1,
            **dataCleanPara.dataState,
            trainPath=pathPara.trainPath,
            validPath=pathPara.validPath,
            testPath=pathPara.testPath)
    else:
        print(" - Switch do not open, Split operation do not activate.")

def cls_select_dataset_clean(
    dataCleanPara: DataCleanPara,
    pathPara:PathPara,
):
    """select dataset clean for classification

    Args:
        dataCleanPara (DataCleanPara): 
            dataClean["dataState"] (dict): {
                "switch"        (int) :  0: disable, 1: enable
                "inputPath"     (str) :  input path, if taskType is 1, the subfolder most be Image and Annotation
                "outputPath"    (str) :  output path, the result is that the dataset split into Train, Test, Valid folders
                "dataSplit"     (list):  [trainPer(float), validPer(float), testPer(float)] data percentage of train, valid and test, the list sum must be 1.0
                "classNameDict" (dict):  {classNumber(str): className(str), ....} the class name corresponding to the number
            }
        
        pathPara (PathPara): 
            trainPath     (str): (str) Train data path
            validPath     (str): (str) Validation data path
            testPath      (str): (str) Test data path
            inferencePath (str): Inference data path
    """
    if dataCleanPara.dataState["switch"]:
        DataSplit.SplitMethodsSelection(taskType=0,
            **dataCleanPara.dataState,
            trainPath=pathPara.trainPath,
            validPath=pathPara.validPath,
            testPath=pathPara.testPath)
    else:
        print(" - Switch do not open, Split operation do not activate.")

def select_annotation_transfer(
    dataCleanPara: DataCleanPara
):
    """select annotation transfer 
    Args:
        dataCleanPara (DataCleanPara): 
            dataClean["onlyLabelTransfer"] (dict): {
                "switch"         (int) :  0: disable, 1: enable
                "inputLabelPath" (str) :  Annotation data input path
                "outputPath"     (str) :  Annotation converted output path
                "classNameDict"  (dict):  {classNumber(str): className(str), ....} the class name corresponding to the number
                "inputImagePath" (str) :  input image path, defaults to None.
                "transferType"   (str) :  "bbox_xml", "yolo_txt" or "bbox_txt" the format you want to convert to 
            }
    """
    if dataCleanPara.onlyLabelTransfer["switch"]:
        AnnotationTransfer(**dataCleanPara.onlyLabelTransfer)
    else:
        print(" - switch do not open, the annotation transfer operation do not activate.")