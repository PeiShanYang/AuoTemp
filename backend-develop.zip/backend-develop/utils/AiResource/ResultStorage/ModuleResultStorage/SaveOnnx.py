import os

import torch
import torch.functional
import torch.nn as nn

def cls_pack_onnx(
    model:nn.Module,
    batchSize:int,
    packageName:str,
    storagedPath:str,
    inputSize:list,
    inputChannel:int=3
) -> None:
    """
    Pack pytorch model into onnx model under the cuda state and save onnx file.

    Args:
        model: whole pytorch model including structure and weighted parameter
        packageName: saved onnx model name
        storagedPath: the path to save weight file
        inputSize: image size that input to model
        inputChannel: number of image channel
    Return:
        .onnx file: onnx model file
    """
    cudaDevice = torch.device('cpu')
    model = model.to(cudaDevice)
    model.eval()
    batch = batchSize
    width = inputSize[0]
    height = inputSize[1]
    inputShape = (batch, inputChannel, width, height)
    dummyInput = torch.randn(*inputShape).to(cudaDevice)
    model(dummyInput)
    packagePath = os.path.join(storagedPath, f'{packageName}.onnx')
    inputNames = ["input"]
    outputNames = ["output"]

    torch.onnx.export(
        model,                    # 要打包的模型
        dummyInput,               # 模型輸入大小
        packagePath,              # 輸出的打包檔名稱
        input_names=inputNames,   # 輸入層的名稱，驗證時要對應相同的input_names
        output_names=outputNames, # 輸出層的名稱
        export_params=True,       # 連參數權重一併打包輸出
        opset_version=14,
        do_constant_folding=True,
        dynamic_axes={"input" :{0: "batch"}}
    )

def det_pack_onnx(
    model:nn.Module,
    packageName:str,
    storagedPath:str,
    inputSize:list,
    batchSize:int,
    inputChannel:int=3
) -> None:
    """
    Pack pytorch model into onnx model under the cuda state and save onnx file.

    Args:
        model: whole pytorch model including structure and weighted parameter
        cudaDevice: cuda deveice that used for training
        packageName: saved onnx model name
        storagedPath: the path to save weight file
        inputSize: image size that input to model
        inputChannel: number of image channel
    Return:
        .onnx file: onnx model file
    """
    # if isinstance(cudaDevice, torch.device):
    #     cudaDevice = cudaDevice
    # else:
    #     cudaDevice = torch.device('cuda:{}'.format(cudaDevice) if torch.cuda.is_available() else 'cpu')
    cudaDevice = torch.device('cpu')
    model = model.to(cudaDevice)
    model.eval()
    batch = batchSize
    width = inputSize[0]
    height = inputSize[1]
    inputShape = (batch, inputChannel, width, height)
    dummyInput = torch.randn(*inputShape).to(cudaDevice)
    model(dummyInput)
    packagePath = os.path.join(storagedPath, f'{packageName}.onnx')
    inputNames = ["input"]
    outputNames = ["boxes", "scores", "labels"]
    # outputNames = ["output"]

    torch.onnx.export(
        model,                    # 要打包的模型
        dummyInput,               # 模型輸入大小
        packagePath,              # 輸出的打包檔名稱
        input_names=inputNames,   # 輸入層的名稱，驗證時要對應相同的input_names
        output_names=outputNames, # 輸出層的名稱
        export_params=True,       # 連參數權重一併打包輸出
        opset_version=14,
        do_constant_folding=True,
        dynamic_axes={"input" :{0: "batch", 2: "height", 3: "width"}}#,
                    #   "boxes" :{0: "batch", 1: "detectNum"},
                    #   "scores":{0: "batch"},
                    #   "labels":{0: "batch"}}
        # dynamic_axes={"input": [0, 2, 3],
        #               "boxes": [0, 1],
        #               "scores": [0],
        #               "labels": [0]}
    )