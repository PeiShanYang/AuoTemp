from numpy import ndarray
import os

def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath: the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)    

def write_mAP_txt(outputPath:str, task:str, cocoEval:ndarray, epochRecord:str=None):
    """
    Args:
        outputPath (str): output path
        task (str): "Train" / "Valid" / "Test" / "Inference" 
        cocoEval (ndarray, optional): evaluate result for coco data form. Defaults to None.
        epochRecord (str, optional): record epoch. Defaults to None.
    
    Output:
        mAP record for evaluation file (txt)
    """
    create_folder(outputPath)
    if task == 'Test' or epochRecord.split('/')[0]=='1':
        mode = 'w'
    else:
        mode = 'a'

    with open(os.path.join(outputPath, f'{task}_mAP.txt'), mode) as f:
        f.write(f'{task}:\n')  
        if epochRecord != None:
            f.write(f'Epoch: [{epochRecord}]\n')  
        f.write(f"""Average Precision  (AP) @[ IoU=0.50:0.95 | area=   all | maxDets=100 ] = {cocoEval[0]}
Average Precision  (AP) @[ IoU=0.50      | area=   all | maxDets=100 ] = {cocoEval[1]}
Average Precision  (AP) @[ IoU=0.75      | area=   all | maxDets=100 ] = {cocoEval[2]}
Average Precision  (AP) @[ IoU=0.50:0.95 | area= small | maxDets=100 ] = {cocoEval[3]}
Average Precision  (AP) @[ IoU=0.50:0.95 | area=medium | maxDets=100 ] = {cocoEval[4]}
Average Precision  (AP) @[ IoU=0.50:0.95 | area= large | maxDets=100 ] = {cocoEval[5]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area=   all | maxDets=  1 ] = {cocoEval[6]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area=   all | maxDets= 10 ] = {cocoEval[7]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area=   all | maxDets=100 ] = {cocoEval[8]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area= small | maxDets=100 ] = {cocoEval[9]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area=medium | maxDets=100 ] = {cocoEval[10]}
Average Recall     (AR) @[ IoU=0.50:0.95 | area= large | maxDets=100 ] = {cocoEval[11]}\n
""")