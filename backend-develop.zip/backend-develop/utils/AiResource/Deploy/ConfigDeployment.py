class DeploymentPara:
    def __init__(self, deployMode:int, deployPath:str, deployName:str, saveIniFile:int) -> None:
        """
        Args:
            deployMode (int): deploy mode: 0 -> onnx&config,  1 -> pyd, 2 -> exe
            deployPath (str): the path you want to deploy to 
            deployName (str): the name you want to deploy
            saveIniFile (int): Whether to save the ini file
        """
        self.deployMode = deployMode
        self.deployPath = deployPath
        self.deployName = deployName
        self.saveIniFile = saveIniFile
        pass

class ClsDeploymentPara(DeploymentPara):
    def __init__(self, deployMode:int, deployPath:str, deployName:str, saveIniFile:int) -> None:
        super().__init__(deployMode, deployPath, 
                        deployName, saveIniFile)
        pass

    @classmethod
    def create_from_dict(cls, deploymentPara:dict) -> None:
        """
        Args:
            deploymentPara (dict): {
                deployMode (int): deploy mode: 0 -> onnx&config,  1 -> pyd(so), 2 -> exe
                deployPath (str): the path you want to deploy to 
                deployName (str): the name you want to deploy
                saveIniFile (int): Whether to save the ini file
            }
        """
        return cls(**deploymentPara)

class ClsOnnxSettingPara:
    def __init__(self, batchSize:int, cudaDevice:int) -> None:
        self.batchSize  = batchSize
        self.cudaDevice = cudaDevice

    @classmethod
    def create_from_dict(cls, onnxSetting: dict) -> None:
        """
        Args:
            deploymentPara (dict): 
            "onnxSetting": {
                "batchSize": 4     : onnx deploy input needs fixed batchsize
                "cudaDevice": 0    : onnx deploy choosing inference device
            }
        """
        return cls(**onnxSetting)

class DetDeploymentPara(DeploymentPara):
    def __init__(self, deployMode:int, deployPath:str, deployName:str, saveIniFile:int) -> None:
        super().__init__(deployMode, deployPath, 
                        deployName, saveIniFile)
        pass

    @classmethod
    def create_from_dict(cls, deploymentPara:dict) -> None:
        """
        Args:
            deploymentPara (dict): 
            "deployment": {
                deployMode (int): deploy mode: 0 -> onnx&config,  1 -> pyd(so), 2 -> exe
                deployPath (str): the path you want to deploy to 
                deployName (str): the name you want to deploy
                saveIniFile (int): Whether to save the ini file
            }
        """
        return cls(**deploymentPara)

class DetOnnxSettingPara:
    def __init__(self, inputSize:list, batchSize:int, cudaDevice:int) -> None:
        self.inputSize  = inputSize
        self.batchSize  = batchSize
        self.cudaDevice = cudaDevice

    @classmethod
    def create_from_dict(cls, onnxSetting: dict) -> None:
        """
        Args:
            deploymentPara (dict): 
            "onnxSetting": {
                "inputSize" (list) : onnx deploy input needs fixed size
                "batchSize": 4     : onnx deploy input needs fixed batchsize
                "cudaDevice": 0    : onnx deploy choosing inference device
            }
        """
        return cls(**onnxSetting)