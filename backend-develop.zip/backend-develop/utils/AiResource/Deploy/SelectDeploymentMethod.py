from utils.AiResource.ModelService.PytorchClassificationModel.ConfigPreprocess import \
    PreprocessPara
from utils.AiResource.ResultStorage.ConfigResultStorage import \
    DetResultStoragePara
from utils.AiResource.Deploy.ConfigDeployment import ClsDeploymentPara, ClsOnnxSettingPara, DetDeploymentPara, DetOnnxSettingPara
from utils.AiResource.Postprocess.ConfigPostprocess import ClsPostProcessPara
from .ModuleDeploy.FileSetting import ClsDepolyConfigJsonSetting, DetDepolyConfigJsonSetting,\
      cls_write_mainPy, det_write_mainPy
from .ModuleDeploy.Tool import write_json, create_folder
from .ModuleDeploy.PyToPyd import py_to_pyd
import os, shutil


def cls_generate_deploy_file(
    deploymentPara:ClsDeploymentPara,
    onnxSettingPara:ClsOnnxSettingPara,
    preprocessPara:PreprocessPara, 
    postProcessPara:ClsPostProcessPara, 
    outputPath:str,
    classNameList:list,
    iniFileName:str) -> None:
    """Generate classification deployment files

    Deployment mode 0: only generate config file and onnx
    Deployment mode 1: generate pyd file, config file and onnx
    Deployment mode 2: generate exe oneFile, config file and onnx
    Deployment mode 3: generate exe oneFolder, config file and onnx

    Args:
        deploymentPara (ClsDeploymentPara): deploy para from ConfigCls.json
        onnxSettingPara (ClsOnnxSettingPara): onnxsetting para from ConfigCls.json
        preprocessPara (PreprocessPara): preprocess para from ConfigCls.json
        postProcessPara (ClsPostProcessPara): post-Process para from ConfigCls.json
        outputPath (str): model and ini file path
        classNameList (list): give class list 
        iniFileName (str): ini file name

    Return:
        deployment file: onnx&config, pyd or exe files
    """
    
    fileName = deploymentPara.deployName
    deployOutputPath = deploymentPara.deployPath

    if deploymentPara.deployMode == 0:
        # if not deployOutputPath existed creating new one
        create_folder(deployOutputPath)
        print('Deployment mode 0: only generate config file and onnx')
    elif deploymentPara.deployMode == 1:
        # Copy whole file folder from ClsPackage/pyd/utils 
        shutil.copytree(f'./utils/AiResource/Deploy/ModuleDeploy/Cls/ClsPackage/pyd/utils', f'{deployOutputPath}/utils')
        # Rename the sampleInference.py into user customized name
        os.rename(f'{deployOutputPath}/utils/sampleInference.py', f'{deployOutputPath}/utils/{fileName}.py')
        # Let .py encrypt into .pyd
        py_to_pyd(f'{deployOutputPath}/utils' , f'{deployOutputPath}/utils')
        # Generate main.py file
        cls_write_mainPy(fileName, deployOutputPath)
        print('Deployment mode 1: generate pyd file, config file and onnx')
    elif deploymentPara.deployMode == 2:
        # Copy oneFile from ClsPackage/exe/deployment 
        shutil.copytree(f'./utils/AiResource/Deploy/ModuleDeploy/Cls/ClsPackage/exe/deployment/oneFile', f'{deployOutputPath}')
        # Rename the main.exe into user customized name
        os.rename(f'{deployOutputPath}/main.exe', f'{deployOutputPath}/{fileName}.exe')
        print('Deployment mode 2: generate exe file, config file and onnx')
    elif deploymentPara.deployMode == 3:
        # Copy oneFolder from ClsPackage/exe/deployment
        shutil.copytree(f'./utils/AiResource/Deploy/ModuleDeploy/Cls/ClsPackage/exe/deployment/oneFolder', f'{deployOutputPath}')
        # Rename the main folder into user customized name
        os.rename(f'{deployOutputPath}/main', f'{deployOutputPath}/{fileName}')
        # if not deployOutputPath existed creating new one
        create_folder(f'{deployOutputPath}/{fileName}/image')
        # Generate inference Config.json format
        configJson = ClsDepolyConfigJsonSetting(onnxSettingPara, preprocessPara, postProcessPara, fileName, classNameList)
        write_json(configJson.config_json_item(), "deployConfig", f'{deployOutputPath}/{fileName}')
        # Rename the BestOnnx.onnx into user customized name
        os.rename(os.path.join(outputPath, 'BestOnnx.onnx'), os.path.join(f'{deployOutputPath}/{fileName}', f'{fileName}.onnx'))
        print('Deployment mode 3: generate exe file, config file and onnx')
    else:
        raise BaseException(f'your deployMode is {deploymentPara.deployMode} not in our deployMode, \
                deployMode:0 -> onnx&config,  1 -> pyd, 2 -> exe oneFile, 3 -> exe oneFolder')

    if deploymentPara.deployMode != 3:
        # if not deployOutputPath existed creating new one
        create_folder(f'{deployOutputPath}/image')
        # Generate inference Config.json format
        configJson = ClsDepolyConfigJsonSetting(onnxSettingPara, preprocessPara, postProcessPara, fileName, classNameList)
        write_json(configJson.config_json_item(), "deployConfig", deployOutputPath)
        # Rename the BestOnnx.onnx into user customized name
        os.rename(os.path.join(outputPath, 'BestOnnx.onnx'), os.path.join(deployOutputPath, f'{fileName}.onnx'))
    
    if deploymentPara.saveIniFile:
        # Copy ini file from outputPath/iniFileName 
        shutil.copy(os.path.join(outputPath, iniFileName), os.path.join(deployOutputPath, f'{fileName}.ini'))
    
    print(f'Generate deployment file complete !!')


def det_generate_deploy_file(
    deploymentPara:DetDeploymentPara,
    onnxSettingPara:DetOnnxSettingPara,
    preprocessPara:PreprocessPara, 
    postProcessPara:ClsPostProcessPara,
    resultStorage:DetResultStoragePara,
    outputPath:str,
    classNameDict:list,
    iniFileName:str) -> None:
    """Generate detection deployment files

    Deployment mode 0: only generate config file and onnx
    Deployment mode 1: generate pyd file, config file and onnx
    Deployment mode 2: generate exe oneFile, config file and onnx
    Deployment mode 3: generate exe oneFolder, config file and onnx

    Args:
        deploymentPara (DetDeploymentPara): deploy para from ConfigDet.json
        onnxSettingPara (DetOnnxSettingPara): onnxsetting para from ConfigDet.json
        preprocessPara (PreprocessPara): preprocess para from ConfigDet.json
        postProcessPara (DetPostProcessPara): post-Process para from ConfigDet.json
        outputPath (str): model and ini file path
        classNameList (list): give class list 
        iniFileName (str): ini file name

    Return:
        deployment file: onnx&config, pyd or exe files
    """
    
    fileName = deploymentPara.deployName
    deployOutputPath = deploymentPara.deployPath

    if deploymentPara.deployMode == 0:
        # if not deployOutputPath existed creating new one
        create_folder(deployOutputPath)
        print('Deployment mode 0: only generate config file and onnx')
    elif deploymentPara.deployMode == 1:
        # Copy whole file folder from DetPackage/pyd/utils 
        shutil.copytree(f'./utils/AiResource/Deploy/ModuleDeploy/Det/DetPackage/pyd/utils', f'{deployOutputPath}/utils')
        # Rename the sampleInference.py into user customized name
        os.rename(f'{deployOutputPath}/utils/sampleInference.py', f'{deployOutputPath}/utils/{fileName}.py')
        # Let .py encrypt into .pyd
        py_to_pyd(f'{deployOutputPath}/utils' , f'{deployOutputPath}/utils')
        # Generate main.py file
        det_write_mainPy(fileName, deployOutputPath)
        print('Deployment mode 1: generate pyd file, config file and onnx')
    elif deploymentPara.deployMode == 2:
        # if not deployOutputPath existed creating new one
        shutil.copytree(f'./utils/AiResource/Deploy/ModuleDeploy/Det/DetPackage/exe/deployment/oneFile', f'{deployOutputPath}')
        # Rename the main.exe into user customized name
        os.rename(f'{deployOutputPath}/main.exe', f'{deployOutputPath}/{fileName}.exe')
        print('Deployment mode 2: generate exe file, config file and onnx')
    elif deploymentPara.deployMode == 3:
        # Copy oneFolder from ClsPackage/exe/deployment
        shutil.copytree(f'./utils/AiResource/Deploy/ModuleDeploy/Det/DetPackage/exe/deployment/oneFolder', f'{deployOutputPath}')
        # Rename the main folder into user customized name
        os.rename(f'{deployOutputPath}/main', f'{deployOutputPath}/{fileName}')
        # if not deployOutputPath existed creating new one
        create_folder(f'{deployOutputPath}/{fileName}/image')
        # Generate inference Config.json format
        configJson = DetDepolyConfigJsonSetting(onnxSettingPara, preprocessPara, postProcessPara, resultStorage, fileName, classNameDict)
        write_json(configJson.config_json_item(), "deployConfig", f'{deployOutputPath}/{fileName}')
        # Rename the BestOnnx.onnx into user customized name
        os.rename(os.path.join(outputPath, 'BestOnnx.onnx'), os.path.join(f'{deployOutputPath}/{fileName}', f'{fileName}.onnx'))
        print('Deployment mode 3: generate exe file, config file and onnx')
    else:
        raise BaseException(f'your deployMode is {deploymentPara.deployMode} not in our deployMode, \
                deployMode:0 -> onnx&config,  1 -> pyd, 2 -> exe oneFile, 3 -> exe oneFolder')

    if deploymentPara.deployMode != 3:
        # if not deployOutputPath existed creating new one
        create_folder(f'{deployOutputPath}/image')
        # Generate inference Config.json format
        configJson = DetDepolyConfigJsonSetting(onnxSettingPara, preprocessPara, postProcessPara, resultStorage, fileName, classNameDict)
        write_json(configJson.config_json_item(), "deployConfig", deployOutputPath)
        # Rename the BestOnnx.onnx into user customized name
        os.rename(os.path.join(outputPath, 'BestOnnx.onnx'), os.path.join(deployOutputPath, f'{fileName}.onnx'))

    if deploymentPara.saveIniFile:
        # Copy ini file from outputPath/iniFileName 
        shutil.copy(os.path.join(outputPath, iniFileName), os.path.join(deployOutputPath, f'{fileName}.ini'))
    
    print(f'Generate deployment file complete !!')
