import os, pathlib, shutil
from distutils.core import setup
from Cython.Build import cythonize
from .Tool import delete_folder

def py_to_pyd(filePath:str, outputPath:str):
    """Convert python files to pyd files

    Args:
        filePath (str): python files path
        outputPath (str): output path to save pyd file
    """
    toPackList = []
    buildPydPath = f'{outputPath}/build'
    buildPydTempPath = f'{outputPath}/build/temp'

    for pyfile in os.listdir(filePath):
        if os.path.isfile(os.path.join(filePath, pyfile)) and pyfile.split('.')[-1]=='py':
            toPackList.append(os.path.join(filePath, pyfile))

    for i in toPackList:
        setup(ext_modules = cythonize(i, compiler_directives={'language_level' : "4"}),
                script_args=["build_ext", "-b", buildPydPath, "-t", buildPydTempPath])
        os.remove(os.path.join(filePath, pathlib.Path(i).stem+'.c'))
        os.remove(i)

    delete_folder(buildPydTempPath)
    for pydFile in os.listdir(buildPydPath):
        shutil.move(os.path.join(buildPydPath, pydFile), outputPath)
    delete_folder(buildPydPath)