from torchvision.ops import batched_nms, nms
from torch import tensor, int64
from torchvision.transforms import InterpolationMode
from torchvision.transforms.functional import resize
from .ConfigSetting import PreprocessPara

def scale_bbox_image(result: list, prePara: PreprocessPara) -> list:
    """
    rewrite result & image

    Args:
        result (list): [
            "image"       (PIL) : image
            "boxes"   (ndarray) : predict the coordinates of box
            "labels"  (ndarray) : predict box of category
            "scores"  (ndarray) : predict box confidence score
            "imageName"   (str) : image name
            "imageScaler"(tuple): image size scale to input size
            "iou"         (str) : iou for every predict box ]
    """
    for resultItem in result:
        ### Scale bbox into original input size 
        if len(resultItem["boxes"]) != 0:
            resultItem["boxes"][:, [0, 2]] *= resultItem['imageScaler'][0].numpy()
            resultItem["boxes"][:, [1, 3]] *= resultItem['imageScaler'][1].numpy()

        ### Scale image into original input size 
        inputSize = (int(resultItem["image"].size[0] * resultItem['imageScaler'][0]), int(resultItem["image"].size[1] * resultItem['imageScaler'][1]))
        if resultItem["image"].size != inputSize:
            resultItem["image"] = resize(resultItem["image"], [inputSize[0], inputSize[1]],
                        getattr(InterpolationMode, prePara.preprocessPara['Resize']['parameters']['interpolation']))
    return result

def apply_nms(prediction:tensor, threshold:float):
    """
    Using nms for prediction

    Args:
        prediction (tensor): model predict result
        threshold (float): confidence socre threshold

    Returns:
        predictionNms (tensor): after nms predict result
    """
    # torchvision returns the indices of the boxes to keep
    # prediction = [tensor(i) for i in prediction]

    pred = {}
    for j in prediction:
        if len(tensor(j).size())==2:
            pred['bbox'] = tensor(j)
        elif tensor(j).dtype == int64:
            pred['labels'] = tensor(j)
        else:
            pred['scores'] = tensor(j)

    # keep = nms(prediction[0], prediction[1], threshold)
    # keep = batched_nms(tensor(prediction[0]), tensor(prediction[2]), tensor(prediction[1]), threshold)
    keep = batched_nms(pred['bbox'], pred['scores'], pred['labels'], threshold)

    # prediction = pred
    # predictionNms = prediction
    prediction[0] = tensor(pred['bbox'])[keep]
    prediction[1] = tensor(pred['scores'])[keep]
    prediction[2] = tensor(pred['labels'])[keep]
    return prediction