from fileinput import filename
import json, os
from configparser import ConfigParser
from .ConfigSetting import *
import torch
from .SelectInference import DetectionDataset, get_eval_transform, det_select_postprocess, det_save_result
from torch.utils.data import DataLoader
from .PostprocessMethod import apply_nms
import torchvision
import onnxruntime
import numpy as np
from tqdm import tqdm
import warnings
# os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

warnings.filterwarnings("ignore", category=UserWarning)
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
### REPRODUCIBILITY
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

#### read config file ####
def read_json_config():
    """read json config file to dict

    Raises:
        BaseException: json file not found. Please check if the file name is "deployConfig.json"

    Returns:
        configDict (dict): config dict 
    """
    try:
        with open(f'./deployConfig.json') as configFile:
            configDict = json.load(configFile)
    except:
        raise BaseException(f'json file not found. Please check if the file name is "deployConfig.json".')
    return configDict

# def read_ini_config(fileName):
#     configDict = ConfigParser()
#     configDict.read(f'./{fileName}.ini', encoding='utf-8')
#     return configDict

# def select_read_data(fileName):
#     configDict = []
#     try:
#         configDict = read_json_config(fileName)
#     except:
#         configDict = read_ini_config(fileName)

#     if configDict == []:
#         raise BaseException("don't have any config file (.ini or .json)")

#     return configDict

def to_numpy(tensor):
    return tensor.detach().cpu().numpy() if tensor.requires_grad else tensor.cpu().numpy()

def inference_precess(
    inferencePara:InferencePara,
    preprocessPara:PreprocessPara,
    postprocessPara:PostProcessPara,
    fileName:str,
):
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(inferencePara.cudaDevice) if torch.cuda.is_available() else 'cpu')
    
    hasNotBackground = inferencePara.classNameDict.__contains__(0)
    classLabelHasBg = {k+1 : v for k, v in inferencePara.classNameDict.items()} if hasNotBackground else inferencePara.classNameDict

    print("Loading data")
    inferenceSet = DetectionDataset(inferencePara.pathPara,
                                transform=get_eval_transform(preprocessPara.preprocessPara),
                                hasNotBackground=hasNotBackground, batchSize=inferencePara.batchSize)

    dataLoader = DataLoader(dataset=inferenceSet, batch_size=inferencePara.batchSize, shuffle=False, num_workers=0)
    
    ### Model define ###
    if cudaDevice == torch.device('cpu'):
        providers = ['CPUExecutionProvider']
    else:
        providers = [('CUDAExecutionProvider', {
                                'device_id': inferencePara.cudaDevice,
                                'cudnn_conv_algo_search': 'HEURISTIC', # OrtCudnnConvAlgoSearchExhaustive
                            }),
                    'CPUExecutionProvider']

    session = onnxruntime.InferenceSession(f'./{fileName}.onnx', providers=providers)

    resultList = []
    numPredict = 0
    print("Model inferencing")
    pbar = tqdm(dataLoader)
    for images, targets in pbar:
        images = images.to(cudaDevice)
        ort_inputs = {session.get_inputs()[0].name: to_numpy(images)}
        prediction = session.run(None, ort_inputs)
        # prediction = torch.tensor(session.run([], {"input": images.cpu().numpy()})[0])
        for i, j in enumerate(range(0, len(prediction), 3)):
            pred = apply_nms(prediction[j:j+3], postprocessPara.nms['iouTreshold']) if postprocessPara.nms['order'] else prediction[j:j+3]
            ##### record each result #####
            predDict = {
                "image"          : torchvision.transforms.ToPILImage(mode='RGB')(images[i]),
                "boxes"          : pred[0].cpu().numpy(),
                "scores"         : pred[1].cpu().numpy(),
                "labels"         : pred[2].cpu().numpy(),
                "imageName"      : targets["imageName"][i],
                "imageScaler"    : (targets['imageOgSize'][i][0] / images[i].size()[1], targets['imageOgSize'][i][1] / images[i].size()[2]),
                "classLabelhasBg": classLabelHasBg
            }

            numPredict += len(predDict["labels"])
            pbar.set_description(f'Detected {numPredict} targets')
            resultList.append(predDict)

    return resultList

def inference():
    print("Step 0: Create config object from dict.")
    configDict = read_json_config()
    inferencePara = InferencePara.create_from_dict(configDict["inferencePara"])
    preprocessPara = PreprocessPara.create_from_dict(configDict["preprocessPara"])
    postProcessPara = DetPostProcessPara.create_from_dict(configDict["postProcessPara"])
    resultStorage = ResultStorage.create_from_dict(configDict["resultStorage"])

    print("Step 1: AI model Inference")
    resultList = inference_precess(inferencePara, preprocessPara, postProcessPara, inferencePara.onnxModelName)
    classLabelhasBg = resultList[-1]["classLabelhasBg"]

    print("Step 2: Post-processing")
    resultList = det_select_postprocess(resultList, inferencePara, postProcessPara, preprocessPara)

    print("Step 3: Result Saveing")
    outputPath = '.'
    saveFileName = f'{inferencePara.csvSave["name"]}'
    det_save_result(resultStorage, classLabelhasBg, outputPath, resultList, saveFileName)