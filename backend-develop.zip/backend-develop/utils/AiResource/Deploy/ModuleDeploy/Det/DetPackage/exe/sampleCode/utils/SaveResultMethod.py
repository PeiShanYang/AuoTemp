import os, csv
from matplotlib.transforms import Bbox
import numpy as np
import collections
import PIL
import PIL.ImageDraw as ImageDraw
import PIL.ImageFont as ImageFont

STANDARD_COLORS = [
    'AliceBlue', 'Chartreuse', 'Aqua', 'Aquamarine', 'Azure', 'Beige', 'Bisque',
    'BlanchedAlmond', 'BlueViolet', 'BurlyWood', 'CadetBlue', 'AntiqueWhite',
    'Chocolate', 'Coral', 'CornflowerBlue', 'Cornsilk', 'Crimson', 'Cyan',
    'DarkCyan', 'DarkGoldenRod', 'DarkGrey', 'DarkKhaki', 'DarkOrange',
    'DarkOrchid', 'DarkSalmon', 'DarkSeaGreen', 'DarkTurquoise', 'DarkViolet',
    'DeepPink', 'DeepSkyBlue', 'DodgerBlue', 'FireBrick', 'FloralWhite',
    'ForestGreen', 'Fuchsia', 'Gainsboro', 'GhostWhite', 'Gold', 'GoldenRod',
    'Salmon', 'Tan', 'HoneyDew', 'HotPink', 'IndianRed', 'Ivory', 'Khaki',
    'Lavender', 'LavenderBlush', 'LawnGreen', 'LemonChiffon', 'LightBlue',
    'LightCoral', 'LightCyan', 'LightGoldenRodYellow', 'LightGray', 'LightGrey',
    'LightGreen', 'LightPink', 'LightSalmon', 'LightSeaGreen', 'LightSkyBlue',
    'LightSlateGray', 'LightSlateGrey', 'LightSteelBlue', 'LightYellow', 'Lime',
    'LimeGreen', 'Linen', 'Magenta', 'MediumAquaMarine', 'MediumOrchid',
    'MediumPurple', 'MediumSeaGreen', 'MediumSlateBlue', 'MediumSpringGreen',
    'MediumTurquoise', 'MediumVioletRed', 'MintCream', 'MistyRose', 'Moccasin',
    'NavajoWhite', 'OldLace', 'Olive', 'OliveDrab', 'Orange', 'OrangeRed',
    'Orchid', 'PaleGoldenRod', 'PaleGreen', 'PaleTurquoise', 'PaleVioletRed',
    'PapayaWhip', 'PeachPuff', 'Peru', 'Pink', 'Plum', 'PowderBlue', 'Purple',
    'Red', 'RosyBrown', 'RoyalBlue', 'SaddleBrown', 'Green', 'SandyBrown',
    'SeaGreen', 'SeaShell', 'Sienna', 'Silver', 'SkyBlue', 'SlateBlue',
    'SlateGray', 'SlateGrey', 'Snow', 'SpringGreen', 'SteelBlue', 'GreenYellow',
    'Teal', 'Thistle', 'Tomato', 'Turquoise', 'Violet', 'Wheat', 'White',
    'WhiteSmoke', 'Yellow', 'YellowGreen'
]

def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath: the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)   

def filter_low_thresh(
    predDict:dict, 
    classLabel:dict, 
    threshold:float,
    boxToDisplayStrMap:collections.defaultdict, 
    boxToColorMap:collections.defaultdict
):
    """
    Filter out confidence scores below the lower threshold, and record display dict  
    Args:
        predDict (dict): [
                "boxes"   (ndarray) : predict the coordinates of box
                "labels"  (ndarray) : predict box of category
                "scores"  (ndarray) : predict box confidence score
            ]
        classLabel (dict): number corresponds to category 
        threshold (float): confidence socre threshold. Defaults to 0.5.
        boxToDisplayStrMap (dict): box item for display record
        boxToColorMap (dict): class name item for color record
    """
    boxes = predDict["boxes"]
    classes = predDict["labels"]
    scores = predDict["scores"]
    
    for i in range(boxes.shape[0]):
        if scores[i] > threshold:
            box = tuple(boxes[i].tolist())
            if classes[i] in classLabel.keys():
                labelName = classLabel[classes[i]]
            else:
                labelName = 'N/A'
            displayStr = str(labelName)
            displayStr = '{}: {}%'.format(displayStr, int(100 * scores[i]))
            boxToDisplayStrMap[box].append(displayStr)
            boxToColorMap[box] = STANDARD_COLORS[
                classes[i] % len(STANDARD_COLORS)]
        else:
            break


def draw_text(
    draw:ImageDraw, 
    boxToDisplayStrMap:collections.defaultdict, 
    box:tuple, 
    color:str):
    """
    box class txt drawn on image

    Args:
        draw (ImageDraw): image can drawing type
        boxToDisplayStrMap (dict): box item for display record
        box (list): x1, y1, x2, y2
        color (str): color name in [STANDARD_COLORS]
    """
    try:
        # font = ImageFont.truetype('arial.ttf', 24)
        font = ImageFont.truetype("./calibril.ttf", 15)
    except IOError:
        font = ImageFont.load_default()

    left, top, right, bottom = box

    displayStrHeights = [font.getsize(ds)[1] for ds in boxToDisplayStrMap[box]]
    totalDisplayStrHeight = (1 + 2 * 0.05) * sum(displayStrHeights)

    if top > totalDisplayStrHeight:
        textBottom = top
    else:
        textBottom = bottom + totalDisplayStrHeight
    # Reverse list and print from bottom to top.
    for displayStr in boxToDisplayStrMap[box][::-1]:
        textWidth, textHeight = font.getsize(displayStr)
        margin = np.ceil(0.05 * textHeight)
        draw.rectangle([(left, textBottom - textHeight - 2 * margin),
                        (left + textWidth, textBottom)], fill=color)
        draw.text((left + margin, textBottom - textHeight - margin),
                  displayStr,
                  fill='black',
                  font=font)
        textBottom -= textHeight - 2 * margin

# def draw_text2(draw, boxToDisplayStrMap, box, color):
#     try:
#         # font = ImageFont.truetype('arial.ttf', 24)
#         font = ImageFont.truetype("./calibril.ttf", 15)
#     except IOError:
#         font = ImageFont.load_default()
    
#     for displayStr in boxToDisplayStrMap[box][::-1]:
#         textWidth, textHeight = font.getsize(displayStr)
#         textboxLocation = [box[0], box[1] - textHeight, box[0] + textWidth + 4., box[1]]
#         textLocation = [box[0] + 2., box[1] - textHeight]
#         draw.rectangle(xy= textboxLocation, fill=color )
#         draw.text(xy=textLocation, text=displayStr, fill='black', font=font)


def draw_box_tool(
    predDict:dict, 
    classLabel:dict, 
    threshold:float=0.5, 
    lineThickness:int=8
)-> PIL:
    """
    draw box to image tool

    Args:
        predDict (dict): 
            [
                "image"       (PIL) : image
                "boxes"   (ndarray) : predict the coordinates of box
                "labels"  (ndarray) : predict box of category
                "scores"  (ndarray) : predict box confidence score
                "imageName"   (str) : image name
                "imageScaler"(tuple): image size scale to input size
            ]
        classLabel (dict):  number corresponds to category 
        threshold (float, optional): confidence socre threshold. Defaults to 0.5.
        lineThickness (int, optional): The thickness of the box drawn on the image. Defaults to 8.

    Returns:
        after drawn on the image (PIL) 
    """
    # collections.defaultdict　: can build dict without key and value
    boxToDisplayStrMap = collections.defaultdict(list)
    boxToColorMap = collections.defaultdict(str)


    filter_low_thresh(predDict, classLabel, threshold, boxToDisplayStrMap, boxToColorMap)

    # Draw all boxes onto image.
    imageResult = predDict["image"].copy()
    drawImage = ImageDraw.Draw(imageResult)
    for box, color in boxToColorMap.items():
        drawImage.rectangle(xy=box, width=lineThickness, outline=color)
        draw_text(drawImage, boxToDisplayStrMap, box, color)
    # return draw
    return imageResult


def draw_box(
    predDictList:list, 
    outputPath:str, 
    classLabel:dict, 
    threshold:float=0.5, 
    lineThickness:int=8,
):
    """
    draw predict box to image

    Args:
        predDictList (list): for every item
        [
            "image"       (PIL) : image
            "boxes"   (ndarray) : predict the coordinates of box
            "labels"  (ndarray) : predict box of category
            "scores"  (ndarray) : predict box confidence score
            "imageName"   (str) : image name
            "imageScaler"(tuple): image size scale to input size
        ]
        outputPath (str): output path
        classLabel (dict): number corresponds to category 
        threshold (float, optional): confidence socre threshold. Defaults to 0.5.
        lineThickness (int, optional): The thickness of the box drawn on the image. Defaults to 8.
    """
    create_folder(outputPath)
    for predDict in predDictList:
        drawImage = draw_box_tool(predDict, classLabel, threshold, lineThickness)
        drawImage.save(os.path.join(outputPath, predDict["imageName"]))

class CsvHandler():
    """
    Operations with csv
    """
    def __init__(self, fileName:str, path:str, title:list) -> None:
        """
        create an object of csv file manager

        Args:
            fileName (str): filename
            path (str): written path
            title (list):  title of csv
        """
        super(CsvHandler, self).__init__()
        self.title = title
        self.path = path
        self.file = os.path.join(path, fileName)
        self.create_folder()
        
    def create_folder(self) -> None:
        """
        create written path
        """
        if not os.path.isdir(self.path):
            os.makedirs(self.path)

    def create_csv(self) -> None:
        """
        create csv file
        """
        with open(self.file, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(self.title)  
            csvfile.close()
    
    def write_csv(self, result:list, mode:str='w') -> None: 
        """
        write result into csv

        Args:
            result (list): result to write
            mode (str, optional): Defaults to 'w'.
                'w': is single write
                'a': is continue to write
        """
        with open(self.file, mode, newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(result)
            csvfile.close()

class DetResultSaver:
    def __init__(self, outputPath:str, fileName:str, classLabel:dict) -> None:
        """
        create detection result object for saving result

        Args:
            outputPath (str): output path
            fileName (str): file name 
            task (str): "Test" / "Inference" 
            classLabel (dict): number corresponds to category 
        """
        self.outputPath = outputPath
        self.fileName = fileName
        self.classLabel = classLabel
        self.create_folder(outputPath)
        
        title = ['fileName', 'prediction', 'x1', 'y1', 'x2', 'y2', 'socre']
        self.ResultCsv = CsvHandler(f'{fileName}.csv', outputPath, title)
        self.ResultCsv.create_csv() 

    @staticmethod        
    def create_folder(folderPath:str) -> None:
        """
        Create storaged folder

        Args:
            folderPath: the path wants to create
        """
        if not os.path.isdir(folderPath):
            os.makedirs(folderPath)    


    def write_result_csv(self, result:list, scoreThreshold:float=0.3):
        """
        write result to csv file

        Args:
            result (list): [
                "image"       (PIL) : image
                "boxes"   (ndarray) : predict the coordinates of box
                "labels"  (ndarray) : predict box of category
                "scores"  (ndarray) : predict box confidence score
                "imageName"   (str) : image name
                "imageScaler"(tuple): image size scale to input size
                "iou"         (str) : iou for every predict box ]
            scoreThreshold (float, optional): confidence score threshold. Defaults to 0.3.
            iouThr (float, optional): iou threshold. Defaults to 0.5.
        """

        for resultItem in result:
            imageName = resultItem["imageName"]
            if len(resultItem["boxes"]) != 0:
                
                boxes = np.around(resultItem["boxes"]).astype(int)
                labels = resultItem["labels"]
                scores = resultItem["scores"]
                # if self.task == 'Test':
                #     try:
                #         iou = resultItem["iou"]  
                #         iouMax, _ = iou.max(0)  # 每個預測框最大的iou
                #     except:
                #         iouMax = [0.0 for _ in range(iou.shape[1])]  # label的txt為空但有預測匡，給定iou = 0.0
                
                scoreQualified = np.where(scores > scoreThreshold)    
                for boxPosition in scoreQualified[0]:
                    resultList = [imageName, self.classLabel[labels[boxPosition]], *boxes[boxPosition], np.round(scores[boxPosition], 2)]
                    # if self.task == 'Test':
                    #     if iouMax[boxPosition] < iouThr:
                    #         continue
                    #     else:
                    #         resultList.append(round(float(iouMax[boxPosition]),3))
                    self.ResultCsv.write_csv(resultList, 'a')


