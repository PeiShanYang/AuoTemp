from utils.sampleInference import inference 

if __name__ == '__main__':
    inference()