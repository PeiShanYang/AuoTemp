import json, os
from .ConfigSetting import *
import numpy.core._dtype_ctypes
import torch
from .SelectInference import InferenceDataset, cls_select_transform, cls_select_postprocess, cls_save_result
from torch.utils.data import DataLoader
import onnxruntime
from tqdm import tqdm
import warnings
# os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

warnings.filterwarnings("ignore", category=UserWarning)
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
### REPRODUCIBILITY
torch.manual_seed(0)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

#### read config file ####
def read_json_config():
    """read json config file to dict

    Raises:
        BaseException: json file not found. Please check if the file name is "deployConfig.json"

    Returns:
        configDict (dict): config dict 
    """
    try:
        with open(f'./deployConfig.json') as configFile:
            configDict = json.load(configFile)
    except:
        raise BaseException(f'json file not found. Please check if the file name is "deployConfig.json".')
    return configDict

def to_numpy(tensor):
    return tensor.detach().cpu().numpy() if tensor.requires_grad else tensor.cpu().numpy()

def inference_process(
    inferencePara:InferencePara,
    preprocessPara:PreprocessPara,
    fileName:str,
):
    """inference main process

    Args:
        inferencePara (InferencePara): inference parameters
        preprocessPara (PreprocessPara): preprocess parameters
        fileName (str): deploy file name

    Returns:
        resultList (list): [
                {
                    filename (str): image name
                    predict (str): predict class name
                    label (str): None,
                    confidence (float): confidence score
                    output (dict): confidence score for every classes 
                }
            ]
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(inferencePara.cudaDevice) if torch.cuda.is_available() else 'cpu')
    inferenceTransform = cls_select_transform(preprocessPara.preprocessPara)
    dataSet = InferenceDataset(inferencePara.pathPara, inferenceTransform)
    dataLoader = DataLoader(dataset=dataSet, batch_size=inferencePara.batchSize, shuffle=False, num_workers=0)

    ### Model define ###
    # session = onnxruntime.InferenceSession(f'./{fileName}.onnx', providers=['CPUExecutionProvider'])
    if cudaDevice == torch.device('cpu'):
        providers = ['CPUExecutionProvider']
    else:
        providers = [('CUDAExecutionProvider', {
                                'device_id': inferencePara.cudaDevice,
                                'cudnn_conv_algo_search': 'HEURISTIC', # OrtCudnnConvAlgoSearchExhaustive
                            }),
                    'CPUExecutionProvider']

    session = onnxruntime.InferenceSession(f'./{fileName}.onnx', providers=providers)

    className = inferencePara.classNameList
    className.sort()
    className.sort(key=lambda x:x)
    resultList = []
    print("Model inferencing")
    pbar = tqdm(dataLoader)
    # for i, data in enumerate(dataLoader):
    for i, data in enumerate(pbar):
        inputs, _ = data[0].to(cudaDevice), data[1].to(cudaDevice)

        # outputs = torch.tensor(session.run([], {"input": inputs.cpu().numpy()})[0])

        ort_inputs = {session.get_inputs()[0].name: to_numpy(inputs)}
        outputs = session.run(None, ort_inputs)
        # outputs = outputs[0][:len(className)]
        # outputs = outputs[None, :]
        _, predicted = torch.max(torch.from_numpy(outputs[0]), 1)
        confidence = torch.nn.functional.softmax(torch.from_numpy(outputs[0]), dim=1)

        ##### record each score for each class #####
        for batch_id, conf in enumerate(confidence):
            confDict = {className[i]: conf[i].item() for i in range(len(conf))}
        ##### record each result #####
            perResultDict = {
                "filename": dataSet.filename[batch_id + i*inferencePara.batchSize],
                "predict": className[predicted[batch_id]],
                "label": None,
                "confidence": conf[predicted[batch_id]].numpy(),
                "output": confDict
            }
            resultList.append(perResultDict)
    
    return resultList

def inference():
    """inference

    Returns:
        resultList (list): [
                {
                    filename (str): image name
                    predict (str): predict class name
                    label (str): None,
                    confidence (float): confidence score
                    output (dict): confidence score for every classes 
                }
            ]
    """
    print("Step 0: Create config object from dict.")
    configDict = read_json_config()
    inferencePara = InferencePara.create_from_dict(configDict["inferencePara"])
    preprocessPara = PreprocessPara.create_from_dict(configDict["preprocessPara"])
    postProcessPara = ClsPostProcessPara.create_from_dict(configDict["postProcessPara"])

    print("Step 1: AI model Inference")
    resultList = inference_process(inferencePara, preprocessPara, inferencePara.onnxModelName)

    print("Step 2: Post-processing")
    resultList = cls_select_postprocess(resultList, postProcessPara)

    print("Step 3: Result Saveing")
    outputPath = '.'
    cls_save_result(resultList, inferencePara.classNameList, outputPath, inferencePara.csvSave)

    return resultList