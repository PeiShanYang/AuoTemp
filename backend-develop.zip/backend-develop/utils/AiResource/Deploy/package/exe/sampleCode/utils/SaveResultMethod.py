# -*- coding: utf-8 -*-

"""
Created on Jun Tue 14 22:00:00 2022
"""
import os, csv

class CsvHandler():
    """
    Operations with csv
    """
    def __init__(self, fileName:str, path:str, title:list) -> None:
        """
        create an object of csv file manager

        Args:
            fileName (str): filename
            path (str): written path
            title (list):  title of csv
        """
        super(CsvHandler, self).__init__()
        self.title = title
        self.path = path
        self.file = os.path.join(path, fileName)
        self.create_folder()
        
    def create_folder(self) -> None:
        """
        create written path
        """
        if not os.path.isdir(self.path):
            os.makedirs(self.path)

    def create_csv(self) -> None:
        """
        create csv file
        """
        with open(self.file, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(self.title)  
            csvfile.close()
    
    def write_csv(self, result:list, mode:str='w') -> None: 
        """
        write result into csv

        Args:
            result (list): result to write
            mode (str, optional): Defaults to 'w'.
                'w': is single write
                'a': is continue to write
        """
        with open(self.file, mode, newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(result)
            csvfile.close()


class ResultCsv():
    def __init__(
        self,
        result:dict,
        count:int,
        outputPath:str,
        classNameList:list
    ) -> None:
        """
        Save result
            1. Wrong result into csv file
            2. Filter out images with scores below the threshold 
            3. Output test result into csv file, file name : Test_result.csv or Inference_result.csv.

        Args:
            result: result from model 
            count: use to record current file
            mode: task - test/ inference
            outputPath: outputPath
            classNameList: class name List
        """
        self.filename = result["filename"]
        self.predict = result["predict"]
        self.label = result["label"]
        self.confidence = result["confidence"]
        self.output = result["output"]
        self.count = count
        self.outputPath = outputPath
        self.classNameList = classNameList
        self.create_folder()

    def create_folder(self) -> None:
        """
        create written path
        """
        if not os.path.isdir(self.outputPath):
            os.makedirs(self.outputPath)


    def write_csv(self, saveFileName:str) -> CsvHandler:
        """
        create unkwon csv file
            saveFileName : file name
        Returns:
            CsvHandler class for unknown csv
        """
        title = ['Filename', 'Prediction', 'Sorce']
        unknownCsv = CsvHandler(saveFileName, self.outputPath, title)
        if self.count == 0:
            unknownCsv.create_csv() 
        return unknownCsv

    
    def write_result(self, saveFileName:str) -> None:
        """
        generate unknown filtered out csv
        """
        unknownCsv =  self.write_csv(saveFileName)
        result =  [self.filename, self.predict, f'{self.confidence:.6f}']
        # if not self.predict in self.classNameList:
        unknownCsv.write_csv(result, 'a')

