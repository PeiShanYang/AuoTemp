config = {
        "ConfigFile": {
            "filePara": {
                "file": {
                    "type": "string",
                    "default": "api",
                    "enums": {
                        "api": "api"
                    }
                }
            }
        },
        "ConfigParameter": {
            "parameterPara": {
                "GPU": {
                    "type": "string",
                    "default": "0",
                    "enums": {}
                },
                "batchSize": {
                    "type": "int",
                    "default": 1,
                    "min": 1,
                    "max": 32
                },
                "inputSizeModified": {
                    "type": "boolean",
                    "default": True
                },
                "inputSizeX": {
                    "type": "int",
                    "default": 416,
                    "min": 64,
                    "max": 1280
                },
                "inputSizeY": {
                    "type": "int",
                    "default": 416,
                    "min": 64,
                    "max": 1280
                }
            }
        }
    }
