config = {
    "ConfigFile": {
        "filePara": {
            "file": {
                "type": "string",
                "default": "onnx",
                "enums": {
                    "onnx": "onnx",
                    "exe": "exe",
                    "pyd (py37)": "pyd (py37)"
                }
            }
        }
    },
    "ConfigParameter": {
        "parameterPara": {
            "GPU": {
                "type": "string",
                "default": 0,
                "enums": {}
            },
            "batchSize": {
                "type": "int",
                "default": 1,
                "min": 1,
                "max": 32
            },
            "iniDownload": {
                "type": "boolean",
                "default": True
            },
            "cfgDownload": {
                "type": "boolean",
                "default": True
            }
        }
    }
}
