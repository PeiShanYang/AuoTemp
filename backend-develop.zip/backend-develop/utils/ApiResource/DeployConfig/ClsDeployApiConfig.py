config = {
    "ConfigFile": {
        "filePara": {
            "file": {
                "type": "string",
                "default": "api",
                "enums": {
                    "api": "api"
                }
            }
        }
    },
    "ConfigParameter": {
        "parameterPara": {
            "GPU": {
                "type": "string",
                "default": "0",
                "enums": {}
            },
            "batchSize": {
                "type": "int",
                "default": 1,
                "min": 1,
                "max": 32
            }
        }
    }
}
