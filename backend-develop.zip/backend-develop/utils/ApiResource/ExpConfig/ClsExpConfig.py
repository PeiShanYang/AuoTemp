config = {
    "ConfigPreprocess": {
        "preprocessPara": {
            "Normalize": {
                "description": "將根據輸入模式找到對應各通道的平均、標準差，進行影像正規化",
                "order": 1,
                "parameters": {
                    "mode": {
                        "type": "string",
                        "default": "ImageNet",
                        "enums": {
                            "ImageNet": "ImageNet",
                            "CIFAR10": "CIFAR10",
                            "MNIST": "MNIST",
                            "CalculateFromData": "CalculateFromData",
                            "UserInput": "UserInput"
                        }
                    },
                    "mean": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 1
                            },
                            "G": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 1
                            },
                            "B": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 1
                            },
                        },
                        "nullable": True
                    },
                    "std": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 1
                            },
                            "G": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 1
                            },
                            "B": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 1
                            },
                        },
                        "nullable": True
                    }
                }
            },
            "Resize": {
                "description": "調整影像大小至給定的數值",
                "order": 2,
                "parameters": {
                    "size": {
                        "type": "list",
                        "default": [224, 224],
                        "enums": {
                            "128x128": [128, 128],
                            "224x224": [224, 224],
                            "256x256": [256, 256],
                            "512x512": [512, 512]
                        }
                    },
                    "interpolation": {
                        "type": "string",
                        "default": "BILINEAR",
                        "enums": {
                            "BILINEAR": "BILINEAR",
                            "NEAREST": "NEAREST",
                            "BICUBIC": "BICUBIC"
                        }
                    }
                }
            },
            "CenterCrop": {
                "description": "以影像中心點切出給定數值大小的影像",
                "order": 0,
                "parameters": {
                    "size": {
                        "type": "list",
                        "default": [224, 224],
                        "enums": {
                            "128x128": [128, 128],
                            "224x224": [224, 224],
                            "256x256": [256, 256],
                            "512x512": [512, 512]
                        }
                    }
                }
            },
            "Pad": {
                "description": "向外進行影像填充",
                "order": 0,
                "parameters": {
                    "padding":  {
                        "type": "list",
                        "children": {
                            "left": {
                                "type": "int",
                                "default": 0,
                                "min": 0,
                                "max": 256,
                                "unit": "pixels"
                            },
                            "top": {
                                "type": "int",
                                "default": 0,
                                "min": 0,
                                "max": 256,
                                "unit": "pixels"
                            },
                            "right": {
                                "type": "int",
                                "default": 0,
                                "min": 0,
                                "max": 256,
                                "unit": "pixels"
                            },
                            "bottom": {
                                "type": "int",
                                "default": 0,
                                "min": 0,
                                "max": 256,
                                "unit": "pixels"
                            }
                        }
                    },
                    "fill": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        },
                        "nullable": True
                    },
                    "paddingMode": {
                        "type": "string",
                        "default": "constant",
                        "enums": {
                            "constant": "constant",
                            "edge": "edge",
                            "reflect": "reflect",
                            "symmetric": "symmetric",
                        }
                    }
                }
            },
            "GaussianBlur": {
                "description": "對影像做高斯模糊",
                "order": 0,
                "parameters": {
                    "kernelSize":
                    {
                        "type": "list",
                        "default": [3, 3],
                        "enums": {
                            "3x3": [3, 3],
                            "5x5": [5, 5],
                            "7x7": [7, 7],
                            "9x9": [9, 9],
                            "11x11": [11, 11]
                        },
                    },
                    "sigma": {
                        "type": "float",
                        "default": 1,
                        "min": 0.1,
                        "max": 2
                    }
                }
            },
            "Brightness": {
                "description": "對影像做亮度調整",
                "order": 0,
                "parameters": {
                    "brightness": {
                        "type": "float",
                        "default": 1.1,
                        "min": 0,
                        "max": 10,
                    }
                }
            },
            "Contrast": {
                "description": "對影像做對比度調整",
                "order": 0,
                "parameters": {
                    "contrast": {
                        "type": "float",
                        "default": 1.1,
                        "min": 0,
                        "max": 10,
                    }
                }
            },
            "Saturation": {
                "description": "對影像做飽和度調整",
                "order": 0,
                "parameters": {
                    "saturation": {
                        "type": "float",
                        "default": 1.1,
                        "min": 0,
                        "max": 10,
                    }
                }
            },
            "Hue": {
                "description": "對影像做色調調整",
                "order": 0,
                "parameters": {
                    "hue": {
                        "type": "float",
                        "default": 0.05,
                        "max": 0.5,
                        "min": -0.5
                    }
                }
            }
        }
    },
    "ConfigAugmentation": {
        "augmentationPara": {
            "RandomHorizontalFlip": {
                "description": "以給定的機率隨機對影像做水平翻轉",
                "order": 1,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    }
                }
            },
            "RandomVerticalFlip": {
                "description": "以給定的機率隨機對影像做垂直翻轉",
                "order": 2,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    }
                }
            },
            "RandomRotation": {
                "description": "在給定角度範圍內隨機對影像做旋轉",
                "order": 0,
                "parameters": {
                    "degrees": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": -360,
                                "max": 360,
                                "min": -360,
                                "unit": "degree"
                            },
                            "max": {
                                "type": "float",
                                "default": 360,
                                "max": 360,
                                "min": -360,
                                "unit": "degree"
                            }
                        }
                    },
                    "fill": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        },
                        "nullable": True
                    }
                }
            },
            "RandomTranslate": {
                "description": "在給定平移範圍內隨機對影像做平移",
                "order": 0,
                "parameters": {
                    "translate": {
                        "type": "list",
                        "children": {
                            "horizontalRatio": {
                                "type": "float",
                                "default": 0,
                                "max": 1,
                                "min": 0
                            },
                            "verticalRatio": {
                                "type": "float",
                                "default": 0,
                                "max": 1,
                                "min": 0
                            }
                        }
                    },
                    "fill": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        },
                        "nullable": True
                    }
                }
            },
            "RandomScale": {
                "description": "在給定縮放範圍內隨機對影像做縮放",
                "order": 0,
                "parameters": {
                    "scale": {
                        "type": "list",
                        "children": {
                            "horizontalRatio": {
                                "type": "float",
                                "default": 1,
                                "max": 10,
                                "min": 0,
                                "unit": "degree"
                            },
                            "verticalRatio": {
                                "type": "float",
                                "default": 1,
                                "max": 10,
                                "min": 0,
                                "unit": "degree"
                            }
                        }
                    },
                    "fill": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        },
                        "nullable": True
                    }
                }
            },
            "RandomShear": {
                "description": "在給定斜變範圍內隨機以軸對影像做斜變",
                "order": 0,
                "parameters": {
                    "shearHorizontal": {
                        "type": "list",
                        "boundary": {
                            "horizontalDegreeMin": {
                                "type": "float",
                                "default": -360,
                                "max": 360,
                                "min": -360,
                                "unit": "degree"
                            },
                            "horizontalDegreeMax": {
                                "type": "float",
                                "default": 360,
                                "max": 360,
                                "min": -360,
                                "unit": "degree"
                            }
                        }
                    },
                    "shearVertical": {
                        "type": "list",
                        "boundary": {
                            "verticalDegreeMin": {
                                "type": "float",
                                "default": -360,
                                "max": 360,
                                "min": -360,
                                "unit": "degree"
                            },
                            "verticalDegreeMax": {
                                "type": "float",
                                "default": 360,
                                "max": 360,
                                "min": -360,
                                "unit": "degree"
                            }
                        }
                    },
                    "fill": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        },
                        "nullable": True
                    }
                }
            },
            "RandomGrayscale": {
                "description": "以給定的機率隨機對影像做灰階轉換",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    }
                }
            },
            "RandomBrightness": {
                "description": "在給定亮度範圍內隨機對影像做亮度調整",
                "order": 0,
                "parameters": {
                    "brightness": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 10
                            },
                            "max": {
                                "type": "float",
                                "default": 1.5,
                                "min": 0,
                                "max": 10
                            }
                        }
                    }
                }
            },
            "RandomContrast": {
                "description": "在給定對比度範圍內隨機對影像對比度調整",
                "order": 0,
                "parameters": {
                    "contrast": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 10
                            },
                            "max": {
                                "type": "float",
                                "default": 1.5,
                                "min": 0,
                                "max": 10
                            }
                        }
                    }
                }
            },
            "RandomSaturation": {
                "description": "在給定飽和度範圍內隨機對影像做飽和度調整",
                "order": 0,
                "parameters": {
                    "saturation": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.5,
                                "min": 0,
                                "max": 10
                            },
                            "max": {
                                "type": "float",
                                "default": 1.5,
                                "min": 0,
                                "max": 10
                            }
                        }
                    }
                }
            },
            "RandomHue": {
                "description": "在給定色調範圍內隨機對影像做色調調整",
                "order": 0,
                "parameters": {
                    "hue": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": -0.05,
                                "max": 0.5,
                                "min": -0.5,
                            },
                            "max": {
                                "type": "float",
                                "default": 0.05,
                                "max": 0.5,
                                "min": -0.5,
                            }
                        }
                    }
                }
            },
            "RandomErasing": {
                "description": "在給定範圍內產生一個矩形，隨機對影像做遮罩",
                "order": 0,
                "parameters": {
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "scale": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.02,
                                "max": 1,
                                "min": 0,
                            },
                            "max": {
                                "type": "float",
                                "default": 0.33,
                                "max": 1,
                                "min": 0,
                            }
                        },
                        "display": "erasingSizeRatio"
                    },
                    "ratio": {
                        "type": "list",
                        "boundary": {
                            "min": {
                                "type": "float",
                                "default": 0.3,
                                "min": 0,
                                "max": 2
                            },
                            "max": {
                                "type": "float",
                                "default": 3.3,
                                "min": 0,
                                "max": 2
                            }
                        },
                        "display": "lengthWidthRatio"
                    },
                    "value": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        },
                        "display": "fill"
                    }
                }
            },
            "RandomPerspective": {
                "description": "以給定的機率隨機對影像做視角轉換",
                "order": 0,
                "parameters": {
                    "distortion": {
                        "type": "float",
                        "default": 0,
                        "max": 1,
                        "min": 0
                    },
                    "probability": {
                        "type": "float",
                        "default": 0.5,
                        "max": 1,
                        "min": 0
                    },
                    "interpolation": {
                        "type": "string",
                        "default": "BILINEAR",
                        "enums": {
                            "BILINEAR": "BILINEAR",
                            "NEAREST": "NEAREST",
                            "BICUBIC": "BICUBIC"
                        }
                    },
                    "fill": {
                        "type": "list",
                        "children": {
                            "R": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "G": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            },
                            "B": {
                                "type": "int",
                                "default": 0,
                                "max": 255,
                                "min": 0,
                            }
                        }
                    }
                }
            }
        }
    },
    "ConfigModelService": {
        "lossFunctionPara": {
            "lossFunction": {
                "type": "string",
                "default": "CrossEntropyLoss",
                "enums": {
                    "CrossEntropyLoss": "CrossEntropyLoss",
                    "NLLLoss": "NLLLoss",
                    "MultiMarginLoss": "MultiMarginLoss",
                }
            }
        },
        "learningRatePara": {
            "learningRate": {
                "type": "float",
                "default": 0.001,
                "min": 0,
                "max": 1
            }
        },
        "optimizerPara": {
            "optimizer": {
                "type": "string",
                "default": "SGD",
                "enums": {
                    "SGD": "SGD",
                    "Adam": "Adam",
                    "Adadelta": "Adadelta",
                    "AdamW": "AdamW",
                    "NAdam": "NAdam"
                }
            }
        },
        "schedulerPara": {
            "scheduler": {
                "type": "string",
                "default": "stepLR",
                "enums": {
                    "stepLR": "stepLR",
                    "cosineAnnealingLR": "cosineAnnealingLR"
                }
            }
        }
    },
    "ConfigPytorchModel": {
        "modelPara": {
            "model": {
                "structure": {
                    "type": "string",
                    "default": "auo_unrestricted_powerful_model_a",
                    "enums": {
                        "auo_tiny_focus_model": "auo_tiny_focus_model",
                        "auo_small_convolution_model_a": "auo_small_convolution_model_a",
                        "auo_small_convolution_model_b": "auo_small_convolution_model_b",
                        "auo_small_convolution_model_c": "auo_small_convolution_model_c",
                        "auo_small_convolution_model_d": "auo_small_convolution_model_d",
                        "auo_classic_deep_model_a": "auo_classic_deep_model_a",
                        "auo_classic_deep_model_b": "auo_classic_deep_model_b",
                        "auo_classic_deep_model_c": "auo_classic_deep_model_c",
                        "auo_anti_degeneration_model_a": "auo_anti_degeneration_model_a",
                        "auo_anti_degeneration_model_b": "auo_anti_degeneration_model_b",
                        "auo_anti_degeneration_model_c": "auo_anti_degeneration_model_c",
                        "auo_anti_degeneration_model_d": "auo_anti_degeneration_model_d",
                        "auo_anti_degeneration_model_e": "auo_anti_degeneration_model_e",
                        "auo_transform_aggregate_model_a": "auo_transform_aggregate_model_a",
                        "auo_transform_aggregate_model_b": "auo_transform_aggregate_model_b",
                        "auo_feature_widen_model_a": "auo_feature_widen_model_a",
                        "auo_feature_widen_model_b": "auo_feature_widen_model_b",
                        "auo_cross_connection_model": "auo_cross_connection_model",
                        "auo_narrow_intensive_model_a": "auo_narrow_intensive_model_a",
                        "auo_narrow_intensive_model_b": "auo_narrow_intensive_model_b",
                        "auo_narrow_intensive_model_c": "auo_narrow_intensive_model_c",
                        "auo_narrow_intensive_model_d": "auo_narrow_intensive_model_d",
                        "auo_group_convolution_model_a": "auo_group_convolution_model_a",
                        "auo_group_convolution_model_b": "auo_group_convolution_model_b",
                        "auo_group_convolution_model_c": "auo_group_convolution_model_c",
                        "auo_group_convolution_model_d": "auo_group_convolution_model_d",
                        "auo_group_convolution_model_e": "auo_group_convolution_model_e",
                        "auo_group_convolution_model_f": "auo_group_convolution_model_f",
                        "auo_group_convolution_model_g": "auo_group_convolution_model_g",
                        "auo_unrestricted_powerful_model_a": "auo_unrestricted_powerful_model_a",
                        "auo_unrestricted_powerful_model_b": "auo_unrestricted_powerful_model_b",
                        "auo_unrestricted_powerful_model_c": "auo_unrestricted_powerful_model_c",
                        "auo_unrestricted_powerful_model_d": "auo_unrestricted_powerful_model_d",
                        "auo_unrestricted_powerful_model_e": "auo_unrestricted_powerful_model_e",
                        "auo_unrestricted_powerful_model_f": "auo_unrestricted_powerful_model_f",
                        "auo_unrestricted_powerful_model_g": "auo_unrestricted_powerful_model_g",
                        "auo_faster_convergency_model_a": "auo_faster_convergency_model_a",
                        "auo_faster_convergency_model_b": "auo_faster_convergency_model_b",
                        "auo_faster_convergency_model_c": "auo_faster_convergency_model_c",
                        "auo_faster_convergency_model_d": "auo_faster_convergency_model_d",
                        "auo_faster_convergency_model_e": "auo_faster_convergency_model_e",
                        "auo_faster_convergency_model_f": "auo_faster_convergency_model_f",
                        "auo_faster_convergency_model_g": "auo_faster_convergency_model_g",
                        "auo_faster_convergency_model_h": "auo_faster_convergency_model_h",
                        "auo_cpu_optimization_model_a": "auo_cpu_optimization_model_a",
                        "auo_cpu_optimization_model_b": "auo_cpu_optimization_model_b",
                        "auo_accelerate_computing_model_a": "auo_accelerate_computing_model_a",
                        "auo_accelerate_computing_model_b": "auo_accelerate_computing_model_b",
                        "auo_lighten_efficient_model_a": "auo_lighten_efficient_model_a",
                        "auo_lighten_efficient_model_b": "auo_lighten_efficient_model_b"
                    }
                },
                "pretrained": {
                    "type": "boolean",
                    "default": True
                }
            },
        },
        "servicePara": {
            "batchSize": {
                "type": "int",
                "default": 4,
                "min": 1,
                "max": 256,
                "unit": "/batch"
            },
            "epochs": {
                "type": "int",
                "default": 10,
                "min": 1,
                "max": 1000,
                "unit": "epoch"
            }
        }
    },
    "ConfigPostprocess": {
        "postProcessPara": {
            "unknownFilter": {
                "description": "將信心度不足的判斷結果存為 Unknown",
                "order": 0,
                "parameters": {
                    "Unknown": {
                        "type": "float",
                        "default": 0.9,
                        "min": 0,
                        "max": 1
                    }
                }
            }
        }
    }
}
