import pynvml
import os
from utils.DatabaseResource import deploymentDb


def append_api_gpu_info(apiConfig, deploymentType):
    """Get server gpu info and append it into return message

    Args:
        apiConfig (dict): config
        deploymentType (str): 'api' or 'download'

    Returns:
        dict: fully config
    """
    pynvml.nvmlInit()
    deviceCount = pynvml.nvmlDeviceGetCount()
    if deploymentType == 'api':
        apiConfig["ConfigParameter"]["parameterPara"]["GPU"]["enums"]["AutoSelect"] = "-1"
        for i in range(deviceCount):
            apiConfig["ConfigParameter"]["parameterPara"]["GPU"]["enums"][str(i)] = str(i)
    elif deploymentType == 'download':
        for i in range(8):
            apiConfig["ConfigParameter"]["parameterPara"]["GPU"]["enums"][str(i)] = str(i)
    return apiConfig

def get_deployment_info(deploymentId, method, info, host, port):
    """Get deployment info

    Args:
        deploymentId (str): deployment ID
        method (str): 'api' or 'download' or 'folder'
        info (str): info
        host (str): host number
        port (str): port number

    Returns:
        tuple[0]: 0: failed, 1: success
        tuple[1]: log message or info
    """
    if method == 'api':
        return 1, f'http://{host}:{port}/deployment/get-prediction-{deploymentId}'
    elif method == 'download':
        return 1, ''
    elif method == 'folder':
        if len(info) == 0:
            return 0, 'Deployment info must be given'
        else:
            info = info.replace('\\', '/')
            return 1, info
    else:
        return 0, 'Wrong deployment method'

def get_url(imgPath, host, port):
    """Get show image URL

    Args:
        imgPath (str): image path
        host (str): host number
        port (str): port number

    Returns:
        str: image URL
    """
    urlSuffix = imgPath.replace('\\', '/')
    url = f'http://{host}:{port}/image/show-img/{urlSuffix}'
    return url

def get_deploy_config_temp(method, task):
    """Get deployment config template

    Args:
        method (str): deployment method
        task (str)  : project task

    Returns:
        dict: deployment config structure
    """
    deployConfigTemp = {
         "deploymentConfig": {
            "ConfigFile" :{
                "filePara": {
                    "file": "api" if method == "api" else "onnx"
                }
            },
            "ConfigParameter": {
                "parameterPara": {
                    "GPU": "0",
                    "batchSize": 4,
                }
            }
         }
    }

    if task == "detection":
        deployConfigTemp["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeModified"] = False
        deployConfigTemp["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeX"] = 416
        deployConfigTemp["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeY"] = 416

    if method == "download" or method == "folder":
        deployConfigTemp["deploymentConfig"]["ConfigParameter"]["parameterPara"]["iniDownload"] = True
        deployConfigTemp["deploymentConfig"]["ConfigParameter"]["parameterPara"]["cfgDownload"] = True

    return deployConfigTemp


def check_img_path(path):
    """Check image path if exists

    Args:
        imgPath (str): image path

    Returns:
        tuple[0]: 0: failed, 1: success
        tuple[1]: log message or info
    """
    ### Check if the path exists
    if not os.path.exists(path):
        return 0, 'The image path is not existed, please use absolute path', ''

    ### Check if the path ends with image format
    format = ['.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff']
    if os.path.splitext(path)[-1].lower() in format:
        return 1, "Get infernece img list success", os.path.split(path)[0]

    ### Check if the path under folder ends with image format
    folderFile = os.listdir(path)
    checkPoint = 0
    for file in folderFile:
        if os.path.splitext(file)[-1].lower() in format:
            checkPoint += 1

    if checkPoint > 0:
        return 1, "Get infernece img list success", path
    else:
        return 0, "The image path does not contain an image", ''


def get_img_list_url(result, urlPath, host, port):
    """Get image list including url

    Args:
        result (dict): prediction result
        imgPath (str): image path
        host (str): host number
        port (str): port number

    Returns:
        List: imgList
    """
    imageList = []
    for pred in eval(result):
        pred["url"] = get_url(f'{urlPath}/{pred["imageName"]}', host, port)

        if not isinstance(pred["result"], list):
            maxKey = max(pred["result"], key=pred["result"].get)
            pred["result"] = {maxKey:pred["result"][maxKey]}

        imageList.append(pred)
    return imageList


def get_img_list(result):
    """Get image list including url

    Args:
        result (dict): prediction result
        imgPath (str): image path
        host (str): host number
        port (str): port number

    Returns:
        List: imgList
    """
    imageList = []
    for pred in eval(result):
        imageList.append(pred)
    return imageList
