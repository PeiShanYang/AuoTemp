from .ModuleLogger import *
"""
logTypes = [LogType.Console, LogType.File, LogType.DB]
level = [LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARNING, LogLevel.ERROR]
"""
Logger.config(
    logTypes=LogType.Console | LogType.File,
    consoleLogConfig=ConsoleLogConfig(
        level=LogLevel.DEBUG,
        ),
    fileLogConfig=FileLogConfig(
        level=LogLevel.DEBUG,
        recordByDate=True,
        dirname="logs",
        suffix="",
        ),
    dbLogConfig=DBLogConfig(
        dbType=DBType.CSV,
        level=LogLevel.DEBUG,
        user="user",
        password="Passw0rd",
        host="127.0.0.1",
        database="db_name",
        port=3306,
        )
    )