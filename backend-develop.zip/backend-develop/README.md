# SALA 2 backend

## 檔案目錄

    │  enter.bat
    │  enter.py
    │  README.md
    │
    ├─input
    │  ├─CustomModel
    │  │      Put_your_customModel_weight_here.txt
    │  │
    │  ├─Data
    │  │      Put_your_data_here.txt
    │  │
    │  └─PretrainedWeight
    │          Put_pretrained_weight_here.txt
    │
    ├─main
    │  │  Config.py
    │  │  ConfigCls.json
    │  │  ConfigDet.json
    │  │  ConfigLoader.py
    │  │  Entrance.py
    │  │  MainCls.py
    │  │  MainDet.py
    │  │
    │  └─Server
    │      dataset.py
    │      deployment.py
    │      deployMethod.py
    │      experiment.py
    │      home.py
    │      image.py
    │      labelTool.py
    │      pipeline.py
    │      project.py
    │      root.py
    │      user.py
    │      __init__.py
    │
    ├─sampleConfig
    │      ConfigCls.json
    │      ConfigDet.json
    │
    └─utils
        ├─AiResource
        │  ├─AiModel
        │  │      alexnet.py
        │  │      cbam_resnet.py
        │  │      csp_resnet.py
        │  │      densenet.py
        │  │      efficientnet.py
        │  │      mnasnet.py
        │  │      mobilenetv3.py
        │  │      regnet.py
        │  │      resnet.py
        │  │      resnetModule.py
        │  │      se_cbam_resnet.py
        │  │      se_resnet.py
        │  │      shufflenetv2.py
        │  │      torchFuture.py
        │  │      vgg.py
        │  │      __init__.py
        │  │
        │  ├─DataAugmentation
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModuleAugmentation
        │  │      │  __init__.py
        │  │      │
        │  │      ├─Cls
        │  │      │      AugmentationMethod.py
        │  │      │      ResizeImage.py
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  ├─DatasetClean
        │  │  │  ConfigDataClean.py
        │  │  │  SelectDatasetCleanMethod.py
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModuleDatasetClean
        │  │      │  AnnotationTransfer.py
        │  │      │  BasicFileProcess.py
        │  │      │  DataSplit.py
        │  │      │
        │  │      ├─Cls
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  ├─Deploy
        │  │  │  ConfigDeployment.py
        │  │  │  SelectDeploymentMethod.py
        │  │  │
        │  │  ├─ModuleDeploy
        │  │  │  │  PyToPyd.py
        │  │  │  │  Tool.py
        │  │  │  │
        │  │  │  ├─Cls
        │  │  │  │      FileSetting.py
        │  │  │  │      __init__.py
        │  │  │  │
        │  │  │  └─Det
        │  │  │          __init__.py
        │  │  │
        │  │  └─package
        │  │      ├─exe
        │  │      │  ├─deployment
        │  │      │  │      Put_your_exe_here
        │  │      │  │
        │  │      │  └─sampleCode
        │  │      │      │  AULOGO.ico
        │  │      │      │  main.py
        │  │      │      │  main.spec
        │  │      │      │
        │  │      │      └─utils
        │  │      │              ConfigSetting.py
        │  │      │              PostprocessMethod.py
        │  │      │              PreprocessMethod.py
        │  │      │              sampleInference.py
        │  │      │              SaveResultMethod.py
        │  │      │              SelectInference.py
        │  │      │
        │  │      └─pyd
        │  │          │  main.py
        │  │          │
        │  │          └─utils
        │  │                  ConfigSetting.py
        │  │                  PostprocessMethod.py
        │  │                  PreprocessMethod.py
        │  │                  sampleInference.py
        │  │                  SaveResultMethod.py
        │  │                  SelectInference.py
        │  │
        │  ├─Evaluation
        │  │  │  ConfigEvaluation.py
        │  │  │  SelectEvaluationMethod.py
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModuleEvaluation
        │  │      │  DrawPlot.py
        │  │      │
        │  │      ├─Cls
        │  │      │      EvaluationMethod.py
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              coco_eval.py
        │  │              coco_utils.py
        │  │              SaveConfusionMatrix.py
        │  │              SaveMapTxt.py
        │  │              __init__.py
        │  │
        │  ├─ModelService
        │  │  ├─PytorchClassificationModel
        │  │  │      ConfigAugmentation.py
        │  │  │      ConfigModelService.py
        │  │  │      ConfigPreprocess.py
        │  │  │      ConfigPytorchModel.py
        │  │  │      CustomDataset.py
        │  │  │      MainProcess.py
        │  │  │      SelectLossFunction.py
        │  │  │      SelectModel.py
        │  │  │      SelectOptimizer.py
        │  │  │      SelectScheduler.py
        │  │  │      SelectTransform.py
        │  │  │      __init__.py
        │  │  │
        │  │  └─PytorchDetectionModel
        │  │      │  ConfigAugmentation.py
        │  │      │  ConfigModelService.py
        │  │      │  ConfigPostprocess.py
        │  │      │  ConfigPreprocess.py
        │  │      │  ConfigPytorchModel.py
        │  │      │  CustomDataset.py
        │  │      │  MainProcess.py
        │  │      │  SelectBackbone.py
        │  │      │  SelectDetectionModel.py
        │  │      │  SelectOptimizer.py
        │  │      │  SelectPostprocess.py
        │  │      │  SelectScaler.py
        │  │      │  SelectScheduler.py
        │  │      │  __init__.py
        │  │      │
        │  │      └─package
        │  │              engine.py
        │  │              group_by_aspect_ratio.py
        │  │              presets.py
        │  │              transforms.py
        │  │              utils.py
        │  │
        │  ├─Others
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModuleOthers
        │  │      │  feature_visualize.py
        │  │      │
        │  │      ├─Cls
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  ├─Postprocess
        │  │  │  ConfigPostprocess.py
        │  │  │  SelectPostprocess.py
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModulePostprocess
        │  │      ├─Cls
        │  │      │      ConfidenceFilter.py
        │  │      │      UnknownFilter.py
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  ├─Preprocess
        │  │  │  __init__.py
        │  │  │
        │  │  └─ModulePreprocess
        │  │      ├─Cls
        │  │      │      normalizeRecord.json
        │  │      │      NormalizeValueCalculate.py
        │  │      │      PreprocessMethod.py
        │  │      │      SelectNormalization.py
        │  │      │      __init__.py
        │  │      │
        │  │      └─Det
        │  │              __init__.py
        │  │
        │  └─ResultStorage
        │      │  ConfigResultStorage.py
        │      │  SelectStorageMethod.py
        │      │  __init__.py
        │      │
        │      └─ModuleResultStorage
        │          │  CsvModule.py
        │          │  __init__.py
        │          │
        │          ├─Cls
        │          │      SaveResult.py
        │          │      SaveWeight.py
        │          │      __init__.py
        │          │
        │          └─Det
        │                  drawBox.py
        │                  SaveDetResult.py
        │                  __init__.py
        │
        ├─ApiResource
        │      datasetUtil.py
        │      projectUtil.py
        │      __init__.py
        │
        ├─DatabaseResource
        |      databaseModule
        |      experimentDb.py
        |      labelToolDb.py
        |      projectDb.py
        |      __init__.py
        |
        └─LoggerResource
                │  ConfigLogger.py
                │
                └─ModuleLogger
                  │      ConsoleLogger.py
                  │      FileLogger.py
                  │      LoggerFunc.py
                  │      __init__.py
                  │
                  └─DBLogger
                          Base.py
                          CsvLogger.py
                          MariaLogger.py
                          __init__.py



## Edit record
- 每次改版，請延續此表格紀錄修改內容

| Branch name          | Push Date     | Editor              | server  | comment                             |
|----------------------|---------------|---------------------|---------|-------------------------------------|
| OtisChang_20220915   | 2022.09.15    | OtisChang   |  39394  | 1. SALA 2 初版<br> 2. 取自瑕疵檢測模組 v2.1.2<br> 3. 已加入 api 模版於 ./main/Server<br> 4. ./main/Entrance.py 建立 blueprint  |
| OtisChang_20221024   | 2022.10.24    | OtisChang   |  39394  | 1. 同步瑕疵檢測模組版本至 v2.1.4 |
| OtisChang_20221024   | 2022.11.11    | OtisChang   |  39394  | 1. 同步瑕疵檢測模組版本至 v2.1.4 (已修復部分 bug) |
| OtisChang_20221024   | 2022.12.09    | OtisChang   |  39394  | 1. workflow 到專案確認頁，假資料串接完成，部分 API 修改完成<br> 2. GaussianBlur 改成 enums<br> 3. cls_save_img_label、det_save_img_label 的 bug 修復<br> 4. label_class 加 dataset_id 欄位，修改相關 API |
| BlackyChang_20221206 | 2022.12.09    | BlackyChang |  39394  | 1. 新增 experimentDb 檔案 <br> 2. experiment/get_list 與 experiment/create API 開發完成 |
| YingYYWang_20221208  | 2022.12.12    | YY, OtisChang       |  39394  | 1. YY 完成 project/add-favorite, get-list, get-info <br> 2. OtisChang 完成 merge |
| BlackyChang_20221206 | 2022.12.16    | BlackyChang |  39394  | 1. pipeline/get_list API 開發完成<br> 2. deployment/create API 開發完成 |
| OtisChang_20221024   | 2022.12.19    | YY, OtisChang       |  39394  | 1. YY 完成 dataset/cls-upload, get-split-rate <br> 2. OtisChang 完成 merge |
| ShanYang_20221219    | 2022.12.20    | BlackyChang, ShanYang, OtisChang | 39394         | 1. BlackyChang 完成 check_exist 相關<br> 2. ShanYang 完成 project/get-list, experiment/get-list, experiment/preview-list, pipeline/get-list, pipeline/preview-list, deployment/get-list, deployment/preview-list|
| YingYYWang_20221222  | 2023.01.03    | YY          |  39394  | 1. YY 完成 dataset/dataset/set-split-rate, project/set-abstract, project/delete, experiment/add-favorite|
| OtisChang_20221024   | 2023.01.03    | OtisChang   |  39394  | 1. resolve conflict wuth YingYYWang_20221222, OtisChang_20221024, develop<br> 2. add get-dataset-structure (chad) into code|
| BlackyChang_20221206 | 2023.01.04    | BlackyChang |  39394  | 1. dataset/det-upload API 開發完成 |
| YingYYWang_20221222  | 2023.01.06    | YY          |  39394  | 1. YY 完成 experiment/set-configs, experiment/check, experiment/select-key |
| OtisChang_20221024   | 2023.01.10    | Chad, OtisChang |  39394  | 1. Chad 完成 dataset/cls_get_dataset_structure, dataset/det_get_dataset_img_structure, det_get_dataset_ant_structure/select-key 相同程式碼整併 2. Otis 完成更版, 確認合法影像格式並統一 |
| OtisChang_20221024   | 2023.01.12    | OtisChang   |  39394  | 1. project/check 的 abstract, islabel, splitRate 改為真資料<br> 2. project/get-info abstract, splitRate改為真資料<br> 3. labelTool/cls_save_img_label 和 labelTool/det_save_img_label 加上儲存 labeled |
| BlackyChang_20221206 | 2023.01.13    | BlackyChang |  39394  | 1. pipeline/delete API 開發完成<br> 2. deployment/delete API 開發完成<br> 3. project/create API 開發完成<br> 4. experiment/create API 開發完成|
| OtisChang_20221024   | 2023.01.18    | OtisChang   |  39394  | 1. get_new_image_num_of_split 不符合 coding rule，已改小寫駝峰<br> 2. project/get-info、project/check 的 train / valid / test 改成 Train / Valid / Test<br> 3. experiment/check 的 CenterCrop 回傳的 default 從 [1, 1] 改回 [224, 224]<br> 4. ApiResource 中的 DetExpConfig.json schedulerPara 移回 ConfigModelService 中|
| BlackyChang_20221206 | 2023.01.20    | BlackyChang |  39394  | 1. pipeline/create API 開發完成<br> 2. deployment/create API 開發完成|
| YingYYWang_20221222  | 2023.02.01    | YY          |  39394  | 1. experiment/set-abstract、pipeline/add-favorite、pipeline/set-abstract、deployment/add-favorite、deployment/set-abstract 開發完成<br> 2. experiment/check: I/O 格式更動<br> 3. dataset/set-split-rate: 更改成class個別切分 |
| BlackyChang_20221206 | 2023.02.03    | BlackyChang |  39394  | 1. pipeline/get-gpu API 開發完成<br> 2. pipeline/set-gpu API 開發完成|
| OtisChang_20221024   | 2023.02.06    | OtisChang   |  39394  | 1. experiment/check islabel 改布林、切分比例為設定之前回傳 0<br> 2. det 切分資料集後，若有 0 張情況發生，錯誤訊息顯示 class 為 None 問題已修正<br> 3. 資料庫清理，真資料串接<br> 4. 上下界格式從 "children" -> "boundary"，已修改為 shan 版本 |
| OtisChang_20221024   | 2023.02.07    | OtisChang   |  39394  | 1. 修改 DB 的 UID 產生方式，時間戳記到 $10^{-9}$ 秒，避免重複 ID 出現導致資料儲存遺漏 <br> 2. 瑕疵檢測模組由 v2.1.4 更換為 v2.4.0，有更動的部分包括 main/Config.py、main/ConfigLoader.py、main/MainDet.py、main/ConfigDet.json、sampleConfig/ConfigDet.json、utils/AiResource |
| YingYYWang_20221222  | 2023.02.10    | YY          |  39394  | 1. experiment/get-info、experiment/export-key、pipeline/check 開發完成 |
| OtisChang_20221024   | 2023.02.14    | OtisChang   |  39394  | 1. project/get-list、experiment/get-list、pipeline/get-list、deployment/get-list 都需要依照時間排序<br> 2. 切分資料集若沒有成功，應把 project 表的比例清成 0 |
| OtisChang_20221024   | 2023.02.20    | OtisChang   |  39394  | 1. experiment/set-config、experiment/check 跳 500 error 已暫時解決<br> 2. pipeline/check 傳值錯誤 和 gpu=None 時狀況處理: Check pipeline failed / an integer is required (got type NoneType)<br> 3. check_name_existed 所有相關function，邏輯修正與流程優化<br> 4. project/get-info、experiment/get-info API 功能移除<br>5. DetExpConfig.json 模板建立 |
| OtisChang_20221024   | 2023.03.01    | OtisChang   |  39394  | 1. 新增 ProcessMonitor.py, ProcessMonitorDb.py, TestProcess.py, TrainProcess.py |
| YingYYWang_20221222  | 2023.03.03    | YY          |  39394  | 1. pipeline/run、load_db_pipeline() 開發完成 |
| OtisChang_20221024   | 2023.03.06    | OtisChang   |  39394  | 1. enter.py 入口程式調整<br>2. ConfigLoader.py 改帶入 config 路徑進行讀取<br>3. MainCls.py, MainDet.py 改傳 config 路徑<br>4. ProcessMonitor.py, TestProcess.py, TrainProcess.py 移出 main 資料夾，同入口程式之層級，確保 import 正確性<br>5.experiment 中 is 改為 == |
| OtisChang_20221024   | 2023.03.09    | OtisChang   |  39394  | 1. labelToolDb.py 生成 id 更新為 28 碼<br> 2. experiment/get_model_description 完成<br> 3. utils/ApiResource/ModelDescription 完成<br> 4. SampleConfig/SampleConfigCls.json 完成|
| YingYYWang_20221222  | 2023.03.09    | YY          |  39394  | 1. save_result() 第一部分已完成，剩餘Test_result.csv需寫入 、load_db_pipeline() 移除accordingTable變數 |
| OtisChang_20221024   | 2023.03.13    | OtisChang   |  39394  | 1. rename 若和原名稱相同，不做修正，允許往下一步<br> 2. ClsExpConfig.py、DetExpConfig.py 模型名稱更新；ClsExpConfig.json、DetExpConfig.json 更新 default model 名稱<br> 3. 產生 cls、det 的 Sample config|
| YingYYWang_20221222  | 2023.03.24    | YY          |  39394  | 1. save_result() 已完成 (Test_result.csv寫入)<br> 2. 新增insert_value()，可一次insert多筆資料到DB|
| OtisChang_20221024   | 2023.04.06    | OtisChang   |  39394  | 1. 監控與串接瑕疵檢測模組程式 (ProcessMonitor, ProcessMonitorDb, TestProcess, TrainProcess)<br> 2. 確認命名規則<br> 3. generate_uid() 加入 time.sleep(0.0000000001), 因為 28 碼依然有 ID 重複問題<br> 4. 解決重新上傳 dataset 時, 舊的 label_class 無法正常刪除的問題|
| YingYYWang_20221222  | 2023.04.12    | YY          |  39394  | 1. 修正 dataset/cls-upload API:<br> i.依照other(path)與train_val_test(path)函式提供的合法資料集與檔案名稱進行處理，並將相關資料寫入資料庫<br> ii.改成一次insert多筆資料到 DB|
| OtisChang_20221024   | 2023.04.17    | OtisChang   |  39394  | 1. 監控與串接瑕疵檢測模組程式 (ProcessMonitor, ProcessMonitorDb, TestProcess, TrainProcess, processDb)|
| OtisChang_20221024   | 2023.04.21    | OtisChang   |  39394  | 1. Test_result儲存 DB 異常: sampleConfig 調整及檢查 (aug 開水平、垂直翻轉、SGD 開 nesterov、batch: 8 -> 4)、若沒有結果輸出，就不執行寫入 DB 動作<br>2. 監控程式 bug 修復與改善 6/7<br> 3. 使用者測試 bug 修復與改善 5/6<br>4. get_process_num 中，若 pipeline 的 status 是 -4 不可算進排隊的 process 中 修改完成<br>5. processMonitorDb.py 中 deal_result_csv 的 timeCount 已移除|
| YingYYWang_20221222  | 2023.04.21    | YY          |  39394  | 1. 完成 project/created、experiment/created、pipeline/created<br> 2. 將 pipeline/get-list回傳的status改成真實值|
| YingYYWang_20221222  | 2023.04.25    | YY          |  39394  | 1. 完成 pipeline/check |
| OtisChang_20221024   | 2023.04.26    | OtisChang   |  39394  | 1. 監控程式 weakly reference 問題解決<br>2. insert_value 和 insert_multiple_value 整併，相關 insert_value 修改<br>3. project/check, experiment/check, pipeline/check 新增 created|
| OtisChang_20221024   | 2023.05.11    | OtisChang   |  39394  | 1. detection config 解碼錯誤問題解決<br>2. check 加入 isSplit, created 作為步驟確認參數<br>3.解決非法資料集 usingDetAnno 被判為合法的問題<br>4. 完成監控程式<br>5. 解決 detection 產生 annotation 檔錯誤|
| OtisChang_20221024   | 2023.05.17    | OtisChang   |  39394  | 1. 解決 MariaDB.Error:2014 (HY000): Commands out of sync; you can’t run this command now -> created 中重複檢查的動作進行註解<br>2. check_exist 語法修改<br>3. 解決 pipeline/check 訓練異常中斷但無法顯示給前端的問題|
| YingYYWang_20221222  | 2023.05.23    | YY          |  39394  | 1. 完成 API註解 |
| OtisChang_20221024   | 2023.05.25    | OtisChang   |  39394  | 1. 標記工具: 新增每分鐘一次週期性儲存動作，週期性 isLabel = 0；使用者確認 isLabel = 1<br>2. 建立訓練: GPU 被其他非 SALA 的 process 卡住，需要可以通知 user 5/5<br>3. 連線資訊寫進設定檔供使用者<br>4. 流程優化: ProcessMonitor 對地端操作改為對 DB 操作|
| OtisChang_20221024   | 2023.06.06    | OtisChang   |  39394  | 1. 解決訓練資訊頁與列表顯示進度不一致問題<br>2. 解決訓練資訊頁: 錯誤訊息一直跳的問題 -> 瑕疵檢測模組 accuracy = 0 導致寫入 json 時缺少 key 值，而後續 api 取值時因取不到對應 key 值所以一直跳錯誤<br>3. 摘要過長時，會跳錯誤訊息提醒使用者<br>4.因應中英翻譯整理，再精簡部分語句 |
| TomWCHsu_20230606    | 2023.06.08    | TomWCHsu   |  39394  | 1. 完成 deployment/select_method|
| OtisChang_20221024   | 2023.06.08    | OtisChang   |  39394  | 1. 設定資料集比例的提示語句中翻英修改<br>2. 回傳路徑修改為相對路徑<br>3. 瑕疵檢測模組更新為 V2.5.1 (num_workers 加入 config) |
| OtisChang_20221024   | 2023.06.09    | OtisChang   |  39394  | 1. num_workers 加入 BasicSetting.ini 檔中，並修改 TrainProcess.py，將此參數加入到 config 中 |
| OtisChang_20221024   | 2023.06.14    | OtisChang   |  39394  | 1. get-gpu 的 available 修改<br>2. deployment 開發 4 支 get 相關 API 及 created |
| TomWCHsu_20230606    | 2023.06.16    | TomWCHsu   |  39394  | 1. 完成 deployment/set-config<br>2. 完成 deployment/check|
| OtisChang_20221024   | 2023.06.16    | OtisChang   |  39394  | 1. experiment/check 移除資料檢查，改善 check 同時 call 的異常問題<br>2. DetDeployApiConfig.py 和 DetDeployDownloadConfig.py 修改 inputSize 的結構<br>3.  deployment 4 支 get 修改 gpu 的設定方式|
| OtisChang_20221024   | 2023.06.20    | OtisChang   |  39394  | 1. deployment/select-method 優化，並新增將 api URL 存入 DB 中<br>2. deployment/check 補相關回傳值<br>3. get_url 從 deployment.py 中移到 deploymentUtil.py<br>4. deployment_Id 改成 deploymentId|
| TomWCHsu_20230606    | 2023.06.21    | TomWCHsu   |  39394  | 1. 新增 deployment/select-method 加入 deployment config template 寫入db|
| OtisChang_20221024   | 2023.07.11    | OtisChang   |  39394  | 1. 加入 inference 於監控程式中<br>2. 串接測試中|
