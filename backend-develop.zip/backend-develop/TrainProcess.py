import argparse
import configparser
import shutil
import os
import jwt
import json
import main.MainCls as MainCls
import main.MainDet as MainDet
from utils.DatabaseResource import processDb


processDbHandler = processDb.ProcessDb()
sampleConfigCls = './sampleConfig/SampleConfigCls.json'
sampleConfigDet = './sampleConfig/SampleConfigDet.json'
modelTransform = './utils/LocalFileResource/ModelTransform.json'

def create_folder(folderPath):
    """ create pipeline folder

    Args:
        folderPath (str): folder path
    """
    try:
        if os.path.isdir(folderPath):
            shutil.rmtree(folderPath)
        os.makedirs(folderPath)
    except Exception as err:
        raise Exception('(TrainProcess) create folder failed: ', err)


def dataset_prepare(pipelineId, task, pipelinePath):
    """prepare local dataset for ai module
    cls:
        1. 取得 dataset_id: 利用 pipelineId 取得 dataset_id
        2. 取得 classList 對應表和建立資料夾: 利用 dataset_id 取得 classList {"class_id": 'class_name', ...}, 並建立所有資料夾 dataset/(Train, Valid, Test)/(A, B ....)
        3. 取得每張圖 label: 併表 image 和 label, 並利用 dataset_id 取得 class_id, image_path, task
        4. 複製圖片: 將圖片從 image_path 複製到 {pipelinePath}/dataset/{splitDataset}/classList["class_id"]/image_name
    det:
        1. 取得 dataset_id: 利用 pipelineId 取得 dataset_id
        2. 取得 classList 對應表和建立資料夾: 利用 dataset_id 取得 classList {"class_id": 'class_name', ...}, 建立所有資料夾 dataset/(Train, Valid, Test)/(Image, Annotation)
        3. 取得每張圖 label: 表 image left join 表 label, 並利用 dataset_id 取得 image_name, image_path, task, x1, y1, x2, y2
        4. 複製圖片: 將圖片從 image_path 複製到 {pipelinePath}/dataset/{splitDataset}/Image
        5. 建立標記檔: 在 {pipelinePath}/dataset/{splitDataset}/Annotation 建立相同檔名的標記檔
    Args:
        pipelineId (str): pipeline ID
        task (str): classification or detection
        pipelinePath (str): pipeline path
    """
    try:
        datasetId = processDbHandler.get_dataset_id(pipelineId)
        classList = processDbHandler.get_label_class(task, datasetId)
        if task == 'classification':
            ### create folder
            for splitDataset in ['Train', 'Valid', 'Test']:
                for className in classList.values():
                    create_folder(os.path.join(pipelinePath, 'dataset', splitDataset, className))
            ### get all image label information
            labelInfoList = processDbHandler.get_cls_label_info(datasetId)
            # print(labelInfoList)

            ### duplicate image and save into correct folder
            for labelInfo in labelInfoList:
                shutil.copyfile(labelInfo["image_pth"],
                                os.path.join(pipelinePath, 'dataset', labelInfo["task"], classList[labelInfo["class_id"]], labelInfo["image_name"]))
        elif task == 'detection':
            ### create folder
            for splitDataset in ['Train', 'Valid', 'Test']:
                for className in classList.values():
                    create_folder(os.path.join(pipelinePath, 'dataset', splitDataset, 'Image'))
                    create_folder(os.path.join(pipelinePath, 'dataset', splitDataset, 'Annotation'))
            ### get all image label information: image.image_name, image.image_pth, image.task, label.class_id, label.x1, label.y1, label.x2, label.y2
            labelInfoList = processDbHandler.get_det_label_info(datasetId)

            ### duplicate image and save into correct folder
            for labelInfo in labelInfoList:
                if not os.path.isfile(os.path.join(pipelinePath, 'dataset', labelInfo["task"], 'Image', labelInfo["image_name"])):
                    shutil.copyfile(labelInfo["image_pth"],
                                    os.path.join(pipelinePath, 'dataset', labelInfo["task"], 'Image', labelInfo["image_name"]))
                antPath = os.path.join(pipelinePath, 'dataset', labelInfo["task"], 'Annotation', os.path.splitext(labelInfo["image_name"])[0]+'.txt')
                with open(antPath, 'a') as f:
                    if sum([ant != None for ant in [labelInfo["class_id"], labelInfo["x1"], labelInfo["y1"], labelInfo["x2"], labelInfo["y2"]]]) == 5:
                        f.write(classList[labelInfo["class_id"]]+' '+str(int(labelInfo["x1"]))+' '+str(int(labelInfo["y1"]))+' '+str(int(labelInfo["x2"]))+' '+str(int(labelInfo["y2"])))
                        f.write('\n')
    except Exception as err:
        raise Exception('(TrainProcess) prepare dataset failed: ', err)


def decode_key(experimentKey):
    """decode experiment key into json format

    Args:
        experimentKey (str): experiment key

    Raises:
        Exception: raise error if decode experiment key failed

    Returns:
        userConfig: user config
    """
    try:
        key = 'AUO-SALA2'
        algorithms = 'HS256'
        userConfig = jwt.decode(experimentKey, key, algorithms=[algorithms])
        return userConfig
    except Exception as err:
        raise Exception('(TrainProcess) decode experiment key failed: ', err)


def get_model_transform(modelTransform, modelSetting, task):
    """get model name transform dict

    Args:
        modelTransform (str): json file of model transform
        modelSetting (dict): {
            "structure": "auo_unrestricted_powerful_model_a",
            "pretrained": 1
        }
        task (str): classification or detection

    Raises:
        BaseException: raise error if read json file failed

    Returns:
        modelPara (dict): model transform dictionary
    """
    try:
        with open(modelTransform) as configFile:
            modelTransformDict = json.load(configFile)
    except:
        raise Exception('(TrainProcess) get model transform: json file is not existed')
    if task == 'classification':
        modelPara = {
            "structure": modelTransformDict[modelSetting["structure"]],
            "pretrained": modelSetting["pretrained"]
        }
    elif task == "detection":
        modelPara = {
            "modelStructure": modelTransformDict[modelSetting["structure"]],
            "modelPretrained": modelSetting["pretrained"]
        }
    return modelPara


def deal_with_special_case(data, pipelineId, pipelinePath, task):
    """deal with special case of config
    **********************
    1. read from database:
        projectId, experimentId, cudaDevice, classNameList
    **********************
    2. special case both in cls and det:
        basicSettingPara, outputPath, optimizerPara, schedulerPara, cudaDevice,
        trainPath, validPath, model
    **********************
    3. special case in cls
        RandomShear, schedulerPara, unknownFilter
    **********************
    4. special case in det
        schedulerPara, nms, lossFunctionPara

    Args:
        data (dict): original config
        pipelineId (str): pipeline ID
        pipelinePath (str): pipeline path
        task (str): classification or detection

    Returns:
        dict: new config
    """
    try:
        ### get information from database & model transform from json file
        basicSettingPara = processDbHandler.get_basic_info(pipelineId)
        cudaDevice = processDbHandler.read_value_with_cond('pipeline', 'gpu_id', f'pipeline_id="{pipelineId}"')
        numWorkers =processDbHandler.read_value_with_cond('basic_setting', 'num_workers', f'1=1')
        modelPara = get_model_transform(modelTransform, userConfig["ConfigPytorchModel"]["modelPara"]["model"], 'classification')

        ### special case both in cls and det
        data["Config"]["basicSettingPara"].update(basicSettingPara)
        data["Config"]["privateSettingPara"]["outputPath"] = pipelinePath
        data["ConfigModelService"]["optimizerPara"]["SGD"]["switch"] = 0 # clear the default value
        data["ConfigModelService"]["optimizerPara"][userConfig["ConfigModelService"]["optimizerPara"]["optimizer"]]["switch"] = 1
        data["ConfigPytorchModel"]["servicePara"]["cudaDevice"] = int(cudaDevice)
        data["ConfigPytorchModel"]["servicePara"]["numWorkers"] = int(numWorkers)
        data["ConfigPytorchModel"]["pathPara"]["trainPath"] = os.path.join(pipelinePath, 'dataset', 'Train')
        data["ConfigPytorchModel"]["pathPara"]["validPath"] = os.path.join(pipelinePath, 'dataset', 'Valid')
        data["ConfigPytorchModel"]["modelPara"]["model"].update(modelPara)
        del data["ConfigModelService"]["optimizerPara"]["optimizer"]
        del data["ConfigModelService"]["schedulerPara"]["scheduler"]

        ### special case in cls
        if task == 'classification':
            data["ConfigAugmentation"]["augmentationPara"]["RandomShear"]["parameters"]["shear"] = userConfig["ConfigAugmentation"]["augmentationPara"]["RandomShear"]["parameters"]["shearHorizontal"] + userConfig["ConfigAugmentation"]["augmentationPara"]["RandomShear"]["parameters"]["shearVertical"]
            data["ConfigModelService"]["schedulerPara"]["stepLR"]["switch"] = 0 # clear the default value
            data["ConfigModelService"]["schedulerPara"][userConfig["ConfigModelService"]["schedulerPara"]["scheduler"]]["switch"] = 1
            data["ConfigPostprocess"]["postProcessPara"]["unknownFilter"]["parameters"]["threshold"] = userConfig["ConfigPostprocess"]["postProcessPara"]["unknownFilter"]["parameters"]
            for key in userConfig["ConfigPostprocess"]["postProcessPara"]["unknownFilter"]["parameters"].keys():
                del data["ConfigPostprocess"]["postProcessPara"]["unknownFilter"]["parameters"][key]
            del data["ConfigAugmentation"]["augmentationPara"]["RandomShear"]["parameters"]["shearHorizontal"]
            del data["ConfigAugmentation"]["augmentationPara"]["RandomShear"]["parameters"]["shearVertical"]
        ### special case in det
        elif task == 'detection':
            data["ConfigModelService"]["schedulerPara"]["multiStepLR"]["switch"] = 0 # clear the default value
            data["ConfigModelService"]["schedulerPara"][userConfig["ConfigModelService"]["schedulerPara"]["scheduler"]]["switch"] = 1
            data["ConfigPostprocess"]["postProcessPara"]["nms"]["iouTreshold"] = userConfig["ConfigPostprocess"]["postProcessPara"]["nms"]["parameters"]["iouTreshold"]
            del data["ConfigPostprocess"]["postProcessPara"]["nms"]["parameters"]
            del data["ConfigPytorchModel"]["modelPara"]["model"]
        return data
    except Exception as err:
        raise Exception('(TrainProcess) deal with special case failed: ', err)


def update_with_user_config(data, userConfig):
    """update data with userConfig

    Args:
        data (dict): sample config
        userConfig (dict): user input config

    Returns:
        dict: new config
    """
    try:
        for key, value in userConfig.items():
            if isinstance(value, dict):
                data[key] = update_with_user_config(data.get(key, {}), value)
            else:
                data[key] = value
        return data
    except Exception as err:
        raise Exception('(TrainProcess) update with user config failed: ', err)


def generate_config(pipelineId, task, pipelinePath, userConfig):
    """generate config.json from user config
    1. open sampleConfig file according to input task
    2. directly update config by userConfig
    3. deal with special case
    4. save config.json

    Args:
        pipelineId (str): pipeline ID
        task (str): classification
        pipelinePath (str): pipeline path
        userConfig (dict): user config

    """
    try:
        if task == 'classification':
            if not os.path.isfile(sampleConfigCls):
                raise Exception('sample config of classification is not existed')
            inputFile = open(sampleConfigCls)
            configPath = os.path.join(pipelinePath, 'ConfigCls.json')

        elif task == 'detection':
            if not os.path.isfile(sampleConfigDet):
                raise Exception('sample config of detection is not existed')
            inputFile = open(sampleConfigDet)
            configPath = os.path.join(pipelinePath, 'ConfigDet.json')

        data = json.load(inputFile)
        data = update_with_user_config(data, userConfig)
        data = deal_with_special_case(data, pipelineId, pipelinePath, task)
        inputFile.close()
        with open(configPath, 'w') as outputFile:
            json.dump(data, outputFile, indent=4)
        return configPath

    except Exception as err:
        raise Exception('(TrainProcess) generate config failed: ', err)


def run_ai_module(task, configPath):
    """run AI module

    Args:
        task (str): classification or detection
        configPath (str): config json file path
    """
    try:
        if task == 'classification':
            MainCls.main(configPath)
        elif task == 'detection':
            MainDet.main(configPath)
    except Exception as err:
        raise Exception('(TrainProcess) ai module error: ', err)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-r", "--root", default='./pipelineOutput', help = "pipeline output root")
    parser.add_argument("-o", "--outputPath", default='./pipelineOutput', help = "full pipeline output path")
    parser.add_argument("-p", "--pId", default='pipeline_2023021512482123514535145900', help = "pipeline ID")
    parser.add_argument("-t", "--task", default='classification', help = "project task (classification or detection)")
    parser.add_argument("-k", "--key", default='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJDb25maWdQcmVwcm9jZXNzIjp7InByZXByb2Nlc3NQYXJhIjp7IkdhdXNzaWFuQmx1ciI6eyJvcmRlciI6MCwicGFyYW1ldGVycyI6eyJrZXJuZWxTaXplIjpbMywzXSwic2lnbWEiOjF9fSwiQnJpZ2h0bmVzcyI6eyJvcmRlciI6MCwicGFyYW1ldGVycyI6eyJicmlnaHRuZXNzIjoxfX0sIkNvbnRyYXN0Ijp7Im9yZGVyIjowLCJwYXJhbWV0ZXJzIjp7ImNvbnRyYXN0IjoxfX0sIlNhdHVyYXRpb24iOnsib3JkZXIiOjAsInBhcmFtZXRlcnMiOnsic2F0dXJhdGlvbiI6MX19LCJIdWUiOnsib3JkZXIiOjAsInBhcmFtZXRlcnMiOnsiaHVlIjowfX19fSwiQ29uZmlnQXVnbWVudGF0aW9uIjp7ImF1Z21lbnRhdGlvblBhcmEiOnsiUmFuZG9tSG9yaXpvbnRhbEZsaXAiOnsib3JkZXIiOjEsInBhcmFtZXRlcnMiOnsicHJvYmFiaWxpdHkiOjAuNX19LCJSYW5kb21WZXJ0aWNhbEZsaXAiOnsib3JkZXIiOjIsInBhcmFtZXRlcnMiOnsicHJvYmFiaWxpdHkiOjAuNX19LCJSYW5kb21FcXVhbGl6ZSI6eyJvcmRlciI6MCwicGFyYW1ldGVycyI6eyJwcm9iYWJpbGl0eSI6MC41fX0sIlJhbmRvbVBvc3Rlcml6ZSI6eyJvcmRlciI6MCwicGFyYW1ldGVycyI6eyJwcm9iYWJpbGl0eSI6MC41LCJiaXRzIjo0fX0sIlJhbmRvbVNvbGFyaXplIjp7Im9yZGVyIjowLCJwYXJhbWV0ZXJzIjp7InByb2JhYmlsaXR5IjowLjUsInRocmVzaG9sZCI6MTI3fX0sIlJhbmRvbUFkanVzdFNoYXJwbmVzcyI6eyJvcmRlciI6MCwicGFyYW1ldGVycyI6eyJwcm9iYWJpbGl0eSI6MC41LCJzaGFycG5lc3NGYWN0b3IiOjJ9fSwiUmFuZG9tQXV0b2NvbnRyYXN0Ijp7Im9yZGVyIjowLCJwYXJhbWV0ZXJzIjp7InByb2JhYmlsaXR5IjowLjV9fSwiUmFuZG9tRXJhc2luZyI6eyJvcmRlciI6MCwicGFyYW1ldGVycyI6eyJwcm9iYWJpbGl0eSI6MC41LCJzY2FsZSI6WzAuMDIsMC4zM10sInJhdGlvIjpbMC4zLDMuM10sInZhbHVlIjpbMCwwLDBdfX0sIlJhbmRvbUJyaWdodG5lc3MiOnsib3JkZXIiOjAsInBhcmFtZXRlcnMiOnsicHJvYmFiaWxpdHkiOjAuNSwiYnJpZ2h0bmVzcyI6WzEsMV19fSwiUmFuZG9tQ29udHJhc3QiOnsib3JkZXIiOjAsInBhcmFtZXRlcnMiOnsicHJvYmFiaWxpdHkiOjAuNSwiY29udHJhc3QiOlsxLDFdfX0sIlJhbmRvbVNhdHVyYXRpb24iOnsib3JkZXIiOjAsInBhcmFtZXRlcnMiOnsicHJvYmFiaWxpdHkiOjAuNSwic2F0dXJhdGlvbiI6WzEsMV19fSwiUmFuZG9tSHVlIjp7Im9yZGVyIjowLCJwYXJhbWV0ZXJzIjp7InByb2JhYmlsaXR5IjowLjUsImh1ZSI6WzAsMF19fSwiUmFuZG9tSW9VQ3JvcCI6eyJvcmRlciI6MCwicGFyYW1ldGVycyI6eyJ0cmlhbHMiOjQwfX0sIlNjYWxlSml0dGVyIjp7Im9yZGVyIjowLCJwYXJhbWV0ZXJzIjp7InRhcmdldFNpemUiOlsxMjgsMTI4XSwic2NhbGVSYW5nZSI6WzAuMSwyXSwiaW50ZXJwb2xhdGlvbiI6IkJJTElORUFSIn19LCJGaXhlZFNpemVDcm9wIjp7Im9yZGVyIjowLCJwYXJhbWV0ZXJzIjp7InNpemUiOlsxMjgsMTI4XSwiZmlsbCI6WzAsMCwwXSwicGFkZGluZ01vZGUiOiJjb25zdGFudCJ9fSwiUmFuZG9tU2hvcnRlc3RTaXplIjp7Im9yZGVyIjowLCJwYXJhbWV0ZXJzIjp7ImludGVycG9sYXRpb24iOiJCSUxJTkVBUiJ9fX19LCJDb25maWdNb2RlbFNlcnZpY2UiOnsibG9zc0Z1bmN0aW9uUGFyYSI6e30sImxlYXJuaW5nUmF0ZVBhcmEiOnsibGVhcm5pbmdSYXRlIjowLjAwMX0sIm9wdGltaXplclBhcmEiOnsib3B0aW1pemVyIjoiU0dEIn0sInNjaGVkdWxlclBhcmEiOnsic2NoZWR1bGVyIjoibXVsdGlTdGVwTFIifX0sIkNvbmZpZ1B5dG9yY2hNb2RlbCI6eyJtb2RlbFBhcmEiOnsibW9kZWwiOnsic3RydWN0dXJlIjoiYXVvX29uZXN0YWdlX2FudGlkZWdlbmVyYXRpb25fbW9kZWwiLCJwcmV0cmFpbmVkIjoxfX0sInNlcnZpY2VQYXJhIjp7ImJhdGNoU2l6ZSI6NCwiZXBvY2hzIjoxMH19LCJDb25maWdQb3N0cHJvY2VzcyI6eyJwb3N0UHJvY2Vzc1BhcmEiOnsibm1zIjp7Im9yZGVyIjoxLCJwYXJhbWV0ZXJzIjp7ImlvdVRyZXNob2xkIjowLjN9fX19fQ.CPXck2KVg1DYjFoiDcxFVpR7AFbgEEaQv-ryA9K0gRM', help = "experiment key")
    args = parser.parse_args()

    userConfig = decode_key(args.key)
    configPath = generate_config(args.pId, args.task, args.outputPath, userConfig)
    dataset_prepare(args.pId, args.task, args.outputPath)
    run_ai_module(args.task, configPath)
