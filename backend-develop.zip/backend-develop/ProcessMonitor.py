import threading
import time, os
import pynvml
import shutil
from utils.LoggerResource.ConfigLogger import Logger
from subprocess import Popen, PIPE
from utils.DatabaseResource import processMonitorDb

# state
#  null            : Unassign
#  positive integer: Wait for train or deployment
#  0               : Done
# -1               : Train
# -2               : Wait for test
# -3               : Test
# -4               : Incorrect finish
# -5               : Inference
# -6               : Deployment (onnx)
# -7               : Deployment (exe)
# -8               : Deployment pyd

monitorDbHandler = processMonitorDb.ProcessMonitorDb()

def check_basic_setting():
    """Check and get basic setting information

    Returns:
        info['monitor_time']: monitor time
        info['gpu_usage_threshold']: gpu usage threshold
        info['output_root']: output root
    """
    ok, info = monitorDbHandler.get_basic_setting()
    if not ok:
        Logger.responseError(0, info)
        exit()
    return info['monitor_time'], info['gpu_usage_threshold'], info['output_root']


def create_folder(folderPath):
    """ create pipeline folder

    Args:
        folderPath (str): folder path
    """
    if os.path.isdir(folderPath):
        shutil.rmtree(folderPath)
    os.makedirs(folderPath)


def save_error_log(filePath, error):
    """save error message into error.txt

    Args:
        filePath (str): pipeline output path
        error (str): error message
    """
    errorFile = os.path.join(filePath, 'error.txt')
    with open(errorFile, 'w') as f:
        f.write(error)


def process(processState, outputRoot, pipelineId, projectTask, experimentKey, outputPath, deploymentId=None):
    """create and run process according to processState

    Args:
        processState (str): Train or Test
        outputRoot (str): output root path
        pipelineId (str): pipeline ID from database
        projectTask (str): project task
        experimentKey (str): experiment key to get config
        outputPath (str): pipeline output path
    """
    try:
        if processState == 'Train':
            create_folder(outputPath)
            _, stderr = Popen(f"python ./TrainProcess.py -r {outputRoot} -o {outputPath} -p {pipelineId} -t {projectTask} -k {experimentKey}",
                              stdout=PIPE, stderr=PIPE).communicate()

        elif processState == 'Test':
            _, stderr = Popen(f"python ./TestProcess.py -r {outputRoot} -o {outputPath} -p {pipelineId} -t {projectTask} -k {experimentKey}",
                              stdout=PIPE, stderr=PIPE).communicate()

        elif processState == 'Inference' or processState == 'Deployment':
            create_folder(outputPath)
            _, stderr = Popen(f"python ./DeployProcess.py -r {outputRoot} -o {outputPath} -p {pipelineId} -t {projectTask} -k {experimentKey} -s {processState} -d {deploymentId}",
                              stdout=PIPE, stderr=PIPE).communicate()

        stderr = str(stderr)
        if ('TrainProcess' in stderr) or ('TestProcess' in stderr) or ('DeployProcess' in stderr):
            save_error_log(outputPath, stderr)
    except Exception as err:
        save_error_log(outputPath, f"unexpected error: {err}")


def test_finish_correct(pipelinePath, pipelineId):
    """Check if test process finish correctly
    correctly finish  : Test_result.csv existed and error.txt do not existed
    incorrectly finish: other situation

    Args:
        pipelinePath (str): pipeline output path
        pipelineId (str): pipeline ID
    """
    if os.path.isfile(os.path.join(pipelinePath, "Test_result.csv")) and not os.path.isfile(
        os.path.join(pipelinePath, "error.txt")
    ):
        print(f'(ProcessMonitor) test finish correct {pipelineId}')
        return True
    print(f'(ProcessMonitor) test finish incorrect {pipelineId}')
    return False


def train_finish_correct(pipelinePath, pipelineId, projectTask):
    """Check if train process finish correctly
    correctly finish  : ValidAcc.json existed and error.txt do not existed
    incorrectly finish: other situation

    Args:
        pipelinePath (str): pipeline output path
        pipelineId (str): pipeline ID
        projectTask (str): project task
    """
    if projectTask == "classification":
        if os.path.isfile(os.path.join(pipelinePath, "ValidAcc.json")) and \
            not os.path.isfile(os.path.join(pipelinePath, "error.txt")):
            print(f'(ProcessMonitor) train finish correct {pipelineId}')
            return True
    elif projectTask == "detection":
        if os.path.isfile(os.path.join(pipelinePath, "ValidMap.json")) and \
            not os.path.isfile(os.path.join(pipelinePath, "error.txt")):
            print(f'(ProcessMonitor) train finish correct {pipelineId}')
            return True
    print(f'(ProcessMonitor) train finish incorrect {pipelineId}')
    return False


def inference_finish_correct(deploymentPath, deploymentId):
    """Check if inference process finish correctly
    correctly finish  : Inference_result.csv existed and error.txt do not existed
    incorrectly finish: other situation

    Args:
        deploymentPath (str): deployment output path
        deploymentId (str): deployment ID
    """
    if os.path.isfile(os.path.join(deploymentPath, "Inference_result.csv")) and \
        not os.path.isfile(os.path.join(deploymentPath, "error.txt")):
        print(f'(ProcessMonitor) inference finish correct {deploymentId}')
        return True
    print(f'(ProcessMonitor) inference finish incorrect {deploymentId}')
    return False


def deployment_finish_correct(deploymentPath, deploymentId, state):
    """Check if deployment process finish correctly
    correctly finish  : Inference_result.csv existed and error.txt do not existed
    incorrectly finish: other situation

    Args:
        deploymentPath (str): deployment output path
        deploymentId (str): deployment ID
    """
    fileList = os.listdir(deploymentPath)
    if state == -6: # check onnx deployment
        checkFile = ['image', 'deployConfig.json', 'deployFile.ini', 'deployFile.onnx']
        for file in checkFile:
            if file not in fileList:
                print(f'(ProcessMonitor) deployment onnx finish incorrect {deploymentId}')
                return False
    elif state == -7: # check pyd deployment
        checkFile = ['image', 'deployConfig.json', 'deployFile.ini', 'deployFile.onnx', 'utils', 'main.py']
        for file in checkFile:
            if file not in fileList:
                print(f'(ProcessMonitor) deployment pyd finish incorrect {deploymentId}')
                return False
    elif state == -8: # check exe deployment
        checkFile = ['image', 'deployConfig.json', 'deployFile.ini', 'deployFile.onnx', 'utils', 'deployFile.exe']
        for file in checkFile:
            if file not in fileList:
                print(f'(ProcessMonitor) deployment exe finish incorrect {deploymentId}')
                return False
    return True


def delete_local_file(localPath):
    """Delete most local file after record into database
       only leave BestDictPth.pth, ConfusionMatrix.jpg

    Args:
        localPath (str): local output path
    """
    retainList = ['BestDictPth.pth', 'ConfusionMatrix.jpg', 'ConfigCls.json', 'ConfigDet.json',
                  'image', 'deployConfig.json', 'deployFile.ini', 'deployFile.onnx', 'utils',
                  'main.py', 'deployFile.exe']
    for fileName in os.listdir(localPath):
        if fileName not in retainList:
            filePath = os.path.join(localPath, fileName)
            if os.path.isdir(filePath):
                shutil.rmtree(filePath)
            elif os.path.isfile(filePath):
                os.remove(filePath)


def check_threads_done(gpuId, gpuSituation):
    """check if gpu with gpuId is idle
    Args:
        gpuId (str): gpu ID
        gpuSituation (list): gpu situation
        gpuSituation:  [(gpuId0, pipelineId, deploymentId, projectTask, <Thread(Thread-1, started 620620)>, state),
                        (gpuId1, pipelineId, deploymentId, projectTask, <Thread(Thread-2, started 608924)>, state), ...]

    Returns:
        boolean: True or False
    """
    for id, _, _, _, _, _ in gpuSituation:
        if id == gpuId:
            return False
    return True


def get_gpu_memory_usage(deviceId):
    """Get the current gpu usage.

    Args:
        deviceId (str): gpu device ID

    Returns:
        float: gpu memory usage percentage
    """
    pynvml.nvmlInit()
    gpuDevice = pynvml.nvmlDeviceGetHandleByIndex(deviceId)
    totalMemory = pynvml.nvmlDeviceGetMemoryInfo(gpuDevice).total
    usedMemory = pynvml.nvmlDeviceGetMemoryInfo(gpuDevice).used
    if totalMemory == 0:
        return 100
    return usedMemory / totalMemory * 100


def add_gpu_situation(processType, gpuSituation, gpuId, projectTask, thread, state, pipelineId, deploymentId=''):
    """record assigned task into gpuSituation both in list and database and update pipeline state

    Args:
        gpuSituation (list): gpu situation recorder (gpuId, pipelineId, deploymentId, projectTask, thread, state)
        gpuId (int): gpu ID
        processId (str): pipeline ID or deployment ID
        projectTask (str): classification or detection
        thread (str): thread ID
        state (int): state number
    """
    gpuSituation.append((gpuId, pipelineId, deploymentId, projectTask, thread, state))
    gpuSituationId = monitorDbHandler.generate_uid("gpu_situation")
    monitorDbHandler.insert_value('gpu_situation (gpu_situation_id, gpu_id, pipeline_id, deployment_id, project_task, thread, state)',
                                  f'("{gpuSituationId}", "{gpuId}", "{pipelineId}", "{deploymentId}", "{projectTask}", "{thread}", "{state}")') # add to gpu situation
    if processType == 'Pipeline':
        monitorDbHandler.update_value_with_cond('pipeline', f'status="{state}"', f'pipeline_id="{pipelineId}"')
    elif processType == 'Deployment':
        monitorDbHandler.update_value_with_cond('deployment', f'status="{state}"', f'deployment_id="{deploymentId}"')


def remove_gpu_situation(gpuSituation, gpuId, pipelineId, deploymentId, projectTask, thread, state):
    """record assigned task into gpuSituation

    Args:
        gpuSituation (list): gpu situation recorder (gpuId, pipelineId, deploymentId, projectTask, thread, state)
        gpuId (int): gpu ID
        pipelineId (str): pipeline ID
        deploymentId (str): deployment ID
        projectTask (str): classification or detection
        thread (str): thread number
        state (str): state
    """
    if deploymentId:
        gpuSituation.remove((gpuId, pipelineId, deploymentId, projectTask, thread, state))
        monitorDbHandler.delete_value('gpu_situation', f'deployment_id="{deploymentId}"')
    else:
        print(f"In else {pipelineId}")
        gpuSituation.remove((gpuId, pipelineId, deploymentId, projectTask, thread, state))
        monitorDbHandler.delete_value('gpu_situation', f'pipeline_id="{pipelineId}"')


def initial_gpu_situation(outputRoot):
    """Check if gpu situation in database is empty:
        empty    : start monitor
        not empty: clean gpu situation, save incorrect finish pipeline, and delete local files
        (gpuId0, pipelineId, deploymentId, projectTask, <Thread(Thread-1, started 620620)>, state)

    Args:
        outputRoot (str): output root path
    """
    gpuTable = monitorDbHandler.read_value_with_cond('gpu_situation', '*', '1=1')
    if not gpuTable.empty:
        for thread in gpuTable.to_dict('records'):
            gpuId, pipelineId, deploymentId, state, updateTime = thread["gpu_id"], thread["pipeline_id"], thread["deployment_id"], thread["state"], thread["update_time"]
            if deploymentId:
                errorLog = f'fatal error: deployment suspend on gpu {gpuId} at time {updateTime}'
                monitorDbHandler.update_value_with_cond('deployment_output', f'error_log="{errorLog}"', f'deployment_id="{deploymentId}"')
                monitorDbHandler.update_value_with_cond('deployment', f'status="{-4}"', f'deployment_id="{deploymentId}"')
                monitorDbHandler.delete_value('gpu_situation', f'deployment_id="{deploymentId}"')
                delete_local_file(os.path.join(outputRoot, pipelineId, deploymentId))
            else:
                pipelineId, gpuId, state, updateTime = thread["pipeline_id"], thread["gpu_id"], thread["state"], thread["update_time"]
                errorLog = f'fatal error: pipeline suspend in state {state} on gpu {gpuId} at time {updateTime}'
                monitorDbHandler.update_value_with_cond('pipeline_output', f'error_log="{errorLog}"', f'pipeline_id="{pipelineId}"')
                monitorDbHandler.update_value_with_cond('pipeline', f'status="{-4}"', f'pipeline_id="{pipelineId}"')
                monitorDbHandler.delete_value('gpu_situation', f'pipeline_id="{pipelineId}"')
                delete_local_file(os.path.join(outputRoot, pipelineId))


# def assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId=None):
#     """Check database and assign new process to gpu if gpu is idle

#     Args:
#         outputRoot (str): output root path
#         gpuUsageThreshold (int): percentage of gpu usage threshold
#         gpuSituation (list): gpu situation record
#         gpuId (str or None): gpu ID
#     """
#     gpuJobList = monitorDbHandler.load_db_pipeline(gpuId)
#     for gpu, queue in gpuJobList.items():
#         if get_gpu_memory_usage(gpu) < gpuUsageThreshold:  # less then 5%
#             pipelineId, state, projectTask, experimentKey = queue.popleft()
#             if state == "Wait for test":
#                 pipelinePath = os.path.join(outputRoot, pipelineId)
#                 testThread = threading.Thread(target=process, args=("Test", outputRoot, pipelineId, projectTask, experimentKey, pipelinePath))
#                 add_gpu_situation(gpuSituation, gpu, pipelineId, projectTask, testThread, -3)
#                 testThread.start()

#             elif state == "Wait for train":
#                 if check_threads_done(gpu, gpuSituation):
#                     pipelinePath = os.path.join(outputRoot, pipelineId)
#                     monitorDbHandler.create_pipeline_output(pipelineId)
#                     trainThread = threading.Thread(target=process, args=("Train", outputRoot, pipelineId, projectTask, experimentKey, pipelinePath))
#                     add_gpu_situation(gpuSituation, gpu, pipelineId, projectTask, trainThread, -1)
#                     trainThread.start()
#         else:
#             print(f"GPU: {gpu} running...") # debug purpose


def assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId=None):
    """Check database and assign new process to gpu if gpu is idle

    Args:
        outputRoot (str): output root path
        gpuUsageThreshold (int): percentage of gpu usage threshold
        gpuSituation (list): gpu situation record
        gpuId (str or None): gpu ID
    """
    ### Get GPU list
    if gpuId == None:
        pynvml.nvmlInit()
        deviceCount = pynvml.nvmlDeviceGetCount()
        gpuIdList = list(range(deviceCount))
    else:
        gpuIdList = [gpuId]

    ### Get job list of each GPU and assign GPU according job list
    for gpuId in gpuIdList:
        jobList = monitorDbHandler.load_db_job(gpuId)
        if len(jobList) != 0 and get_gpu_memory_usage(gpuId) < gpuUsageThreshold:  # less then 5%
            pipelineId, deploymentId, state, projectTask, configKey = jobList[0]

            if state == "Wait for test":
                pipelinePath = os.path.join(outputRoot, pipelineId)
                testThread = threading.Thread(target=process, args=("Test", outputRoot, pipelineId, projectTask, configKey, pipelinePath))
                add_gpu_situation('Pipeline', gpuSituation, gpuId, projectTask, testThread, -3, pipelineId)
                testThread.start()

            elif state == "Wait for inference":
                if check_threads_done(gpuId, gpuSituation):
                    infernecePath = os.path.join(outputRoot, pipelineId, deploymentId)
                    monitorDbHandler.create_deployment_output(deploymentId)
                    trainThread = threading.Thread(target=process, args=("Inference", outputRoot, pipelineId, projectTask, configKey, infernecePath, deploymentId))
                    add_gpu_situation('Deployment', gpuSituation, gpuId, projectTask, trainThread, -5, pipelineId, deploymentId)
                    trainThread.start()

            elif state in ['Wait for deployment (onnx)', 'Wait for deployment (exe)', 'Wait for deployment (pyd)']:
                if check_threads_done(gpuId, gpuSituation):
                    deploymentPath = os.path.join(outputRoot, pipelineId, deploymentId)
                    monitorDbHandler.create_deployment_output(deploymentId)
                    trainThread = threading.Thread(target=process, args=("Deployment", outputRoot, pipelineId, projectTask, configKey, deploymentPath, deploymentId))
                    if 'onnx' in state:
                        add_gpu_situation('Deployment', gpuSituation, gpuId, projectTask, trainThread, -6, pipelineId, deploymentId)
                    elif 'exe' in state:
                        add_gpu_situation('Deployment', gpuSituation, gpuId, projectTask, trainThread, -7, pipelineId, deploymentId)
                    elif 'pyd' in state:
                        add_gpu_situation('Deployment', gpuSituation, gpuId, projectTask, trainThread, -8, pipelineId, deploymentId)
                    trainThread.start()

            elif state == "Wait for train":
                if check_threads_done(gpuId, gpuSituation):
                    pipelinePath = os.path.join(outputRoot, pipelineId)
                    monitorDbHandler.create_pipeline_output(pipelineId)
                    trainThread = threading.Thread(target=process, args=("Train", outputRoot, pipelineId, projectTask, configKey, pipelinePath))
                    add_gpu_situation('Pipeline', gpuSituation, gpuId, projectTask, trainThread, -1, pipelineId)
                    trainThread.start()
        elif len(jobList) == 0:
            print(f"GPU: {gpuId} has no job in line ...") # debug purpose
        else:
            print(f"GPU: {gpuId} running...") # debug purpose



if __name__ == "__main__":
    monitorTime, gpuUsageThreshold, outputRoot = check_basic_setting()

    # Initial monitorDbHandler and gpuSituation: [(gpuId, pipelineId, deploymentId, projectTask, thread, state), ....]
    initial_gpu_situation(outputRoot)
    gpuSituation = []
    count = 0
    while True:
        print("(ProcessMonitor) round: ", count)
        print("(ProcessMonitor) gpuSituation: ", gpuSituation)
        ### check process running on gpu

        for gpuId, pipelineId, deploymentId, projectTask, thread, state in gpuSituation.copy():
            if state == -3: # Test
                if not thread.is_alive():
                    remove_gpu_situation(gpuSituation, gpuId, pipelineId, deploymentId, projectTask, thread, state)
                    pipelinePath = os.path.join(outputRoot, pipelineId)
                    if test_finish_correct(pipelinePath, pipelineId):
                        monitorDbHandler.save_pipeline_result('Test', projectTask, pipelineId, pipelinePath)
                        monitorDbHandler.update_db_state(0, pipelineId)
                    else:
                        monitorDbHandler.save_error_db(os.path.join(pipelinePath, 'error.txt'), pipelineId)
                        monitorDbHandler.update_db_state(-4, pipelineId)
                    delete_local_file(pipelinePath)
                    assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId)

            elif state == -1: # Train
                pipelinePath = os.path.join(outputRoot, pipelineId)
                monitorDbHandler.save_pipeline_result('Train', projectTask, pipelineId, pipelinePath)
                if not thread.is_alive():
                    remove_gpu_situation(gpuSituation, gpuId, pipelineId, deploymentId, projectTask, thread, state)
                    if train_finish_correct(pipelinePath, pipelineId, projectTask):
                        monitorDbHandler.save_pipeline_result('Train', projectTask, pipelineId, pipelinePath)
                        monitorDbHandler.update_db_state(-2, pipelineId)
                    else:
                        monitorDbHandler.save_error_db(os.path.join(pipelinePath, 'error.txt'), pipelineId)
                        monitorDbHandler.update_db_state(-4, pipelineId)
                        delete_local_file(pipelinePath)
                    assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId)

            elif state == -5: # Inference
                if not thread.is_alive():
                    remove_gpu_situation(gpuSituation, gpuId, pipelineId, deploymentId, projectTask, thread, state)
                    deploymentPath = os.path.join(outputRoot, pipelineId, deploymentId)
                    if inference_finish_correct(deploymentPath, deploymentId):
                        print("====================== finish correct ======================")
                        monitorDbHandler.save_deployment_result('Inference', projectTask, deploymentId, deploymentPath)
                        monitorDbHandler.update_db_state(0, pipelineId, deploymentId)
                    else:
                        print("------------------ wrong ------------------")
                        monitorDbHandler.save_error_db(os.path.join(deploymentPath, 'error.txt'), pipelineId, deploymentId)
                        monitorDbHandler.update_db_state(-4, pipelineId, deploymentId)
                    # delete_local_file(deploymentPath)
                    assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId)

            elif state == -6 or state == -7 or state == -8: # Deployment (onnx, exe, pyd)
                if not thread.is_alive():
                    remove_gpu_situation(gpuSituation, gpuId, pipelineId, deploymentId, projectTask, thread, state)
                    deploymentPath = os.path.join(outputRoot, pipelineId, deploymentId)
                    if deployment_finish_correct(deploymentPath, deploymentId, state):
                        monitorDbHandler.save_deployment_result('Deployment')
                        monitorDbHandler.update_db_state(0, pipelineId, deploymentId)
                    else:
                        monitorDbHandler.save_error_db(os.path.join(deploymentPath, 'error.txt'), pipelineId, deploymentId)
                        monitorDbHandler.update_db_state(-4, pipelineId, deploymentId)
                        # delete_local_file(deploymentPath)
                    assign_process(outputRoot, gpuUsageThreshold, gpuSituation, gpuId)


        ### assign process to gpu
        assign_process(outputRoot, gpuUsageThreshold, gpuSituation)

        ### wait 30 second for next monitor round
        print(f"(ProcessMonitor) Sleep {monitorTime} second")
        time.sleep(monitorTime)
        count += 1
