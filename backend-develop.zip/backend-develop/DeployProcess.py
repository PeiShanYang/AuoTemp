import argparse
import os, shutil, json
import main.MainCls as MainCls
import main.MainDet as MainDet
from utils.DatabaseResource import processDb

processDbHandler = processDb.ProcessDb()


def create_folder(folderPath):
    """ create pipeline folder

    Args:
        folderPath (str): folder path
    """
    try:
        if os.path.isdir(folderPath):
            shutil.rmtree(folderPath)
        os.makedirs(folderPath)
    except Exception as err:
        raise Exception('(TrainProcess) create folder failed: ', err)


def dataset_prepare(deploymentId, deploymentPath):
    """Prepare local dataset for ai module

    Args:
        deploymentId (str): deployment ID
        deploymentPath (str): deployment path
    """
    imagePath = processDbHandler.read_value_with_cond('deployment', 'image_path', f'deployment_id = "{deploymentId}"')
    format = ['.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff']

    ### create dataset folder
    create_folder(os.path.join(deploymentPath, 'dataset'))

    ### imagePath is image
    if os.path.splitext(imagePath)[-1].lower() in format:
        shutil.copyfile(imagePath, os.path.join(deploymentPath, 'dataset', os.path.split(imagePath)))

    ### imagePath is dir and contain images
    else:
        folderFile = os.listdir(imagePath)
        for file in folderFile:
            if os.path.splitext(file)[-1].lower() in format:
                shutil.copyfile(os.path.join(imagePath, file), os.path.join(deploymentPath, 'dataset', file))
    if not len(os.listdir(os.path.join(deploymentPath, 'dataset'))):
        raise Exception('(DeployProcess) dataset prepare failed: no file existed')



def modify_config(pipelinePath, deploymentPath, deployConfigPath, state, projectTask, key):
    """modify config from test to inference or deployment

    Args:
        pipelinePath (str): pipeline path
        deploymentPath (str): deployment path
        deployConfigPath (str): deployment config path
        state (str): Inference or Deployment
        projectTask (str): Classification or Detection
        key (str): deployment config

    Raises:
        Exception: return modify config failed while error occurred

    Returns:
        str: deploy Config Path
    """
    try:
        with open(deployConfigPath, 'r+') as f:
            data = json.load(f)
            # Common modify parameters
            data["Config"]["basicSettingPara"]["task"] = state
            data["Config"]["privateSettingPara"]["outputPath"] = deploymentPath

            if state == 'Inference':
                # Set task, cudaDevice and batchSize
                data["ConfigPytorchModel"]["pathPara"]["inferencePath"] = os.path.join(deploymentPath, 'dataset')
                data["ConfigPytorchModel"]["servicePara"]["cudaDevice"] = int(key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["GPU"])
                data["ConfigPytorchModel"]["servicePara"]["batchSize"] = key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["batchSize"]
                data["ConfigPytorchModel"]["pathPara"]["weightPath"]["evaluatedWeight"] = os.path.join(pipelinePath, 'BestDictPth.pth')
                if projectTask == 'detection' and key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeModified"]:
                    data["ConfigPreprocess"]["preprocessPara"]["Resize"]["parameters"]["size"] = \
                        [key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeX"], key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeY"]]

            elif state == 'Deployment':
                # Set deployment mode
                if key["deploymentConfig"]["ConfigFile"]["filePara"]["file"] == 'onnx':
                    data["ConfigDeployment"]["deployment"]["deployMode"] = 0
                elif key["deploymentConfig"]["ConfigFile"]["filePara"]["file"] == 'pyd (py37)':
                    data["ConfigDeployment"]["deployment"]["deployMode"] = 1
                else:
                    data["ConfigDeployment"]["deployment"]["deployMode"] = 2

                # Set deployPath, iniDownload, cudaDevice, batchSize, cfgDownload
                data["ConfigDeployment"]["deployment"]["deployPath"] = deploymentPath
                data["ConfigDeployment"]["deployment"]["deployName"] = 'deployFile'
                data["ConfigDeployment"]["deployment"]["saveIniFile"] = key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["iniDownload"]
                data["ConfigDeployment"]["onnxSetting"]["cudaDevice"] = key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["gpu"]
                data["ConfigDeployment"]["onnxSetting"]["batchSize"] = key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["batchSize"]
                if projectTask == 'detection' and key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeModified"]:
                    data["ConfigDeployment"]["onnxSetting"]["inputSize"] = \
                        [key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeX"], key["deploymentConfig"]["ConfigParameter"]["parameterPara"]["inputSizeY"]]
            f.seek(0)
            json.dump(data, f, indent=4)
            f.truncate()
        return deployConfigPath
    except Exception as err:
        raise Exception('(DeployProcess) modify config failed: ', err)


def generate_config(pipelinePath, deploymentPath, state, projectTask, key):
    configFile = 'ConfigCls.json' if projectTask == 'classification' else 'ConfigDet.json'
    shutil.copyfile(os.path.join(pipelinePath, configFile), os.path.join(deploymentPath, configFile))
    deployConfig = modify_config(pipelinePath, deploymentPath, os.path.join(deploymentPath, configFile), state, projectTask, key)
    return deployConfig


def run_ai_module(task, configFile):
    """run AI module

    Args:
        task (str): classification or detection
        configFile (str): config json file path
    """
    try:
        if task == 'classification':
            MainCls.main(configFile)
        elif task == 'detection':
            MainDet.main(configFile)
    except Exception as err:
        raise Exception('(TestProcess) ai module error: ', err)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-r", "--root", default='pipelineOutput', help = "pipeline output root path")
    parser.add_argument("-o", "--outputPath", default='./pipelineOutput/pipeline_2023062811521546706267062500/deployment_2023071016241555747957479000', help = "full deployment output path")
    parser.add_argument("-p", "--pId", default='pipeline_2023062811521546706267062500', help = "pipeline ID")
    parser.add_argument("-t", "--task", default='detection', help = "project task (classification / detection)")
    parser.add_argument("-k", "--key", default={'deploymentConfig': {'ConfigFile': {'filePara': {'file': 'api'}}, 'ConfigParameter': {'parameterPara': {'GPU': '3', 'batchSize': 8, 'inputSizeModified': False, 'inputSizeX': 416, 'inputSizeY': 416}}}}, help = "experiment key")
    parser.add_argument("-s", "--state", default='Inference', help = "Deployment or Inference")
    parser.add_argument("-d", "--dId", default='deployment_2023071016241555747957479000', help = "deployment ID")
    args = parser.parse_args()
    pipelinePath = os.path.join(args.root, args.pId)
    configPath = generate_config(pipelinePath, args.outputPath, args.state, args.task, args.key)
    if args.state == 'Inference':
        dataset_prepare(args.dId, args.outputPath)
    print("ready to run_ai_module")
    run_ai_module(args.task, configPath)
