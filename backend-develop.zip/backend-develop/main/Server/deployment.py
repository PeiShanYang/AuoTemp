from flask import Blueprint, request
from utils.LoggerResource.ConfigLogger import Logger
from utils.DatabaseResource import deploymentDb
from utils.ApiResource import deploymentUtil
from utils.ApiResource.DeployConfig import ClsDeployApiConfig, DetDeployApiConfig, ClsDeployDownloadConfig, DetDeployDownloadConfig
from datetime import datetime
import os, time

prefix = "/deployment"
blueprintApp = Blueprint(prefix, __name__)
deploymentDbHandler = deploymentDb.DeploymentDb()


@blueprintApp.route("/get-classification-api-configs", methods=["POST"])
def get_classification_api_configs():
    """Get classification api configs

    Returns:
        tuple[0]: 0: get configs failed, 1: get configs success
        tuple[1]: log message
    """
    try:
        apiConfig = deploymentUtil.append_api_gpu_info(ClsDeployApiConfig.config, 'api')
    except:
        return Logger.responseDebug(0, "Get classification api config failed")
    return Logger.responseDebug(1, "Get classification api config success", apiConfig)


@blueprintApp.route("/get-detection-api-configs", methods=["POST"])
def get_detection_api_configs():
    """Get detection api configs

    Returns:
        tuple[0]: 0: get configs failed, 1: get configs success
        tuple[1]: log message
    """
    try:
        apiConfig = deploymentUtil.append_api_gpu_info(DetDeployApiConfig.config, 'api')
    except:
        return Logger.responseDebug(0, "Get detection api config failed")
    return Logger.responseDebug(1, "Get detection api config success", apiConfig)


@blueprintApp.route("/get-classification-download-configs", methods=["POST"])
def get_classification_download_configs():
    """Get classification download configs

    Returns:
        tuple[0]: 0: get configs failed, 1: get configs success
        tuple[1]: log message
    """
    try:
        apiConfig = deploymentUtil.append_api_gpu_info(ClsDeployDownloadConfig.config, 'download')
    except:
        return Logger.responseDebug(0, "Get detection api config failed")
    return Logger.responseDebug(1, "Get classification download config success", apiConfig)


@blueprintApp.route("/get-detection-download-configs", methods=["POST"])
def get_detection_download_configs():
    """Get detection download configs

    Returns:
        tuple[0]: 0: get configs failed, 1: get configs success
        tuple[1]: log message
    """
    try:
        apiConfig = deploymentUtil.append_api_gpu_info(DetDeployDownloadConfig.config, 'download')
    except:
        return Logger.responseDebug(0, "Get detection api config failed")
    return Logger.responseDebug(1, "Get detection download config success", apiConfig)


@blueprintApp.route("/created", methods=["POST"])
def created():
    """Create the deployment

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "deploymentName": deployment name
    }
    Returns:
        tuple[0]: 0: save created failed, 1: save created success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName = data["projectName"], data["experimentName"], data["pipelineName"], data["deploymentName"]
    ### Update column name created to 1
    deploymentDbHandler.update_value_with_cond('project, experiment, pipeline, deployment',
                                               'deployment.created=1',
                                               f'project.project_name="{projectName}" \
                                                and experiment.experiment_name="{experimentName}" \
                                                and pipeline.pipeline_name="{pipelineName}" \
                                                and deployment.deployment_name="{deploymentName}" \
                                                and project.project_id=experiment.project_id \
                                                and experiment.experiment_id=pipeline.experiment_id\
                                                and pipeline.pipeline_id=deployment.pipeline_id')
    return Logger.responseDebug(1, 'Deployment created')

@blueprintApp.route("/get-list", methods=["POST"])
def get_list():
    """
    get deployment list of project
    """
    ### Get input variable
    data = request.get_json()
    projectName = data["projectName"]
    experimentName = data["experimentName"]
    pipelineName = data["pipelineName"]
    ### Check if the project exists
    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    ### Project does not exist
    if not ok:
        return Logger.responseError(0, 'Get list failed / ' + message)
    ### is experimentName
    if experimentName != '':
        ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
        if not ok:
            return Logger.responseError(0, 'Get list failed / ' + message)
        ### is pipelineName
        if pipelineName != '':
            ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
            if not ok:
                return Logger.responseError(0, 'Get list failed / ' + message)
            deploymentsList = deploymentDbHandler.generate_list(
                projectName, experimentName=experimentName, pipelineName=pipelineName
            )
        else:
            deploymentsList = deploymentDbHandler.generate_list(projectName, experimentName=experimentName)
    else:
        deploymentsList = deploymentDbHandler.generate_list(projectName)
    return Logger.responseDebug(1, "Get list success", deploymentsList)


# @blueprintApp.route("/preview-list", methods=["POST"])
# def preview_list():
#     """
#     preview deployment list in info page
#     """
#     ### Get input variable
#     data = request.get_json()
#     projectName = data["projectName"]
#     experimentName = data["experimentName"]
#     pipelineName = data["pipelineName"]
#     ### Check if the project exists
#     ok, message = deploymentDbHandler.check_project_name_existed(projectName)
#     ### Project does not exist
#     if not ok:
#         return Logger.responseError(0, message + ", please select other project name")
#     ### is experimentName
#     if experimentName != "":
#         ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
#         if not ok:
#             return Logger.responseError(0, message + ", please select other experiment name")
#         ### is pipelineName
#         if pipelineName != "":
#             ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
#             if not ok:
#                 return Logger.responseError(0, message + ", please select other pipeline name")
#             deploymentsList = deploymentDbHandler.generate_list(
#                 projectName, experimentName=experimentName, pipelineName=pipelineName, returnCurrentNum=4
#             )
#         else:
#             deploymentsList = deploymentDbHandler.generate_list(projectName, experimentName=experimentName, returnCurrentNum=4)
#     else:
#         deploymentsList = deploymentDbHandler.generate_list(projectName, returnCurrentNum=4)
#     ### 4 current deployments in the output project if exist
#     return Logger.responseDebug(1, "Preview deployments list success", deploymentsList)


@blueprintApp.route("/create", methods=["POST"])
def create():
    """Create a new deployment or rename deployment"""
    ### Get input variable
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName, deploymentRename = (
        data["projectName"],
        data["experimentName"],
        data["pipelineName"],
        data["deploymentName"],
        data["deploymentRename"],
    )
    ### Check if the project exists
    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the experiment exists
    ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    ### experiment name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the pipeline exists
    ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    ### Pipeline name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the deployment exists
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    ### Deployment name existed or deployment name not existed and need to reaname, return error message
    if (ok and deploymentRename == "") or (not ok and deploymentRename != ""):
        return Logger.responseError(0, 'Create failed / Incorrect rename situation')
    ### Deployment name is new, create pipeline
    if deploymentRename == "":
        ok, message = deploymentDbHandler.create_deployment(projectName, experimentName, pipelineName, deploymentName)
    ### Deployment name is old, execute Rename
    else:
        ### Check if the rename deployment exists
        ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentRename)
        ### Deployment name is old, execute Rename
        if not ok:
            ok, message = deploymentDbHandler.deployment_rename(projectName, experimentName, pipelineName, deploymentName, deploymentRename)
        ### deployment name same as deployment rename
        elif deploymentName == deploymentRename:
            return Logger.responseDebug(1, "Check name correct")
        ### Deployment rename existed, return error message
        else:
            return Logger.responseError(0, message + ", please rename with other deployment name")
    if ok:
        return Logger.responseDebug(1, 'Create success')
    return Logger.responseError(0, 'Create or rename failed')


@blueprintApp.route("/delete", methods=["POST"])
def delete():
    """
    delete deployment
    """
    ### Get input variable
    data = request.get_json()
    deleteList = data["deleteList"]
    for delete in deleteList:
        projectName, experimentName, pipelineName, deploymentName = (
            delete["projectName"],
            delete["experimentName"],
            delete["pipelineName"],
            delete["deploymentName"],
        )
        ### Check if the project exists
        ok, message = deploymentDbHandler.check_project_name_existed(projectName)
        ### Project does not exist
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ### Check if the experiment exists
        ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
        ### Experiment does not exist
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ### Check if the pipeline exists
        ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
        ### Pipeline does not exist
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ### Get pipeline ID
        pipelineId = deploymentDbHandler.read_value_with_cond(
            "project, experiment, pipeline",
            "pipeline_id",
            f'project.project_id = experiment.project_id\
                                                      and experiment.experiment_id = pipeline.experiment_id\
                                                      and project.project_name = "{projectName}"\
                                                      and experiment.experiment_name = "{experimentName}"\
                                                      and pipeline.pipeline_name = "{pipelineName}"',
        )
        ### Delete deployment
        deploymentDbHandler.delete_value("deployment", f'pipeline_id="{pipelineId}" and deployment_name="{deploymentName}"')
    return Logger.responseDebug(1, f"Delete success")


@blueprintApp.route('/set-abstract', methods=['POST'])
def set_abstract():
    """Save abstract into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "deploymentName": deployment name,
        "deploymentAbstract": deployment abstract
    }
    Returns:
        tuple[0]: 0: save abstract failed, 1: save abstract success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName, deploymentAbstract \
                = data["projectName"], data["experimentName"], data["pipelineName"], data["deploymentName"], data["deploymentAbstract"]

    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')

    ### Get pipeline id
    pipelineId = deploymentDbHandler.get_pipeline_id(projectName, experimentName, pipelineName)
    ### update experiment abstract
    ok, message = deploymentDbHandler.update_deployment_abstract(pipelineId, deploymentName, deploymentAbstract)

    return Logger.responseDebug(ok, message)


@blueprintApp.route('/add-favorite', methods=['POST'])
def add_favorite():
    """Add favorite deployment into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "deploymentName": deployment name
    }

    Returns:
        tuple[0]: 0: add favorite deployment failed, 1: add favorite deployment success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName \
                = data["projectName"], data["experimentName"], data["pipelineName"], data["deploymentName"]

    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')
    ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')
    ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')

    ### Update column name created to 1
    code, message = deploymentDbHandler.add_favorite(deploymentName)

    return Logger.responseDebug(code, message)


@blueprintApp.route('/select-method', methods=['POST'])
def select_method():
    """Select deployment method into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "deploymentName": deployment name,
        "deploymentMethod":
        {
            "method": "api" or "download" or "folder",
            "info": ""
        }
    }

    Returns:
        tuple[0]: 0: Select deployment method failed, 1: Select deployment method success
        tuple[1]: log message
    """
    ### Get input variable
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName, deploymentMethod, deploymentInfo = (
        data["projectName"],
        data["experimentName"],
        data["pipelineName"],
        data["deploymentName"],
        data["deploymentMethod"]["method"],
        data["deploymentMethod"]["info"]
    )
    ### Check if the project exists
    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Select method failed / ' + message)
    ### Check if the experiment exists
    ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    ### experiment name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Select method failed / ' + message)
    ### Check if the pipeline exists
    ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    ### Pipeline name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Select method failed / ' + message)
    ### Check if the deployment exists
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    if not ok:
        return Logger.responseError(0, 'Select method failed / ' + message)
    ### Get deployment id
    deploymentId = deploymentDbHandler.get_deployment_id(projectName, experimentName, pipelineName, deploymentName)

    ### If choosing the method is folder checking the deplotment info exisits and writing into DB
    ok, message = deploymentUtil.get_deployment_info(deploymentId, deploymentMethod, deploymentInfo, deploymentDbHandler.serverHost, deploymentDbHandler.serverPort)
    if not ok:
        return Logger.responseError(0, f'Select method failed / {message}')

    ### Get project task
    projectTask = deploymentDbHandler.read_value_with_cond('project', 'project_task', f'project_name="{projectName}"')

    ### Get deployment config template and write into DB
    deployConfigTemp = deploymentUtil.get_deploy_config_temp(deploymentMethod, projectTask)
    deploymentDbHandler.update_value_with_cond("deployment", f'method="{deploymentMethod}", info="{message}",\
                                                deployment_config="{deployConfigTemp}"', f'deployment_id="{deploymentId}"')

    return Logger.responseDebug(1, "Select dpeloyment method success")


@blueprintApp.route('/set-configs', methods=['POST'])
def set_configs():
    """Save deployment configs into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "deploymentName": deployment name,
        "deploymentConfig": {
            "ConfigFile": {
                "filePara": {
                    "file": "api" or "onnx" or "pyd (py37)" or "exe"
                    }
                }
            },
            "ConfigParameter": {
                "parameterPara": {
                    "gpu": "0",
                    "batchsize": 4,
                    "inputSizeModified": False,
                    "inputSizeX": 224,
                    "inputSizeY": 224,
                    "iniDownload": True,
                    "cfgDownload": True
                }
            }
        }
    }

    Returns:
        tuple[0]: 0: Saving deployment configs failed, 1: Saving deployment configs success
        tuple[1]: log message
    """
    ### Get input variable
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName = (
    data["projectName"],
    data["experimentName"],
    data["pipelineName"],
    data["deploymentName"],
    )
    ### Check if the project exists
    ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Set deployment config failed / ' + message)
    ### Check if the experiment exists
    ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    ### experiment name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Set deployment config failed / ' + message)
    ### Check if the pipeline exists
    ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    ### Pipeline name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Set deployment config failed / ' + message)
    ### Check if the deployment exists
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    if not ok:
        return Logger.responseError(0, 'Set deployment config failed / ' + message)
    ### Get deployment id
    deploymentId = deploymentDbHandler.get_deployment_id(projectName, experimentName, pipelineName, deploymentName)
    ### Reading deplotment configs and writing into DB
    deploymentConfig = {}
    deploymentConfig['deploymentConfig'] = data["deploymentConfig"]
    deploymentDbHandler.update_value_with_cond('deployment', f'deployment_config="{deploymentConfig}",\
        gpu_id="{deploymentConfig["deploymentConfig"]["ConfigParameter"]["parameterPara"]["GPU"]}"',
        f'deployment_id="{deploymentId}"')

    return Logger.responseDebug(1, "Set deployment config success")


@blueprintApp.route('/check', methods=['POST'])
def check():
    """Get deployment all information

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "deploymentName": deployment name,
        }

    Returns:
        tuple[0]: 0: Getting deployment information failed, 1: Getting deployment information success
        tuple[1]: log message
        tuple[2]: all deployment information
    """
    ### Get input variable
    data = request.get_json()
    projectName, experimentName, pipelineName, deploymentName = (
    data["projectName"],
    data["experimentName"],
    data["pipelineName"],
    data["deploymentName"],
    )
    # ### Check if the project exists
    # ok, message = deploymentDbHandler.check_project_name_existed(projectName)
    # ### Project name not existed, return error message
    # if not ok:
    #     return Logger.responseError(0, 'Get deployment information failed / ' + message)
    # ### Check if the experiment exists
    # ok, message = deploymentDbHandler.check_experiment_name_existed(projectName, experimentName)
    # ### experiment name not existed, return error message
    # if not ok:
    #     return Logger.responseError(0, 'Get deployment information failed / ' + message)
    # ### Check if the pipeline exists
    # ok, message = deploymentDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    # ### Pipeline name not existed, return error message
    # if not ok:
    #     return Logger.responseError(0, 'Get deployment information failed / ' + message)
    ### Check if the deployment exists
    ok, message = deploymentDbHandler.check_deployment_name_existed(projectName, experimentName, pipelineName, deploymentName)
    if not ok:
        return Logger.responseError(0, 'Get deployment information failed / ' + message)
    ### Get deployment id
    deploymentId = deploymentDbHandler.get_deployment_id(projectName, experimentName, pipelineName, deploymentName)
    ### Read deployment method, info and config information
    deploymentInfo = deploymentDbHandler.read_value_with_cond("deployment", "method, info, created, deployment_config, abstract", f'deployment_id="{deploymentId}"').to_dict('list')
    projectTask = deploymentDbHandler.read_value_with_cond('project', 'project_task', f'project_name="{projectName}"')
    deploymentAbstract = '' if deploymentInfo["abstract"][0] == None else deploymentInfo["abstract"][0]

    if deploymentInfo["deployment_config"][0] == None:
        deploymentConfig = {"deploymentConfig": ''}
    else:
        deploymentConfig = eval(deploymentInfo["deployment_config"][0])

    if deploymentInfo["method"][0] == None:
        deploymentMethod = ''
    else:
        deploymentMethod = deploymentInfo["method"][0]

    if deploymentInfo["info"][0] == None:
        deploymentMethodInfo = ''
    else:
        deploymentMethodInfo = deploymentInfo["info"][0]

    data = {
        "information": {
            "deploymentName": deploymentName,
            "deploymentMethod": {
                "method": deploymentMethod,
                "info": deploymentMethodInfo
            },
            "deploymentCreator": "someone",
            "deploymentAbstract": deploymentAbstract,
            "projectTask":projectTask,
            "created": deploymentInfo["created"][0]
        },
        "deploymentConfig": deploymentConfig["deploymentConfig"]
    }

    return Logger.responseDebug(1, "Get deployment information success", data)


@blueprintApp.route('/get-preview-<string:deploymentId>', methods=['GET'])
def get_preview(deploymentId):
    """Get image list

    Input: {
        "path": "image path or image folder path"
        "inference": 1 or 0, 0: Waiting for result, 1: Inference request
        }

    Returns:
        tuple[0]: 0: Get infernece result failed, 1: Get infernece datasets success
        tuple[1]: log message
        tuple[2]: image list include imagename and url
    """
    ### Check if the pipline was done or going or failed
    ok, message = deploymentDbHandler.check_pipline_status(deploymentId)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Infernece failed / ' + message)

    ### Get input variable
    data = request.get_json()
    path = data["path"].replace('\\', '/')

    ### Check if the path exists and ends with image format or the path under folder ends with image format, writting into db
    ok, message, urlPath = deploymentUtil.check_img_path(path)
    if not ok:
        return Logger.responseError(0, 'Infernece failed / ' + message)
    else:
        deploymentDbHandler.update_value_with_cond('deployment', f'image_path="{path}"', f'deployment_id="{deploymentId}"')

    ### Check if the inference status
    if data["inference"] == 1:
        deploymentStatus = deploymentDbHandler.read_value_with_cond("deployment", "status", f'deployment_id="{deploymentId}"')
        deploymentStatus = deploymentStatus if deploymentStatus == None else int(deploymentStatus)

        if deploymentStatus == 0 or deploymentStatus == None:
            data = {
                "state": "running",
                "imgList": ""
            }
            dataTime = datetime.now().strftime("%Y%m%d%H%M%S%f") + str(time.time_ns())[11:]
            deploymentDbHandler.update_value_with_cond('deployment', f'status="{dataTime}"', f'deployment_id="{deploymentId}"')
            deploymentDbHandler.update_value_with_cond('deployment_output', f'result=""', f'deployment_id="{deploymentId}"')
            return Logger.responseError(1, 'Infernece success / Inference process is running', data)

        if deploymentStatus == -1 or deploymentStatus > 0:
            data = {
                "state": "running",
                "imgList": ""
            }
            return Logger.responseError(1, 'Infernece success / Inference process is running', data)

    elif data["inference"] == 0:
        ### Check if the inference results exists
        try:
            result = deploymentDbHandler.read_value_with_cond("deployment_output", "result", f'deployment_id="{deploymentId}"')
        except:
            result = None

        if result == None:
            data = {
                "state": "running",
                "imgList": ""
            }
            return Logger.responseError(1, 'Infernece success / Inference process is running', data)
        else:
            '''
            Writting result information into data[imgList]
            '''
            imageList = deploymentUtil.get_img_list_url(result, urlPath, deploymentDbHandler.serverHost, deploymentDbHandler.serverPort)
            data = {
                "state": "done",
                "imgList": imageList
            }
            return Logger.responseError(1, 'Infernece success / Inference process is running', data)
    else:
        return Logger.responseError(0, 'Infernece failed / Error code with inference status', data)


@blueprintApp.route('/get-prediction-<string:deploymentId>', methods=['GET'])
def get_prediction(deploymentId):
    """Get image list

    Input: {
        "path": "image path or image folder path"
        "inference": 1 or 0, 0: Waiting for result, 1: Inference request
        }

    Returns:
        tuple[0]: 0: Get infernece result failed, 1: Get infernece datasets success
        tuple[1]: log message
        tuple[2]: image list include imagename and url
    """
    ### Check if the pipline was done or going or failed
    ok, message = deploymentDbHandler.check_pipline_status(deploymentId)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Infernece failed / ' + message)

    ### Get input variable
    data = request.get_json()
    path = data["path"].replace('\\', '/')

    ### Check if the path exists and ends with image format or the path under folder ends with image format, writting into db
    ok, message, urlPath = deploymentUtil.check_img_path(path)
    if not ok:
        return Logger.responseError(0, 'Infernece failed / ' + message)
    else:
        deploymentDbHandler.update_value_with_cond('deployment', f'image_path="{path}"', f'deployment_id="{deploymentId}"')

    ### Check if the inference status
    if data["inference"] == 1:
        deploymentStatus = deploymentDbHandler.read_value_with_cond("deployment", "status", f'deployment_id="{deploymentId}"')
        deploymentStatus = deploymentStatus if deploymentStatus == None else int(deploymentStatus)

        if deploymentStatus == 0 or deploymentStatus == None:
            data = {
                "state": "running",
                "imgList": ""
            }
            dataTime = datetime.now().strftime("%Y%m%d%H%M%S%f") + str(time.time_ns())[11:]
            deploymentDbHandler.update_value_with_cond('deployment', f'status="{dataTime}"', f'deployment_id="{deploymentId}"')
            deploymentDbHandler.update_value_with_cond('deployment_output', f'result=""', f'deployment_id="{deploymentId}"')
            return Logger.responseError(1, 'Infernece success / Inference process is running', data)

        if deploymentStatus == -1 or deploymentStatus > 0:
            data = {
                "state": "running",
                "imgList": ""
            }
            return Logger.responseError(1, 'Infernece success / Inference process is running', data)

    elif data["inference"] == 0:
        ### Check if the inference results exists
        try:
            result = deploymentDbHandler.read_value_with_cond("deployment_output", "result", f'deployment_id="{deploymentId}"')
        except:
            result = None

        if result == None:
            data = {
                "state": "running",
                "imgList": ""
            }
            return Logger.responseError(1, 'Infernece success / Inference process is running', data)
        else:
            '''
            Writting result information into data[imgList]
            '''
            imageList = deploymentUtil.get_img_list(result)
            data = {
                "state": "done",
                "imgList": imageList
            }
            return Logger.responseError(1, 'Infernece success / Inference process is running', data)
    else:
        return Logger.responseError(0, 'Infernece failed / Error code with inference status', data)
