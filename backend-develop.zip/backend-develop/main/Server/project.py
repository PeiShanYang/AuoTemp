from flask import Blueprint, request
from utils.LoggerResource.ConfigLogger import Logger
from utils.DatabaseResource import projectDb

prefix = "/project"
blueprintApp = Blueprint(prefix, __name__)
projectDbHandler = projectDb.ProjectDb()


@blueprintApp.route("/get-list", methods=["POST"])
def get_list():
    """Get project list

    Returns:
        tuple[0]: 0: get project list failed, 1: get project list success
        tuple[1]: log message
    """
    ok, message, dbResult = projectDbHandler.generate_list()
    if not ok:
        return Logger.responseError(0, message)

    output = {"list": dbResult}
    return Logger.responseDebug(1, message, output)


@blueprintApp.route("/add-favorite", methods=["POST"])
def add_favorite():
    """Add favorite project into database

    Input: {
        "projectName": project name
    }
    Returns:
        tuple[0]: 0: add favorite failed, 1: add favorite success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName = data["projectName"]
    ok, message = projectDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f"Add favorite failed / {message}")
    ### Add favorite project into database
    ok, message = projectDbHandler.add_favorite(projectName)
    return Logger.responseDebug(ok, message)


@blueprintApp.route("/check", methods=["POST"])
def check():
    """
    get project information if permitted
    """
    data = request.get_json()
    projectName = data["projectName"]
    ok, message = projectDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f"Check project information failed / {message}")
    projectInfo = projectDbHandler.get_project_info(projectName)
    imagePath = projectDbHandler.get_img_path(projectName)
    annotationPath = projectDbHandler.get_annotation_path(projectName)
    splitRate = projectDbHandler.get_split_rate(projectName)
    isLabel, isSplit = projectDbHandler.get_islabel_split(projectName)
    ok, fileList = projectDbHandler.get_file_list(projectName, projectInfo['project_task'], projectDbHandler.serverHost, projectDbHandler.serverPort)
    if not ok:
        return Logger.responseError(0, 'Check project information failed /' + fileList)

    output = {
        "information": {
            "projectName": projectName,
            "projectCreator": "someone",
            "projectAbstract": projectInfo['abstract'],
            "projectTask": projectInfo['project_task'],
            "created": projectInfo['created']
        },
        "dataStatus": {
            "imagePath": imagePath,
            "annotationPath": annotationPath,
            "dataSplit": splitRate,
            "isLabel": isLabel,
            "isSplit": isSplit
        },
        "fileList": fileList,
    }
    return Logger.responseDebug(1, "Check project information success", output)


@blueprintApp.route("/create", methods=["POST"])
def create():
    """Create a new project or rename project"""
    ### Get input variable
    data = request.get_json()
    projectName, projectRename = data["projectName"], data["projectRename"]
    ### Check if the project exists
    ok, message = projectDbHandler.check_project_name_existed(projectName)
    ### Project name existed or project name not existed and need to reaname, return error message
    if (ok and projectRename == "") or (not ok and projectRename != ""):
        return Logger.responseError(0, 'Create failed / Incorrect rename situation')
    ### Project name is new, create project
    if projectRename == "":
        ok, message = projectDbHandler.create_project(projectName)
    else:
        ### Check if the rename project exists
        ok, message = projectDbHandler.check_project_name_existed(projectRename)
        ### Project name is old, execute Rename
        if not ok:
            datasetId = projectDbHandler.read_value_with_cond('dataset, project', 'dataset_id', f'project.project_id=dataset.project_id\
                                                                                    AND project.project_name="{projectName}"')
            projectDbHandler.delete_value('label_class', f'dataset_id="{datasetId}"')
            projectDbHandler.delete_value('project', f'project_name="{projectName}"')
            ok, message = projectDbHandler.create_project(projectRename)
        ### Project name same as project rename
        elif projectName == projectRename:
            return Logger.responseDebug(1, "Check name correct")
        ### Project rename existed, return error message
        else:
            return Logger.responseError(0, message + ", please rename with other project name")
    if ok:
        return Logger.responseDebug(1, 'Create success')
    return Logger.responseError(0, 'Create or rename failed')


@blueprintApp.route("/select-task", methods=["POST"])
def select_task():
    """
    input: projectName, projectTask (classification / detection)
    存到DB
    """
    data = request.get_json()
    projectName, projectTask = data["projectName"], data["projectTask"]
    ok, message = projectDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, 'Save project task failed /' + message)
    ok, message = projectDbHandler.save_project_task(projectName, projectTask)
    if ok:
        return Logger.responseDebug(1, 'Save project task success')
    return Logger.responseError(0, 'Save project task failed /' + message)


@blueprintApp.route("/set-abstract", methods=["POST"])
def set_abstract():
    """Save abstract into database

    Input: {
        "projectName": project name,
        "projectAbstract": project abstract
    }
    Returns:
        tuple[0]: 0: save abstract failed, 1: save abstract success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, projectAbstract = data["projectName"], data["projectAbstract"]
    ok, message = projectDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseDebug(0, f"Save abstract failed / {message}")

    ### Update project abstract
    ok, message = projectDbHandler.update_project_abstract(projectName, projectAbstract)
    return Logger.responseError(ok, message)


@blueprintApp.route("/delete", methods=["POST"])
def delete():
    """Delete database information associated with this project

    Input: {
        "deleteList": project name list
    }
    Returns:
        tuple[0]: 0: delete project failed, 1: delete project success
        tuple[1]: log message
    """
    data = request.get_json()
    deleteList = data["deleteList"]
    for project in deleteList:
        ok, message = projectDbHandler.check_project_name_existed(project["projectName"])
        if not ok:
            return Logger.responseDebug(0, f"Delete failed / {message}")

        ### Get project id
        projectId = projectDbHandler.read_value_with_cond("project", "project_id", f"project_name='{project['projectName']}'")
        ### Get dataset id
        datasetId = projectDbHandler.read_value_with_cond("dataset", "dataset_id", f"project_id='{projectId}'")

        ### Delete project
        projectDbHandler.delete_value('project', f'project_name="{project["projectName"]}"')
        ### Delete label class
        projectDbHandler.delete_value('label_class', f'dataset_id="{datasetId}"')

    return Logger.responseDebug(1, "Delete success")


@blueprintApp.route("/created", methods=["POST"])
def created():
    """Create the project

    Input: {
        "projectName": project name
    }
    Returns:
        tuple[0]: 0: project created failed, 1: project created success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName = data["projectName"]

    ### Update column name created to 1
    projectDbHandler.update_value_with_cond('project', 'created=1', f'project_name="{projectName}"')
    return Logger.responseDebug(1, 'Project created')
