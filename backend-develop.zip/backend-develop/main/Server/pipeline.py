from flask import Blueprint, request
from utils.LoggerResource.ConfigLogger import Logger
from utils.DatabaseResource import pipelineDb
import pynvml
import json
import os
from pathlib import Path

prefix = "/pipeline"
blueprintApp = Blueprint(prefix, __name__)
pipelineDbHandler = pipelineDb.PipelineDb()


@blueprintApp.route("/get-list", methods=["POST"])
def get_list():
    """Get all pipeline information

    Input: {
        "projectName": project name,
        "experimentName": experiment name
    }

    Returns:
        tuple[0]: 0: get pipelines list failed, 1: get pipelines list sucess
        tuple[1]: log message
        tuple[2]: all pipeline information
    """
    ### Get input variable
    data = request.get_json()
    projectName = data["projectName"]
    experimentName = data["experimentName"]
    ### Check if the project exists
    ok, message = pipelineDbHandler.check_project_name_existed(projectName)
    ### Project does not exist
    if not ok:
        return Logger.responseError(0, 'Get list failed / ' + message)
    ### is experimentName
    if experimentName != "":
        ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
        if not ok:
            return Logger.responseError(0, 'Get list failed / ' + message)
        pipelinesList = pipelineDbHandler.generate_list(projectName, experimentName=experimentName)
    else:
        pipelinesList = pipelineDbHandler.generate_list(projectName)
    return Logger.responseDebug(1, "Get list success", pipelinesList)


@blueprintApp.route("/create", methods=["POST"])
def create():
    """Create a new pipeline or rename pipeline"""
    ### Get input variable
    data = request.get_json()
    projectName, experimentName, pipelineName, pipelineRename = (
        data["projectName"],
        data["experimentName"],
        data["pipelineName"],
        data["pipelineRename"],
    )
    ### Check if the project exists
    ok, message = pipelineDbHandler.check_project_name_existed(projectName)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the experiment exists
    ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
    ### Experiment name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the pipeline exists
    ok, message = pipelineDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    ### Pipeline name existed or pipeline name not existed and need to reaname, return error message
    if (ok and pipelineRename == "") or (not ok and pipelineRename != ""):
        return Logger.responseError(0, 'Create failed / Incorrect rename situation')
    ### Pipeline name is new, create pipeline
    if pipelineRename == "":
        ok, message = pipelineDbHandler.create_pipeline(projectName, experimentName, pipelineName)
    ### Pipeline name is old, execute Rename
    else:
        ### Check if the rename pipeline exists
        ok, message = pipelineDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineRename)
        ### Pipeline name is old, execute Rename
        if not ok:
            # ok, message = pipelineDbHandler.pipeline_rename(projectName, experimentName, pipelineName, pipelineRename)
            experimentId = pipelineDbHandler.get_experiment_id(projectName, experimentName)
            pipelineDbHandler.delete_value('pipeline', f'experiment_id="{experimentId}" and pipeline_name="{pipelineName}"')
            ok, message = pipelineDbHandler.create_pipeline(projectName, experimentName, pipelineRename)
        ### pipeline name same as pipeline rename
        elif pipelineName == pipelineRename:
            return Logger.responseDebug(1, "Check name correct")
        ### Experiment rename existed, return error message
        else:
            return Logger.responseError(0, message + ", please rename with other pipeline name")
    if ok:
        return Logger.responseDebug(1, 'Create success')
    return Logger.responseError(0, 'Create or rename failed')


@blueprintApp.route("/delete", methods=["POST"])
def delete():
    """
    delete pipeline
    """
    ### Get input variable
    data = request.get_json()
    deleteList = data["deleteList"]
    for delete in deleteList:
        projectName, experimentName, pipelineName = (
            delete["projectName"],
            delete["experimentName"],
            delete["pipelineName"],
        )
        ### Check if the project exists
        ok, message = pipelineDbHandler.check_project_name_existed(projectName)
        ### Project does not exist
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ### Check if the experiment exists
        ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
        ### Experiment does not exist
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ### Get experiment ID
        experimentId = pipelineDbHandler.read_value_with_cond(
            "project, experiment",
            "experiment_id",
            f'project.project_id = experiment.project_id\
            and project.project_name = "{projectName}"\
            and experiment.experiment_name = "{experimentName}"',
        )
        ### Delete pipeline
        pipelineDbHandler.delete_value("pipeline", f'experiment_id="{experimentId}" and pipeline_name="{pipelineName}"')
    return Logger.responseDebug(1, f"Delete success")


@blueprintApp.route('/set-abstract', methods=['POST'])
def set_abstract():
    """Save abstract into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name,
        "pipelineAbstract": pipeline abstract
    }
    Returns:
        tuple[0]: 0: save abstract failed, 1: save abstract success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName, pipelineAbstract \
                    = data["projectName"], data["experimentName"], data["pipelineName"], data["pipelineAbstract"]

    ok, message = pipelineDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = pipelineDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')

    experimentId = pipelineDbHandler.get_experiment_id(projectName, experimentName)
    ### update pipeline abstract
    ok, message = pipelineDbHandler.update_pipeline_abstract(experimentId, pipelineName, pipelineAbstract)

    return Logger.responseDebug(ok, message)


@blueprintApp.route('/add-favorite', methods=['POST'])
def add_favorite():
    """Add favorite pipeline into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name
    }

    Returns:
        tuple[0]: 0: Add favorite pipeline failed, 1: Add favorite pipeline success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName = data["projectName"], data["experimentName"], data["pipelineName"]

    ok, message = pipelineDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')
    ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')
    ok, message = pipelineDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    if not ok:
        return Logger.responseError(0, f'Add favorite failed / {message}')

    ### Add favorite pipeline into database
    code, message = pipelineDbHandler.add_favorite(pipelineName)

    return Logger.responseDebug(code, message)


@blueprintApp.route("/get-gpu", methods=["POST"])
def get_gpu():
    """Get GPU"""
    gpuList, processList = [], []
    pynvml.nvmlInit()
    deviceCount = pynvml.nvmlDeviceGetCount()
    for deviceID in range(deviceCount):
        handle = pynvml.nvmlDeviceGetHandleByIndex(deviceID)
        deviceName = pynvml.nvmlDeviceGetName(handle).decode("utf-8")
        memInfo = pynvml.nvmlDeviceGetMemoryInfo(handle)
        memPercentage = int(memInfo.used / memInfo.total * 100)
        fanSpeed = pynvml.nvmlDeviceGetFanSpeed(handle)
        deviceTemperature = pynvml.nvmlDeviceGetTemperature(handle, 0)
        processNum = pipelineDbHandler.get_process_num(deviceID)
        processList.append(processNum)
        gpuUsageThres = pipelineDbHandler.read_value_with_cond('basic_setting', 'gpu_usage_threshold', '1=1')
        available = pipelineDbHandler.check_gpu_available(deviceID, memPercentage, gpuUsageThres)
        gpuList.append(
            {
                "gpuName": deviceName,
                "gpuId": int(deviceID),
                "gpuMemoryUsage": memPercentage,
                "gpuFan": fanSpeed,
                "gpuTemperature": deviceTemperature,
                "processNum": processNum,
                "available": available
            }
        )
    pynvml.nvmlShutdown()
    processMinIndex = processList.index(min(processList))
    indexList = [i[0] for i in sorted(enumerate(processList), key=lambda x:x[1])]
    for index in indexList:
        if gpuList[index]["available"]:
            processMinIndex = index
            break
    dataDict = {"gpuList": gpuList, "gpuSuggest": processMinIndex}
    return Logger.responseDebug(1, "Get GPU information success", dataDict)


@blueprintApp.route("/set-gpu", methods=["POST"])
def set_gpu():
    """Set GPU"""
    ### Get input variable
    data = request.get_json()
    projectName, experimentName, pipelineName, gpuID = (
        data["projectName"],
        data["experimentName"],
        data["pipelineName"],
        data["gpuId"],
    )
    ### Check if the project exists
    ok, message = pipelineDbHandler.check_project_name_existed(projectName)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Set GPU failed' + message)
    ### Check if the experiment exists
    ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
    ### Experiment name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Set GPU failed' + message)
    ### Check if the pipeline exists
    ok, message = pipelineDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    ### Pipeline name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Set GPU failed' + message)
    ok, message = pipelineDbHandler.update_gpu_id(projectName, experimentName, pipelineName, gpuID)
    if not ok:
        return Logger.responseError(0, message)
    return Logger.responseDebug(1, message)


@blueprintApp.route("/check", methods=["POST"])
def check():
    """Check pipeline information

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name
    }
    Returns:
        tuple[0]: 0: check pipeline failed, 1: check pipeline success
        tuple[1]: log message
        tuple[2]: pipeline information
    """
    data = request.get_json()
    projectName, experimentName, pipelineName = data["projectName"], data["experimentName"], data["pipelineName"]

    ok, message = pipelineDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Check pipeline information failed / {message}')
    ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Check pipeline information failed / {message}')
    ok, message = pipelineDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    if not ok:
        return Logger.responseError(0, f'Check pipeline information failed / {message}')

    try:
        ### Get project and pipeline information
        pipelineInfo = pipelineDbHandler.get_pipeline_info(projectName, experimentName, pipelineName)

        ### Project task cannot be empty
        if pipelineInfo['project_task'] in ['', None, "None"]:
            raise Exception("Project task is empty")


        ### Get gpu information
        if pipelineInfo['gpu_id'] is None or pipelineInfo['gpu_id'] is "None":
            deviceName, gpuId = "", ""
        else:
            gpuId = int(pipelineInfo['gpu_id'])
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(gpuId)
            deviceName = pynvml.nvmlDeviceGetName(handle).decode("utf-8")

        information = {
            "pipelineName": pipelineName,
            "pipelineCreator": "someone",
            "pipelineAbstract": pipelineInfo['abstract'],
            "projectTask": pipelineInfo['project_task'],
            "gpuName": deviceName,
            "gpuId": gpuId,
            "created": pipelineInfo['created']
        }

        ### Not started training
        if pipelineInfo['status'] in [None, '']:
            data = {
                "information": information
            }

        ### start training and error happened
        elif int(pipelineInfo['status']) == -4:
            errorMsg = pipelineDbHandler.read_value_with_cond('pipeline_output', 'error_log', f'pipeline_id="{pipelineInfo["pipeline_id"]}"')
            if 'RuntimeError: stack expects each tensor to be equal size' in errorMsg:
                errorMsg = 'Inconsistent image sizes lead to abnormal training, it is recommended to enable the resize function of pre-processing'
            data = {
                    "information": information,
                    "state": {
                        "percentage": -1,
                        "eta": "",
                        "errorMsg": f'Error happened: {errorMsg}'
                    }
                }

        ### Start training
        else:
            pipeOutputInfo = pipelineDbHandler.read_value_with_cond('pipeline_output',
                                                            'cf_matrix_path, test_record, valid_record, create_time, update_time',
                                                            f'pipeline_id="{pipelineInfo["pipeline_id"]}"')

            if pipeOutputInfo.empty:
                data = {
                        "information": information,
                        "state": {
                            "percentage": 0,
                            "eta": "",
                            "errorMsg": ""
                        }
                    }

            else:
                pipeOutputInfo = pipeOutputInfo.to_dict('records')[0]
                ### Inline or just started training
                if int(pipelineInfo['status']) > 0 or pipeOutputInfo['valid_record'] in [None, '']:
                    data = {
                        "information": information,
                        "state": {
                            "percentage": 0,
                            "eta": "",
                            "errorMsg": ""
                        }
                    }
                else:
                    ### Get valid_record information
                    validRecordJson = json.loads(pipeOutputInfo["valid_record"])
                    percentage = pipelineDbHandler.calculate_execution_percentage(validRecordJson)
                    eta = pipelineDbHandler.calculate_execution_time(validRecordJson, pipeOutputInfo["create_time"], pipeOutputInfo["update_time"])
                    if pipelineInfo['project_task'] == 'classification':
                        trainResult = [{"epoch": validRecordJson[key]["model"]["epoch"], "rate": validRecordJson[key]["Valid"]["accuracy"]}
                                    for key in validRecordJson.keys()]
                    elif pipelineInfo['project_task'] == 'detection':
                        trainResult = [{"epoch": validRecordJson[key]["model"]["epoch"], "rate": validRecordJson[key]["Valid"]["precision"]}
                                    for key in validRecordJson.keys()]

                    ### Training for more than one epoch
                    if int(pipelineInfo['status']) in [-1, -2, -3]:
                        data = {
                            "information": information,
                            "state": {
                                "percentage": percentage,
                                "eta": eta,
                                "errorMsg": ""
                            },
                            "trainResult": trainResult
                        }

                    ### Testing finish
                    elif int(pipelineInfo['status']) == 0:
                        ### Get test_record information
                        testRecordJson = json.loads(pipeOutputInfo["test_record"])["Test"]["Test"]
                        cfMatrixPath = '/'.join(pipeOutputInfo["cf_matrix_path"].split('/')[1:])
                        testRecordJson["confusionMatrix"] = \
                            f"http://{pipelineDbHandler.serverHost}:{pipelineDbHandler.serverPort}/image/show-img/" + \
                            os.path.join(os.getcwd(), cfMatrixPath).replace('\\', '/')

                        data = {
                            "information": information,
                            "state": {
                                "percentage": percentage,
                                "eta": "",
                                "errorMsg": ""
                            },
                            "trainResult": trainResult,
                            "testResult": testRecordJson
                        }

                    ### Process have error
                    elif int(pipelineInfo['status']) == -4:
                        pass
    except Exception as message:
        return Logger.responseDebug(0, f'Check pipeline information failed')
    return Logger.responseDebug(1, "Check pipeline information success", data)


@blueprintApp.route("/run", methods=["POST"])
def run():
    """Check pipeline status

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name
    }
    Returns:
        tuple[0]: 0: check pipeline status failed / status error,
        1: add status to pipeline success / the pipeline has finished /
        the pipeline has in line / the pipeline is running"/ the pipeline finished incorrect
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName = data["projectName"], data["experimentName"], data["pipelineName"]

    ok, message = pipelineDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Set pipeline status failed / {message}')
    ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Set pipeline status failed / {message}')
    ok, message = pipelineDbHandler.check_pipeline_name_existed(projectName, experimentName, pipelineName)
    if not ok:
        return Logger.responseError(0, f'Set pipeline status failed / {message}')

    ### Get specify pipeline information
    pipelineInfo = pipelineDbHandler.get_pipeline_info(projectName, experimentName, pipelineName)
    ### check specify pipeline status
    code, message = pipelineDbHandler.check_pipeline_status(pipelineInfo['status'], pipelineInfo['pipeline_id'])
    return Logger.responseDebug(code, message)


@blueprintApp.route("/created", methods=["POST"])
def created():
    """Create the pipeline

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "pipelineName": pipeline name
    }
    Returns:
        tuple[0]: 1: pipeline created
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, pipelineName = data["projectName"], data["experimentName"], data["pipelineName"]

    ### Update column name created to 1
    pipelineDbHandler.update_value_with_cond('project, experiment, pipeline',
                                               'pipeline.created=1',
                                               f'project.project_name="{projectName}" \
                                                and experiment.experiment_name="{experimentName}" \
                                                and pipeline.pipeline_name="{pipelineName}" \
                                                and project.project_id=experiment.project_id \
                                                and experiment.experiment_id=pipeline.experiment_id')
    return Logger.responseDebug(1, 'Pipeline created')


# @blueprintApp.route("/preview-list", methods=["POST"])
# def preview_list():
#     """
#     preview pipeline list in info page
#     """
#     ### Get input variable
#     data = request.get_json()
#     projectName = data["projectName"]
#     experimentName = data["experimentName"]
#     ### Check if the project exists
#     ok, message = pipelineDbHandler.check_project_name_existed(projectName)
#     ### Project does not exist
#     if not ok:
#         return Logger.responseError(0, message + ", please select other project name")
#     ### is experimentName
#     if experimentName != "":
#         ok, message = pipelineDbHandler.check_experiment_name_existed(projectName, experimentName)
#         if not ok:
#             return Logger.responseError(0, message + ", please select other experiment name")
#         pipelinesList = pipelineDbHandler.generate_list(projectName, experimentName=experimentName, returnCurrentNum=4)
#     else:
#         pipelinesList = pipelineDbHandler.generate_list(projectName, returnCurrentNum=4)
#     ### 4 current pipelines in the output project if exist
#     return Logger.responseDebug(1, "Preview pipelines list success", pipelinesList)
