import os
import xml.etree.ElementTree as ET
from flask import Blueprint, request, send_file, send_from_directory, jsonify
from utils.LoggerResource.ConfigLogger import Logger
from utils.ApiResource import datasetUtil
from utils.DatabaseResource import datasetDb

prefix = '/dataset'
blueprintApp = Blueprint(prefix, __name__)
datasetDbHandler = datasetDb.DatasetDb()

@blueprintApp.route('/get-dataset-structure', methods=['POST'])
def get_dataset_structure():
    data = request.get_json()
    datasetRootPath, projectTask, projectObject = data["datasetRootPath"], data["projectTask"], data["projectObject"]
    if projectTask == 'classification':
        return cls_get_dataset_structure(datasetRootPath)
    elif projectTask == 'detection':
        if projectObject == 'image':
            return det_get_dataset_img_structure(datasetRootPath)
        elif projectObject == 'yolo_txt' or projectObject == 'bbox_txt' or projectObject == 'bbox_xml':
            return det_get_dataset_ant_structure(datasetRootPath, projectObject)
        else: ### projectObject is not image, yolo_txt, bbox_txt, or bbox_xml
            return Logger.responseError(0, 'Get dataset structure failed / Return type incorrect')
    else: ### projectTask is not classification or detection
        return Logger.responseError(0, 'Get dataset structure failed / Project task incorrect')


def other(path): # TC:O(N^2) SC:O(N)
    result = []
    for file in os.listdir(path):
        # check is a folder
        if os.path.isdir(path + "/" + file):

            # check is Train, Valid, Test
            if file in ["Train", "Valid", "Test"]:
                return False

            # Special char check
            if not datasetUtil.check_special_characters(file):
                return False

            # first char is english
            if file[0].isdigit():
                return False

            # check folder img
            if datasetUtil.img_folder_check(path + "/" + file):
                result.append(file)

        # if is img
        elif datasetUtil.img_check(path + "/" + file):
            return True

    if len(result)==0:
        return False
    else:
        return result


def train_val_test(path): # TC:O(N^3) SC:O(N)
    types = {"Train": 0, "Valid": 0, "Test": 0}
    clsSubfolder = []

    # Check classify num
    for folder in os.listdir(path):
        if datasetUtil.img_check(folder):
            return False
        # Train, Valid, Test
        elif folder in types:
            types[folder] += 1
            subfolderCheck = set()
            for cls in os.listdir(path + "/" + folder):
                # Special char check
                if not datasetUtil.check_special_characters(cls):
                    return False
                # first char is english
                if cls[0].isdigit():
                    return False
                # class folder name should not be 'train', 'valid', 'test'
                if cls.lower() in ['train', 'valid', 'test']:
                    return False
                # if is image
                if datasetUtil.img_check(cls):
                    return False
                # cls folder is folder not txt
                if not os.path.isdir((path + "/" + folder + "/" + cls)):
                    continue
                # check folder img
                if datasetUtil.img_folder_check(path + "/" + folder + "/" + cls):
                    types[folder] += 1
                    subfolderCheck.add(cls)
                else:
                    return False
            clsSubfolder.append(subfolderCheck)
        # found other Folder
        elif os.path.isdir(path + "/" + folder):
            return False

    # Train, Valid, Test should have at least one class subfolder and
    # each of them should have same numbers of subfolders
    if sum(types.values()) == 3 or len(set(types.values())) != 1:
        return False

    # Just judge set contains Train, Valid, Test
    if len(clsSubfolder) != 3:
        return False
    # check subfolder name are same (set() compare)
    return clsSubfolder[0] == clsSubfolder[1] == clsSubfolder[2]


def cls_get_dataset_structure(datasetRootPath):
    """
    說明: 確認 datasetPath 下有哪些合法資料集, 並撈出資料集樹狀結構
    input: datasetRootPath (str)
    output: 資料集樹狀結構
    註:
        可參考 SALA1 的 list_deploy_folder 或是 list_dataset_folder
        合法資料集:
            1. 資料夾下全部都是影像, 沒有分資料集, 也沒有分類別
            2. 資料夾下已有分類別, 類別名稱不可為中文也不可用數字開頭, 可有 "-"或是"_", 其餘特殊字元不允許, 要有影像
            3. 資料夾下已分好資料集(名稱必須為 Train / Valid / Test), 也分好類別, 各資料集下的類別數必須相同, 不可有影像散落在外, Train 資料夾下的各類別都必須要有影像, 不可以是空資料夾
            4. 使用者未完成編輯,需要到SALA上使用
        {
            "datasetRootPath": "D:/Users/ChadYCLu/SALA2/data",
            "projectTask": "classification",
            "projectObject": "image"
        }
    """
    result = []
    for dataset in os.listdir(datasetRootPath): # TC:O(n^4) SC:ON(N)
        if os.path.isdir(datasetRootPath + "/" + dataset):
            out = other(datasetRootPath + "/" + dataset)
            if out != False:
                result += [dataset] # + [dataset + "/" + i for i in out]
                continue
            # strict (Train, Valid, Test)
            if train_val_test(datasetRootPath + "/" + dataset):
                result += [dataset]

    if len(result) == 0:
        return Logger.responseError(0, "Get dataset structure failed / Get classification folder failed")
    return Logger.responseDebug(1, "Get dataset structure success", result)


def det_get_dataset_img_structure(datasetRootPath):
    """
    說明: 確認 datasetPath 下有哪些合法資料集, 並撈出資料集樹狀結構
    input: datasetRootPath (str)
    output: 資料集樹狀結構
    註:
        可參考 SALA1 的 list_deploy_folder 或是 list_dataset_folder
        合法資料集:
            1. 資料夾下全部都是影像, 沒有分資料集, 也沒有分類別
            2. 資料夾下已有分類別, 類別名稱不可為中文也不可用數字開頭, 可有 "-"或是"_", 其餘特殊字元不允許, 要有影像
            3. 資料夾下已分好資料集(名稱必須為 Train / Valid / Test), 也分好類別, 各資料集下的類別數必須相同, 不可有影像散落在外, Train 資料夾下的各類別都必須要有影像, 不可以是空資料夾
            4. 使用者未完成編輯,需要到SALA上使用
    """

    def other(path): # TC:O(N) SC:O(N)
        result = []
        foundimg = 0
        for file in os.listdir(path):
            # check is a folder
            if os.path.isdir(path + "/" + file):

                # check is Train、Valid、Test
                if file in ["Train", "Valid", "Test"]:
                    return False

                # Special char check
                if not datasetUtil.check_special_characters(file):
                    return False

                # first char is english
                if file[0].isdigit():
                    return False

                # check folder img
                if datasetUtil.img_folder_check(path + "/" + file):
                    result.append(file)
            else:
                if datasetUtil.img_check(file):
                    foundimg += 1

        if len(result) == 0 and foundimg == 0:
            return False
        else:
            return result

    def train_val_test(path): # TC:O(N^2) SC:O(N)
        types = {"Train": 0, "Valid": 0, "Test": 0}

        # Check classify num
        for folder in os.listdir(path):
            if datasetUtil.img_check(folder):
                return False
            # Train, Valid, Test
            elif os.path.isdir(path + '/' + folder):
                if folder in types:
                    types[folder] += 1
                    # check folder img
                    if not datasetUtil.img_folder_check(path + "/" + folder):
                        return False
                else:
                    return False

        return len(set(types.values())) == 1 and sum(types.values()) == 3


    result = []
    for dataset in os.listdir(datasetRootPath): # TC:O(n^4) SC:ON(N)
        # print("dataset: ", dataset)
        if os.path.isdir(datasetRootPath + "/" + dataset):
            # all img
            if datasetUtil.img_folder_check(datasetRootPath + "/" + dataset):
                result.append(dataset)
                continue
            # other
            out = other(datasetRootPath + "/" + dataset)
            if out != False:
                result += [dataset] #+[dataset + "/" + i for i in out]
                continue
            # strict (Train、Valid、Test)
            if train_val_test(datasetRootPath  + "/" + dataset):
                result += [dataset]

    if len(result) == 0:
        return Logger.responseError(0, "Get dataset structure failed / Get detection folder failed")
    return Logger.responseDebug(1, "Get dataset structure success", result)


def det_get_dataset_ant_structure(datasetRootPath, projectObject):
    """
    說明: 確認 datasetPath 下有哪些合法資料集, 並撈出資料集樹狀結構
    input: datasetRootPath (str)
    output: 資料集樹狀結構
    註:
        可參考 SALA1 的 list_deploy_folder 或是 list_dataset_folder
        合法資料集:
            1. 資料夾下全部都是影像, 沒有分資料集, 也沒有分類別
            2. 資料夾下已有分類別, 類別名稱不可為中文也不可用數字開頭, 可有 "-"或是"_", 其餘特殊字元不允許, 要有影像
            3. 資料夾下已分好資料集(名稱必須為 Train / Valid / Test), 也分好類別, 各資料集下的類別數必須相同, 不可有影像散落在外, Train 資料夾下的各類別都必須要有影像, 不可以是空資料夾
            4. 使用者未完成編輯,需要到SALA上使用
    """

    def bbox_xml(xml_file): # TC: O(1) SC: O(1)
        try:
            xmlTree = ET.parse(xml_file)
            xmlRoot = xmlTree.getroot()
            for info in xmlRoot.findall('object'): # just check one line
                name = info.find('name').text
                bbox = info.find('bndbox')
                xmin = int(bbox[0].text)
                ymin = int(bbox[1].text)
                xmax = int(bbox[2].text)
                ymax = int(bbox[3].text)
                # print(name, xmin, ymin, xmax, ymax)
                if name != "" and xmin != "" and ymin != "" and xmax != "" and ymax != "":
                    return True
                else:
                    return False
        except:
            return False

    def bbox_txt(bbox_txt): # TC: O(1) SC: O(1)
        try:
            with open(bbox_txt) as f:
                line = f.readlines()[0].split(" ")
                _ = [int(line[0]), int(line[1]), int(line[2]), int(line[3]), int(line[4])]
                f.close()
                return True
        except:
            f.close()
            return False

    def yolo_txt(yolo_txt): # TC: O(1) SC: O(1)
        try:
            with open(yolo_txt) as f:
                line = f.readlines()[0].split(" ")
                line = [int(line[0]), float(line[1]), float(line[2]), float(line[3]), float(line[4])]
                f.close()
                for i in range(1, 5):
                    if not (0 <= line[i] <= 1):
                        return False
                return True
        except:
            f.close()
            return False

    def anno_check(path, imgname, type): # TC: O(1) SC: O(1)
        # bbox xml
        if imgname.lower().endswith(".xml") and type == "bbox_xml":
            if bbox_xml(path + "/" + imgname):
                return True
        # bbox txt
        if imgname.lower().endswith(".txt") and type == "bbox_txt":
            if bbox_txt(path + "/" + imgname):
                return True
        # yolo txt
        if imgname.lower().endswith(".txt") and type == "yolo_txt":
            if yolo_txt(path + "/" + imgname):
                return True
        return False

    def anno_folder_check(path, type): # TC: O(N) SC: O(1)
        count = 0
        for img in os.listdir(path):
            if os.path.isdir(path + "/" + img):
                return False
            else:
                if anno_check(path ,img, type):
                    count += 1
        return count >= 1

    def other(path, type): # TC:O(N) SC:O(N)
        result = []
        foundimg = 0
        for file in os.listdir(path):
            # check is a folder
            if os.path.isdir(path + "/" + file):

                # check is Train、Valid、Test
                if file in ["Train", "Valid", "Test"]:
                    return False

                # Special char check
                if not datasetUtil.check_special_characters(file):
                    return False

                # first char is english
                if file[0].isdigit():
                    return False

                # check folder anno
                if anno_folder_check(path + "/" + file, type):
                    result.append(file)
            else:
                if anno_check(path, file, type):
                    foundimg += 1

        if len(result)==0 and foundimg == 0:
            return False
        else:
            return result

    def train_val_test(path, type): # TC:O(N^2) SC:O(N)
        types = {"Train": 0, "Valid": 0, "Test": 0}

        # Check classify num
        for folder in os.listdir(path):
            if anno_check(path, folder, type):
                return False
            # Train, Valid, Test
            elif os.path.isdir(path + '/' + folder):
                if folder in types:
                    types[folder] += 1
                    # check folder img
                    if not anno_folder_check(path + "/" + folder, type):
                        return False
                else:
                    return False
        return len(set(types.values())) == 1 and sum(types.values()) == 3


    result = []
    for dataset in os.listdir(datasetRootPath): # TC:O(n^4) SC:ON(N)
        # print("dataset: ", dataset)
        if os.path.isdir(datasetRootPath + "/" + dataset):
            # all img
            if anno_folder_check(datasetRootPath + "/" + dataset, projectObject):
                result.append(dataset)
                continue
            # other
            out = other(datasetRootPath + "/" + dataset, projectObject)
            if out != False:
                result += [dataset] #+[dataset + "/" + i for i in out]
                continue
            # strict (Train、Valid、Test)
            if train_val_test(datasetRootPath  + "/" + dataset, projectObject):
                result += [dataset]

    if len(result) == 0:
        return Logger.responseError(0, "Get dataset structure failed / Get annotation folder failed")
    return Logger.responseDebug(1, "Get dataset structure success", result)


@blueprintApp.route('/cls-upload', methods=['POST'])
def cls_upload():
    """
    說明: 依照 get_dataset_struc_cls 的三種合法資料集狀況, 把路徑下的影像寫入DB的 image 表
          1. 全部影像寫入 image 表中即可, task 皆為 null
          2. 全部影像寫入 image 表中, 並在 label_class 表中紀錄此資料集有哪些類別, 並在 label 表中紀錄已有類別的影像
          3. 若已拆分資料集(Train / Valid / Test), 除了第2.要做的事情外, 還要計算三個資料集的比例, 並在 project 表記錄比例, 且紀錄每張影像的task
          註:
            確認資料集比例: 計算 Train / Valid / Test 三個資料夾下的資料總數，即可得到比例

    Input: {
        "projectName": project name,
        "imagePath": image path
    }
    Returns:
        tuple[0]: 0: upload classification dataset failed, 1: upload classification dataset success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, imgFolderPath = data["projectName"], data["imagePath"]
    ok, message = datasetDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, message)
    if not os.path.exists(imgFolderPath):
        return Logger.responseError(0, f"Upload classification dataset failed / The image path is not existed")

    ### First, remove existing database data for projectName
    datasetDbHandler.remove_existing_label_class_db(projectName)
    datasetDbHandler.remove_existing_dataset_db(projectName)
    datasetDbHandler.update_value_with_cond('project', f'train_rate="", valid_rate="", test_rate=""', f'project_name="{projectName}"')

    ### Second, add project information into dataset_db and get dataset id
    ok, message = datasetDbHandler.save_proj_dataset('classification', projectName, imgFolderPath)
    if not ok:
        return Logger.responseError(0, message)
    projectId = datasetDbHandler.read_value_with_cond("project", "project_id", f"project_name='{projectName}'")
    datasetId = datasetDbHandler.get_dataset_id(projectId)


    isSplit = False ### The value is True if is a split dataset; Otherwise, the value is False
    ### Dataset is split
    if train_val_test(imgFolderPath):
        isSplit = True
        ### Get classified information of legal dataset
        classifiedInfo, listOfClassifiedName, imgNumsOfSplitType = datasetUtil.get_dataset_info(imgFolderPath)
        splitRate = datasetUtil.calculate_split_rate(imgNumsOfSplitType)
        datasetDbHandler.update_project_split_rate(projectName, splitRate)
        ### Deal with classified information
        ok, message = datasetDbHandler.deal_with_classifiedInfo(projectName, datasetId, classifiedInfo, listOfClassifiedName, isSplit)

    ### Dataset is not split
    elif other(imgFolderPath):
        ### Must have folders in dataset and Must does not have any images in dataset outside
        if other(imgFolderPath) is not True:
            ### Get classified information of legal dataset
            classifiedInfo = {}
            listOfClassifiedName = []
            for folderName in other(imgFolderPath):
                imgPath = os.path.join(imgFolderPath, folderName)
                classifiedInfo[imgPath] = datasetUtil.remove_non_image_files(os.listdir(imgPath))
                listOfClassifiedName.append(folderName)

            ### Deal with classified information
            ok, message = datasetDbHandler.deal_with_classifiedInfo(projectName, datasetId, classifiedInfo, listOfClassifiedName, isSplit)
            if not ok:
                return Logger.responseDebug(0, f"Upload classification dataset failed / error 1")

        ### Must have images in dataset outside and Maybe have folder in dataset
        else:
            ### Deal with unclassified information
            unclassifiedInfo = {}
            ### Get all image in folder
            unclassifiedInfo[imgFolderPath] = datasetUtil.remove_non_image_files(
                [file for file in os.listdir(imgFolderPath) if os.path.isfile(os.path.join(imgFolderPath, file))]
            )
            ok, message = datasetDbHandler.deal_with_unclassifiedInfo(unclassifiedInfo, datasetId)
            if not ok:
                return Logger.responseDebug(0, f"Upload classification dataset failed / error 2")

            ### Deal with classified information if have folder in dataset
            classifiedInfo = {}
            listOfClassifiedName = []
            for clsName in os.listdir(imgFolderPath):
                clsPath = os.path.join(imgFolderPath, clsName)
                if os.path.isdir(clsPath):
                    ### Get classified information of legal dataset
                    imageNames = datasetUtil.remove_non_image_files(os.listdir(clsPath))
                    if len(imageNames) > 0:
                        classifiedInfo[clsPath] = imageNames
                        listOfClassifiedName.append(clsName)
            ### Deal with classified information
            ok, message = datasetDbHandler.deal_with_classifiedInfo(projectName, datasetId, classifiedInfo, listOfClassifiedName, isSplit)
            if not ok:
                return Logger.responseDebug(0, f"Upload classification dataset failed / error 3")

    else:
        return Logger.responseDebug(0, f"Upload classification dataset failed")

    return Logger.responseDebug(1, "Upload classification dataset success")


@blueprintApp.route('/det-upload', methods=['POST'])
def det_upload():
    """Upload detection dataset.
    """
    ### Get input variable
    data = request.get_json()
    projectName, imgFolderPath, antFolderPath, antType = data["projectName"], data["imagePath"], data["annotationPath"], data["annotationType"]
    datasetName = projectName
    ### Check if the project exists
    ok, message = datasetDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, message)
    if not os.path.exists(imgFolderPath):
        return Logger.responseError(0, f"Upload detection dataset failed / The image path is not existed")
    ### Get project ID
    projectId = datasetDbHandler.read_value_with_cond("project", "project_id", f"project_name='{projectName}'")
    ### Check if the dataset exists
    ok, message = datasetDbHandler.check_dataset_name_existed(datasetName)
    ### Delete if dataset exists
    if ok:
        datasetId = datasetDbHandler.get_dataset_id(projectId) # Get old dataset ID
        datasetDbHandler.delete_value('label_class', f'dataset_id="{datasetId}"')
        datasetDbHandler.delete_value('dataset', f'dataset_id="{datasetId}"')
        datasetDbHandler.update_value_with_cond('project', f'train_rate="", valid_rate="", test_rate=""', f'project_name="{projectName}"')
    ### Create dataset
    datasetDbHandler.save_proj_dataset('detection', projectName, imgFolderPath, antType, antFolderPath)
    datasetId = datasetDbHandler.get_dataset_id(projectId) # Get new dataset ID
    ### Contains annotation files
    if antFolderPath=="":
        ok, message = datasetDbHandler.upload_img(datasetId, imgFolderPath)
    ### Not contains annotation files
    else:
        ok, message = datasetDbHandler.upload_img_and_ant(projectName, datasetId, imgFolderPath, antFolderPath, antType)
    if ok: # Currently only ok
        return Logger.responseDebug(1, "Upload detection dataset success")
    return Logger.responseError(0, "Upload detection dataset failed")


@blueprintApp.route('/get-split-rate', methods=['POST'])
def get_split_rate():
    """Get split rate

    Input: {
        "projectName": project name
    }
    Returns:
        tuple[0]: 0: get dataset split rate failed, 1: get dataset split rate success
        tuple[1]: log message
        tuple[2]: split rate
    """
    data = request.get_json()
    projectName = data["projectName"]
    ok, message = datasetDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, message)

    ### Get split rate of this project
    ok, splitRate = datasetDbHandler.get_split_rate(projectName)
    if ok:
        return Logger.responseDebug(1, "Get dataset split rate success", splitRate)

    return Logger.responseDebug(0, "Get dataset split rate failed")


@blueprintApp.route("/set-split-rate", methods=["POST"])
def set_split_rate():
    """Update split rate and image task on database

    Input: {
        "projectName": project name
        "datasetPath": dataset path,
        "splitRate": split rate
    }
    Returns:
        tuple[0]: 0: split dataset failed, 1: original split rate is the same as split rate to be updated / split dataset success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, _, splitRate = data["projectName"], data["datasetPath"], data["split"]
    ok, message = datasetDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f"Split dataset failed / {message}")

    ### get original project split rate from database
    ok, originalSplitRate = datasetDbHandler.get_split_rate(projectName)

    ### get project id, project task, and dataset id by project name
    projectInfo = datasetDbHandler.read_value_with_cond("project", "project_id, project_task", f"project_name='{projectName}'")
    projectId, projectTask = projectInfo.to_dict()['project_id'].get(0), projectInfo.to_dict()['project_task'].get(0)
    datasetId = datasetDbHandler.get_dataset_id(projectId)

    ### get all image id and class id
    allImageIdOfClass = datasetDbHandler.get_image_list(projectTask, datasetId)

    ### split dataset, save the splited result, and update split rate, if split failed, get_image_id_of_split() will reset project split rate
    ok, imageIdOfSplit = datasetDbHandler.get_image_id_of_split(allImageIdOfClass, splitRate, projectName, projectTask)
    if not ok:
        return Logger.responseError(0, 'Split dataset failed / ' + str(imageIdOfSplit))
    if datasetUtil.have_same_split_rate(originalSplitRate, splitRate):
        datasetDbHandler.update_value_with_cond('dataset', f'split={1}', f'dataset_id="{datasetId}"')
        return Logger.responseDebug(1, "Original split rate is the same as split rate to be updated")
    ### Update project split rate on database
    datasetDbHandler.update_project_split_rate(projectName, splitRate)   ### update project split rate on database
    datasetDbHandler.update_image_task(imageIdOfSplit)
    datasetDbHandler.update_value_with_cond('dataset', f'split={1}', f'dataset_id="{datasetId}"')

    return Logger.responseDebug(1, "Split dataset success")
