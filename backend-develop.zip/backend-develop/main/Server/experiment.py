import json
from flask import Blueprint, request
from utils.LoggerResource.ConfigLogger import Logger
from utils.ApiResource.ExpConfig import ClsExpConfig, DetExpConfig
from utils.ApiResource import ModelDescription, encode_key, decode_key
from utils.DatabaseResource import experimentDb

prefix = "/experiment"
blueprintApp = Blueprint(prefix, __name__)
experimentDbHandler = experimentDb.ExperimentDb()


@blueprintApp.route("/get-classification-configs", methods=["POST"])
def get_classification_configs():
    """
    get classification configs from file
    """
    return Logger.responseDebug(1, "Get classification configs success", ClsExpConfig.config)


@blueprintApp.route("/get-detection-configs", methods=["POST"])
def get_detection_configs():
    """
    get detection configs from file
    """
    return Logger.responseDebug(1, "Get detection configs success", DetExpConfig.config)


@blueprintApp.route("/get-model-description", methods=["POST"])
def get_model_description():
    """
    get model description from file
    """
    return Logger.responseDebug(1, "Get model description success", ModelDescription.modelDescription)


@blueprintApp.route("/get-list", methods=["POST"])
def get_list():
    """
    get experiments list of project
    """
    ### Get input variable
    data = request.get_json()
    projectName = data["projectName"]
    ### Check if the project exists
    ok, message = experimentDbHandler.check_project_name_existed(projectName)
    ### Project does not exist
    if not ok:
        return Logger.responseError(0, 'Get list failed / ' + message)
    ### Generate all experiments
    experimentsList = experimentDbHandler.generate_list(projectName)
    return Logger.responseDebug(1, "Get list success", experimentsList)


@blueprintApp.route("/create", methods=["POST"])
def create():
    """Create a new experiment or rename experiment"""
    ### Get input variable
    data = request.get_json()
    projectName, experimentName, experimentRename = (
        data["projectName"],
        data["experimentName"],
        data["experimentRename"],
    )
    ### Check if the project exists
    ok, message = experimentDbHandler.check_project_name_existed(projectName)
    ### Project name not existed, return error message
    if not ok:
        return Logger.responseError(0, 'Create failed / ' + message)
    ### Check if the experiment exists
    ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentName)
    ### Experiment name existed or experiment name not existed and need to reaname, return error message
    if (ok and experimentRename == "") or (not ok and experimentRename != ""):
        return Logger.responseError(0, 'Create failed / Incorrect rename situation')
    ### Experiment name is new, create experiment
    if experimentRename == "":
        ok, message = experimentDbHandler.create_experiment(projectName, experimentName)
    ### Experiment name is old, execute Rename
    else:
        ### Check if the rename experiment exists
        ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentRename)
        ### Experiment name is old, execute Rename
        if not ok:
            # ok, message = experimentDbHandler.experiment_rename(projectName, experimentName, experimentRename)
            projectId = experimentDbHandler.read_value_with_cond('project', 'project_id', f'project_name="{projectName}"')
            experimentDbHandler.delete_value('experiment', f'project_id="{projectId}" and experiment_name="{experimentName}"')
            ok, message = experimentDbHandler.create_experiment(projectName, experimentRename)
        ### experiment name same as experiment rename
        elif experimentName == experimentRename:
            return Logger.responseDebug(1, "Check name correct")
        ### Experiment rename existed, return error message
        else:
            return Logger.responseError(0, message + ", please rename with other experiment name")
    if ok:
        return Logger.responseDebug(1, 'Create success')
    return Logger.responseError(0, 'Create or rename failed')


@blueprintApp.route("/delete", methods=["POST"])
def delete():
    """
    delete experiment
    """
    data = request.get_json()
    deleteList = data["deleteList"]
    for experiment in deleteList:
        projectName, experimentName = experiment["projectName"], experiment["experimentName"]
        ok, message = experimentDbHandler.check_project_name_existed(projectName)
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentName)
        if not ok:
            return Logger.responseError(0, f"Delete failed / {message}")
        projectId = experimentDbHandler.read_value_with_cond("project", "project_id", f'project_name="{projectName}"')
        experimentDbHandler.delete_value("experiment", f'project_id="{projectId}" AND experiment_name="{experimentName}"')
    return Logger.responseDebug(1, f"Delete success")


@blueprintApp.route("/add-favorite", methods=["POST"])
def add_favorite():
    """Add favorite experiment into database

    Input: {
        "projectName": project name
    }
    Returns:
        tuple[0]: 0: add favorite project failed, 1: add favorite success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName = data["projectName"], data["experimentName"]
    ok, message = experimentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f"Add favorite failed / {message}")
    projectId = experimentDbHandler.read_value_with_cond("project", "project_id", f"project_name='{projectName}'")
    ### Add favorite project into database
    code, message = experimentDbHandler.add_favorite(projectId, experimentName)
    return Logger.responseDebug(code, message)


@blueprintApp.route("/select-key", methods=["POST"])
def select_key():
    """Save selected key into database

    Input: {
        "projectName": project name
        "experimentName": experiment name,
        "experimentKey": "" or experiment key
    }
    Returns:
        tuple[0]: 0: select experiment key failed, 1: create pipeline success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, experimentKey = data["projectName"], data["experimentName"], data["experimentKey"]
    if experimentKey != "":
        ok, experimentConfig = decode_key(experimentKey)
        if not ok:
            return Logger.responseError(0, experimentConfig)

    ok, message = experimentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Set experiment key failed / {message}')
    ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Set experiment key failed / {message}')

    projectId = experimentDbHandler.read_value_with_cond("project", "project_id", f"project_name='{projectName}'")
    if experimentKey == "":
        projectTask = experimentDbHandler.get_project_task(projectId)
        if projectTask == "classification":
            defaultConfigtype = "Cls"
        else:
            defaultConfigtype = "Det"
        ### Get config
        with open(f"./utils/ApiResource/ExpConfig/{defaultConfigtype}ExpConfig.json", "r") as jsonfile:
            defaultConfig = json.load(jsonfile)
        ### Encode config
        ok, experimentKey = encode_key(defaultConfig)
        if not ok:
            return Logger.responseError(0, 'Set experiment key failed / ' + experimentKey)
    code, message = experimentDbHandler.update_experiment_key_and_created(projectId, experimentName, experimentKey)
    return Logger.responseDebug(code, message)


@blueprintApp.route("/set-configs", methods=["POST"])
def set_configs():
    """Set experiment configs

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "experimentConfig": {
            "ConfigPreprocess": {
                ...
    }
    Returns:
        tuple[0]: 0: set experiment key failed, 1: create pipeline success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, experimentConfig = (
        data["projectName"],
        data["experimentName"],
        data["experimentConfig"],
    )

    ok, message = experimentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Set configs failed / {message}')
    ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Set configs failed / {message}')

    ### Get project id
    projectId = experimentDbHandler.read_value_with_cond("project", "project_id", f"project_name='{projectName}'")
    ### Encode config
    ok, experimentKey = encode_key(experimentConfig)
    if not ok:
        return Logger.responseError(0, experimentKey)
    code, message = experimentDbHandler.update_experiment_key_and_created(projectId, experimentName, experimentKey)
    return Logger.responseDebug(code, message)


@blueprintApp.route("/check", methods=["POST"])
def check():
    """check experiment information

    Input: {
        "projectName": 'proj1'
        "experimentName": "exp1"
    }
    Output: Logger message
    """
    data = request.get_json()
    projectName, experimentName = data["projectName"], data["experimentName"]

    # ok, message = experimentDbHandler.check_project_name_existed(projectName)
    # if not ok:
    #     return Logger.responseError(0, f'Check experiment information failed / {message}')
    # ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentName)
    # if not ok:
    #     return Logger.responseError(0, f'Check experiment information failed / {message}')

    try:
        ### Get project task, experiment key, experiment abstract, and experiment config
        experimentInfo = experimentDbHandler.get_experiment_info(projectName, experimentName)
        experimentConfig = ""
        if experimentInfo['experiment_key'] != "":
            ok, experimentConfig = decode_key(experimentInfo['experiment_key'])   ### Experiment key decode to experiment config
            if not ok:
                return Logger.responseError(0, experimentConfig)
    except Exception as message:
        return Logger.responseDebug(0, f'Check experiment information failed')

    data = {
        "information": {
            "experimentName": experimentName,
            "experimentKey": experimentInfo['experiment_key'],
            "experimentCreator": "someone",
            "experimentAbstract": experimentInfo['abstract'],
            "projectTask": experimentInfo['project_task'],
            "created": experimentInfo['created']
        },
        "experimentConfig": experimentConfig,
    }
    return Logger.responseDebug(1, "Check experiment information success", data)


@blueprintApp.route('/set-abstract', methods=['POST'])
def set_abstract():
    """Save abstract into database

    Input: {
        "projectName": project name,
        "experimentName": experiment name,
        "experimentAbstract": experiment abstract
    }
    Returns:
        tuple[0]: 0: save abstract failed, 1: save abstract success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName, experimentAbstract \
                    = data["projectName"], data["experimentName"], data["experimentAbstract"]

    ok, message = experimentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')
    ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f'Save abstract failed / {message}')

    projectId = experimentDbHandler.read_value_with_cond("project", "project_id", f"project_name='{projectName}'")

    ### update experiment abstract
    ok, message = experimentDbHandler.update_experiment_abstract(projectId, experimentName, experimentAbstract)

    return Logger.responseDebug(ok, message)


@blueprintApp.route('/export-key', methods=['POST'])
def export_key():
    """Export experiment key

    Input: {
        "projectName": project name,
        "experimentName": experiment name
    }
    Returns:
        tuple[0]: 0: export experiment key failed, 1: export experiment key success
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName = data["projectName"], data["experimentName"]

    ok, message = experimentDbHandler.check_project_name_existed(projectName)
    if not ok:
        return Logger.responseError(0, f"Export experiment key failed / {message}")
    ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentName)
    if not ok:
        return Logger.responseError(0, f"Export experiment key failed / {message}")

    experimentInfo = experimentDbHandler.get_experiment_info(projectName, experimentName)
    if experimentInfo['experiment_key'] == None or experimentInfo['experiment_key'] == '':
        return Logger.responseDebug(0, "Export experiment key failed")

    return Logger.responseDebug(1, "Export experiment key success", {"experimentKey": experimentInfo['experiment_key']})


@blueprintApp.route("/created", methods=["POST"])
def created():
    """Create the experiment

    Input: {
        "projectName": project name,
        "experimentName": experiment name
    }
    Returns:
        tuple[0]: 1: experiment created
        tuple[1]: log message
    """
    data = request.get_json()
    projectName, experimentName = data["projectName"], data["experimentName"]

    experimentDbHandler.update_value_with_cond('project, experiment',
                                               'experiment.created=1',
                                               f'project.project_name="{projectName}" \
                                                and experiment.experiment_name="{experimentName}" \
                                                and project.project_id=experiment.project_id')
    return Logger.responseDebug(1, 'Experiment created')


# @blueprintApp.route('/get-info', methods=['POST'])
# def get_info():
#     """get experiment information

#     Input: {
#         "projectName": "proj1",
#         "experimentName": "exp1"
#     }
#     Output: Logger message
#     """
#     data = request.get_json()
#     projectName, experimentName = data["projectName"], data["experimentName"]

#     ok, message = experimentDbHandler.check_project_name_existed(projectName)
#     if not ok:
#         return Logger.responseError(0, f"Get experiment information failed / {message}")
#     ok, message = experimentDbHandler.check_experiment_name_existed(projectName, experimentName)
#     if not ok:
#         return Logger.responseError(0, f"Get experiment information failed / {message}")

#     projectId = experimentDbHandler.read_value_with_cond("project", "project_id", f'project_name="{projectName}"')
#     try:
#         ### Get project task, experiment key, experiment abstract, and experiment config
#         projectTask = experimentDbHandler.get_project_task(projectId)

#         experimentInfo = experimentDbHandler.get_experiment_info(projectName, experimentName)
#         experimentKey = "" if experimentInfo['experiment_key'] == None or experimentInfo['experiment_key'] == "None" \
#                             else experimentInfo['experiment_key']
#         experimentAbstract = "" if experimentInfo['abstract'] == None or experimentInfo['abstract'] == "None" \
#                             else experimentInfo['abstract']

#         experimentConfig = ""
#         if experimentKey != "":
#             ok, experimentConfig = decode_key(experimentKey)   ### Experiment key decode to experiment config
#             if not ok:
#                 return Logger.responseError(0, experimentConfig)
#     except Exception as message:
#         return Logger.responseDebug(0, f'Get experiment information failed / {message}')

#     output = {
#         "information": {
#             "experimentName": experimentName,
#             "experimentKey": experimentKey,
#             "experimentCreator": "someone",  # 角色劃分待規劃
#             "experimentAbstract": experimentAbstract,
#             "projectTask": projectTask
#         },
#         "experimentConfig": experimentConfig
#     }
#     return Logger.responseDebug(1, "Get experiment information success", output)


# @blueprintApp.route("/preview-list", methods=["POST"])
# def preview_list():
#     """
#     preview experiment list in info page
#     """
#     ### Get input variable
#     data = request.get_json()
#     projectName = data["projectName"]
#     ### Check if the project exists
#     ok, message = experimentDbHandler.check_project_name_existed(projectName)
#     ### Project does not exist
#     if not ok:
#         return Logger.responseError(0, message + ", please select other project name")
#     ### 4 current experiments in the output project if exist
#     experimentsList = experimentDbHandler.generate_list(projectName, returnCurrentNum=4)
#     return Logger.responseDebug(1, "Preview experiments list success", experimentsList)
