from flask import Blueprint, request
from utils.LoggerResource.ConfigLogger import Logger
from utils.DatabaseResource import labelToolDb

prefix = '/label-tool'
blueprintApp = Blueprint(prefix, __name__)
labelToolDbHandler = labelToolDb.LabelToolDb()

@blueprintApp.route('/cls-get-img-list', methods=['POST'])
def cls_get_img_list():
    """Give projectName and datasetName and return image list

    Returns:
        log message: {'code': code, 'message': message, 'data': {"className": list, "fileList": list, "datasetName": str}}
        fileList: [{"fileName": str, "url": str, "className": str}]
    """
    ### Step 1: Get projectName, datasetPath
    data = request.get_json()
    projectName = data["projectName"]
    ### step 2: Get projectId in DB by projectName
    ok, projectId = labelToolDbHandler.get_project_id(projectName)
    if not ok: return Logger.responseError(0, projectId)


    ### Step 3: Query className list and image list
    ok, datasetNameDb = labelToolDbHandler.get_dataset_name(projectId)
    if not ok: return Logger.responseError(0, datasetNameDb)
    ok, datasetIdDb = labelToolDbHandler.get_dataset_id(projectId)
    if not ok: return Logger.responseError(0, datasetIdDb)
    queryList = labelToolDbHandler.cls_get_img_classname_list(datasetIdDb, datasetNameDb, labelToolDbHandler.serverHost, labelToolDbHandler.serverPort)

    return Logger.responseDebug(1, 'Get imgList success', queryList)


@blueprintApp.route('/det-get-img-list', methods=['POST'])
def det_get_img_list():
    """Give projectName and datasetName and return image list

    Returns:
        log message: {'code': code, 'message': message, 'data': {"className": list, "fileList": list, "datasetName": str}}
        fileList: [{"className": str, "url": str, "fileName": str, labelId: str, "x1": int, "y1": int, "x2": int, "y2": int}]
    """
    ### Step 1: Get projectName, datasetName
    data = request.get_json()
    projectName = data["projectName"]
    ### step 2: Get projectId in DB by projectName
    ok, projectId = labelToolDbHandler.get_project_id(projectName)
    if not ok: return Logger.responseError(0, projectId)

    ### Step 3: Query className list and image list
    ok, datasetNameDb = labelToolDbHandler.get_dataset_name(projectId)
    if not ok: return Logger.responseError(0, datasetNameDb)
    ok, datasetIdDb = labelToolDbHandler.get_dataset_id(projectId)
    if not ok: return Logger.responseError(0, datasetIdDb)
    queryList = labelToolDbHandler.det_get_img_classname_list(datasetIdDb, datasetNameDb, labelToolDbHandler.serverHost, labelToolDbHandler.serverPort)

    return Logger.responseDebug(1, 'Return imgList success', queryList)


@blueprintApp.route('/cls-save-img-label', methods=['POST'])
def cls_save_img_label():
    """Give datasetName, className, image name and save image label to database

    Returns:
        Logger message

    """
    ### Step 1: Get datasetPath, className, imgList
    data = request.get_json()
    projectName, className, imgList, labeled = data["projectName"], data["classList"], data["fileList"], data["isLabel"]
    
    ### step 1.5: get projectId name by projectName
    projectId = labelToolDbHandler.read_value_with_cond('project', 'project_id', f'project_name="{projectName}"')
    
    ### step 2: get dataset name and ID by projectId
    ok, datasetNameDb = labelToolDbHandler.get_dataset_name(projectId)
    if not ok: return Logger.responseError(0, datasetNameDb)
    ok, datasetIdDb = labelToolDbHandler.get_dataset_id(projectId)
    if not ok: return Logger.responseError(0, datasetNameDb)

    ### Step 3: check if new label class exist and add it into db
    labelToolDbHandler.add_class_name(datasetNameDb, datasetIdDb, className)

    ### Step 4: save image label into db
    ok, message = labelToolDbHandler.cls_save_label(datasetNameDb, imgList)
    if not ok: return Logger.responseError(0, message)

    ### Step 5: delete disappeared class name
    labelToolDbHandler.delete_class_name(datasetIdDb, className)

    ### Step 6: Save dataset labeled as 1 and reset split rate
    labelToolDbHandler.update_value_with_cond('dataset', f'labeled="{labeled}", split={0}', f'project_id="{projectId}"')

    return Logger.responseDebug(1, 'Save classification label success')


@blueprintApp.route('/det-save-img-label', methods=['POST'])
def det_save_img_label():
    """Give datasetName, className, image name and save image label to database

    Returns:
        {"code": 1, "data": null, "message": "Save det img label success"}
    """
    ### Step 1: Get datasetPath, className, imgList
    data = request.get_json()
    projectName, className, imgList, labeled = data["projectName"], data["classList"], data["fileList"], data["isLabel"]
    ### step 1.5: get projectId name by projectName
    projectId = labelToolDbHandler.read_value_with_cond('project', 'project_id', f'project_name="{projectName}"')
    ### step 1: get dataset name and ID by projectId
    ok, datasetNameDb = labelToolDbHandler.get_dataset_name(projectId)
    if not ok: return Logger.responseError(0, datasetNameDb)
    ok, datasetIdDb = labelToolDbHandler.get_dataset_id(projectId)
    if not ok: return Logger.responseError(0, datasetIdDb)
    ### Step 2: check if new label class exist and add it into db
    labelToolDbHandler.add_class_name(datasetNameDb, datasetIdDb, className)

    ### Step 3: save image label into db
    ok, message = labelToolDbHandler.det_save_label(datasetNameDb, imgList)
    if not ok: return Logger.responseError(0, message)

    ### Step 5: delete disappeared class name
    labelToolDbHandler.delete_class_name(datasetIdDb, className)

    ### Step 6: Save dataset labeled as 1 and reset split rate
    labelToolDbHandler.update_value_with_cond('dataset', f'labeled="{labeled}", split={0}', f'project_id="{projectId}"')

    return Logger.responseDebug(1, 'Save detection label success')
