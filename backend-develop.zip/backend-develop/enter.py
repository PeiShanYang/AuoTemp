# -*- coding: utf-8 -*-


from main.MainCls import main as clsMain
from main.MainDet import main as detMain
from main.Entrance import main

clsConfig = './/main//ConfigCls.json'
detConfig = './/main//ConfigDet.json'

from utils.DatabaseResource import processMonitorDb
monitorDbHandler = processMonitorDb.ProcessMonitorDb()



if __name__ == "__main__":
    # clsMain(clsConfig)
    # detMain(detConfig)
    main()

    # monitorDbHandler.save_deployment_result('Inference', 'detection', 'deployment_2023070510362488663986639600', './what')
