import argparse
import os
import json
import main.MainCls as MainCls
import main.MainDet as MainDet

def check_folder_exist(folderPath):
    """check if folder is existed

    Args:
        folderPath (str): folder path

    Raises:
        BaseException: raise error if folder is not existed
    """
    if not os.path.isdir(folderPath):
        raise Exception(f'(TestProcess) folder {folderPath} is not existed')


def modify_config(projectTask, pipelinePath):
    """modify config from train to test
    task, testPath, evaluatedWeight

    Args:
        projectTask (str): project task
        pipelinePath (str): pipeline output path

    Raises:
        BaseException: raise error if file is not existed
    """
    configPath = os.path.join(pipelinePath, 'ConfigCls.json') if projectTask == 'classification' else os.path.join(pipelinePath, 'ConfigDet.json')
    try:
        if not os.path.isfile(configPath):
            raise Exception(f'config json file {configPath} is not existed')
        with open(configPath, 'r+') as f:
            data = json.load(f)
            data["Config"]["basicSettingPara"]["task"] = 'Test'
            data["ConfigPytorchModel"]["pathPara"]["testPath"] = os.path.join(pipelinePath, 'dataset', 'Test')
            data["ConfigPytorchModel"]["pathPara"]["weightPath"]["evaluatedWeight"] = os.path.join(pipelinePath, 'BestDictPth.pth')
            f.seek(0)
            json.dump(data, f, indent=4)
            f.truncate()
        return configPath
    except Exception as err:
        raise Exception('(TestProcess) modify config failed: ', err)


def run_ai_module(task, configFile):
    """run AI module

    Args:
        task (str): classification or detection
        configFile (str): config json file path
    """
    try:
        if task == 'classification':
            MainCls.main(configFile)
        elif task == 'detection':
            MainDet.main(configFile)
    except Exception as err:
        raise Exception('(TestProcess) ai module error: ', err)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-r", "--root", help = "pipeline output root path")
    parser.add_argument("-o", "--outputPath", default='./pipelineOutput', help = "full pipeline output path")
    parser.add_argument("-p", "--pId", help = "pipeline ID")
    parser.add_argument("-t", "--task", help = "project task (classification / detection)")
    parser.add_argument("-k", "--key", help = "experiment key")
    args = parser.parse_args()

    check_folder_exist(args.outputPath)
    configPath = modify_config(args.task, args.outputPath)
    run_ai_module(args.task, configPath)
